# Josh’s Durability-First Training System: Methods Section

## Overview
This methods section specifies a closed-loop, state-driven endurance training framework in which training load is regulated by athlete state rather than by fixed weekly mileage, pace targets, or a precommitted intensity distribution. The framework treats the athlete as a dynamic system whose metabolic, neuromuscular, and structural responses are observed through repeatable process variables, and whose training load is adjusted in response to those signals.[cite:6][cite:9] The practical aim is to regulate adaptation while minimizing hidden fatigue, mechanical deterioration, and structural overload.[cite:6]

## Control objective
The control objective is to keep the athlete near a functional training state in which threshold work can progress without causing prolonged readiness distortion, excessive drift, or cycle-length expansion. Within this framework, successful control is indicated by stable or improving pace at fixed heart rate, clean readiness return after loading, and stable or shortening cycle length across repeated training cycles.[cite:6][cite:9] When those variables drift in the opposite direction, the system interprets that pattern as evidence that load has exceeded current absorptive capacity and responds by reducing threshold exposure, inserting additional easy days, or delaying neural work.[cite:6][cite:9]

## Setpoint and baseline
The system setpoint is defined by four practical targets: a Continuous Effort Baseline (CEB), a target cycle length, a target readiness return time, and stable or improving pace at fixed heart rate under repeatable conditions. CEB is defined operationally as an intensity–duration operating region whose accumulated cost remains effectively negligible for control purposes, nominally centered near 130 bpm, rather than as a single exact heart-rate value.[cite:5][cite:9] In practice, CEB is calibrated by observing whether accumulated work performed near that region continues to behave like effectively free volume, meaning that it does not meaningfully distort drift, recovery demand, readiness, or subsequent cycle length.[cite:5][cite:9]

## Athlete model
The plant in this framework is the athlete’s combined metabolic, neuromuscular, and structural/tissue system. This combined plant is assumed to respond nonlinearly to applied training load and to real-world disturbances such as sleep disruption, life stress, terrain, heat, footwear changes, racing, manual labor, illness, and tissue irritation.[cite:6][cite:9] Because those disturbances can alter internal load for a given external workload, the framework prioritizes internal state markers and return-to-readiness behavior over calendar-based programming alone.[cite:6]

## Process variables
The live control loop monitors actual cycle length, readiness return time, pace at fixed heart rate, drift behavior during Easy and Threshold work, neural readiness quality, and tissue status. Drift behavior is interpreted using repeatable heart-rate and pace relationships, consistent with the broader use of heart-rate drift as a practical marker of aerobic strain and durability during steady work.[cite:9] Neural readiness is assessed through a controlled high-neural probe, a capped stride set, and velocity-based lifting metrics, while tissue status is assessed from movement cleanliness and the presence or absence of irritation, especially in previously vulnerable regions such as the back.[cite:6]

## Error representation
The framework does not require a single scalar error term. Instead, it uses a multidimensional error picture in which positive error is represented by longer cycle length, delayed readiness return, increased drift, slower pace at the same heart rate, degraded neural sharpness, or tissue irritation/protective patterning. This approach is conceptually consistent with autoregulated training models that adapt loading in response to observed readiness and recovery signals rather than rigid preplanned microcycles.[cite:6] The purpose of the error representation is not mathematical elegance but reliable decision-making under noisy real-world conditions.[cite:6]

## Session architecture
Training is organized as a repeating yet flexible sequence consisting of Running Neural, Weights Neural, Easy Run, Threshold, Easy, and Easy sessions. This sequence provides stable structural logic, but the calendar spacing between sessions is allowed to change according to readiness and gating outcomes rather than being forced into a fixed 7-day template.[cite:6] As a result, the cycle is treated as an emergent property of the system rather than a fixed scheduling input.[cite:6]

## Emergent cycle length
Cycle length is interpreted as one of the system’s most informative integrated feedback signals. Early in development, the cycle may extend to 8–10 days or longer because extra Easy days are inserted whenever readiness gates fail or when post-load recovery remains incomplete. As durability improves and readiness returns more rapidly, cycle length can contract naturally toward approximately 6–7 days.[cite:6] Longer cycles are therefore interpreted as information about current system strain rather than as failure of adherence.[cite:6]

## Neural gating
Running Neural exposure is permitted only when neural readiness is confirmed through a controlled high-neural probe and a capped stride set that remain mechanically clean relative to baseline. If either probe indicates degraded readiness, the planned neural session is blocked and replaced by Easy day insertion until readiness returns.[cite:6] The purpose of this gate is to prevent hidden fatigue, deteriorating mechanics, and premature exposure to ceiling-oriented work when the athlete is not prepared to express high-quality neural output.[cite:6]

## Strength gating
Weights Neural exposure is regulated using velocity-based lifting metrics. Load is increased only when bar velocity remains consistent with baseline, grinding is not permitted, and degraded lifting velocity is interpreted as evidence of reduced neural readiness.[cite:6] This creates a separate readiness gate for strength work and aligns resistance training exposure with the same state-driven logic that governs running neural work.[cite:6]

## Easy-day function
Easy days are not treated as the controller itself; they function as the stabilizing layer of the system. Their role is to damp accumulated disturbance, consolidate adaptation, allow the plant to settle, and keep readiness, cycle length, and threshold response interpretable.[cite:5][cite:30] When Easy days are performed too hard, they stop functioning as damping and instead become additional training load, which can blur the distinction between loading and recovery and compromise the quality of harder sessions.[cite:18][cite:20][cite:22]

## Threshold actuator
Threshold work functions as the primary metabolic actuator in the framework. Threshold is defined by internal state rather than by pace, with pace treated as an output that emerges from a given internal load state.[cite:7][cite:10] Initial threshold work begins conservatively at 30 minutes continuous, with threshold heart rate raised gradually across cycles until the effort reaches its highest stable equilibrium just below loss of control.[cite:7][cite:10] After that state is established, progression follows a dual-progression structure: duration is increased in discrete steps, target heart rate is temporarily reduced by approximately 5 bpm, stability is re-established, and heart rate is then built upward again until the new duration reaches its own stable equilibrium.[cite:7][cite:10][cite:13]

## Actuators and progression
The framework uses two actuators. Threshold volume is the primary actuator and main metabolic load driver, while neural exposure is a secondary actuator that remains tightly gated and usually low in structural volume.[cite:6][cite:13] Neural progression is expected to occur primarily through improved quality, speed, and expression rather than through large increases in neural session volume, whereas threshold progression is the main dial adjusted to drive endurance adaptation.[cite:3][cite:13]

## Decision rules
Threshold volume is progressed only when pace at fixed heart rate is stable or improving, readiness returns cleanly, cycle length is stable or shortening, tissue remains quiet, and neural quality remains clean. If these conditions are not met, the system holds or reduces threshold exposure, expands the cycle with additional Easy days, or delays neural work until the athlete returns closer to setpoint.[cite:6][cite:9] In this way, pace is allowed to emerge as a consequence of internal adaptation rather than being forced as a primary control target.[cite:7][cite:9]

## Safety layer
If a neural gate fails, the system defaults to Easy-only mode until the athlete returns near setpoint. This safety layer is intended to protect against rapid accumulation of hidden fatigue and against technical deterioration that may not yet be obvious in slower running or lower-force activities.[cite:6] The loop can tolerate imperfect data, but it cannot function safely if readiness gates are ignored.[cite:6]

## PID-like interpretation
The framework is best interpreted as PID-like rather than as a literal industrial PID implementation. Threshold volume adjustment serves a proportional-like role by responding to current evidence of strain, persistent drift across cycles produces integral-like slowing or reduction of progression, and readiness gates provide derivative-like protection against rapid deterioration in neural coordination or readiness.[cite:6] Easy days are not equivalent to the integral term; they act as passive damping and consolidation within the broader control structure.[cite:30]

## Analytical load model
A separate analytical layer is maintained to describe accumulated stress without directly driving live decisions. In that layer, HR Cost is represented as the sum of \\(HR - 130\\)^2 \\times t / 100 and Neural Cost is represented as the sum of \\N \\times t, where t denotes time and N denotes an assigned neural weighting for a given task. This dual-load model is intended for retrospective interpretation of stress, comparison of cycles and blocks, and future predictive modeling, while the live control loop remains governed by readiness gating, threshold-volume adjustment, emergent cycle length, and Easy-day stabilization.[cite:5][cite:6]

## CEB recalibration
CEB is not assumed to be perfectly known at the outset. Instead, it is treated as a slowly recalibrated baseline parameter that is adjusted only if work near the presumed CEB begins to generate measurable drift, nontrivial recovery demand, readiness distortion, or cycle-length distortion, or if slightly higher work still behaves as effectively free volume.[cite:5][cite:9] This makes CEB a baseline calibration variable rather than a fast-acting control dial.[cite:9]

## Practical implementation
In practical use, the framework seeks to keep the athlete stable, raise the ceiling only when readiness allows, and fill toward that ceiling only when the system can absorb the load without prolonged distortion. The underlying purpose is not to complete preselected workouts at all costs, but to produce durable adaptation while preventing hidden fatigue from stacking into breakdown.[cite:6][cite:9]
