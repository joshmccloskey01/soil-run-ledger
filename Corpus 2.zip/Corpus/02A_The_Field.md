<!-- NORMALIZED COPY. Canonical source: 02_SOURCE/The Field.json. Document ID: FIELD. Sequence: 1. -->

# The Field

**Author:** Josh McCloskey

**Document Type:** Working paper

**First Issued:** Date unknown (prior to July 11, 2026)

**Current Revision:** R2

**Last Revised:** July 11, 2026

**Status:** Active working paper

*The body is the current model, read as it now stands. The complete revision history is at the back.*

*The intuition layer. Read this first. It carries the shape, not the numbers.*

> **Mechanism boundary.** In this framework, a mechanism is a bounded arrangement of interacting components whose organized relationships transform inputs into repeatable outputs under governing constraints. The Field is an intuition layer: structural similarity across soil, biology, training, and computation does not establish that they share the same material mechanism.


**One system.** Plant, soil, rain, sun — one living thing seen from four angles. Same in the body: the tissue that adapts, the capacity that supports it, the load that stresses it, the energy that funds it are all the same system. You don't stand on your capacity. You *are* it.

**Plant adapts, soil supports.**[^1] The plant is stressed, depletes, rebuilds stronger — that's adaptation. The soil doesn't undergo adaptation in the way the plant does. It gradually becomes richer and more capable of supporting a larger, healthier plant. Adaptation belongs to the plant.

**Soil supports — except the part of it that's alive.** The plant/soil split isn't quite clean: soil isn't one thing. There's the passive part — mineral structure, aggregate, depth — that only accumulates or erodes; it doesn't sense a stress and rebuild from it. And there's the living part, the microbiome, which runs its own version of the plant's loop: disturbed, some populations die back, others bloom, and it resettles into a new working composition. That's a second adaptive system nested inside what looked like plain "support" — not the plant's adaptation, someone else's, running on its own faster clock, in service of the plant. The same split exists in the body: the gut microbiome adapts on its own clock, distinct from the tissue clock of whatever it's supporting.

**State can contain nested adaptive systems.** The microbiome is not merely another input to the field. It is part of the field's current state, and because that living state changes in response to what enters the system, it can change how later inputs are processed. The same external input can therefore meet a different internal system on the next pass. That is one reason history matters: retained change inside a nested subsystem can alter the response of the larger system.

**What you add selects, it doesn't just accumulate.** Add organic matter to soil and it isn't inert filler — it's food for a living population, and different food selects different populations. Woody, high-cellulose material favors fungi; fresh green matter favors bacteria. The soil doesn't change because the material is special, it changes because a specific population got fed and grew, at the expense of the population that wasn't. Diet does the same thing to the gut microbiome: different fiber types ferment differently and favor different bacterial species, the way different residues favor fungi over bacteria in soil. The mechanism is real at that level — what you feed a living population determines which part of it thrives. It doesn't, by itself, crown any single input as correct; a soil fed only one narrow type of matter ends up less diverse too, regardless of which direction it's narrowed. The lesson the mechanism actually supports is about variety feeding variety, not about any one input being uniquely best.

**Rain is load, and absorption is rate-limited.** A downpour runs off — too fast to soak in, and it strips the surface. A light rain spread out soaks in completely. Same water, different result. There's a limit on how much productive work you can absorb in a given period. Under the limit, load becomes adaptation. Over it, runoff — cost spent, nothing gained, and past a point, damage.

**Sun is funding, a different axis than rain.** Sun doesn't cancel rain — they're not the same scale. The plant needs both: rain to stress it, sun to fund the rebuild. In the body, metabolic energy and resource delivery is the sun — it funds the resolution that resolving a stress actually costs.

**Water is the medium, not a third axis.** Rain is load. Sun is funding. Those stay separate — but there's something underneath both of them that makes either one actually work: water. In the soil, the nutrients are already there. The richness is already there. But none of it reaches the root without water to carry it. Water doesn't add funding — it's what makes funding *mobile*. Rich soil next to a root, with no water between them, delivers nothing. In the body, blood is the sun — blood is the funding, the thing carrying energy and resource to the tissue that needs to resolve a stress. But blood only works because it's carried in water. Water isn't competing with blood for the job. Water is what lets blood exist and move at all. So water isn't rain, and it isn't sun. It's the medium both of them depend on to reach the plant at all — the carrier underneath the carrier. Same role at two scales: in soil, it moves nutrients to the root. In the body, it moves blood to the tissue.

**Walking does two things, neither is subtraction.** It builds the soil (circulation, tissue, aerobic base — organic material worked into sand). And it keeps energy and resources flowing through the field without meaningfully increasing rain — delivery stays high, load stays near zero, because there's no flight phase. It doesn't erase a hard exposure; it continues funding resolution while adding very little new demand. **Power walking** is the same soil-building worked harder, still feet-down, providing a larger positive signal.

**The Drought Line and the Flood Line.** Drought line = what the field needs just to not wither. Flood line = the maximum absorption limit. Between them is where load becomes growth. Build the soil and both rise — your new drought line becomes what used to be your peak.

**The soil has depth — three layers, three clocks.** Surface reacts now (nervous system). Middle fills over days-weeks (muscle, metabolism). Deep changes over seasons (tendon, bone, structure). The trap: the surface looks soaked while the deep soil is still dry. Performance is silent about the layers that haven't caught up. Same three-layer shape shows up in any adaptive system — fast acts, medium adapts, slow authorizes.

**Where the field ends.** It gives you the shape and the why. It can't give you the how-much — raindrops don't convert to reps. That's what the app is: the soil-management system, making the invisible visible so you manage by data, not hope.

*The field tells you what's happening and why. For how much, you measure.*

---

## Postscript: The Wandering Plant

*Planet* comes from the Greek *planetes* — wanderer. The ancients named them that because, against the fixed backdrop of the stars, these few lights drifted: no fixed place, always somewhere new.

*Plant* comes from the Latin *planta* — a sprout, a cutting, pressed into the ground with the sole of the foot. The word for the thing that stays.

They look like opposites. One never settles. The other never leaves.

But watch a root work, and the opposition gets thinner. A root doesn't drive straight down on a plan — it wanders, feeling through the soil for where the water is, where resistance is lowest, where the last root already broke ground. It doesn't have the map in advance. It finds the map by moving through it: sense, correct, sense again — the same loop the wanderer runs, just slower, and in the dark.

So maybe the plant isn't the fixed thing standing opposite the wanderer. Maybe it's the wanderer that folded its wandering inward — the search didn't stop, it just went underground and got slow enough to look like staying still. The plant is planted, and it is still, in its own way, a wandering plant: reaching root by root toward wherever the next patch of good soil is, the way a planet reaches, degree by degree, toward wherever it's going next.

Same shape as the rest of the field, one more time: adaptation isn't a place you arrive at and hold. It's a wander that's found a rhythm slow enough to be mistaken for rest.

---

[^1]: In a real field, plant and soil are two different things interacting — the soil exists before the seed, and you could remove the plant and the soil would remain. In a body there's no separation: the same tissue is both the adaptive plant and the capacity soil at once. The plant/soil split is a lens for seeing two different functions — adapt-to-survive-now versus develop-to-expand-what's-absorbable-later — not two separable things. In the field they're two things; in you they're one thing doing two jobs.

## Related Work

- **Intuition layer for:** Adaptive Framework — Core — Carries the same boundary, state, input, response, output, retained-change, feedback, and update structure in field form.

- **Related to:** The Computer — The same state-transition shape can be mapped onto a computational system without claiming that a computer and a field are materially identical.

- **Constrained by:** Mechanism Definition — The field is a structural analogy and explanatory lens; it should not be mistaken for a complete causal mechanism in every domain.

- **Applied by:** Weekly Exposure Limit — The app operationalizes the field's load-and-absorption intuition by measuring weighted locomotion exposure rather than relying on the analogy for quantity.

## Open Questions

- Which parts of the field model are true structural correspondences across domains, and which are useful analogy only?

- How should nested adaptive systems such as a soil or gut microbiome be represented without collapsing their boundary into the larger system they influence?

- Which parts of state, load, funding, response, output, and retained change can be measured directly across biological, computational, and engineered systems?

- When does a retained change in a nested subsystem materially alter the response of the larger system to the same later input?

## Revision History

### R1 — Date unknown (prior to July 11, 2026)

- **Field intuition model established**

  - **What Changed:** Established the field as an intuition layer for adaptation: plant, soil, rain, sun, water, drought line, flood line, and layered clocks were used to separate load, funding, support, absorption, and retained capacity.

  - **Forcing Error:** A more intuitive way was needed to see how present state changes the meaning of later inputs without reducing the model to isolated training variables.

  - **Verification:** The model was retained because it repeatedly helped organize distinctions in training and adaptation. It remains an analogy and must not be treated as proof that unlike systems share identical mechanisms.

### R2 — July 11, 2026

- **Microbiome added as a nested adaptive state**

  - **What Changed:** Integrated the soil microbiome and gut microbiome as examples of adaptive subsystems nested inside a larger system. Clarified that the microbiome is part of current state, not merely another input, and that retained change inside it can alter how later inputs are processed.

  - **Forcing Error:** The earlier plant-versus-soil split treated support as too homogeneous. The soil contains both relatively passive structure and living communities that change on their own clocks, creating a nested adaptive system inside the field.

  - **Verification:** The nested-system framing is structurally consistent with the broader state-and-history model. The specific soil-to-gut comparison remains a cross-domain analogy and should be tested without assuming identical biological mechanisms.

- **Converted to structured working-paper JSON**

  - **What Changed:** Converted the current Markdown paper into the standard working-paper JSON schema with metadata, typed body blocks, related work, open questions, and revision history.

  - **Forcing Error:** The paper needed the same persistent, machine-readable revision structure used by the broader knowledge system.

  - **Verification:** The JSON is syntactically valid and preserves the full current body of the Markdown paper.
