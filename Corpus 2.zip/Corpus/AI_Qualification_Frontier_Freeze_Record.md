# AI Learning / Qualification Frontier — Freeze Record

**Date frozen:** 2026-08-10
**Status:** UNPROPOSED — UNDER AUDIT
**Purpose:** Preserve state so this thread can be resumed without reconstructing the conversation. Not a proposal, not a specification, not an implementation plan.

**Status marks used below:** `[PROPOSED]` design produced during audit, not validated · `[SOURCE]` established in cited external material · `[SYNTHESIS]` inference made during this work, not sourced · `[OPEN]` unresolved · `[IMPLEMENTED]` exists in code today.

---

## 1. Core object

The smallest surviving idea `[PROPOSED]`:

A model checkpoint is held fixed while a bounded block of generative probes is run against it. Each probe belongs to an authored probe family carrying an independently derivable preservation or alteration relation. Before observation, the expected relation between probe and response is sealed. Results accumulate; the checkpoint does not change during the block. At block termination, failures may become training material. Training produces a **candidate** checkpoint, not an authoritative one. The candidate must be requalified before authority transfers.

**Naming.** This is not called Base/Edge. Its relationship to Base/Edge is historical (it arose from that thread) rather than established. The term **edge** additionally carries an unresolved three-way collision flagged as a standing violation in the Corpus Governance Contract; importing it here would propagate that collision.

---

## 2. Regime identity `[PROPOSED]`

The model checkpoint is part of regime identity.

Candidate digest concept:

```
regime_digest = hash(checkpoint_id,
                     probe_family_spec_version,
                     seal_schema_version,
                     admissibility_criterion)
```

**Do not modify the ledger envelope to add this.** `schema_version` derives from genesis chain constants; an envelope field means a new genesis with no migration path. Current direction is to record regime identity in event `body` and validate it through a future Regime Identity Contract, preserving the existing write path.

Regime status is three-valued:

- **authoritative**
- **candidate**
- **abandoned**

Requalification evidence belongs to the candidate regime — not to the prior authoritative regime (the model changed) and not to the next authoritative regime (that regime is created by the promotion decision the evidence feeds). Promotion is an explicit authority transition, candidate → authoritative. Abandoned candidates remain historical ledger objects.

All of the above is proposed design. None of it is implemented.

---

## 3. Block semantics `[PROPOSED]`

1. Freeze authoritative regime R_n.
2. Run a bounded probe block.
3. Seal predictions before observations.
4. Evaluate under the existing blindness/authority rules.
5. Do not update the model during the block.
6. Terminate on the existing degradation/termination conditions rather than running indefinitely.
7. At block close, failures may be used as training material.
8. Training produces a candidate checkpoint.
9. Candidate is requalified.
10. Promotion requires an explicit authorized transition.
11. Failure leaves the prior authoritative checkpoint authoritative.

Unattended operation, if ever allowed, is meaningful only at **block** granularity. It is not an endless self-modifying per-probe loop. Termination is a designed detector in Field Loop v4, not a failure of the run.

---

## 4. Probe-family requirement

**Currently the main intellectual bottleneck.**

A valid family must be **generative**, not a curated finite test set. Each family must specify:

- transformation / generation rule
- independently derivable preservation or alteration relation
- validity domain
- expected response relation
- whether its observable is graded or cliff-only
- conditions under which the family stops carrying authority

Fresh instances must be generatable for requalification. The generator must not depend on per-item adjudicator outcomes. Family-level clearance may be visible under future policy; per-item failure adaptation by the probe generator is **not** currently authorized.

**Preserved falsifier:**

> If preservation/alteration cannot be derived independently, the system has a patch pipeline rather than a qualification instrument.

Note on dependency: generativity is not only what stops training-on-the-probe from destroying the instrument. It is also the property that makes gate rotation, distributional baselines, and leak resistance available at all. Several other items collapse without it. `[SYNTHESIS]`

---

## 5. Behavioral claim ceiling

**Permanent. Do not upgrade.**

Black-box behavioral testing establishes only extensional competence over tested transformations. It cannot establish that the model internally represents the "true relation," learned a causal graph, discovered the most compact rule, abandoned all shortcuts, or reasons in any particular internal representation. Because the pass criterion is extensional, behavioral success can never adjudicate an intensional claim about representation — this is a structural ceiling, not a current limitation.

Strongest admissible form:

> Competence survived the tested transformation/relation family under the stated conditions.

---

## 6. Relevant evaluation prior art `[SOURCE]`

- Metamorphic testing (software testing literature; Segura et al. 2016 survey)
- CheckList INV/DIR-style testing (Ribeiro et al., ACL 2020), explicitly derived from metamorphic testing
- Representation-preserving transformations
- Structural-sensitivity / minimal-contrast tests

The useful experimental pair:

- representation changes while relevant structure is preserved
- representation remains similar while relevant structure changes

These must be **jointly** interpreted. Invariance alone is scored perfectly by constant output; sensitivity alone is scored perfectly by always-different output. Only the joint carries signal.

**No novelty claim.** This testing structure is published prior art.

---

## 7. Requalification gate `[PROPOSED]`

For every previously cleared family, the regression baseline is fixed at that family's **first authoritative clearance**. Do not compare only against R_{n-1}; per-block tolerances compound invisibly.

If complete historical requalification becomes too expensive and sampling is used, retention becomes a statistical claim and must be labelled as one. The future gate spec must state:

- sampling procedure
- minimum detectable regression (required: "no regression" is a null hypothesis and cannot be powered without a named effect size)
- confidence/power or equivalent statistical warrant, with multiplicity handling across families
- admissibility threshold

**Composition is OUT OF SCOPE.** Clearing family A and family B does not clear A∘B. The resulting product must not be described as compositional competence — including externally. Single-transformation robustness described in general-robustness language is the failure the scoping exists to prevent.

---

## 8. Retry / gate contamination `[OPEN]`

If failed candidate diagnostics are used to generate another candidate, candidate generation is adapting to the qualification gate, and the gate has become part of the optimizer.

Keeping detailed diagnostics hidden is **necessary but not sufficient**. Binary pass/fail outcomes leak information across attempts and across blocks; n blocks against a fixed instrument is n adaptive decisions against it.

Candidate possibilities already established in source material, recorded without selection among them:

- strict gate — failed-candidate information does not reach retraining
- two-gate — an inner development gate may inform retries; a separate held-out promotion gate is never exposed
- refreshed / rotated / hidden-family-sampled promotion instrument (available only if §4 generativity holds)

**Not resolved here.**

---

## 9. Goodhart constraint

**Corrected rule:**

> A metric is usable only inside a stated validity domain, and the system needs something that reports when that validity domain has been left.

**Correction logged.** The earlier formulation conditioned Goodhart on the optimizer and cost-bearer being different parties. That condition holds for adversarial Goodhart only; regressional, extremal, and causal Goodhart are single-agent proxy failures (Manheim & Garrabrant, *Categorizing Variants of Goodhart's Law*, arXiv:1803.04585). `[SOURCE]` The mode most relevant here is **extremal**: a measure valid inside its calibrated region stops tracking the intended property once optimization pushes the system outside that region.

The goal of choosing optimization targets aligned with safety/stability rather than superficial outcome maximization stands. **Aligned incentives do not eliminate Goodhart effects.** A safety/stability metric can itself become a bad proxy outside its validity range.

Two separate instrument properties — do not let one clause cover both:

- **Censoring / bound coverage:** can the instrument record values beyond its normal operating region?
- **Resolution / margin:** can it indicate distance from the boundary, rather than only PASS/FAIL?

A binary gate can satisfy the first and still fail the second.

Possible defenses against proxy failure outside known regions: instruments on different clocks, external anchors, uncensored scales, graded margins. These are partial. They do not solve all such failures.

---

## 10. Graded-margin gap `[OPEN]`

Flutter clearance has a graded precursor — modal damping trending toward zero — and the literature supplements it (Zimmerman–Weissenburger flutter margin) precisely because damping alone is fallible under hard flutter and the transonic dip. `[SOURCE]`

The current qualification concept may have only pass/fail family clearance. If so it functions as a **cliff detector**, not an early-warning instrument, and is worse positioned than the case that already required supplementing.

**No universal graded metric is invented here.** Each probe family must declare whether a justified graded observable exists. Cliff families require a stated consequence (e.g. more samples, no interpolation to neighbours, no block enlargement) or the declaration is decorative.

---

## 11. Silent permissiveness `[OPEN]` — stated limitation

In biological training, an overly permissive decision may eventually produce a physical consequence that reveals the error. At AI block cadence there may be no equivalent correcting force. A promotion gate can drift permissive while candidates continue passing and every individual decision remains internally valid.

Note the direction inverts between domains: in training, the *over-conservative* direction is the silent one; in promotion, the *over-permissive* direction is. A guard designed by analogy to the training case would point the wrong way.

Note also that held-out families, untouched baselines, and second suites are **independent**, not **external** — authored by the same process, run by the same system, and not surviving a shared authoring error. Genuinely external candidates (human judgment on sampled outputs; real downstream task consequence) are not present at block cadence.

**No demonstrated complete solution.** This sits with the conceded costs, not the solvable items.

---

## 12. Control-theory / aerospace references

### Dual control

Dual control establishes that a single action can simultaneously regulate a system and alter information about it (Feldbaum 1960–61; dual effect formalized by Bar-Shalom & Tse 1974). `[SOURCE]`

**Do not import "dual control" as the name of this architecture.** The literature's own terminology audit records that the term has drifted to cover both the exact optimum and crude heuristic probing — the same collision pattern the invariant-name rule rejects.

Standard dual-control formulations do not automatically encode catastrophic irreversibility; irreversibility/safety is usually not in the cost. `[SOURCE]`

**Provenance correction logged.** The stronger claim — that aerospace *rejects* joint optimization *because* the boundary is catastrophic and irreversible — is tagged `[SYNTHESIS]` in the flutter report. It is the report's own inference, not aerospace literature about its own reasoning. It was briefly treated as sourced during this session; it is not. Status: supported by analogy, not established.

### Flutter / flight-envelope expansion `[SOURCE]`

Useful established structure: controlled test condition → bounded excitation → prediction → measured response → model comparison/update → explicit clearance decision → retreat/abort logic → expansion only within warranted territory.

**Correction logged.** The aircraft plant is not literally static. Fuel/mass/CG state moves the flutter boundary (X-56A: body-freedom flutter ~111 kn at low fuel/forward CG, ~114 kn at higher fuel). Engineers hold mass state as part of the test condition and report both onsets rather than one. This is the concrete precedent for checkpoint-as-regime. An earlier claim in this session that the plant is fixed was wrong; the correct distinction is exogenous plant drift versus probe-caused plant change.

**Governance precedent:** model update, limit change, and authorization of the next test point are three separate signed decisions with different owners. A favorable model update must not silently authorize a larger step.

**Authority precedent:** interpolation inside cleared territory and extrapolation beyond it are different authorities. Interpolation is licensed by a smoothness assumption; extrapolation is forbidden where that assumption fails.

**Trust region:** structural analogy only. Not an identity. A rejected trust-region step is free on a static landscape; a rejected probe has already changed the system it was preserving.

---

## 13. Existing ledger constraints `[IMPLEMENTED]`

- append-only event history
- authority through committed events
- prediction/seal before observation
- blind adjudication structure where already specified (Field Loop v4: the proposer never sees adjudicator output or rejection history — structural, not a rule)
- termination/degradation semantics from Field Loop v4
- the core guarantees **occurrence and order**, not automatic cross-regime comparability

**The Regime Identity Contract does not exist.** It is specified nowhere in code. Regime status is derived state, and `reconstruct.py` is on the removed list, so nothing currently reads it.

---

## 14. Candidate build objects

**A — Authoritative regime reader.** Derived-state reader answering: *which regime/checkpoint is authoritative now?* Required because status is derived and no reader exists.

**B — Generative probe-family specification.** The family contract in §4.

**C — Requalification gate specification.** Baseline, regression detection, statistical warrant, scope, and promotion/abandonment semantics.

These are candidate build objects identified during audit. **Their order and design are not validated merely because they were produced in this session.**

One observation worth carrying: across successive revisions in this session, the blocker list was repeatedly consolidated, and each consolidation shed an implementation-blocking clause while becoming more conceptually clean (the reader dropped out of the regime item; the derivable-relation requirement was displaced by validity domain). On resume, check the list against this document rather than against the most recent summary of it.

---

## 15. Open items

- retry/gate leakage across attempts and blocks
- graded precursor availability per probe family
- silent permissiveness / independent external anchor
- statistical requalification cost at large family count
- exact regime-status transition contract
- whether useful generative families with independently derivable relations exist at sufficient breadth

**Not solved here.**

---

## 16. Final status

**STATUS: UNPROPOSED — UNDER AUDIT**

**What exists:** a candidate architecture assembled from existing ledger governance, prediction/seal/evaluation machinery, generative metamorphic-style probes, candidate checkpoint requalification, and conservative envelope-expansion ideas.

**What does not exist:** demonstrated learning advantage, validated general-intelligence mechanism, autonomous frontier discovery, proven protection against gate Goodharting, or an implemented regime/requalification layer.

**Primary falsifier:** if broad useful probe families cannot be generated with independently derivable preservation/alteration relations, the architecture collapses toward ordinary patch-driven training.

**Next action:** none. Preserve the state and stop exploration until deliberately reopened.
