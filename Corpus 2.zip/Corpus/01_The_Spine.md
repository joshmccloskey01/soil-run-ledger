# The Spine

1. **Organization is coordinated motion.**

2. **Reality is the final judge.**

3. **State is the condition of the system that determines what can happen next. Observation is partial evidence of that state.**

4. **A boundary identifies the system whose state is being tracked. It determines what belongs to the system, what crosses it, and where consequence is accounted for. Within that boundary, a stable pattern of coordination can be described as a mechanism.**

5. **State history is the record of how the system’s state changes through time. It reveals consequences that no single observation can show.**
