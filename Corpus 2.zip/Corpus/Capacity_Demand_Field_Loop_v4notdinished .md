# Capacity–Demand Field Loop

**Version:** v4
**Status:** Frozen.

**One agent. Deterministic harness. Separation by context partition and write authority.**

> One agent may perform every reasoning role, but no single call may propose, defend, adjudicate, and commit the same claim.

"Agent" describes the stateful reason–act–observe cycle, not a count of model instances. The same model and the same agent identity run every stage. The separation is created entirely by what the harness withholds and what it permits to be written.

---

## 0. Two loops, not one

The critique loop and the training loop share the Common Analysis Stage and diverge after it. Welding them together produces a Review mode with nothing to execute and nothing to predict.

| | **Review** | **Act** |
|---|---|---|
| Question | does the record hold? | what is the next action? |
| Back half | closure → adjudicate → retreat check | seal → execute → evaluate |
| Output | findings, or none | one authorized action + consequence |
| Predicts | nothing | everything |

**Fast** is a third mode: a single admissible answer, no execution change, no defect generation.

Downgrade is free. **Upgrade is mandatory** the moment a contradiction or defect claim appears.

---

## 1. Common Analysis Stage

Both branches reconstruct the same state before diverging.

### Call 1 — Analyze *(agent)*

**Context:** authoritative record(s), current state version.

- Bound the system: system, objective, horizon, environment, out of scope.
- Tag every statement: `DECLARED` · `EVIDENCED` · `INFERRED` · `HYPOTHESIS` · `UNRESOLVED`
- Declare each ledger with capacity, demand, estimator, unit, uncertainty, failure mode. **Do not combine unlike ledgers.**
- Test the boundary for hidden splits: muscle/tendon/bone · magnitude/rate/duration/frequency · skill/structure · maintenance/performance · entry gate/standing control.
- Locate the gradient per ledger: `reserve` · `matched` · `overload` · `approaching cliff` · `undefined`
- Name the **limiting ledger** and every **unreadable ledger**.

**Boundary changed** → harness opens a new state version and re-runs Call 1.

**Record conflict.** If two authoritative records disagree, the run halts with `RECORD_CONFLICT`, reporting both passages and attempting no reconciliation — precedence is an authoring decision, not an agent one. If Step 0 declared precedence, it applies and the conflict is logged rather than halting.

### Call 2 — Propose *(agent)*

**Context:** record, state. **Never adjudicator output. Never rejection history.**

The proposer cannot adapt its wording to a judge it cannot see. This is structural, not a rule.

**Act mode** — one action, changing one declared variable, producing a readable result.

Rejected if it:
- adds specification without changing execution;
- moves several variables at once;
- relies on an unmeasurable success condition;
- exceeds the current action envelope.

**Review mode** — up to **three** candidate findings, ranked, each carrying a neutral capability question `X`: a question about what the record *does*, never one containing its own answer.

**Everything below the cut is discarded. Findings are never queued across passes.** Queueing is what creates serial retreat.

---

## 2. Act branch

### Call 3 — Seal *(agent, harness-locked)*

Recorded before execution, immutable after, attached to the current state version:

- expected evidence;
- expected state movement;
- what result would count against the prediction;
- what would trigger re-entry to an earlier call.

### Execute and observe

Record: action actually taken · raw observation · consequence · recovery · state change · provenance of every new claim.

### Call 4 — Evaluate *(agent, fresh context)*

**Context:** sealed prediction, raw observation, authoritative record, current state version. **Never the proposal or the reasoning that produced the action.**

This is the mirror of Call 3R's blindness. An evaluator that sees the argument for an action will find the observation supports it.

**Verdicts:**

| Verdict | Meaning |
|---|---|
| `CONFIRMED` | observation matches the seal |
| `PARTIALLY_CONFIRMED` | some expected movement, some not |
| `DISCONFIRMED` | the disconfirming result occurred |
| `INDETERMINATE` | the seal was unmeasurable against what happened |
| `BOUNDARY_INVALIDATED` | the observation invalidates the boundary itself |

**Output only:** observed evidence · comparison against expected evidence · supported state movement · unsupported state movement · required re-entry point · proposed authorized delta.

The harness commits only the schema-valid delta returned by Call 4.

**`INDETERMINATE` is not a null result.** It is a defect in the seal, not in the action. It is logged against the seal and counts toward the same run-degradation limit as `SERIAL_RETREAT`. Repeated unmeasurable predictions terminate the run.

**`BOUNDARY_INVALIDATED`** forces re-entry to Call 1 *and* triggers the parent-version recheck: every defect closed under the old boundary gets one cheap pass.

---

## 3. Review branch

### Call 3R — Closure *(agent, fresh context, batched)*

**Context:** record and the `X` list only. **No defect framing. No advocacy. No knowledge that defects exist.**

> *Does the authoritative record handle each of these? Return the strongest supporting passages and any unresolved remainder.*

Batching preserves blindness — several neutral questions read no differently from one.

The harness rejects a loaded `X` and returns to Call 2. A question phrased by someone who already believes it is a defect carries the answer inside it, and blindness becomes nominal.

Inside Call 3R:

1. Receive the neutral capability question `X`.
2. Search the full record.
3. Re-read the relevant surrounding sections.
4. Return the strongest record-supported handling.
5. Return any unresolved remainder.

**Held by the harness, outside Call 3R:** the suspected defect and the definition of what would close it. Both are supplied to Call 4R, never to the closure call — otherwise the blindness is nominal.

**Burden of proof sits on the gap, not on the closure.**

### Call 4R — Adjudicate *(agent)*

**Context:** candidate findings, closure results, record, **full rejection history for this run**, prior state versions.

| Verdict | Action |
|---|---|
| `CLOSED` | discard; log against this state version |
| `PARTIALLY_CLOSED` | report the residual only, never the original claim |
| `OPEN` | report as a defect, with effect on execution |
| `DESIGN_QUESTION` | report as a question to the author; exempt from the execution-effect clause |
| `SERIAL_RETREAT` | suppress; increment the run counter |

**Silence rule.** Record silent + author reachable → `DESIGN_QUESTION`, not `OPEN`. A record gap is not a design gap. Ask whether it is handled and unwritten, or unhandled, and let the answer classify it.

**Retreat test.** *Does this rely on material evidence or an execution failure that was unavailable when the previous related defect was rejected?* If no → `SERIAL_RETREAT`. A closed gap stays closed unless new evidence reopens it.

**Ambiguous closure resolves `CLOSED`.**

---

## 4. Commit — harness only, no model

Schema-valid authorized deltas appended as a new state version. Never overwrites.

---

## 5. Fast mode

**One call:** a merged Call 1 + Call 2. Tools off. Hard token ceiling. Defect generation disabled. No closure, no seal, no evaluation, no commit. Output is one paragraph.

Any contradiction or defect claim triggers automatic upgrade to Review or Act, and the fast output is discarded.

The fast path exists because a protocol too expensive to run gets skipped, and a skipped protocol changes no execution at all.

---

## 6. Harness responsibilities

**Context partition.** The security model lives here, not in the agent — same weights every call, so only withholding creates separation.

**Prediction seal.** Immutable, version-attached.

**Re-adjudication on boundary change.** Every defect `CLOSED` under the parent version gets one cheap recheck: does the closure still hold under the new boundary?

**Run termination.** Two `SERIAL_RETREAT` verdicts, or repeated `INDETERMINATE`, ends the run. Degradation is a property of the pass, not of any single finding.

**Budget enforcement.** By ceiling, not by instruction.

**Leak test.** Dump every call's context and assert: the closure call contains no defect framing; the propose call contains no adjudicator output; the evaluate call contains no proposal reasoning.

---

## 7. State version

```
state_version
parent_version
boundary definition
ledger set
active constraints
gate states
unresolved items
authorized action envelope
provenance map
sealed prediction
reason for re-entry
defects closed under this version
```

Versioning exists so a later review can ask whether a finding was already resolved under an earlier boundary.

---

## 8. Where separate agents earn their cost

Not role separation — that is context partitioning, and multiplying agents to achieve it buys nothing. Three cases only:

- **Disjoint inputs, run in parallel.** One per ledger; one per document across a corpus. They do not need to see each other.
- **A different model for closure.** Fresh context removes the advocacy but not the disposition — the same model often reconstructs the same reading that produced the defect. A different model is the only blindness that adds an independent reader rather than a cleaner one.
- **Persistent specialization.** Retrieval holding indexes and search history that would otherwise bloat every reasoning call.

> **Test:** separate agents when the *inputs* differ or the *model* differs. Same model, same inputs, different job is a stage, not an agent.

---

## 9. Re-entry and stop

**Re-enter to:**

| Trigger | Return to |
|---|---|
| boundary changed | Call 1 |
| capacity or demand misdefined | Call 1 |
| action inadmissible, or `X` loaded | Call 2 |
| new apparent gap | Call 3R |
| `BOUNDARY_INVALIDATED` | Call 1 + parent recheck |

**Stop when:**

- the question is answered;
- the next action is authorized;
- no unresolved residual remains;
- `RECORD_CONFLICT`;
- an authority boundary is reached;
- budget exhausted;
- two `SERIAL_RETREAT` verdicts;
- repeated `INDETERMINATE`;
- no progress is occurring.

---

## 10. Output contract

No **defect** reports without:

- provenance;
- exact supporting text or observation;
- closure search result;
- surviving residual;
- **effect on execution.**

**Design questions** carry provenance, supporting text, and closure result — but not effect on execution, since none exists yet.

If nothing survives:

> *No unresolved defect remains after full-record closure review.*

---

## Core loop

> Route → load versioned state → bound → tag provenance → separate ledgers → locate the gradient → propose one action or up to three findings → **Act:** seal, execute, evaluate blind against the seal — **Review:** blind closure, adjudicate against history, suppress serial retreat → commit authorized delta → re-enter or stop.

## Governing symmetry

- **Review claims** must survive blind closure and adjudication against the full rejection history.
- **Act results** must survive blind evaluation against an immutable sealed prediction.
- **Neither proposals nor the reasoning that produced them can authorize their own state movement.**
