# Exact Pictures in Linear Algebra

Which representations preserve the structure of a linear-algebraic object, which assert structure it does not have, and where the faithful representation is a calculation.

---

## 0. Representation criterion

> **A representation is admissible only insofar as it preserves the relationships relevant to the question, without asserting structure the underlying object does not warrant.**

Everything below is a consequence of this rule.

The question is therefore not *how do I visualize high dimensions*, and not primarily *how should this be taught*. It is: **what representation preserves the structure relevant to the question?**

The thesis that follows:

$$\boxed{\text{Linear algebra does not lose representation beyond three dimensions. What changes is which representation is faithful.}}$$

**The failure mode has one name.** Coordinate slices, the cross product, "axis of rotation," rotate-stretch-rotate, exact rank in floating point — each preserves structure that is not there in general. That is **representational inflation**: the representation claims more than the object contains. It is the same defect throughout, and the sections below are instances rather than separate cautions.

---

## 1. The break at three is in the eyes

$\mathbb{R}^2$ and $\mathbb{R}^3$ are not spatial. They are *drawable*. That is a fact about human vision, not about the mathematics. The vector space axioms never mention $n$, and no proof about $\mathbb{R}^n$ uses a picture.

Teaching that presents two and three dimensions geometrically and everything above them algebraically encodes an accident of perception as a property of the subject.


## 2. Geometry is the dot product

Every geometric word in linear algebra has an algebraic definition, and none of the definitions know what $n$ is.

| Word | Definition |
|---|---|
| length | $\lvert u\rvert = \sqrt{u\cdot u}$ |
| angle | $\cos\theta = \dfrac{u\cdot v}{\lvert u\rvert\,\lvert v\rvert}$ |
| perpendicular | $u\cdot v = 0$ |

Cauchy–Schwarz guarantees the cosine lands in $[-1,1]$ for every $n$. So two vectors in $\mathbb{R}^{100}$ meet at a definite angle. That is geometry — computed rather than seen.

## 3. Where the $\mathbb{R}^3$ picture actively lies

Some of what is learned in three dimensions is a low-dimensional accident, not a general fact:

- **The cross product** exists only in $\mathbb{R}^3$ (and $\mathbb{R}^7$). It is not a general operation.
- **"Axis of rotation"** is 3D-only. In $\mathbb{R}^n$ rotations act on 2-planes; in $\mathbb{R}^4$ a rotation can have two independent rotation planes and no fixed axis at all.
- **Random vectors are nearly orthogonal** in high dimensions, almost always. Nothing in $\mathbb{R}^3$ prepares for this.

## 4. The span rule

> **Don't picture the ambient space. Picture the span of the objects actually in the problem.**

Two vectors in $\mathbb{R}^{100}$: their angle, projection, distance, orthogonality, and Gram–Schmidt step all happen inside $\operatorname{span}\{u,v\}$, which has dimension at most 2. Drawing that plane is not a metaphor or a shadow. It is the actual subspace containing the problem, and the drawing is exact.

Three vectors live in a subspace of dimension at most 3. Higher-dimensional geometry is needed only when the problem genuinely involves more independent directions than can be drawn.

$$\boxed{\text{ambient dimension may be huge; local span dimension may be tiny}}$$

### 4.1 Why coordinate slices are the wrong general picture

Freezing coordinates to view a 3D slice privileges whichever axes were chosen. In $\mathbb{R}^4$ the plane spanned by $(1,1,0,0)$ and $(0,0,1,1)$ is an ordinary 2-dimensional subspace that no coordinate slice reveals — every slice cuts across it. Slicing presents $\mathbb{R}^n$ as a product of $n$ lines, which is a fact about the coordinate system rather than the space, and it hides exactly what is basis-independent.

Slices are the right picture for something else: fixing all variables but one is a partial derivative. Correct tool for multivariable calculus, wrong tool for subspaces.

## 5. Where the span rule breaks: maps

If $x \in \operatorname{span}\{u,v\}$, then $Ax$ generally is not. A linear map sends that plane to a different plane, so picturing what $A$ *does* requires $\operatorname{span}\{u, v, Au, Av\}$ — up to four dimensions in that example.

The rule holds cleanly for relations among vectors. It stops the moment a matrix acts.

## 6. Invariant subspaces are the geometric prize

$$A(U) \subseteq U$$

Inside an invariant subspace the transformation stays in something drawable. An eigenvector is the one-dimensional case: $Av = \lambda v$ means the line is invariant and the action on it is pure scaling, possibly with sign reversal.

This is what the eigenvalue problem is actually asking — not a determinant exercise, but a search for directions in which the map is dimension-preserving.

**Not every map decomposes.** Over $\mathbb{R}$, a rotation in a plane has no real eigenvector, though the 2-plane itself is invariant. And some maps do not split at all: $\begin{bmatrix}0&1\\0&0\end{bmatrix}$ has only one invariant line and no invariant complement. Its finest description is a Jordan block, where the action inside a piece is scaling **plus** a nilpotent slide.

So the general goal is not *find eigenvectors so everything is drawable*. It is:

> **Find the smallest invariant subspaces in which the transformation becomes simple.**

## 7. Symmetric first

$$A = Q\Lambda Q^{T}, \qquad Q \text{ orthogonal}, \quad \Lambda \text{ diagonal}$$

A symmetric matrix always has an orthonormal eigenbasis and real eigenvalues. No missing eigenvectors, no complex pairs, no Jordan slide. Every geometric picture is exactly true.

The transformation is: change to an orthonormal eigenbasis, scale independently along perpendicular directions, change back.

**Wording caveat.** $Q$ orthogonal means $\det Q = \pm 1$ — rotation *or* reflection. And $\Lambda$ may carry negative entries, so the middle step is scaling with possible flips. The picture is exact; "rotate, stretch, rotate" is looser than the mathematics.

**Learning order.** Spectral theorem first, then general matrices as *what breaks when symmetry is removed*: eigenvectors stop being orthogonal, real eigenvectors go missing, eigenspaces come up short. Each failure has a picture attached because the intact case is known. Determinant-and-characteristic-polynomial first makes eigenvalues look like a computation whose purpose arrives later.

## 8. The symmetric case is the reduction engine

$A^{T}A$ is symmetric and positive semidefinite for **any** $A$ — rectangular, non-symmetric, non-normal, non-diagonalizable. So it gets the full spectral theorem regardless.

$$A^{T}A = V\Sigma^{2}V^{T} \quad\Longrightarrow\quad A = U\Sigma V^{T}$$

Every linear map is therefore: orthogonal change of input coordinates → nonnegative axis scaling → orthogonal change of output coordinates.

The clean case is not a special case left behind. It is the machine the messy cases are routed through.

## 9. The deep split

**Eigen-decomposition presupposes one space.** For rectangular $A:\mathbb{R}^n\to\mathbb{R}^m$ with $m \neq n$, the equation $Av = \lambda v$ is not merely unsatisfiable — it is not type-correct. $Av \in \mathbb{R}^m$ while $v \in \mathbb{R}^n$. The eigenproblem assumes an endomorphism $A: V \to V$. SVD allows $A: V \to W$ and chooses an orthonormal basis in each independently.

**The two decompositions preserve different things.**

- Similarity, $B = P^{-1}AP$: same operator, different basis in the same space. Preserves eigenvalues.
- Left–right *orthogonal* equivalence, $A \mapsto U^{T}AV$: preserves singular values. The orthogonality is essential — arbitrary invertible left/right changes preserve rank but destroy singular values, because only orthogonal changes preserve lengths and angles.

**They answer different questions.**

$$\text{eigenstructure} \longrightarrow A, A^2, A^3, \ldots \qquad\qquad \text{singular structure} \longrightarrow x \mapsto Ax$$

Repeated application is governed by the spectral radius; a single application is bounded by $\sigma_{\max} = \max_{x\neq 0} \lVert Ax\rVert / \lVert x\rVert$.

For a non-normal matrix these come apart hard: $\rho(A) < 1$ so $A^k \to 0$, while $\sigma_{\max}(A) \gg 1$. One application amplifies enormously even though repeated application eventually kills everything. **Transient growth under an asymptotically stable map** is exactly where eigenvalue intuition alone fails, and non-normality is the gap between the two decompositions.

> Eigenvalues ask how a map acts repeatedly on the same state space. Singular values ask how strongly a map transfers one direction from an input space into an output space.

That is more fundamental than "eigenvalues for square, SVD for rectangular."

## 10. Rank

For a consistent system in $n$ unknowns:

$$\dim(\text{solution set}) = n - \operatorname{rank}(A)$$

Only **independent** constraints reduce dimension. A second equation that is a multiple of the first removes nothing. This is why a square singular system is not "overdetermined" or "underdetermined" — those describe the shape of a system, not its rank. The real dichotomy is about $b$: if the columns are dependent, either $b$ lies in the column space and there are infinitely many solutions, or it does not and there are none.

$\operatorname{rank}(A) = \#\{\sigma_i \neq 0\}$ is an exact characterization. But exact rank is **discontinuous** — an arbitrarily small perturbation turns a zero singular value nonzero. What SVD provides is better than pretending otherwise: the full spectrum $\sigma_1 \ge \sigma_2 \ge \cdots$, so a meaningful gap is visible and numerical rank can be defined relative to tolerance. The smallest singular values measure how close $A$ is to rank deficiency, and Eckart–Young makes this geometric: truncating them gives the nearest lower-rank approximation.

## 11. The hierarchy, derived

Applying §0 to each kind of question. The right column is not a list of tricks — it is what the criterion returns when asked which representation preserves the structure in play.

| Question is about | Structure that must be preserved | Faithful representation |
|---|---|---|
| relations among a few vectors | lengths and angles among them | their exact span — literally true |
| a map acting on them | where those directions go | span of inputs and images |
| a map with an invariant subspace | closure under the map | the subspace alone |
| a diagonalizable map | independent scaling directions | invariant eigenvector lines |
| a real rotation / complex pair | rotation without a fixed axis | invariant 2-planes |
| a non-diagonalizable map | coupling between directions | Jordan blocks — the nilpotent slide is the structure |
| a symmetric map | orthogonality *and* scaling together | orthonormal eigenbasis — best case |
| any linear map at all | transfer from an input space to a distinct output space | SVD: orthogonal → scale → orthogonal |
| coordinate dependence | the chosen coordinates themselves | slices — here the basis *is* the question |
| global volume and probability | counting facts about the whole space | **calculation** |

Two rows are worth reading closely.

**Slices appear as faithful here** and were rejected in §4.1. No contradiction: the criterion is question-relative. When the basis is the object of interest — partial derivatives, coordinate sensitivity — a slice preserves exactly what matters. When the question is basis-independent, the same slice asserts a product-of-lines structure the space does not have.

**Calculation is not a fallback.** Concentration of measure — nearly all the volume of a high-dimensional ball near its surface, random vectors nearly orthogonal — consists of counting facts about the whole space, not relations inside a low-dimensional span. No low-dimensional geometry can preserve them, so under §0 the calculation *is* the faithful representation. Intuition from any drawable dimension predicts these backwards, which is inflation again: a picture asserting structure the object does not have.

## 12. Where the transfer stops

Two things are worth carrying out of linear algebra into state-machine work, and one is not.

**Carries, conditionally:** dimension as the number of independent directions of variation. *If* the relevant ledgers can vary independently, then a scalar state description is insufficient and state requires multiple degrees of freedom. That antecedent is a domain claim — asserted in the biological fundamental, not supplied by linear algebra. What linear algebra supplies is the meaning of *dimension*: a statement about a state space, not about linear structure on it.

**Does not carry:** superposition. In $S_t + I_t \to S_{t+1}$ the plus sign is not vector addition — state and input need not even live in the same space. The honest notation is $F(S_t, I_t) = S_{t+1}$.

What follows from the notation is an **absence of licence**, not an assertion of the opposite:

$$\text{not assumed} \;\neq\; \text{false}$$

Nothing establishes $F(S_1 + S_2) = F(S_1) + F(S_2)$, and nothing establishes its negation. $I_1 + I_2$ may not be a defined operation at all, in which case $F(S, I_1 + I_2 + I_3)$ is ill-formed rather than unequal. Likewise for order: input order *may* matter, and distributed inputs *need not* be equivalent to an aggregate one — but both must be established by the domain rather than read off the notation.

**Where the domain does assert it.** The training model separately claims path dependence: the same external load arranged differently costs differently, and reps within a session do not sum to recurrence across days. That is a substantive domain claim carrying its own evidence and its own status. It is not a property of $F$, and it does not transfer to other state machines written in the same notation.

> **Geometry of the state: yes. Linear algebra of the transition: no.**

---

## Errors corrected in derivation

Kept because the corrections are more instructive than the final statements.

1. **Shear vs. nilpotent Jordan block.** $\begin{bmatrix}0&1\\0&0\end{bmatrix}$ was called a shear. A shear is $I + N$ and invertible, e.g. $\begin{bmatrix}1&1\\0&1\end{bmatrix}$. Same nilpotent slide $N$, different object.
2. **Equivalence vs. orthogonal equivalence.** SVD was described as preserving singular values under matrix equivalence. Arbitrary invertible left/right changes preserve only rank. Singular values survive specifically because the changes are orthogonal.
3. **Rank under perturbation.** "$\#\{\sigma_i \neq 0\}$ is the definition that survives floating point" overstated it. The characterization is exact but the quantity is discontinuous; what survives numerically is the spectrum and a tolerance, not exact rank.
4. **Absence of assumption stated as assertion — repeat of the pattern in item 2.** §12 originally wrote $F(F(S,I_1),I_2) \neq F(F(S,I_2),I_1)$ and an inequality against $F(S, I_1+I_2+I_3)$. Neither was established. The formalism withholds equality; it does not assert inequality, and the aggregate expression is ill-formed because $I_1 + I_2$ is not a defined operation. The dimension claim was likewise stated flatly when it depends on a domain antecedent. Corrected to conditionals.

   Same error in the same direction as item 2, three sections later in the same document. Turning *not assumed* into *asserted false* is the inflation failure recorded in the corpus governance contract, and it recurs under pressure to make a conclusion punchier.
