# Dual Control: Theory, Mechanism, History, and Modern Use

## TL;DR

- **Dual control** is the branch of stochastic optimal control, founded by A. A. Feldbaum (1960–61), that recognizes a single control input has two simultaneous consequences — it drives the physical state (a “directing” effect) *and* it changes the future information the controller will have about the unknown system (a “probing/investigating” effect) — and chooses inputs that optimally balance the two by treating the *belief* over unknowns as part of the state.
- The single most important insight is the **dual effect**: when control affects future uncertainty (not just the state), the separation principle and certainty equivalence break down, so the optimal policy is *information-sensitive* — it may deliberately sacrifice short-term regulation to excite the plant and learn, because that learning has future value.
- The single biggest cost is **computational intractability**: exact dual control requires dynamic programming over an infinite-dimensional belief (hyper)state, solved exactly only for a handful of toy problems; virtually all practical “dual” controllers are approximations (dual MPC, implicit/explicit schemes, approximate DP), and “optimal under a Bayesian cost” does **not** imply robustness, safety, or stability guarantees.

## Key Findings

1. **Origin (directly established).** Feldbaum introduced “dual control” in a four-part series, *Dual Control Theory I–IV*, in *Avtomatika i Telemekhanika* (Russian, 1960–61) / *Automation and Remote Control* (English translation). His own words: control in closed systems with incomplete a-priori information must include “tentative actions, ‘experiments’… whose problem consists in studying” the plant and “directing actions… adjusting the plant to the required operating conditions,” and the optimal action “should, generally speaking, realize both of the above-mentioned tasks simultaneously, and because of this, has a dual character” (Feldbaum, “Dual control theory problems,” 2nd IFAC Congress, Basle, 1963). He showed the solution follows from dynamic programming (a Bellman functional equation) and is generally intractable. 
1. **Dual effect formalized (directly established).** Bar-Shalom & Tse, “Dual effect, certainty equivalence, and separation in stochastic control,” *IEEE Trans. Automatic Control* 19(5):494–500, 1974, defined the **dual effect**: a control has a dual effect if it can affect at least one central moment of order r≥2 of a state (i.e., it changes future estimation uncertainty). They proved the tight link between “no dual effect” (NDE), the separation principle, and certainty equivalence (CE), with LQG as the canonical case where the dual effect vanishes (“neutrality”).
1. **The turn-off phenomenon is real and precise (directly established).** A cautious (one-step, uncertainty-aware) controller reduces gain when parameter uncertainty is high; small inputs generate little information, so uncertainty grows further, driving gain toward zero — a vicious circle that can “turn off” the control (Åström & Wittenmark 1971; named in Hughes & Jacobs, “Turn-off, escape and probing in nonlinear stochastic control,” 1974). This is the sharpest demonstration of why passive adaptation fails and why deliberate probing is needed.
1. **Directing vs probing is a heuristic decomposition, not a phase split (synthesis).** Optimal dual control does *not* alternate pure-control and pure-probe phases; it seeks single actions that accomplish regulation and information-gain simultaneously. The “two actions” language is Feldbaum’s expository device; mathematically there is one input optimized against a cost that already accounts for future information.
1. **Modern reframing (directly established).** Dual control is now widely viewed as a POMDP / belief-state control problem and as an early, principled form of the exploration–exploitation trade-off in Bayesian reinforcement learning. Active, tractable instantiations appear as **dual MPC** and stochastic MPC “with active uncertainty learning” (Mesbah, *Annual Reviews in Control* 45:107–117, 2018, DOI 10.1016/j.arcontrol.2017.11.001).

## Details

### 1. Historical origin (Feldbaum, 1960–61)

**Bibliography (directly established, with a flagged discrepancy).** The series is *Dual Control Theory I–IV*. English-translation page ranges commonly cited: Part I, *Autom. Remote Control* 21(9):874–880; Part II, 21(11):1033–1039;  Part III, 22(1):1–12; Part IV, 22(3):109–121. The Russian originals (Math-Net.Ru, Steklov Institute) carry different pagination — Part I 21(9):1240–1249;  Part II 21(11):1453–1464;  Part III 22(1):3–16;  Part IV listed in Russian issue 2, pp. 129–142  — so both should be cited. Feldbaum consolidated the work in his 1965 book *Optimal Control Systems* (Academic Press),  and restated it in English in “Dual control theory problems,” *2nd IFAC Congress*, Basle, 1963 (DOI 10.1016/S1474-6670(17)69687-3).

**Content of each part (from Feldbaum’s own primary abstracts).**

- **Part I** compares communication-theory and control-theory problems, introduces the dual-control idea, and formulates the optimal (statistical, closed-loop) dual-control problem. 
- **Part II** derives the general optimum control algorithm, first for open-loop then closed-loop (nonlinear in general) systems, and contrasts the two.
- **Part III** (“Theory of dual control”) solves two worked examples: (a) stabilization of a linear plant under a mean-square-error criterion; (b) an extremum-seeking problem for a plant with a parabolic (quadratic) static characteristic.
- **Part IV** generalizes to a dynamic MIMO plant “with memory,” gives an application example, and outlines future directions.

**What problem it solved / why ordinary control was insufficient (synthesis).** Feldbaum addressed control of a plant whose characteristics/parameters are unknown and possibly time-varying, modeled as a discrete Markov process, with only incomplete a-priori information.  Ordinary (certainty-equivalent) control treats the current best estimate as if it were true and never accounts for the fact that the controller’s own actions determine how much it will learn. A companion 1961 paper, “On the accumulation of information in closed-loop automatic control systems”  (*Izv. AN SSSR, OTN, Energetika i Avtomatika*, No. 4),  framed closed-loop control-under-uncertainty explicitly as a process of *accumulating information* — the conceptual seed of the later “dual effect.”

**What “dual” meant originally (directly established).** Two coexisting purposes of one control action: *investigating/studying* (experimental/probing) and *directing* (regulating). Feldbaum advocated **both simultaneously** — a single optimal action with dual character — solved by dynamic programming, not an explicit separate probe.

### 2. The core mathematical problem

Consider a discrete-time uncertain system (Mesbah 2018 formulation):

- xₖ₊₁ = f(xₖ, uₖ, wₖ, θ), yₖ = h(xₖ, vₖ), with unknown parameter/latent θ, process noise w, measurement noise v. 

The input uₖ has two consequences: (1) it moves the physical state xₖ; (2) through the resulting measurement yₖ₊₁, it changes what the controller will know about θ (and x). Define the **information state** Iₖ = [yₖ,…,y₀, uₖ₋₁,…,u₀] and the **hyperstate / belief state** ξₖ|ₖ = P[xₖ | Iₖ] (or P[xₖ, θ | Iₖ] when parameters are unknown). The belief evolves by recursive Bayesian filtering: a measurement-update step and a time-update step.  Crucially the belief’s *future evolution depends on uₖ*.

Optimal control then solves a **Bellman recursion in which the belief is part of the state**:

- Vᵢ(ξᵢ|ᵢ) = min_{πᵢ} E[ l(xᵢ, πᵢ) + Vᵢ₊₁(ξᵢ₊₁|ᵢ₊₁) ], with ξᵢ₊₁|ᵢ₊₁ = H(ξᵢ|ᵢ, uᵢ, yᵢ₊₁). 

Because the cost-to-go depends on the *future belief* — which uₖ shapes — the optimal policy becomes **information-sensitive**: it weighs the future value of reduced uncertainty against present regulation cost. This is what distinguishes it from **certainty-equivalent (CE) control**, which plugs the current mean estimate into the deterministic optimal law and ignores the impact of actions on future information.

By augmenting the state with the parameters, zₖ = (xₖ, θₖ), dual control becomes optimal control of an augmented system whose dynamics are *nonlinear even if the physical system is linear*, because inference is nonlinear and future states and parameter beliefs are coupled (Klenske & Hennig, “Dual Control for Approximate Bayesian Reinforcement Learning,” *JMLR* 2016).

### 3. The dual effect (Bar-Shalom & Tse, 1974)

**Definition (directly established).** A control has **dual effect** if it can affect, with nonzero probability, at least one central moment of order r ≥ 2 of a state variable — i.e., it influences the *uncertainty* (e.g., conditional covariance), not merely the conditional mean. Equivalently (per Derpich & Yüksel’s restatement), no-dual-effect “is said to hold when the updated conditional distribution of the plant state given the plant output measurements does not depend on past control actions.”

**Orders (directly established).** The general definition is order-r (r≥2); the practically important case is **second-order dual effect** (control affects the conditional covariance Σₖ|ₖ). “No dual effect of second order” means Σₖ|ₖ is not a function of past controls.

**Separation / certainty equivalence (directly established).** For linear dynamics with quadratic cost, Bar-Shalom & Tse’s theorem states CE holds (for all Q≥0, R>0) *iff* the control has no dual effect of second order. LQG is the canonical **neutral** case: the Kalman-filter covariance is independent of the controls, the dual effect vanishes, separation holds exactly, and probing has no value. When the system is nonlinear, has state/input constraints, or has parameters entering multiplicatively, separation generally fails and certainty equivalence is suboptimal.

**Caveat (directly established).** Derpich & Yüksel, “Dual Effect, Certainty Equivalence, and Separation Revisited” (*IEEE Trans. Automatic Control*, 2022, DOI 10.1109/TAC.2022.3151189): “We show that there is a subtle error in Bar-Shalom and Tse’s proof of the claim that CE implies NDE… we prove that the claim does not hold by providing a counterexample.” They introduce a relaxed “no-dual-effect control-policy” (NDECP) condition sufficient for separation. So the *equivalence* as originally stated is not exactly correct, though the practical picture (LQG neutrality; dual effect breaks CE) stands.

**Turn-off phenomenon (directly established, stated precisely).** In a cautious controller (e.g., minimum-variance with parameter uncertainty pθ), the gain is scaled down by a factor like θ̂²/(θ̂² + pθ): as uncertainty pθ grows, the gain → 0. Small inputs excite the plant less, so the estimator gains little information and pθ grows further, producing progressively smaller inputs — the control “turns off.” Documented by Åström & Wittenmark (1971) and named by Hughes & Jacobs (1974).

**Worked example of caution reducing excitation.** Integrator with stochastic gain: y(k) = y(k−1) + θ(k−1)u(k−1) + e(k).  CE controller u = −y/θ̂ is undefined/erratic when θ̂→0. Cautious controller u = −(θ̂ y)/(θ̂² + pθ). As pθ ↑, |u| ↓ → less information about θ → pθ stays large → gain stays near zero. A dual controller instead accepts a slightly larger |u| now because the resulting measurement sharpens the θ-estimate, lowering future cost.

### 4. Directing vs probing actions

The exploration/exploitation, regulation/identification, and excitation vocabularies are largely coextensive descriptions of one trade-off. In the optimal formulation there is **no phase separation**: the optimal input intrinsically carries both a directing and a probing component, applied “to the extent required for reducing the system uncertainty pertinent to the optimal control performance”  (Mesbah 2018). Explicit probing (adding a separate dither/perturbation signal) is an *approximation* device, not a feature of the exact optimum. The exact optimum performs *control-oriented* identification: it reduces only the uncertainty that matters for the cost, not uncertainty in general.

### 5. Passive vs active adaptation

|Scheme                                   |Model uncertainty assumed                   |Deliberately excites plant?|Does info-gain affect the action?            |Objective optimized                                          |
|-----------------------------------------|--------------------------------------------|---------------------------|---------------------------------------------|-------------------------------------------------------------|
|**Certainty-equivalent adaptive**        |Estimated params treated as true (mean only)|No                         |No                                           |Deterministic optimal cost at current estimate               |
|**Cautious control**                     |Parameter mean + covariance                 |No                         |Partially (hedges via covariance, no probing)|Expected one-step (myopic) cost                              |
|**Passive adaptive** (CE/cautious family)|Point/mean or mean+cov                      |No                         |No (learning is “accidental” via feedback)   |Short-horizon expected cost                                  |
|**Active adaptive / dual control**       |Full belief (Bayesian posterior over x,θ)   |Yes, to the optimal extent |Yes — future information enters cost-to-go   |Expected multi-stage (closed-loop) cost via Bellman recursion|

Distinctions (directly established): CE and cautious are both **passively adaptive** (learning is a by-product of feedback). Only **actively adaptive** (dual) control anticipates future observations and therefore probes. Bar-Shalom & Tse tie this to the class of control laws: the **closed-loop** policy (anticipating all future measurements) is actively adaptive; the **feedback** policy (single-stage lookahead) is only passively adaptive; open-loop uses no observations.

### 6. Why exact dual control is hard

- **Belief-state explosion / partial observability.** The exact state is the belief (a probability distribution over x and θ), living in an infinite-dimensional space; the problem is a POMDP.
- **Nonlinear dynamic programming.** Even for linear physical systems, the augmented (state+parameter) dynamics and the Bayesian update are nonlinear; expectations become rational-polynomial functions whose degree grows with horizon.
- **Curse of dimensionality.** Quantizing the hyperstate for numerical DP grows exponentially in the belief dimension.
- **Non-Gaussian uncertainty.** With nonlinear measurements or multiplicative parameters, the posterior is non-Gaussian, so no finite sufficient statistic exists and the filter itself is intractable.

Consequence (directly established): exact optimal dual control is essentially a **theoretical ideal**. Closed-form/exact solutions exist only for a few toy problems (e.g., Sternby 1976; scalar systems with two possible gains, Bernhardsson 1989;  certain classes where only the observation matrix depends on θ, Cao et al. 2016). Feldbaum himself proved solvability by DP but noted its impracticality. Essentially all deployed “dual” controllers are approximate.

### 7. Approximate dual control

Mesbah (2018)  and Filatov & Unbehauen (“Survey of adaptive dual control methods,” *IEE Proc. Control Theory Appl.* 147(1):118–128, 2000) organize approximations into **implicit** (directly approximate the stochastic DP so that the genuine dual effect is preserved) and **explicit** (reformulate into a tractable problem, adding a heuristic probing term). What each approximates or discards:

- **Certainty-equivalent control** — discards the dual effect entirely (mean estimate only); no caution, no probing.
- **Cautious control** — keeps covariance (caution) but discards probing; risks turn-off.
- **Probing / persistent-excitation add-ons** — inject a dither or PE constraint to force excitation; discards the *optimal* balance (probing is heuristic, not cost-derived). Explicit dual.
- **Sequential identify-then-control** — separates estimation and control in time; discards the coupling (the very thing dual control captures).
- **Receding-horizon / dual MPC** — approximates the closed-loop DP with a finite-horizon reoptimization; implicit if the reformulation retains anticipation of future information, explicit if a heuristic uncertainty-cost term is added.
- **Approximate dynamic programming / forward DP with particle filtering** (Bayard & Schumitzky 2010) — approximates the value function/belief propagation numerically.
- **Bayesian MPC / dual MPC** (Heirung et al.; Arcari et al. 2020) — propagate parameter-estimate covariances over the horizon so learning is correctly rewarded.
- **Information-regularized / Fisher-information / experiment-design-in-control** (Houska “self-reflective MPC”; La et al.; Larsson et al.) — add a term rewarding information (e.g., Fisher information, covariance reduction, mutual information/entropy), embedding optimal experiment design in the controller.

### 8. Dual control vs system identification

- **Offline identification:** identify first (a dedicated experiment), then control on the fixed model. Estimation and control are fully decoupled.
- **Online identification (adaptive/self-tuning):** update the model while controlling, but choose the control *as if* the current estimate were correct (certainty equivalence) — learning is a passive by-product.
- **Dual control:** choose the control *partly because of how it will change future knowledge* — the anticipated informativeness of an action enters the control objective.

**Sharpest discriminator (synthesis):** Does the *anticipated future information* produced by an action influence the action chosen now? If yes → dual. If the controller only reacts to information already obtained → passive adaptive / identification, not dual.

### 9. Persistent excitation (PE)

- **Why passive operation can’t identify some systems (directly established).** Parameter convergence in adaptive identification/control requires the regressor to be *persistently exciting* (sufficiently rich in frequencies). A plant sitting at setpoint produces near-constant signals that don’t excite all modes, so some parameters are unidentifiable from passive operation.
- **Estimates stall without PE.** Insufficient excitation leaves parameter estimates converging only to a subspace, or drifting (bursting).
- **Probing-signal design.** PE is enforced by injecting sufficiently rich reference/dither signals or, in modern schemes, by adding PE *constraints* to the MPC optimization (e.g., Lu & Cannon, “Robust adaptive model predictive control with persistent excitation conditions,” *Automatica* 2023: set-membership adaptive MPC giving recursive feasibility, input-to-state stability, and almost-sure parameter convergence).
- **Trade-off.** More excitation → faster/better identification but worse regulation (larger output variance); this is the excitation-vs-regulation tension.

**Status of PE relative to dual control (synthesis).** PE is a *distinct identification condition*, not dual control itself. Enforcing PE (a fixed richness requirement) is an **explicit/heuristic approximation** to dual control: it guarantees learning but is not derived from optimally trading information against cost. Exact dual control produces excitation *endogenously and only as much as the cost warrants* — it may satisfy PE incidentally, but PE is neither necessary nor sufficient for optimality.

### 10. Stabilization–learning conflict

The tension is structural: the control action that best regulates (drives error and thus signal energy to zero) is exactly the action that starves the estimator of information.

- **Aggressive stabilization destroys identifiability:** driving y→setpoint quickly removes excitation; parameters become unidentifiable (turn-off phenomenon; Åström & Wittenmark 1971). Bernhardsson (1989) showed for y(t+1)=ay(t)+bu(t)+σe(t+1) with unknown gain b ∈ {b₁,b₂} that probing depends on stability: for small |a| there is *no* probing, and the region of probing grows as the plant becomes more unstable — i.e., the controller probes more when getting the model wrong is more dangerous.
- **Aggressive probing harms regulation:** large dither raises output variance and can violate constraints.

Dual control represents this formally by making the cost-to-go depend on the belief covariance, so the optimizer internalizes both the regulation cost of probing *now* and the control-performance benefit of reduced uncertainty *later*.

### 11. Relationship to POMDPs

**Directly established.** Modern dual control is standardly cast as a POMDP / belief-MDP: the unknown parameters are latent variables, the hyperstate is the belief, and optimal dual control is the solution of the belief-space Bellman equation. A POMDP with unknown static parameters (θ constant) is exactly the augmented-state dual-control problem; more generally the parameters can be time-varying latents.

**Similarities:** both plan in belief space; both have the value function preserve information value; both are generally intractable (continuous belief space).
**Differences / cautions (synthesis):** (i) Classical dual control emphasizes *parametric* uncertainty in otherwise-known dynamics and continuous states/inputs with a quadratic-type cost; generic POMDP theory (e.g., Smallwood–Sondik piecewise-linear value functions) targets finite state/observation/action sets. (ii) Dual control literature stresses the *dual effect / turn-off / probing* structure specific to control-with-estimation; POMDP literature stresses value-iteration/point-based solvers. They are the same in principle but the literatures make different assumptions, so they should not be collapsed uncritically.

### 12. Relationship to reinforcement learning

- **Is dual control an early exploration–exploitation framework? (synthesis, strongly supported).** Yes. Feldbaum’s simultaneous “investigating vs directing” is a principled, model-based exploration–exploitation trade-off predating RL. Multiple sources explicitly equate the dual effect with the exploration–exploitation trade-off.
- **Genuinely equivalent:** **Bayesian RL / Bayes-adaptive MDPs** are essentially dual control — the Bayes-optimal policy selects actions by both reward and information value over the belief, exactly Feldbaum’s augmented-state Bellman recursion (Klenske & Hennig 2016 explicitly cast dual control as approximate Bayesian RL).
- **Merely analogous:** ε-greedy, UCB, Thompson sampling, and exploration bonuses are *heuristic* explorers; most do not model the effect of actions on *future beliefs* (they explore in state/action space, often assuming episodic resets). Model-based RL and adaptive control overlap with dual control when they plan over model uncertainty.
- **Differing assumptions:** classical dual control assumes a *known model structure* with unknown parameters, continuous dynamics, a single non-episodic trajectory, and additive/quadratic structure; much of RL assumes discrete MDPs, episodic resets, and model-free value learning. Safe RL adds explicit safety constraints that classical dual control (which optimizes a Bayesian expected cost) does not inherently provide.

### 13. Relationship to model predictive control (dual MPC)

- **Ordinary MPC and uncertainty:** nominal MPC assumes an accurate model; robust MPC hedges against worst-case bounded uncertainty (conservative); stochastic MPC uses probabilistic descriptions and chance constraints — but standard SMPC *cannot actively learn* (it does not anticipate that actions shape future information).
- **What makes MPC “dual”:** the optimization anticipates how present inputs change the *future* posterior/estimate uncertainty and rewards informative inputs — i.e., future (predicted) measurements influence the present control decision.
- **Does information gain enter the objective:** in *implicit* dual MPC it enters intrinsically via propagation of the conditional distributions over the horizon; in *explicit* dual MPC it is added as a heuristic term (e.g., covariance/Fisher-information reward or PE constraint).
- **Tractability:** achieved by finite horizons, moment/Gaussian (EKF) belief approximations, scenario trees, QCQP/QP reformulations, and receding-horizon reoptimization.

**Modern peer-reviewed examples (directly established):**

1. **Heirung, Foss & Ydstie, “MPC-based dual control with online experiment design,” *J. Process Control* 32 (2015):64–76** — propagates parameter-estimate error covariances into the horizon; controllers converge to CE-MPC as uncertainty vanishes, avoiding needless excitation.
1. **Heirung, Ydstie & Foss, “Dual adaptive model predictive control,” *Automatica* 80 (2017):340–348**  — dual MPC for linear systems with parametric uncertainty; incentivizes exploration by minimizing expected output error.
1. **Arcari, Hewing & Zeilinger, “An approximate dynamic programming approach for dual stochastic MPC,” *IFAC-PapersOnLine* 53(2) (2020):8105–8111**  — ADP approximation of the dual SMPC problem.
1. **Houska, Telen, Logist & Van Impe, “Self-reflective model predictive control,” *SIAM J. Control Optim.* 55(5) (2017):2959–2980**  — embeds optimal experiment design in MPC.
1. **Hu, Isele, Bae & Fisac, “Active uncertainty reduction for safe and efficient interaction planning: a shielding-aware dual control approach,” *Int. J. Robotics Research* (2024)** — implicit dual control for human–robot interaction using scenario-tree SMPC that provably preserves the dual effect.

### 14. Stability guarantees (kept carefully separate)

These are logically independent properties, and Bayesian optimality implies **none** of them automatically:

- **Bayesian optimality:** exact dual control minimizes the expected (Bayesian) cost — this is what the theory targets. It does *not* by itself guarantee robustness, safety, or stability.
- **Lyapunov stability / asymptotic stability:** not inherent; must be engineered (e.g., via terminal ingredients in dual MPC).
- **Recursive feasibility & constraint satisfaction:** provided by specific *robust/stochastic adaptive MPC* designs, not by dual control per se — e.g., Lu & Cannon (2023): robust adaptive MPC with PE constraints giving recursive feasibility, ISS, and a.s. parameter convergence; scenario/tube dual-MPC schemes give recursive feasibility and input-to-state-practical stability under robust constraint satisfaction.
- **Asymptotic parameter convergence:** requires excitation (PE/interval-excitation) conditions; not guaranteed by optimality alone.
- **Regret guarantees:** come from the learning-theoretic (RL/online-learning) treatments, not from classical dual-control formulations.

### 15. Failure modes and limitations

For each, whether it is a failure of *exact theory*, of *approximation*, or a *violation of assumptions*:

- **Model misspecification / wrong structure** — *assumption violation* (dual control assumes known f, h with unknown θ). Exact theory says nothing if the structure is wrong.
- **Wrong priors** — *assumption violation*; Bayesian optimality is only “optimal” relative to the prior; a bad prior yields confidently wrong probing.
- **Unsafe / catastrophic probing** — *failure of exact theory as a safety tool*: a Bayesian-optimal probe can drive the state into unsafe/irreversible regions because expected-cost optimality ≠ safety. Motivates safe RL / shielding / chance constraints.
- **Insufficient excitation** — *approximation failure* (CE/cautious schemes) causing turn-off; exact dual control avoids it endogenously.
- **Nonstationary plants / hidden slow dynamics** — *assumption violation / approximation failure*: time-varying θ can be modeled (random walk) but approximations may track poorly.
- **Irreversible state changes** — *exact-theory limitation*: standard formulations assume the cost captures all consequences; irreversibility/safety usually isn’t encoded, so probing can be catastrophic.
- **Delayed / poor observations, poor observability** — *assumption stress*: weak observability makes the belief update uninformative; PE/identifiability fails.
- **Computational intractability** — *exact-theory limitation* (belief explosion, curse of dimensionality), forcing approximation.

### 16. Canonical examples

For each: state / unknown / input / information gained / regulation objective / dual trade-off.

1. **Integrator with unknown (stochastic) gain** (Åström & Wittenmark 1971; Wittenmark EOLSS). State: output y. Unknown: gain θ. Input: u. Info: each u reveals θ via y-response. Objective: minimize output variance. Trade-off: small u regulates but starves estimation (turn-off); larger u probes θ.
1. **First-order system with unknown gain taking two values b∈{b₁,b₂}** (Bernhardsson 1989). State: y in y(t+1)=ay(t)+bu(t)+σe. Unknown: which gain. Input: u. Info: response discriminates b₁ vs b₂. Objective: regulate y. Trade-off: probing intensity grows with plant instability |a|; none for small |a|.
1. **Unknown-parameter linear plant / actively adaptive LQ** (Tse & Bar-Shalom 1973, third-order plant with six uncertain parameters). State: xₖ. Unknown: entries of F(θ),G(θ). Input: uₖ. Info: closed-loop data on dynamics. Objective: LQ regulation. Trade-off: dual controller injects probing early, converges to CE as covariance shrinks.
1. **Adaptive process control (chemical/mechanical, e.g., chip-refiner motor load; steel recycling)** (Allison et al., “Dual Adaptive Control of Chip Refiner Motor Load,” *Automatica* 31(8):1169–1184, 1995; steel-recycling dual MPC). State: process outputs. Unknown: process gains/time-varying parameters. Input: manipulated variables. Info: input–output data. Objective: setpoint tracking with low variance. Trade-off: excite enough to maintain the model during operation without upsetting product quality.
1. **Autonomous search / source localization (DCEE)** (Chen, Rhodes & Liu, “Dual Control for Exploitation and Exploration (DCEE) in autonomous search,” *Automatica* 133 (2021):109851).  State: robot position. Unknown: source location (Bayesian-estimated). Input: motion command. Info: sensor readings at visited positions. Objective: reach the source. Trade-off: cost = expected error between the *future* robot position and the *predicted future* estimate of the source, so the robot moves both to approach and to gather information.
1. **Human–robot interaction / autonomous driving** (Hu et al. 2024; Bonzanini/Mesbah perception-aware MPC). State: ego + other-agent states. Unknown: other agent’s latent intent/parameters. Input: ego control. Info: observed reactions. Objective: safe efficient interaction. Trade-off: probe the other agent’s intent vs. progress safely.

### 17. One minimal numerical example

Take the scalar plant xₖ₊₁ = θ xₖ + uₖ + wₖ, with wₖ ~ 𝒩(0, σ_w²), σ_w²=1, and a prior on the unknown θ: mean μ=1.0, variance p=1.0, current state x₀ = 1. θ is observed only through how x responds: rearranging, (xₖ₊₁ − uₖ) = θ xₖ + wₖ, so the informativeness of one step about θ scales with the regressor xₖ². The Bayesian variance update after a step with regressor value r is p⁺ = p·σ_w² / (r²·p + σ_w²).

- **Action A — greedy/CE regulation:** choose u₀ to drive E[x₁]=0, i.e. u₀ = −μx₀ = −1, so E[x₁]=0. Because the next-step regressor x₁ is driven near zero, the next observation is nearly *uninformative* about θ, so the posterior variance stays ≈ p = 1.0. Immediate cost is low (x₁≈0) but we learn almost nothing.
- **Action B — informative/probing:** choose u₀ = +1, giving E[x₁] = μ·1 + 1 = 2. Now the next-step update uses regressor r ≈ 2: p⁺ = 1·1/(4·1 + 1) = **0.2**, a five-fold reduction in parameter uncertainty (1.0 → 0.2). Immediate cost is higher (x₁≈2 ⇒ x₁²≈4 plus control effort), but the sharpened θ makes *all future* regulation cheaper.
- **Cost-to-go comparison (mechanism).** Under CE (Action A), future control uses a poor θ estimate (var 1.0), so future regulation carries a large expected variance contribution ∝ p·x². Under Action B, future control uses θ with var 0.2, cutting the uncertainty term of the expected future quadratic cost by ~80%. If the horizon/weight on future cost is large enough that the future variance saving outweighs the ~4-unit extra immediate cost of probing, the dual controller **prefers Action B** — chosen partly *because* of the future value of the information it produces. For a short horizon or small a the saving doesn’t repay the probe, matching Bernhardsson’s “no probing for small a.” (Numbers are an illustrative mechanism, not a fully solved optimal policy.)

### 18. Terminology audit

- **Dual control** — Feldbaum’s optimal control of an uncertain plant where inputs both direct and investigate; often used loosely online for *any* explore-exploit or *any* adaptive scheme. *Flag:* the term has drifted to cover both the exact optimum and crude heuristic probing.
- **Dual effect** — Bar-Shalom–Tse property that control affects a state’s central moment of order ≥2 (future uncertainty). *Flag:* not a synonym for “dual control”; it is the precise property whose presence makes control dual.
- **Active adaptation** — controller deliberately anticipates future info and probes (closed-loop policy).
- **Passive adaptation** — learning is an accidental by-product of feedback (CE, cautious).
- **Cautious control** — uses parameter covariance to shrink gain under uncertainty; *not* dual (no probing); can cause turn-off.
- **Certainty equivalence** — replace unknown by its estimate/mean and use the deterministic optimal law; exact only in neutral (LQG) cases.
- **Probing** — deliberately exciting to gain information; in exact dual control it is endogenous, in explicit schemes it is an added heuristic.
- **Excitation / persistent excitation** — signal richness needed for parameter convergence; PE is an identification condition, *related to but distinct from* dual control. *Flag:* PE ≠ dual control.
- **Information state / hyperstate** — sufficient statistic (the belief, e.g., posterior) that makes the problem Markov in belief space.
- **Belief state** — the posterior distribution over (states and) parameters; the state variable of the POMDP/dual problem. *Flag:* “information state” and “belief state” are used near-synonymously, but “information state” can also mean the raw (y,u) history that the belief summarizes.
- **Neutrality** — absence of dual effect (LQG); probing has no value.

### 19. What survived historically

- **Still foundational:** the dual-effect insight; belief/hyperstate augmentation; the fact that CE/separation are special (neutral) cases; the exploration–exploitation trade-off framed as a control problem; the caution-vs-probing distinction.
- **Superseded:** direct numerical DP on quantized hyperstates for anything but toy problems — replaced by approximate DP, particle/EKF belief propagation, scenario-tree and QP/QCQP reformulations.
- **Computationally impractical (valid but rarely solved exactly):** the exact optimal dual controller / exact Bellman recursion in belief space — a benchmark ideal, solved exactly only for special toy classes.
- **Renamed / reframed:** the same ideas now appear as **Bayesian RL / Bayes-adaptive MDPs**, **POMDP belief-space planning**, **active learning / optimal experiment design in control**, **dual MPC / SMPC with active uncertainty learning**, and **DCEE**.

### 20. Final synthesis

- **What dual control is (most accurate form):** the optimal control of a dynamical system with incompletely known state/parameters, formulated as dynamic programming over the *belief* (hyperstate), in which each input is chosen to optimally trade its effect on the physical state against its effect on the controller’s *future information* — the latter mattering only insofar as it improves future control performance.
- **Single most important insight:** control has a *dual effect* — it moves the state and shapes future uncertainty — so certainty equivalence/separation are only special (neutral) cases, and the optimal policy is information-sensitive, sometimes deliberately probing.
- **Single biggest cost/limitation:** exact solution is computationally intractable (infinite-dimensional, nonlinear belief-space DP; curse of dimensionality), so real controllers are approximations; and Bayesian-cost optimality guarantees neither safety, robustness, nor stability.
- **Misconception to avoid:** that dual control = “add a probing signal,” or that it alternates between a control phase and a probe phase, or that “optimal (Bayesian)” means “safe/robust/stable.” Optimal dual control produces one action that is *simultaneously* directing and investigating, probes only to the cost-justified extent, and carries no automatic safety or stability guarantee.

## Recommendations

1. **If your model is accurate and uncertainty is low →** use nominal or certainty-equivalent MPC/LQG. The dual effect is negligible (near-neutral); probing wastes effort. *Threshold to revisit:* if closed-loop parameter-estimate covariance stops shrinking or output variance drifts up, uncertainty is no longer low.
1. **If uncertainty is moderate and safety-critical constraints exist →** use **robust or stochastic adaptive MPC with recursive-feasibility and constraint guarantees** (tube/scenario/set-membership MPC, e.g., Lu & Cannon 2023), optionally with PE constraints to ensure identifiability. Do *not* rely on unconstrained dual optimality for safety. *Threshold:* if constraint-violation risk under probing exceeds your chance-constraint level δ, tighten constraints or add a safety filter/shield before allowing exploration.
1. **If uncertainty is high, the plant is (mildly) unstable, or fast adaptation matters →** use **implicit dual MPC** that propagates the posterior/covariance over the horizon (Heirung et al. 2015/2017; Arcari et al. 2020), so probing is cost-justified and self-limiting (converges to CE as uncertainty vanishes). Prefer implicit over explicit (heuristic-term) dual control when tractable, to avoid tuning an arbitrary probing weight.
1. **If the task is inherently exploratory (search, interaction, mapping) →** adopt a belief-space/POMDP or DCEE formulation (Chen et al. 2021; Hu et al. 2024) where the objective is defined on predicted future beliefs.
1. **Always separate the guarantees you need** (Lyapunov stability, recursive feasibility, constraint satisfaction, parameter convergence, regret) from “Bayesian optimality,” and select a method that *explicitly* provides the specific guarantee — dual optimality does not imply the others.
1. **Diagnostics that should change your choice:** persistent non-shrinking estimate covariance → add excitation/PE or switch to active dual; frequent constraint violations under probing → move to robust/shielded scheme; heavy compute overrun → coarser belief approximation (EKF/moment, fewer scenarios) or explicit dual with a tuned probing term.

## Caveats

- **Feldbaum bibliographic discrepancy:** Russian originals (Math-Net.Ru) and English translations differ in pagination; Part IV appears in the Russian issue 2 (pp. 129–142) but is cited in English as 22(3):109–121. Cite both.
- **Verbatim Feldbaum quotes** are drawn from his English-language 1963 IFAC paper; the interior text of the four Russian papers (behind Russian-language PDFs) could not be quoted directly, only via authoritative abstracts and secondary sources (Wittenmark, Mesbah, Filatov & Unbehauen).
- **Bar-Shalom & Tse (1974) CE⇔NDE equivalence** contains a proof error identified by Derpich & Yüksel (2022); the corrected/relaxed condition (NDECP) is what strictly guarantees separation. The qualitative teaching (LQG neutral; dual effect breaks CE) is unaffected.
- **The numerical example in §17** is a deliberately simplified illustration to expose the mechanism (Bayesian variance update p⁺ = pσ²/(r²p+σ²) and the info-vs-cost trade); exact numbers depend on horizon, weights, and noise and are illustrative, not a solved optimal policy.
- **“Dual control” terminology is used loosely** in online/secondary sources (and even across the technical literature it now spans both the exact optimum and heuristic probing). Claims tying modern methods directly to Feldbaum should distinguish his original optimal-exploration concept from later approximations.
- Some material encountered during research (Grokipedia, vendor/patent pages, ResearchGate snippets) was used only for orientation; all load-bearing claims rest on peer-reviewed papers (Bar-Shalom & Tse 1974; Mesbah 2018; Heirung et al.; Derpich & Yüksel 2022; Chen et al. 2021), the Feldbaum primary abstracts and 1963 IFAC paper, and authoritative surveys (Wittenmark EOLSS; Filatov & Unbehauen 2000).