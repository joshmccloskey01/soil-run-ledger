# Capacity-Demand Gradient

**Author:** Josh McCloskey
**Current Revision:** R4
**Last Revised:** August 2, 2026
**Status:** Active working paper — specification, not yet validated on a recorded node

*The body is the current model, read as it now stands. The complete revision history is at the back.*

## Capacity-Demand Gradient

The Capacity-Demand Gradient has two functions, and the second is prior to the first.

**Admission.** The licensing, definedness, commensurability, and closure requirements below specify when a bounded system may be represented as a node in a heterogeneous state graph, and when a declared relation between nodes is entitled to function as an edge. A node is not admitted merely because values have been assigned to it: its inputs must have derivation paths, its quantities must be typed and defined relative to declared operators, and its comparisons must satisfy the same-bucket and derived-quantity discharge rules. An edge is not admitted merely because two quantities appear related: the relation must preserve those licenses through every transformation and must survive the closure test against detectable export.

**The two admissions are not the same grade.** A node's derivation paths do not expire. Once its inputs are licensed it remains licensed, and it loses that standing only if an input is withdrawn. An edge's admission is provisional by construction, because the closure verdict that licenses it is scoped to the model class, probe envelope, and detection power that produced it, and is revocable by a probe added later. A graph that treats both grades as settled will carry revocable edges as permanent structure, and will do so silently, because a revoked edge and a never-tested edge look identical in a record that does not distinguish them.

**Steering.** Only after those conditions are met does the Gradient function as the local steering variable of the framework, expressing the mismatch between what a bounded system can currently absorb or resolve and what its environment, process, or task is imposing. Capacity and demand are not treated as fixed isolated properties; both are state-dependent, history-dependent, and may vary across space, time, scale, and subsystem.

**Ordering is a prohibition, not a preference.** A nudge computed at an unlicensed node, or transmitted along an unadmitted edge, is not a weak update. It is not an update. The steering law has no *authorized* output at a node that has not been admitted. A value mechanically produced there may be recorded as an inadmissible result — production and authorization are different acts and the record must show which one occurred — but it may not be applied or propagated.

The framework uses one comparison lens across domains, but it does not assume that every domain literally shares one physical unit. In thermodynamic systems the common currency may be exergy. In structural mechanics it may be stress, strain energy, stability margin, or reserve factor. In software it may be memory, latency, dependency stability, or constraint margin. Cross-domain unification occurs at the level of normalized relation and update law unless a valid physical conversion establishes a shared unit.

### 1. Mathematical Definition

The word gradient must remain explicit because several related quantities are useful and must not be collapsed into one symbol.

- Deficit: e_cd(x,t) = D(x,t) - C(x,t). Positive values indicate unmet demand; negative values indicate reserve capacity.
- Utilization: u_cd(x,t) = D(x,t) / C(x,t), for C > 0. Values near 1 indicate operation near the modeled limit.
- Temporal approach rate: g_t = d[e_cd]/dt. This measures whether the system is moving toward or away from overload.
- Spatial gradient: g_x = nabla[e_cd]. This identifies where mismatch is increasing most sharply across geometry or a field.
- Parameter gradient: g_theta = nabla_theta J(...). This points toward the parameter change that most reduces the chosen objective. Its argument list is fixed in Section 3.

The canonical Capacity-Demand Gradient is therefore not a single scalar without context. It is a typed family of local error and slope measures. Every token must declare its domain, units, boundary, reference state, coordinate, and derivative type.

#### 1.1 Definedness

The five members are not co-equal in scope, and treating them as co-equal has already caused one error in this paper.

- Estimator-free given C and D: deficit and utilization. These are algebraic in the inputs and require nothing beyond the inputs being licensed under 1.2.
- Estimator-dependent: g_t. A temporal derivative taken from discrete, noisy observations is not read off; it is estimated. The differencing, regression, or filtering operator, the sampling cadence, and the estimation window W must be declared with the value. Two nodes reporting g_t under different estimators are not comparable, and neither is the same node across a change of estimator.
- Metric-dependent: g_x requires a declared metric or adjacency operator. On a continuous field it is the ordinary gradient. On a dependency graph, a process network, or any discrete structure it is undefined until a difference operator over declared edges is named, and the resulting value is operator-relative. The operator must be recorded with the token.
- Objective-dependent: g_theta requires a differentiable objective and an authorized continuous parameter space. Where the parameter space is discrete, or authority is categorical rather than continuous, g_theta is replaced by an enumerated admissible-change set evaluated by finite difference. This is a different object and must be typed as such.

A node may legitimately report deficit, utilization, and approach rate while declaring g_x undefined. That is a complete token, not a deficient one.

#### 1.2 Input Licensing

C(x,t) and D(x,t) are not observed. In every domain the framework addresses, capacity and demand are model-derived estimates produced by a measurement chain plus a model, and in some domains they are derived from other estimates in turn. Nothing downstream can be better licensed than they are.

Therefore every constraint this paper places on later quantities applies to the inputs first. Each of C and D carries a declared derivation path: which raw measurements, taken by which instrument, under which reference state, through which model and model version, using which estimator, with which uncertainty-propagation rule.

A node reporting a deficit to three significant figures over an undeclared capacity derivation has produced a precise number of unknown provenance. This is the framework's first act of licensing its own inputs rather than assuming them, and it is prior to everything in Sections 3 through 6.

### 2. Regimes

- Reserve regime: D < C. The system has available capacity, though excessive reserve may represent unnecessary mass, cost, latency, or stored potential depending on the objective.
- Matched regime: D approximately equals C within an accepted tolerance and safety policy. This is local objective balance, not proof of zero dissipation, zero waste, or global optimality.
- Overload regime: D > C. Demand exceeds modeled capacity and the deficit is positive.
- Approaching-cliff regime: e_cd may still be acceptable while d(e_cd)/dt, nabla(e_cd), uncertainty, or loss of margin indicates rapidly increasing risk. This is why slope and trend matter in addition to threshold.

**Representability requirement, in two levels.** Naming a regime is not enough, and reaching the objective is not enough either.

- Visible: the regime changes the value of the objective in Section 3. A regime with no path into J is decoration, because the engine cannot register it.
- Actuable: at least one authorized parameter direction changes that contribution. A regime that is visible but not actuable is registered and cannot be steered on.

The approaching-cliff regime is the binding case for visibility, since it is defined by acceptable present error and unacceptable slope. It is also the case where visibility is most likely to arrive without actuability, because the parameters that move present deficit and the parameters that move its rate of change are frequently not the same parameters. Visible-but-unactuable is a defined output — escalation, per 3.4 — not a failure of the loop.

### 3. The Nudge Engine

The Capacity-Demand Gradient supplies the local optimization signal inside the Observation -> Prediction -> Error -> Update loop. The system observes state, predicts the response, computes mismatch, selects an allowed parameter direction, applies a bounded nudge, and observes again.

- Observe the local state and boundary conditions.
- Estimate demand, capacity, uncertainty, and reserve margin using a domain-valid model, under the input licensing of 1.2.
- Compute the relevant deficit, utilization, temporal slope, spatial gradient, or parameter gradient.
- Project the deficit forward to the declared horizon.
- Choose a change vector subject to constraints, safety factors, manufacturability, reversibility, and authority limits.
- Apply a bounded parametric nudge rather than an unconstrained redesign.
- Re-simulate or re-measure, then accept, reject, or reduce the update.

#### 3.1 Horizon Projection

Approach rate enters the objective through a projected deficit at a declared horizon tau:

e_hat_cd(x, t + tau) = e_cd(x,t) + g_t(x,t) * tau

to first order, with higher-order terms where curvature is modeled and the model supports them.

The horizon tau and the estimator window W are declared jointly, because the projection is only as good as the slope it extends. There is no simple inequality between them: a long window may legitimately estimate a slope used for a short forecast. The requirements are three, and all three are recorded.

- Sample sufficiency: enough completed samples inside W for the declared estimator to return a slope at all.
- Uncertainty admissibility: tau times the standard error of g_t must remain small against the matched-regime tolerance band. A projection whose uncertainty exceeds the band it is compared against carries no decision content.
- Timescale validity: W and tau are validated against the system's own timescale of variation. A window long relative to that timescale smooths away the dynamics the projection exists to catch; a window short relative to the noise correlation returns variance and reads it as slope.

#### 3.2 Objective, Hard Constraints, and Soft Penalties

Hard feasibility and soft preference are different objects and must not both live inside J. Hard constraints — manufacturability, safety limits, reversibility requirements, authority bounds — define the permitted set Theta_allowed and are enforced by the projection and the feasibility check. Soft preferences — cost, dissipation, aesthetic or policy penalties — are terms inside J, weighted under Section 4.

For parameter vector theta, the objective takes both present and projected error:

J = J(e_cd, e_hat_cd, u_cd, uncertainty, losses, soft penalties)

Constraints are absent from that list by construction. A quantity that appears both as a penalty in J and as a bound on Theta_allowed is double-counted and must be assigned to one or the other with the assignment recorded.

#### 3.3 The Feasible-Step Update

The steering direction is the projection of the negative gradient onto the tangent cone of the permitted set at the current point:

d_n = Pi_[T_Theta(theta_n)] ( -nabla_theta J )

theta_(n+1) = R_Theta( theta_n , alpha_n * d_n ),  with alpha_n <= alpha_max and theta_(n+1) in Theta_allowed

Assumptions, declared per node: Theta_allowed is closed. Where it is convex, the tangent cone is closed and convex, the Euclidean projection is unique, and the norm bound in 3.4 holds. Where it is nonconvex, the projection may be non-unique and the tie-break rule must be declared in advance under Section 4, since choosing it after seeing the candidates is a retroactive decision.

The retraction R_Theta is not decoration. A tangent direction is feasible only infinitesimally: on a curved or nonconvex permitted set, a straight finite step along an exactly tangent direction can leave the set — the tangent to a circle is the standard picture, valid locally and outside the set at every positive step length. Two admissible treatments:

- Convex polyhedral Theta_allowed: the straight step is feasible for sufficiently small alpha. Use theta_n + alpha_n d_n with an explicit feasibility check and a backtracking line search that shortens alpha_n until the result is inside the set.
- Curved or nonconvex Theta_allowed: a declared retraction is required, and its form is a policy declaration under Section 4.

Point-projection of the proposed parameter value — stepping first and projecting back — is not used. It permits an excursion outside the permitted set followed by a snap back, and where the permitted set encodes manufacturability, safety, and authority, the intermediate point may not be evaluable at all and the snap-back can land where no authorized direction would have gone. Bounded nudge means never leaving the set, not leaving it briefly.

Every step that had to be shortened to remain feasible is recorded. Repeated shortening at a node is the signature of a parameter pinned against a constraint face, and it is the same information as a low actuability ratio arriving by a different route.

#### 3.4 Visible Versus Actuable, and the Actuability Ratio

With the projected term present, the approaching-cliff regime contributes to the objective. Contribution is not steering. The chain rule gives

nabla_theta e_hat_cd = nabla_theta e_cd + tau * nabla_theta g_t

and both terms can vanish over the authorized directions, or the tangent-cone projection can remove the direction that carried them. Representation in J is therefore necessary and not sufficient.

The regime produces a steering gradient only where the declared parameterization contains an authorized direction with nonzero sensitivity to present or projected deficit. Otherwise the node escalates as visible but locally unactuable.

The magnitude is:

a_n = || Pi_[T_Theta(theta_n)] ( -nabla_theta J ) || / || nabla_theta J ||

which lies in [0,1] under Euclidean projection onto a closed convex tangent cone, since such a cone contains the origin and the projection is non-expansive. Define a_n = 0 when || nabla_theta J || <= tol. The ratio reports what fraction of the demanded steering the authorized space can actually deliver at this point. It is a magnitude rather than a flag, it is recorded with every update, and its trend across a run is itself a diagnostic: a node whose actuability is falling is losing authority over its own error before that error becomes visible as overload.

Escalation splits by cause, because the two go to different people and carry different evidence.

- Locally constraint-blocked: || nabla_theta J || > tol with a_n approximately 0 at this theta. The direction exists and is blocked here. Route to authority or constraint review. This establishes nothing about the parameterization; one blocked point is one blocked point.
- Parameterization failure: projected sensitivity absent throughout the declared operating region. Route to redesign. This claim requires a sensitivity audit — the rank of the sensitivity Jacobian of (e_cd, e_hat_cd) with respect to theta, evaluated over a declared sample of the operating region, not at the single point where the block was noticed. The audit, its sample, and its rank result are recorded with the escalation.

### 4. Objective Weights, Policy Constants, and Derived-Quantity Discharge

Any J that combines terms of different type contains weights, and weights carrying units perform a conversion. Section 7 forbids undeclared conversion at the variable level; the same prohibition must hold at the objective level, or the rule is defeated one layer up.

Two kinds of weight are admissible, and they must be labeled differently.

- Physical conversion weight: licensed by a valid mapping to a shared physical quantity under a common reference state. Recorded with the mapping that licenses it.
- Policy weight: a declared preference among incommensurable terms. Legitimate, but it is a decision, not a measurement, and must be recorded with provenance — who set it, when, on what basis, and under what authority.

Every free constant in the loop falls under the same precommitment rule: horizon tau, estimator window W and estimator form, step ceiling alpha_max, line-search and retraction rule, nonconvex tie-break rule, gradient tolerance tol, matched-regime tolerance band, safety factor, acceptance threshold, model-class challenge cadence, and all objective weights. Each is declared before the run and recorded in the token.

**Retroactive tuning is prohibited.** Adjusting a weight, horizon, window, threshold, or tie-break after seeing the realized outcome converts the update law into a description of that outcome. The loop still runs and still produces numbers, and those numbers no longer carry evidential weight, because no result could have failed. A constant may be revised — but the revision is a new declaration, applies forward only, and prior runs remain scored under the constant in force when they ran.

#### 4.1 The Derived-Quantity Discharge Rule

One failure has now recurred three times in this paper, in three different sections, each time one layer above where it was blocked. Undeclared unit conversion was blocked at the variable level and reappeared inside the objective weights. Blocked there, it reappeared inside normalization. Measurement precommitment was imposed on the raw value and was defeated by the free choice of estimator that turns the raw value into the compared quantity.

The pattern is general enough to state as a rule rather than patch a fourth time:

**Every constraint placed on a declared quantity must be discharged again against every quantity derived from it** — including derivatives, projections, normalizations, aggregates, objective terms, and the estimators that produce any of them. A constraint that binds only at the layer where it was written is a naming convention, not a constraint.

Operationally: for each derived quantity carried in the token, record its derivation path, then check the constraint list of each input against the derived value. A derived quantity whose inputs were licensed and whose own derivation is undeclared inherits nothing.

### 5. Closing the Loop in Physical Reality

The predictive CAD state is not the final authority. Manufacturing, operation, sensing, and inspection produce a realized state. Let G_p be the predicted typed gradient and G_r the realized typed gradient under matched coordinates and reference conditions. The model discrepancy is epsilon_G = G_r - G_p.

That discrepancy is the true calibration token only when prediction and measurement refer to the same variable, location, time window, unit, boundary, and operating state. A nonzero discrepancy can arise from model error, material variation, tool wear, sensor error, boundary-condition error, unmodeled coupling, probe memory, or incorrect state estimation. The update mechanism must preserve those competing explanations rather than automatically assigning all error to model weights.

#### 5.1 Measurement Commitment Covers the Derivation

Before the realized state is observed, the node records what will be measured: variable, instrument, location, coordinate frame, time window, and acceptance condition.

The commitment must also cover everything between the raw reading and G_r: estimator, preprocessing and filtering, sampling cadence, model version, and uncertainty-propagation rule. Freezing the raw measurement while leaving the processing free means the compared number is still chosen after the fact — the derived-quantity discharge rule of 4.1, applied to the one place it matters most.

A realized value collected without a prior commitment may be recorded and reported, but it cannot license an update. Matching after the fact is selection, and selection among available measurements is indistinguishable from choosing the one that agrees.

#### 5.2 Instrument Licensing

Calibration has no foundation. Calibrating a probe requires a reference, and the reference is another probe. What replaces a foundation is a network: probes that agree, whose failure modes do not overlap.

Independence must therefore mean independent in mechanism of failure, not physically separate housings. Two instruments sharing a clock, a temperature reference, a supply rail, a calibration standard, or a model can agree exactly and be wrong together, and their agreement will read as confirmation. The independence argument is recorded with the calibration, and it names what the probes do not share.

**The probe-memory confound.** Probe memory and hysteresis leave the same signature in the record as system residue: the next result depends on what came before. Averaging does not separate them, and the confound is structural rather than statistical — the framework's central measurand is confounded with the artifact calibration exists to remove. Three variations separate them, because they act differently on the two:

- Hold the probe, change the system. Probe memory persists; system residue changes.
- Hold the system, change the probe. The reverse.
- Vary the inter-probe interval. Two decay constants, belonging to two different objects.

This is a design requirement and not only a procedure. Where the instrument is being designed rather than inherited, design it so its failure modes carry a different signature from the residue being hunted.

**Detection floor.** Every probe carries the smallest residue it has been demonstrated to detect, together with the demonstration that established it. A null result from a probe with no established floor carries no information: it is consistent with there being nothing there and with the probe being unable to see what is there. The floor is what converts a null into a bound.

#### 5.3 Attribution Requires Discrimination

The candidate list — model error, material variation, tool wear, sensor error, boundary-condition error, unmodeled coupling, probe memory, state-estimation error — is not resolved by plausibility, and an attribution made after seeing the discrepancy is a preference unless a probe backs it.

Each attribution must name a probe whose outcome differs across the candidates it separates. Where no such probe exists or none was run, the discrepancy is recorded as unattributed and the update is withheld or reduced. Unattributed is a valid terminal value for the field and must be available in the schema.

**Asymmetry.** One discriminating result can eliminate a candidate. No measurement confirms a candidate outright — surviving candidates stay on the record with the probes that failed to separate them. An attribution field holding a single value with no elimination history is incomplete.

### 6. Sufficiency and the Closure Test

A local nudge can reduce a local gradient by exporting demand across a boundary. The state graph then worsens while every local token improves. The test for that is not another threshold; it is a check on whether the local description is still sufficient after the update.

Procedure:

- Hold parameters after an accepted nudge.
- Predict at the neighbor nodes the coupling map says are reachable across the boundary.
- Measure under a prior commitment per 5.1, with instruments licensed per 5.2.
- Test the residuals at those nodes for structure over the declared window.

Verdicts:

- No export detected: residuals show no structure the probes that ran were able to detect. The compressed local description remains adequate under the scope below, and convergence may be accepted at this node. The verdict is not that no export occurred.
- Export detected: residuals are structured. Demand was moved rather than resolved, or the coupling map is incomplete. Either way the local gradient was flattened against the global state graph and the update is reversed or reduced. Which of the two it is requires a discriminating probe under 5.3.

**Convergence condition.** Convergence is accepted only when local deficits sit within declared tolerance and neighbor residuals show no detected structure across the probe envelope actually run. Both conditions, not the first alone.

**Scope of a sufficiency verdict.** Unstructured residuals license exactly one thing: local closure relative to the fitted model class, the probe envelope run, and the demonstrated detection power. All three are recorded with the verdict. A verdict missing any of the three is not a verdict, because each of them can produce clean residuals from a system that is not closed.

**Revocability.** Adding a probe can revoke a prior verdict. That revocation is information — it says the earlier description was insufficient and nobody had asked the question that showed it — and it is recorded as an envelope expansion rather than as a failed prior result. The converse does not hold: no quantity of non-discriminating probes certifies sufficiency permanently.

Edge admission inherits this revocability, because the verdict that licenses an edge is the verdict revoked here. An edge admitted under one envelope is withdrawn when a later probe detects export across it, and the graph must be able to represent that withdrawal as a recorded change of standing rather than by deletion. An edge that was withdrawn and an edge that was never tested are different objects and must not reduce to the same absence.

#### 6.1 Two Outer Loops

The framework requires two expansions above the local loop, and they are named separately because they fail in opposite directions.

- **Probe envelope expansion.** Tests the current model class against a larger set of questions. Its failure mode is silence: an under-expanded envelope returns sufficiency until the day someone finally asks, and then returns insufficiency honestly and loudly.
- **Model-class challenge.** Tests the class itself. Residual structure in Section 6 is measured against the model that made the prediction, so a model class that cannot represent the residue can return unstructured residuals across an arbitrarily large probe envelope. Its failure mode is a clean false verdict, which is the worse of the two because nothing announces it.

Model-class challenge is therefore a standing obligation, not an occasional prompt: a scheduled comparison of the fitted class against a broader or structurally different class, at a cadence declared in advance under Section 4 like any other policy constant. An obligation without a declared cadence happens when convenient, which is never.

### 7. Exergy and the Same-Bucket Rule

Exergy is a rigorous unifying quantity when the compared subsystems are thermodynamic and share a defined environment or reference state. It measures useful work potential relative to that reference and makes dissipation and irreversibility visible. The supplied integrated-energy paper uses exergy-flow density as a Lagrangian-like quantity for coupled dissipative energy systems, while the supplied soil-restoration paper uses an exergy-based demand model to quantify the work required to close a soil-organic-carbon gap over time.

These papers support exergy as a powerful physical bucket for energy and restoration processes. They do not by themselves establish that software complexity, cognitive load, geometric constraint, and material failure are literally measured in exergy. The framework therefore distinguishes physical exergy from generalized capacity-demand coordinates. A generalized coordinate may be normalized into a dimensionless margin, but it must not be called thermodynamic exergy without a valid mapping.

Normalization does not discharge this rule. Normalizing two incommensurable margins removes their units from the token and moves the conversion into the objective weight that combines them, where it is harder to see. Section 4 governs that case, and 4.1 governs the general form of the evasion.

### 8. Position in the Full Framework

- The ledger is the floor. A precommitted probe and a provenance-sealed record must exist before a prediction error means anything at all; without it, a discrepancy cannot be distinguished from a change in what was asked. This is the framework's single assumed layer, and it is assumed because it is the precondition for iteration rather than a product of it.
- Coupling defines which states can affect which other states across a boundary.
- The state graph preserves current state, history, dependencies, and authority.
- ROPEU defines the adaptive cycle: observation, prediction, error, and update.
- Input licensing establishes that capacity and demand are earned estimates rather than given states.
- The Capacity-Demand Gradient supplies the local steering signal.
- Exergy supplies a physically rigorous common currency where thermodynamic mapping is valid.
- Instrument licensing establishes what the record is able to reveal before the record is used.
- Measurement closes the loop by comparing predicted and realized state under a prior commitment covering the full derivation.
- The closure test decides whether the local description remained sufficient after the update, scoped to class, envelope, and detection power.
- Governance limits what the system may change, how far, and on what evidence.

### 9. Minimum Token Schema

Identity and typing:

- node_id and boundary_id
- domain and variable name
- location, coordinate frame, and time window
- reference state and environmental conditions

Input licensing:

- derivation path for C: raw measurements, instrument, model and version, estimator, uncertainty-propagation rule
- derivation path for D: same fields
- capacity value, demand value, and units

Values:

- deficit, utilization, and selected gradient type
- g_t estimator form, sampling cadence, estimation window W, and standard error
- gradient operator declaration where g_x is reported, or explicit undefined
- horizon tau, projected deficit e_hat_cd, and the tau-versus-W validation record
- uncertainty and confidence

Policy constants, declared before the run:

- objective weights, each typed as physical conversion or policy, with provenance
- horizon tau, estimator window W, step ceiling alpha_max, gradient tolerance tol
- line-search rule, retraction rule, and nonconvex tie-break rule
- matched-regime tolerance band and safety factor or policy margin
- acceptance condition and threshold
- model-class challenge cadence

Update:

- Theta_allowed description and its convexity and closedness declaration
- assignment of every constrained quantity to either Theta_allowed or a soft penalty in J
- steering direction d_n and step alpha_n
- actuability ratio a_n
- step shortening record, if the line search reduced alpha_n
- update applied, reduced, or withheld
- escalation route, if any: constraint-blocked or parameterization failure
- sensitivity audit reference, sample, and rank result, where parameterization failure is claimed

Measurement:

- measurement commitment id and the timestamp at which it was recorded
- committed instrument, variable, window, and acceptance condition
- committed estimator, preprocessing and filtering, sampling cadence, model version, uncertainty-propagation rule
- predicted state and realized state
- discrepancy epsilon_G

Instrument:

- probe id and calibration record
- calibration network and the failure-mode independence argument, naming what the probes do not share
- probe memory and hysteresis variation results
- detection floor and the demonstration establishing it

Attribution:

- error attribution candidates
- discriminating probe named per attribution, or unattributed
- elimination history: candidates ruled out and by which probe

Closure:

- probe envelope run for the closure test
- fitted model class and version
- demonstrated detection power for the residual test
- neighbor residual structure result and sufficiency verdict, scoped to class, envelope, and detection power
- verification method

### 10. Canonical Claim

The Capacity-Demand Gradient is a typed, state-dependent error field that tells a coupled adaptive system where its imposed demand is diverging from its available capacity, and how fast that divergence is arriving. It becomes an actionable steering law when connected to licensed inputs, a bounded objective that sees both present and projected error, hard constraints held in the permitted set rather than in the objective, an update that never leaves that set, declared policy constants fixed before the run, measurement committed before it is taken and committed through its full derivation, instruments whose detection floor is established and whose failure modes are known not to overlap, attribution backed by discriminating probes, and a closure test that can return not-sufficient and is scoped to the model class, probe envelope, and detection power that produced it.

That same list is the graph's admission criterion. The conditions that make the Gradient an actionable steering law at a node are the conditions that make the node representable in a heterogeneous state graph, and the conditions under which a declared relation between two nodes is entitled to function as an edge. The paper therefore states one set of requirements serving two functions. Nothing is admitted to the graph that cannot enter the steering procedure, and nothing enters the steering procedure that has not been admitted. Eligibility for the procedure is the admission requirement; possession of an executable local direction is not, since an admitted node may be visible and unactuable and the procedure's correct return there is escalation. The asymmetry of the preamble carries through: node standing persists until an input is withdrawn, edge standing persists only within the class, envelope, and detection power under which it was granted.

Where the objective registers a regime the authorized parameters cannot move, the correct output is an escalation with an actuability ratio attached, not a nudge.

### 11. Status and Validation Gap

This paper specifies apparatus. No node has been carried through it end to end, and the paper should be scored accordingly.

What R3 does not contain: a case in which a real capacity and a real demand were licensed at a named node, a bounded nudge was applied under declared constants, a realized state was measured under a prior commitment covering its derivation, a discrepancy was attributed by a discriminating probe against an instrument with an established detection floor, and a sufficiency verdict was returned by the closure test.

**Completion condition for a first node.** Exactly one such node, recorded in full, including at least one instance where the typed treatment produced a different action than a scalar threshold would have produced at the same moment. A worked node in which the typed and scalar treatments never diverge does not discharge this, because it demonstrates the machinery running without demonstrating that it was needed.

**What completion does and does not establish.** Completing the node makes the apparatus adjudicable — the claim becomes the kind of thing that can be checked by someone other than its author. It does not by itself validate the steering claim. The node's result can support the typed steering claim, falsify it, or leave it unresolved, and which of the three occurred is a separate verdict recorded under a separate name. A miss discharges the completion condition and counts against the steering claim at the same time; both facts are entered.

Until that node exists, every section above is a specification of how a measurement would be handled, and none of it is evidence that handling measurements this way finds anything.

## Related Work

- **Extends:** Adaptive Operating Code — Adds the typed local error and steering variable used by the update loop.
- **Uses concept from:** Thermodynamic Alignment — Uses exergy where a thermodynamic reference-state mapping is valid.
- **Related to:** The Field — Formalizes the drought-line, flood-line, absorption, and capacity-demand intuition as typed quantitative relations.
- **Uses mechanism from:** Capture Path / pre-promotion probe — Supplies the precommitment-before-execution mechanism adapted in Section 5, and the rule that a result produced outside the declared path is recorded but cannot be promoted.
- **Applied by:** AI CAD / Adaptive Computer — Provides the local signal for bounded parametric changes and model calibration.
- **Supported by:** Exergy as a Unifying Principle — External reference for exergy-flow treatment of coupled dissipative energy systems.
- **Supported by:** Soil Exergy — External reference for dynamic exergy demand to close a restoration gap over time.

## Open Questions

- Which domains can be mapped to physical exergy without category error, and which require only a dimensionless normalized capacity-demand margin?
- What canonical objective function should combine present deficit, projected deficit, reserve, dissipation, uncertainty, safety, cost, and reversibility — and can any of its weights ever be derived rather than declared, or is the policy label permanent?
- What is the discriminating probe for each standard attribution candidate, per domain? Section 5.3 requires one to be named; no catalog exists yet, and without it the requirement will be satisfied on paper and skipped in practice.
- Which statistic tests neighbor-residual structure in Section 6, at what threshold, and with what power against which alternatives? The convergence condition is stated; the test that implements it is not, and the detection-power field in the schema cannot be filled until it is.
- How is a probe's detection floor established in domains where no reference residue of known magnitude can be injected? Injection settles it where a synthetic residue can be added; elsewhere the floor is currently unobtainable and the schema field would sit empty.
- What is the minimum probe envelope that makes a sufficiency verdict worth recording, and on what schedule should the envelope be expanded rather than left where it happened to start?
- What cadence and what comparison class discharge the model-class challenge of 6.1? A cadence too slow makes the obligation nominal; a comparison class too close to the fitted one tests nothing.
- Does g_x admit a canonical operator on dependency graphs, or is it permanently operator-relative and therefore not comparable across nodes?
- What is the sampling design for the sensitivity audit in 3.4, such that absence of sensitivity across the declared operating region is established rather than assumed from a sample of convenient points?

## Revision History

### R4 — August 2, 2026

- **Second function declared: node and edge admission**
  - **What changed:** The preamble now declares two functions and states admission as prior to steering: the licensing, definedness, commensurability, and closure requirements specify when a bounded system may be represented as a node in a heterogeneous state graph and when a declared relation is entitled to function as an edge. The asymmetry between the two admissions is stated — node standing does not expire, edge standing is provisional because the closure verdict that grants it is scoped and revocable — and the ordering is stated as a prohibition rather than a preference: a nudge computed at an unlicensed node or transmitted along an unadmitted edge is not an update at all. Section 6's revocability clause is extended to edge admission, with the requirement that a withdrawn edge and an untested edge remain distinguishable in the record. Section 10 states that the same requirement list serves both functions. No new apparatus, no new schema fields, no new policy constants, no change to any section numbering.
  - **Forcing error:** R3 opened by calling the Gradient "the local steering variable of the framework" and never revised that description. The paper's requirements had been operating throughout as admission conditions for a heterogeneous state graph, and that function was nowhere declared. A reader building the graph from R3 would take the requirements as preconditions for a control law and would find no statement of what entitles a node to be a node or a relation to be an edge — and in particular no statement that the two entitlements carry different grades of permanence, which is the failure with consequences, since a graph that cannot distinguish a revoked edge from an untested one will read structure into an absence.
  - **Verification:** Not verified by measurement. No node has been run, and this revision adds nothing that could be run — that is deliberate, since the outstanding condition is a completed node and not a longer specification. Internal checks only: every clause of the admission statement names a requirement already binding in R1–R3 (input licensing 1.2, definedness 1.1, same-bucket 7, derived-quantity discharge 4.1, closure test and scope 6); no requirement is introduced that was not already in force; the token schema in Section 9 is unchanged; the enumeration of free policy constants in Section 4 is unchanged; Section 11 and its completion condition are unaffected and remain outstanding. The claim that one requirement list serves two functions is asserted, not demonstrated, and its demonstration is the same first node.

- **Correction within R4 — same day, prior to any run**
  - **What changed:** Two sentences introduced earlier in R4 were replaced. The canonical claim's "nothing is admitted to the graph that could not be steered, and nothing is steered that has not been admitted" became "nothing is admitted to the graph that cannot enter the steering procedure, and nothing enters the steering procedure that has not been admitted," with eligibility for the procedure named as the admission requirement and possession of an executable local direction explicitly excluded from it. The preamble's "the steering law has no output at a node that has not been admitted" became "no *authorized* output," with production and authorization named as different acts and an inadmissible result given a recorded type.
  - **Forcing error:** The first sentence contradicted Sections 2 and 3.4. A node may be fully licensed, representable, and diagnostically important while carrying no authorized direction with nonzero sensitivity; the paper defines that condition as visible-but-unactuable and defines escalation as its correct output, not as a failure. Requiring steerability for admission would have excluded from the graph exactly the nodes the approaching-cliff regime exists to catch. This is the same collapse R3 repaired at the level of the objective — R2 asserted that representation in J produces a steering gradient, R3 corrected it with the two-level visible/actuable rule — reintroduced one layer up in the canonical claim by the revision that was meant to be additive only. The second sentence conflated a mechanically produced number with an authorized one in a paper whose governing separation is between proposal and authorization.
  - **Verification:** Not verified by measurement. Internal checks only: the canonical claim was read against Sections 2, 3.4, and 6 for consistency of the admission and actuability categories; the actuability ratio, the two-way escalation split, and the sensitivity-audit requirement are unchanged and now consistent with the canonical claim rather than contradicted by it; no schema field, policy constant, or section number changed. Recorded as a correction rather than applied silently, because the same-day interval does not license a quiet edit and the record should show that the error occurred and was caught.

### R3 — July 28, 2026

- **Visible versus actuable, feasible-step update, input licensing, instrument licensing, model-class obligation**
  - **What changed:** Section 3 splits into subsections. The claim that a represented regime produces a steering gradient is corrected to the two-level visible/actuable rule, with the actuability ratio a_n as its magnitude and a two-way escalation split, the parameterization-failure branch now requiring a sensitivity audit across the operating region rather than a single blocked point. The update is restated as a tangent-cone direction with a bounded feasible step under a declared retraction or a backtracking line search, with convexity and closedness declared and point-projection explicitly rejected. Hard constraints move out of J into Theta_allowed. Horizon tau and estimator window W are declared jointly under three recorded requirements rather than an inequality. New 1.2 licenses C and D as derived estimates. New 4.1 states the derived-quantity discharge rule. 5.1 extends the measurement commitment to cover estimator, preprocessing, cadence, model version, and uncertainty propagation. New 5.2 licenses instruments: failure-mode independence, the probe-memory confound and the three variations that separate it from system residue, and the detection floor. Section 6 verdict language changes to no-export-detected and is scoped to model class, probe envelope, and detection power. New 6.1 makes model-class challenge a scheduled obligation distinct from envelope expansion. Section 8 names the ledger as the framework's floor. Section 11 separates completing the first node from validating the steering claim. Schema regrouped and extended. Section numbering is unchanged from R2.
  - **Forcing error:** R2 asserted that a regime represented in the objective produces a steering gradient. That is false: nabla_theta e_hat_cd = nabla_theta e_cd + tau nabla_theta g_t, and both terms can vanish over the authorized directions, or the projection can remove the direction carrying them. R2 therefore guaranteed that the approaching cliff was visible and silently guaranteed that the controller could act on it. Related: the update equation described P as projecting the proposed change while applying it only to the gradient, leaving the finite step unlicensed on any curved or nonconvex permitted set; hard constraints were listed inside J while also defining the permitted set, double-counting them; the measurement commitment covered the raw value but not the derivation that produces the compared quantity, so precommitment was defeated one layer up for the third time in three revisions; and C and D were treated as given inputs in a paper whose entire argument is that quantities must be licensed.
  - **Verification:** Not verified by measurement — no node has been run. Internal checks only: every regime in Section 2 now has both a visibility path and a defined output when unactuable; every free constant in the loop is enumerated in Section 4 and carried in the schema; every constraint is assigned to exactly one of Theta_allowed or J; every step remains inside the permitted set by construction rather than by correction; every attribution either names a discriminating probe or is marked unattributed; every null result requires a detection floor before it counts; every sufficiency verdict carries its class, envelope, and power. The three-times-repeated evasion of Section 4.1 was checked against all quantities currently in the schema. A worked node remains outstanding and is the stated completion condition.

### R2 — July 28, 2026

- **Horizon term, precommitment, discriminating attribution, closure test**
  - **What changed:** The objective now takes a projected deficit at a declared horizon, so approach rate reaches the update law. New Section 4 governs objective weights and all free policy constants under a precommitment rule. Section 5 adds a measurement commitment recorded before the realized state is observed, requires a named discriminating probe per attribution, admits unattributed as a terminal value, and states the elimination asymmetry. New Section 6 supplies the convergence condition that was Open Question 4, as an envelope-relative and revocable sufficiency verdict. Section 1 adds a definedness clause separating the domain-general members from the conditional ones. Section 7 notes that normalization relocates a conversion rather than removing it. The schema is regrouped and extended. New Section 11 records the validation gap and fixes the acceptance condition for the next revision. Sections renumbered: old 4-8 became 5, 7, 8, 9, 10.
  - **Forcing error:** The update law could not see the regime the paper called most important. Approach rate g_t was computed in the observe step and never appeared in J, so the engine steered on present error and was blind to the approaching-cliff regime by construction. Two related errors: cross-domain weights inside J performed exactly the unit conversion the same-bucket rule forbids one layer down, with no requirement to declare them; and error attribution was performed after the discrepancy was seen, with no prior measurement commitment and no requirement that a probe separate the candidates, which made the preserved candidate list a formality.
  - **Verification:** Not verified by measurement. Internal checks only: every regime in Section 2 had a nonzero path into the objective; every free constant was enumerated and carried in the schema; every attribution named a discriminating probe or was marked unattributed; the convergence condition was stated as a test that can return not-sufficient.

### R1 — July 14, 2026

- **First issue**
  - **What changed:** Combined the Capacity-Demand Gradient proposal with mathematical disambiguation, exergy scope limits, bounded gradient updates, and predicted-versus-realized calibration.
  - **Forcing error:** The initial formulation used gradient, zero balance, and exergy too broadly, risking collapse of deficit, ratio, derivative, spatial gradient, and thermodynamic work potential into one term.
  - **Verification:** The paper now separates each mathematical object, preserves domain units and reference states, and treats exergy as physically authoritative only where a valid thermodynamic mapping exists.
