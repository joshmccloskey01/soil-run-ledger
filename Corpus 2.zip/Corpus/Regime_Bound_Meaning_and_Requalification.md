<!-- Working paper. Document ID: REGIME-BIND. Sequence: 1. -->

# Regime-Bound Meaning and the Limits of Requalification

**Author:** Josh McCloskey

**Document Type:** Working paper

**First Issued:** August 12, 2026

**Current Revision:** R1

**Last Revised:** August 12, 2026

**Status:** Active working paper — derived architecture, no implementation

*The body is the current model, read as it now stands. The complete revision history is at the back.*

> **Scope boundary.** This paper covers one seam: how a governed-loop event binds to the regime that authorized it, how historical meaning is later derived, what a counterfactual replay may and may not establish, and how far that verification structure transfers to systems with no canonical state object. It is not a statement of the wider framework. Nothing here is implemented; the ledger primitives it relies on are.

---

## 1. The seam

Three things exist that are frequently confused:

| | Object | Status |
|---|---|---|
| 1 | **Regime subsystem** — regime objects, derivation, historical-versus-current interpretation, amendment interaction | Built (`regime.py`, tests green) |
| 2 | **Binding contract** — a governed event carries the identity of the regime that authorized and interprets it | Specified (trace record contract §6.2, `regime_digest` on PolicyDecision) |
| 3 | **Binding implementation** — the runtime resolves the applicable regime at commit, writes that digest into the event, and later reconstruction resolves by the recorded digest | **Missing** |

The third is the seam. It requires no new regime architecture. The contract exists and the subsystem exists; the missing work is the connection between them.

The governing invariant:

```
meaning(e) = D(e, R_recorded_on_e)
```

not

```
meaning(e) = D(e, R_current)
```

unless the operation explicitly asks for current-policy reinterpretation rather than historical reconstruction.

Without the binding, event contents remain append-only while their interpreted meaning drifts as policy changes. The ledger proves occurrence and order; it does not prove comparability.

---

## 2. Commit-time regime provenance

Storing `regime_digest` is not sufficient. The recorded digest must be the regime that actually governed the authorization, not one read shortly beforehand.

This sequence is invalid:

```
read R_a  →  authorize under R_a  →  promotion to R_b  →  commit(e, R_a)
```

The record then says the event was governed by `R_a` while the authoritative state at admission was already `R_b`. Append-only in form; false provenance in fact.

The required property:

```
R_authorized = R_recorded = R_authoritative_at_successful_commit
```

The commit must establish one indivisible fact — `(e, R_d, authorization under R_d)` — or fail. If the regime head moved between authorization and commit, the commit fails and retries rather than silently admitting a stale decision.

**No new primitive is needed.** `append` already performs compare-and-swap against `expected_head`, and `lease.py` supplies fencing tokens. The work is bringing the regime head inside the same CAS rather than reading it alongside. The equality above then becomes a property the commit either establishes or does not, with no third outcome.

---

## 3. Derivation-time regime semantics

Three questions exist. They are not interchangeable, and the distinction must live at the function boundary rather than in documentation, because the return value alone cannot expose substitution of the wrong regime.

```
derive_historical(event_id)
    What did this event mean under the regime actually recorded with it?

derive_current(event_id, current_regime)
    How does the current regime assess this historical event?

derive_counterfactual(event_id, alternate_regime)
    What follows if this historical prefix is replayed under an
    explicitly chosen other regime?
```

There should be no generic `derive(event, regime)` API if it can be avoided. The regime relationship is part of the semantic operation, not an argument to it.

**`derive_historical` takes no regime argument.** This is the strongest of the three signatures: the recorded regime is not caller-selectable, it is recovered from the event's provenance, and substitution is therefore impossible at that boundary.

A mode enum with a required argument is weaker than distinct entry points, because a wrapper can fill in the mode and reintroduce the default one layer up.

### 3.1 The counterfactual return type

Counterfactual replay differs from the other two in that its valid output domain is a prefix, not necessarily a complete derivation. Once replay under the alternate regime reaches the first point where a different constitutive event would have been produced, the historical suffix is no longer admissible as part of that branch. It remains fact about what happened; it is not a valid continuation of the counterfactual execution.

A wrapper-level warning is too weak. `result.valid_prefix[-1]` turns a qualified intermediate state back into something that can masquerade as a completed reconstruction. The truncation must survive arbitrary unwrapping, which requires a distinct type — `CounterfactualPrefixState` — that is not accepted anywhere a completed reconstruction is required.

### 3.2 Two outcomes, not one with an optional field

A complete non-divergent replay supports a materially stronger claim than a truncated one and must not share its type:

```
CounterfactualReplayResult =
    CounterfactualDiverged(
        alternate_regime_digest,
        valid_prefix,        # qualified counterfactual states
        first_divergence
    )
  | CounterfactualEquivalentOnTrace(
        alternate_regime_digest,
        completed_trace
    )
```

The first supports only: *under R_x, the historical execution remains valid through prefix P; beyond the first divergence, no claim is made.*

The second supports: *under R_x, replay of the entire observed trace produced no behavioral divergence from the recorded path.*

That is trace-relative, not global. The phrase **"equivalent on this trace"** should be preserved verbatim, because it is the one place a status could inflate silently into "the regimes are equivalent."

### 3.3 The relation is directional

Even `≡_T` is misleading if read as symmetric. What replay establishes is that the alternate regime admitted the same continuation at every tested point, given the states and decisions that actually occurred:

```
R_alt ⊨_T P_recorded
```

It does not test states that never occurred, branches the recorded regime never entered, trajectories the recorded regime terminated before producing evidence, or whether the recorded regime would admit everything the alternate admits.

The human-readable claim: *alternate regime R_a reproduced the recorded decision path over the exercised portions of trace T, with no divergence.* Harder to inflate than "the regimes were equivalent on the trace."

---

## 4. What a clean replay does not establish

Non-divergence is evidence only where divergence had an admissible opportunity to occur. Two separate failures produce a clean result for reasons that cannot be distinguished from the result alone.

### 4.1 Path coverage

Coverage is a property of the alternate-regime × recorded-trace pair, not of the amendment:

```
C_path(R_alt, T_recorded) = { decision points on T where R_alt ≠ R_recorded could have mattered }
```

An empty coverage set means only: *this recorded history did not exercise any decision point where the amendment could affect the traversed path.* It does not mean the amendment is irrelevant. The changed rule may matter only in states the recorded regime never reached, branches it never admitted, or trajectories it terminated before they could appear.

```
path-relative non-exercise  ≠  amendment irrelevance
```

Only the first is inferable from replay. Without this distinction, "10,000 events, zero relevant decisions" can masquerade as stronger evidence than "20 events, 12 direct probes of the amended rule."

### 4.2 Directional discrimination

Visiting an affected decision point is not enough. The point must be able to falsify the amendment *in the direction the amendment moved*.

If the alternate regime is strictly more permissive at `d_i` and the recorded action was allowed by both, replay proves only that the alternate does not reject this recorded action. It says nothing about the region the alternate newly admits:

```
R_recorded ⊂ R_alt,  identical outcome on trace  ⇒  R_alt \ R_recorded untested
```

That is the silent-permissiveness hole, arriving inside replay.

Classification per exercised point:

| Label | Meaning |
|---|---|
| `UNCHANGED_RULE` | both regimes make the same rule-level determination; contributes ~nothing |
| `AFFECTED_NONDISCRIMINATING` | amendment live here, but the recorded case lies in the overlap |
| `AFFECTED_DISCRIMINATING` | the case touches the boundary where the amendment could have decided differently |
| `DIVERGED` | it did |

### 4.3 The evidentiary object

```
( R_alternate, T_recorded, C_path, Q_discrimination, D_outcome )
```

Allowable claims are then mechanically bounded:

- empty `C_path` → "not exercised on this trace"
- non-empty `C_path`, zero discriminating points → "exercised but not discriminating"
- discriminating points, no divergence → "alternate reproduced the recorded path over the tested changed region"
- divergence → valid only to first divergence

Complete replay is not sufficient. **Complete + relevant exercise + directional discrimination + no divergence** is the evidentiary object.

---

## 5. Where the classification comes from, and what it costs

`Q_discrimination` requires saying that one regime is *strictly more permissive* at a point. Two regimes represented as opaque canonicalized bytes support digest equality and nothing else. Identity does not carry semantics:

```
canonical regime → digest identity              (persistence, provenance)
structured regime → rule-level comparison → Q   (requalification layer)
```

The ledger need not understand what "more permissive" means. It needs only to preserve exactly which regime governed the event. A requalification layer resolves the digest to an immutable structured regime and applies a comparison contract producing relations such as unchanged, narrowed, widened, altered-but-unordered.

**If that comparison is unavailable, no point may be called discriminating.** The honest default is `AFFECTED_NONDISCRIMINATING`, which collapses the third bullet of §4.3 into the second. Semantic ignorance must not be converted into evidentiary confidence.

---

## 6. Why the probe family is structurally separate

Replay can evaluate evidence; it cannot create missing evidence.

Discriminating points arrive only if the recorded history happened to contain them. Nothing in passive replay generates a probe. A regime whose amended region is systematically underrepresented in normal operation returns "exercised but not discriminating" indefinitely — never failing, never accumulating evidence. That is not small sample size; it is an observability defect in the evidence-generation process.

So the gate cannot be `amend → replay → no divergence → qualify`. It needs two channels:

```
Passive replay      Did the alternate preserve the recorded path where history exercised it?
Active probe family What happens in the changed region, including the direction ordinary
                    history may never expose?
```

This is the same structure as a **floor**. A ceiling can often be detected from observed violations; a floor cannot be inferred from the absence of violations, because the required demand may simply never have occurred. It must therefore be an externally enforced requirement on evidence production rather than something read off results.

The probe family is not "more testing." It is the mechanism that prevents structurally unobservable permissiveness from qualifying by silence.

**Build order** (among the governed-loop additions, not absolute chronology):

1. Regime binding and comparison seam
2. Probe-family machinery
3. Requalification gate

Without #2, #3 can only certify historical compatibility, not the absence of newly introduced permissiveness.

---

## 7. The probe family inherits the same hole one level down

Probes are constructed against the amended region *as the comparison contract represents it*. A widening the comparison layer cannot name produces no probes and no failures — the same silence, moved up a layer.

```
regime representation → comparison coverage → changed-region identification
                      → probe generation → requalification evidence
```

A failure upstream makes every downstream stage look clean. `Q_discrimination = 0` is therefore ambiguous unless provenance says which:

- changed region represented, no discriminating case occurred, or
- changed region never represented, so no discriminating case could be generated

The comparison contract needs an explicit, auditable coverage claim over the structured regime it consumes:

```
P_represented ⊆ P_regime          (what is claimed)
P_represented = P_regime          (the floor, for every behaviorally relevant parameter)
```

Where equality cannot be established, the uncovered set `P_regime \ P_represented` remains an explicit verification gap. It cannot disappear into "no differences found." No number of successful probes can demonstrate the comparator omitted a parameter, because the omitted parameter is outside the machinery generating the evidence.

**Provenance sentence, to survive verbatim:**

> Probes are discriminating only up to the parameters the comparison contract enumerates; common-mode uncertainty begins at the regime representation.

Hierarchy of failure modes:

| Failure | Repair |
|---|---|
| history didn't exercise it | active probes |
| probes didn't target it | comparison coverage |
| the regime representation omitted it | **not repairable from inside this chain** |

The last requires an external specification, schema audit, independent implementation, or other non-common-mode witness. The system can preserve provenance up to that boundary; it cannot bootstrap proof of its own representational completeness from outputs generated by that representation.

---

## 8. One internal witness, and its limit

Representational completeness has a partial check that is not proof but is not nothing.

The regime object is canonicalized and hashed. A parameter that affects governed behavior and lies inside the canonicalized bytes moves the digest when it changes. So:

```
H(R_a) ≠ H(R_b)  ∧  diff_{P_represented}(R_a, R_b) = ∅
```

is the signature of `P_regime \ P_represented` being non-empty — the identity layer registering a change the semantic layer cannot name. Status: `UNEXPLAINED_REGIME_DELTA`, recorded as part of the verification record rather than resolved.

**Contract check, not completeness proof:** every regime digest transition must be fully accounted for by named semantic differences. Any unexplained remainder is registered as a verification gap.

The check is **one-sided**, which is what makes it usable as a gate. Identical digest with an empty diff is genuinely clean, because a parameter inside the canonicalization cannot change without moving the hash. The only false clean is a behaviorally relevant parameter omitted from the canonical regime itself — where digest and comparator share the omission. That is the common-mode boundary.

Two layers that fail independently; their disagreement is readable. No layer certifies the one below it, and the residual is the diagnostic.

---

## 9. Transfer to Adaptive Earth

Adaptive Earth needs proxies for slow debt precisely because it cannot wait for the consequence; the framework says a proxy earns trust only by repeatedly predicting that consequence. That tension is real but smaller than it appears, for two reasons.

### 9.1 Authority is directional

"How much authority does an unvalidated proxy deserve" is malformed, because it treats authority as one quantity. Denial and permission fail in opposite directions with opposite costs:

- **False denial** → foregone opportunity. Observable, bounded, usually reversible.
- **False permission** → hidden debt admitted as affordable. Delayed, distributed, often irreversible before the error is legible.

Therefore:

```
weakly validated proxy  ⇒  high possible denial authority + low permission authority
```

This is not extra conservatism. It follows from the floor: absence of detected debt is not evidence that debt is absent. A proxy reading clean without validation in the relevant region is epistemically the `Q_discrimination = 0` case and cannot license expansion.

"The governor decides permission, not truth" is what makes the asymmetry coherent. The governor need not assert *this proves danger exists*; only *the evidence required to authorize expansion is not present*.

```
failure to establish safety  ≠  proof of danger
failure to establish danger  ≠  permission to expand
```

The second line is the one Adaptive Earth needs stated explicitly, because it is the direction absence-of-evidence normally gets read.

### 9.2 Retrodiction removes most of the waiting problem

Validation does not require starting today and waiting fifty years. Given reconstructible historical state, test `P(1970) → D̂(2020)` against `D_observed(2020)`.

That is structurally the same operation as regime replay: historical state + candidate rule → replay → compare with realized path. All the same limits transfer unchanged — only paths history traversed, no active planetary probes, discrimination bounded by `P_represented`.

```
regime requalification  ≅  civilization proxy qualification
```

Both: historical replay → path-relative coverage → directional discrimination → residual and common-mode boundary. The civilization problem is not a new epistemic species. It is the same verification problem at a scale where active probing is much weaker.

### 9.3 Where the transfer breaks

The regime case has a witness the civilization case does not. §8 works because the regime is a bounded, canonicalized object; an unrepresented change still moves the hash. **A planet has no canonical form and no digest.** There is no identity layer independent of the model against which "world changed ∧ model says nothing changed" can be tested.

The closest substitute is disagreement among independently constructed representations:

```
Regime case:     residual via digest/semantic disagreement    (detects one class of omission internally)
Adaptive Earth:  residual via representational disagreement   (cannot)
```

Observability must be *purchased* through diversity, and the amount purchased is limited by how independent those representations actually are. Two climate models sharing state variables, priors, calibration data, causal assumptions, and objective structure are not two strong witnesses because their codebases differ. What matters is different variables, causal decompositions, boundaries, timescales, measurement systems, failure assumptions.

Adversarial review is therefore stronger read as *require independently constructed representations whose residual disagreement remains visible* than as *have another controller critique this score*. It still cannot manufacture independence; common mode simply begins higher up.

**Terminal statement for Adaptive Earth:**

> Debt estimates are supported only over the historical regions exercised, the parameters represented, and the representational diversity actually present among the models. Agreement beyond their shared common mode is not independent confirmation.

This is a genuine architectural difference, not a scale effect.

---

## 10. Divergence and convergence are not symmetric

If two representations disagree, something is learned **for free**:

```
at least one representation is insufficient for the question posed
```

That conclusion does not require independence. Shared assumptions do not erase a visible contradiction.

If they agree, evidentiary value depends heavily on shared common mode:

```
agreement strength  ∝  representational independence
```

**Convergence is expensive; divergence is cheap.** This reverses the usual reading, where agreement feels reassuring and disagreement feels like noise. Under this accounting, agreement is possibly redundant evidence and disagreement is definite unresolved structure.

Consequently, reporting an ensemble spread as a confidence interval converts a flag into a number. If model A says +10 and B says −10, `0 ± 10` is statistically convenient and has changed the object. Do not collapse representational disagreement into a consensus statistic unless the models are commensurable for the question being asked; otherwise preserve `(M₁(x), …, Mₙ(x))` and the disagreement itself as state.

This is the general form of *never silently average dissimilar sources*.

### 10.1 The commensurability gate

The primitive is not "two outputs differ." It is:

```
same question  +  both models claim jurisdiction  +  different answers
```

If one model is outside its validity domain, or the outputs refer to different quantities, scales, horizons, or operational definitions, the apparent disagreement is malformed — there are not yet two competing answers. Shared vocabulary does not confer a common measurement object.

The gate is symmetric:

| Same question? | Divergence | Averaging | Convergence |
|---|---|---|---|
| Yes | informative | erases structure | evidence, discounted by common mode |
| No | not licensed | not licensed | — separate the questions first |

Final form:

> **Commensurable divergence is evidence of insufficiency for the question posed.**
> **Commensurable convergence is evidence only to the extent the witnesses are independent.**
> **Question identity must be established first.**

---

## Related Work

- **Extends:** Trace Record Contract §6.2 — `regime_digest` on PolicyDecision is the binding contract this paper implements.
- **Extends:** Irreversible Ledger Contract — supplies the CAS and fencing primitives §2 relies on; guarantees occurrence and order, not comparability.
- **Uses concept from:** AI Qualification Frontier Freeze Record — probe-family requirement, requalification gate, silent-permissiveness open item, graded-margin gap.
- **Applies to:** Adaptive Earth / Level 5 — §9 transfers the verification structure and identifies where it breaks.
- **Constrained by:** The Same Structure Found Seven Times §2 — independence is a degree; the provenance sentences here follow that limit's required form.
- **Related to:** The Computer §25 — structural damage, process cost, and debt as three ledgers; damage-free regulation.

## Open Questions

- What exactly must be inside the CAS for §2's equality to hold under concurrent promotion — regime head only, or regime head plus lease epoch?
- Should `CounterfactualEquivalentOnTrace` carry `C_path` and `Q_discrimination` in its type, so a non-exercised complete replay cannot be constructed at all?
- Can a probe family be generated automatically from a structured regime diff, or does probe construction require domain knowledge the comparison contract does not hold?
- What is the minimum representational diversity that makes convergence carry non-trivial evidence, and can it be stated other than qualitatively?
- Is there any analogue of the §8 one-sided witness for non-canonical systems, or is representational disagreement strictly the best available?
- How should a proxy's denial authority be bounded, given that unbounded denial authority is itself a failure mode?
- Does the commensurability gate admit a mechanical test, or does question identity always require a judgment outside the machinery?

## Revision History

### R1 — August 12, 2026

- **Scope error corrected: "regime layer not built"**
  - **What Changed:** Separated the regime subsystem (built), the binding contract (specified), and the binding implementation (missing). Established that the outstanding work is a schema/wiring seam, not a new subsystem.
  - **Forcing Error:** "Regime layer *(not built)*" in the ledger_core README described the stripped package after `regime.py` had been intentionally removed. This was read as the state of the baseline system. `test_regime.py` passing in the same session was direct contradictory evidence, so repeating the claim afterward was a reconstruction failure, not artifact ambiguity. The error propagated into a second misstatement: that the freeze record "puts the regime layer first in the build order," which can only mean first among governed-loop additions.
  - **Verification:** `run_all.py` on `ledger_baseline_v1` returns BASELINE GREEN across nine modules including `test_regime.py`; the contract file hashes identically across all three archive copies.

- **Commit-time atomicity required**
  - **What Changed:** Storing `regime_digest` was shown insufficient. Required `R_authorized = R_recorded = R_authoritative_at_commit`, enforced by bringing the regime head inside the existing CAS.
  - **Forcing Error:** A read-then-commit sequence with a promotion in between produces an event with correct form and false provenance, and nothing in the record objects.
  - **Verification:** `append` already CASes on `expected_head` and `lease.py` supplies fencing tokens, so the primitive exists; the property is achievable without new architecture. Untested — no implementation.

- **Derivation paths separated at the function boundary**
  - **What Changed:** Three non-interchangeable entry points, with `derive_historical` taking no regime argument.
  - **Forcing Error:** Two documented conventions around one generic `derive(event, regime)` cannot expose substitution, because the wrong call and the right call return the same shape. A mode enum is weaker than distinct signatures because a wrapper can restore the default.
  - **Verification:** Argument-level: the historical form has nothing for a caller to pass wrongly. Not implemented.

- **Counterfactual replay given its own type and a tagged union**
  - **What Changed:** Qualified prefix states as a distinct type; `CounterfactualDiverged` separated from `CounterfactualEquivalentOnTrace`.
  - **Forcing Error:** A wrapper-level truncation flag is shed by `result.valid_prefix[-1]`. Separately, a complete non-divergent replay and a truncated one returned the same type with `divergence=None` meaning something different, allowing the weaker result to support the stronger claim.
  - **Verification:** Structural. The distinct-type route makes the limitation survive arbitrary unwrapping; the union makes the two claims non-substitutable.

- **Coverage and directional discrimination added**
  - **What Changed:** The evidentiary object became a five-tuple; the four-way classification per exercised point was introduced.
  - **Forcing Error:** First, a long clean trace that never reached the amended region produced the same verdict as a short trace that probed it directly. Second, an amendment that is strictly more permissive can be exercised at points lying in the overlap, producing non-divergence while the newly admitted region is entirely untested.
  - **Verification:** Each bullet in §4.3 maps to a distinct combination of the tuple; the bounds are mechanical once the tuple is populated.

- **Coverage relocated from amendment to pair**
  - **What Changed:** `C_path` stated as a property of `(R_alt, T_recorded)`, not of the amendment.
  - **Forcing Error:** An empty coverage set was readable as "this change does nothing" when it means "this history never asked." The amendment may bite only in states the recorded regime never reached.
  - **Verification:** Follows from replay traversing only the recorded path.

- **Comparison layer separated from identity layer**
  - **What Changed:** Established that `Q_discrimination` requires structured regime semantics the digest deliberately does not expose, and that the honest default without it is `AFFECTED_NONDISCRIMINATING`.
  - **Forcing Error:** The four-way classification cannot be computed from canonicalized bytes; without the separation, semantic ignorance converts into evidentiary confidence.
  - **Verification:** Digest equality supports only equal/not-equal. Stated, not built.

- **Probe family shown structurally separate from replay**
  - **What Changed:** Two evidence channels rather than a better replay; build ordering derived rather than asserted.
  - **Forcing Error:** Passive history can hold `C_path > 0` and `Q_discrimination = 0` indefinitely. That is an observability defect in evidence generation, not a sample-size problem, so no accumulation of history repairs it.
  - **Verification:** Same argument form as the floor in the biological adaptation paper: a bound whose violation cannot report itself must be externally enforced.

- **Probe family shown to inherit the hole one level down**
  - **What Changed:** Comparison-contract coverage stated as its own floor; provenance sentence fixed.
  - **Forcing Error:** Probes are generated against the region as represented, so a widening the comparator cannot name yields no probes, no failures, and a clean result. `Q_discrimination = 0` is ambiguous between "not exercised" and "not representable."
  - **Verification:** Terminates correctly — the last layer is not repairable from inside, and the provenance sentence names where common mode begins rather than claiming independence.

- **One-sided internal witness added**
  - **What Changed:** `UNEXPLAINED_REGIME_DELTA` as a contract check on the comparison layer.
  - **Forcing Error:** Representational completeness appeared entirely unfalsifiable from inside. It is not: a canonicalized parameter cannot change without moving the digest, so digest change with an empty semantic diff is a readable signature of omission.
  - **Verification:** One-sided by construction, which is what makes it usable as a gate. Does not reach parameters outside the canonical regime; that boundary is stated.

- **Transfer to Adaptive Earth, with the break located**
  - **What Changed:** Directional authority; retrodictive validation; structural equivalence of regime requalification and proxy qualification; loss of the canonical witness at civilization scale.
  - **Forcing Error:** "How much authority does an unvalidated proxy deserve" treats authority as one scalar, which hides that denial and permission fail with opposite costs. Separately, the apparent need to wait fifty years for validation ignored retrodiction.
  - **Verification:** The asymmetry follows from the floor already established in §6. The equivalence holds through coverage, discrimination, and residual, and breaks at the witness layer — which is a genuine architectural difference, not a scale effect.

- **Convergence/divergence asymmetry and the commensurability gate**
  - **What Changed:** Divergence established as independence-free evidence; convergence discounted by common mode; question identity made a precondition for both.
  - **Forcing Error:** Representational diversity was being priced as if it governed all ensemble information, when it governs only convergence. Then the reverse: divergence stated without a jurisdiction condition licenses spurious insufficiency when two models answer different questions under a shared label.
  - **Verification:** Same test in both directions — are these answering the same question. Fail it and neither disagreement nor averaging is licensed.
