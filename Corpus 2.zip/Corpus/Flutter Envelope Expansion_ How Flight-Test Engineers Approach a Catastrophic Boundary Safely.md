# How Flight-Test Engineers Expand the Flutter Envelope Without Crossing a Catastrophic Boundary

## TL;DR

- Flutter clearance works by **predicting the boundary analytically, then verifying it experimentally from a safe distance**: engineers hold a stabilized flight condition, apply a small bounded excitation, measure modal frequency and damping, extrapolate a stability trend/margin toward the still-uncrossed boundary, and only then step to the next condition — the “build-up approach.” [SOURCE]
- The single most authoritative observable is **modal damping (and margin parameters derived from it) trending as speed/Mach increases**; certification standards fix the go-criteria (FAR/CS 25.629: 15% equivalent-airspeed margin above V_D/M_D and no large/rapid loss of damping; MIL-A-8870 adds a 3% structural-damping floor). [SOURCE]
- The method deliberately **never probes to failure**: it substitutes prediction + margin + trend-extrapolation + small steps for boundary-crossing, because subcritical damping cannot be reliably extrapolated and “hard”/explosive flutter can collapse damping in a few knots — a limitation proven by fatal cases (Lockheed Electra whirl flutter; DAST ARW-1). [SOURCE/SYNTHESIS]

-----

## Key Findings

1. **Analytical prediction is necessary but never sufficient** for final envelope clearance; flight test is the required final verification (FAR 25.629(e) mandates full-scale flight flutter tests to V_DF/M_DF). [SOURCE]
1. **The operative control logic is sequential, not jointly optimal**: stabilize → excite → measure → identify → compare-to-prediction → clear/hold/retreat. Stabilization and excitation are deliberately separated in time. [SOURCE]
1. **Damping is the early-warning variable**, but a fallible one: it can drop abruptly (hard flutter, transonic dip), so modern practice augments raw damping with margin parameters (Zimmerman–Weissenburger flutter margin) and model-based worst-case tools (Lind–Brenner flutterometer). [SOURCE]
1. **Clearance is governed, not ad hoc**: test cards, build-up increments, Test Hazard Analyses, Safety Review Boards, real-time telemetry rooms, and documented go/no-go damping thresholds (commonly ~3% net) form the governance layer. [SOURCE]
1. **The mapping to dual control is partial**: the excitation input is genuinely a probing signal that generates information, but flutter clearance is best described as sequential experiment-design/system-identification under a hard safety constraint, not a jointly optimal Feldbaum dual-control law. [SYNTHESIS]

-----

## Details

### 1. DEFINE THE PROBLEM

A **flight envelope** is the closed region of flight conditions — usually plotted in altitude vs. airspeed/Mach, or equivalently Mach vs. dynamic pressure — within which an aircraft is approved to operate. [SOURCE] Expanding or “clearing” it experimentally means demonstrating, condition by condition, that the aircraft is free of instabilities out to (and beyond, by a margin) the operational limits.

Distinctions the literature enforces:

- **Design envelope**: the V_D/M_D (design dive) boundary the structure is designed to. [SOURCE]
- **Predicted envelope**: where analysis (FEM + unsteady aero + flutter solution) says instabilities lie. [SOURCE]
- **Demonstrated/cleared envelope**: the subset actually verified by flight test to have adequate damping. [SOURCE]
- **Structural limits** (stress/load), **aerodynamic limits** (buffet, stall, control effectiveness), **aeroelastic/flutter limits** (dynamic instability from aero–elastic–inertia coupling), and **operational limits** (placarded limits, usually inside all of the above). [SOURCE/DERIVED]

Why analysis alone is insufficient: FAR 25.629 states compliance may be by analysis and/or test, but §25.629(e) still **requires** full-scale flight flutter testing to V_DF/M_DF for new type designs. [SOURCE] Kehoe (NASA TM-4720, *A Historical Overview of Flight Flutter Testing*) states flight flutter testing “provides the final verification of the analytical predictions throughout the flight envelope,”  precisely because unsteady transonic aerodynamics, structural damping, freeplay, and control-system coupling are imperfectly modeled. [SOURCE]

### 2. FLUTTER SPECIFICALLY

Flutter is a **self-excited dynamic instability** arising from the unfavorable coupling of aerodynamic, elastic, and inertial forces, producing oscillations that grow rather than decay. Kehoe: it “involves the unfavorable interaction of aerodynamic, elastic, and inertia forces on structures to produce an unstable oscillation that often results in structural failure.”  [SOURCE]

Physically/mathematically: a lifting surface has **structural modes** (e.g., wing first bending, first torsion), each with a natural frequency and modal damping. As dynamic pressure (q = ½ρV²) rises, motion-induced unsteady **aerodynamic forces** change the effective stiffness and damping of these modes. In the classic binary bending–torsion mechanism, two mode frequencies move together (“coalesce”) and the aerodynamic coupling lets the airflow feed net energy into the structure once per cycle; the **total damping of one coalesced mode passes through zero and becomes negative** — that zero-crossing is the flutter point. [SOURCE] This is captured in the eigenvalue-based **V-g / V-f diagrams** (damping g and frequency f vs. velocity) and solved by the **p-k method** or **g-method** using doublet-lattice (subsonic) or CFD-based unsteady aero. [SOURCE]

Why it can be catastrophic and cannot simply be crossed: past the boundary, oscillation amplitude can diverge to structural failure “in a matter of seconds or even tens of milliseconds.”  Kehoe records aircraft (Junkers JU90, 1938) destroyed this way, and the DAST drone’s wing broke into pieces “less than 6 seconds after oscillations began.”   [SOURCE] Because the instability is divergent, you cannot cross the boundary to locate it — locating it by crossing usually destroys the test article.

Required distinctions:

- **Flutter prediction** — a priori analysis of where the boundary is.
- **Flutter detection** — recognizing in flight that damping is falling / a mode is emerging.
- **Flutter margin** — the distance (in speed, q, or a derived parameter) from the current cleared point to the boundary.
- **Flutter suppression/control** — active feedback to raise the boundary (X-56A, DAST, X-53 AAW).
- **Flutter clearance testing** — the certification act of demonstrating adequate margin/damping across the envelope. **This report’s focus is clearance, not suppression.** [SOURCE/DERIVED]

### 3. THE BASIC FLIGHT-TEST LOOP

The user’s straw-man loop is essentially correct and confirmed by multiple sources. The classical, still-current sequence (Cooper/Wright, “Towards Faster and Safer Flight Flutter Testing,” AGARD/DTIC): (1) stabilize at a test point; (2) excite the structure; (3) curve-fit the response with system-ID to estimate modal parameters; (4) decide whether to progress to the next point.  [SOURCE] A more granular reconstruction:

1. **Establish/authorize test point** — cleared on a test card by the flutter team and test director; what is controlled: which Mach/altitude is authorized next. [SOURCE]
1. **Stabilize the aircraft** — hold Mach, altitude, configuration, fuel state steady. [SOURCE]
1. **Apply bounded excitation** — control-surface raps, sweeps, or exciter; amplitude deliberately limited. [SOURCE]
1. **Measure response** — accelerometers/strain gauges, telemetered to a ground station. [SOURCE]
1. **Estimate modal behavior** — frequency and damping via near-real-time parameter ID in the telemetry room. [SOURCE]
1. **Compare with prediction/limits** — plot damping alongside predicted V-g trend; check against go/no-go criteria. [SOURCE]
1. **Clear or refuse the next point** — test director/flutter engineers authorize the next increment, hold for more data, or retreat. [SOURCE]

Authority to proceed rests with the flutter engineers and test director in the control room, informed by the telemetered damping estimates. Kehoe: the test director “has access to all of this information to make decisions on continuing the flutter envelope expansion.”  [SOURCE]

### 4. STABILIZED TEST POINTS

The aircraft must hold a steady condition before excitation so that the measured response reflects the *aeroelastic system at that condition*, not transients from changing q, Mach, or configuration. Parameters held: altitude, Mach, airspeed/dynamic pressure, configuration (flaps/gear/stores), fuel state (mass distribution shifts modes), and control-surface configuration. Fuel/CG effects are real and measurable: on the X-56A the body-freedom-flutter speed moved from approximately 111 kn at low fuel/forward CG to a value where “at higher fuel conditions the flutter speed was approximately 114 kn”   (NASA/TM–20220012337, *Flying Beyond Flutter with the X-56A Aircraft*). [SOURCE]

These parameters are held within **controlled tolerance bands**, not to exact constancy. The Active Aeroelastic Wing F/A-18 program documented that even while holding indicated Mach, true Mach errors at supersonic conditions were “larger than expected,” and altitude errors of “several thousand feet were seen as the pilot accelerated to the Mach 1.1 indicated condition,”  forcing the crew to fly indicated Mach with a GPS-altitude cross-check. [SOURCE] This illustrates that tolerance bands are real and that off-nominal drift is expected and managed rather than eliminated. [SOURCE/DERIVED] Published exact tolerance widths (e.g., Mach ±0.01, altitude ±X ft) are program-specific and were not fixed numerically in the public sources reviewed. [OPEN]

### 5. DELIBERATE EXCITATION

Engineers must inject energy because **detection of impending instability is impossible without adequate excitation**. Kehoe: “Detection of impending aeroelastic instabilities cannot be made without adequate excitation.”  [SOURCE] Normal flight rarely excites the critical modes cleanly, and ambient response has poor signal-to-noise ratio — you cannot reliably estimate damping from noise. This connects directly to **system identification**: to identify modal parameters you need an input that is both known/repeatable and rich enough over the frequency band of interest. [SOURCE]

Excitation methods documented in Kehoe TM-4720 and AGARD sources:

- **Manual control-surface pulses / stick raps** — simplest, approximate an impulse (broadband) but limited to <~10 Hz and hard to make repeatable; low-pass filters in fly-by-wire stick paths (e.g., the F-16XL had a 1.6-Hz single-pole low-pass filter) wash out sharp inputs.  [SOURCE]
- **Oscillating control surfaces / frequency sweeps / sine dwells** — commanded through the autopilot or FCS (XF3H-1 rudder 5–35 Hz; F-4; X-31 0.1–100 Hz). [SOURCE]
- **Multisine / pseudo-random / chirp inputs** via flight-control computer (F-18; X-56A used orthogonal phase-optimized multisines on symmetric surface pairs). [SOURCE]
- **Thrusters / bonkers (pyrotechnic/ballistic exciters)** — 18–26 ms burns, 400–4,000 lbf; single-shot.  [SOURCE]
- **Inertial exciters** (rotating/oscillating eccentric masses — the B-1A used five oscillating-mass exciters). [SOURCE]
- **Aerodynamic vanes** (wingtip oscillating airfoils; DC-10, L-1011, 747, C-5A) and the **fixed vane + rotating slotted cylinder** (W. Reed’s device, ~10 lb, used on the F-16XL). [SOURCE]
- **Atmospheric turbulence** — free but weak, biased low in damping, and only excites low-frequency modes (P6M Seamaster, YF-16). [SOURCE]

Why not just watch normal flight: Kehoe documents that turbulence excitation gave larger scatter and **systematically lower (unconservative) damping estimates** than forced excitation; the B-58 needed excitation “three to four times higher than obtained by random atmospheric turbulence.” [SOURCE]

### 6. MINIMUM SUFFICIENT PERTURBATION

Amplitude selection is an explicit trade: enough energy to identify the modes with good SNR, but not so much as to overstress the structure, drive nonlinear response (freeplay, LCO), or itself trigger instability. Kehoe documents the failure of *inadequate* excitation (Transavia PL-12/T-400: control-pulse + turbulence excitation showed no flutter in the test, but violent rudder/tailboom oscillation appeared later in rough air that provided higher excitation than the test).  [SOURCE] Conversely, the X-56A used deliberately small inputs — “short doublets of 0.25 s at amplitudes between 1.0 and 1.5 degrees”  — chosen to be “repeatable and larger than typical background turbulence disturbances”  yet gentle. [SOURCE] The engineering principle: minimum input that yields reliable modal identification, on the conservative side of any nonlinear amplitude threshold. [SOURCE/SYNTHESIS]

### 7. PREDICTION BEFORE TEST

Before a new point, engineers carry an explicit predicted stability picture built from: **finite-element structural models**, **ground vibration testing (GVT)** to measure real modal frequencies/shapes/damping and update the FEM, **wind-tunnel flutter models** (e.g., Langley Transonic Dynamics Tunnel), and **flutter analysis** (p-k / V-g / V-f, doublet-lattice, increasingly CFD). [SOURCE] GVT is the anchor: it “delivers experimental vibration data… to validate and improve structural dynamic models,”  which then predict the flutter boundary and “establish a safe flight envelope before the first test flight.”  [SOURCE]

Flight tests carry **explicit preregistered expectations**: predicted modal frequencies, predicted damping trend, and predicted flutter speed are plotted in advance, and measured points are overlaid on them. [SOURCE] The flight-test literature (flighttestfact.com, “Good Vibrations”) describes engineers drawing V-f and V-g charts for each mode before flight and requiring a “sensitivity analysis or predictions on the magnitude of potential variance” so the team knows what deviation is tolerable. [SOURCE] **Prediction error** is the divergence between the measured modal parameter (or margin) and its predicted value at that condition — the quantity that drives step-size and retreat decisions. [SOURCE/DERIVED]

### 8. MEASUREMENT

Primary sensors: **accelerometers** (today the workhorse — piezoelectric, sub-ounce, 1–10,000 Hz)  and **strain-gauge bridges**; plus control-surface position, air-data (Mach, altitude, q), and inertial measurements. [SOURCE] The X-56A carried 10 vertical (z-axis) accelerometers across the wings and centerbody plus INS/GPS and single-axis gyros.  [SOURCE] Data are **telemetered in real time** to a ground station; Kehoe’s “typical modern flight flutter test process” shows response signals simultaneously displayed on strip charts and real-time spectrum analyzers while a computer runs parameter ID. [SOURCE] What engineers actually infer from these signals: **modal frequency and modal damping** (and their trends vs. Mach/airspeed) for each critical mode — the raw accelerometer decay/FRF is only the means to those two inferred quantities. [SOURCE]

### 9. DAMPING AS AN EARLY-WARNING VARIABLE

The core idea: damping of the critical mode **decreases toward zero as the flutter boundary is approached**, so you can sense proximity without reaching it — ζ > 0 → ζ → 0 → instability. [SOURCE] This is why subcritical testing works at all.

But the literature is emphatic about its **limitations**:

- **Subcritical damping cannot be reliably extrapolated.** Kehoe lists this as a fundamental hazard: “subcritical damping trends cannot be accurately extrapolated to predict stability at higher airspeeds,”  and “aeroelastic stability may change abruptly from a stable condition to one that is unstable with only a few knots’ change in airspeed.”  [SOURCE]
- **Hard/explosive flutter**: damping can collapse abruptly with little warning (the mu-method patent notes damping “may be highly nonlinear… so damping trends may indicate stability despite proximity to an explosive flutter condition”).  [SOURCE]
- **Transonic dip**: near Mach 0.85–0.88, damping can plunge into negative territory and recover within ~0.03 Mach (Bratt et al. single-DOF pitch data), so linearized trends mislead. [SOURCE]
- **Nonlinear/LCO** cases: response saturates into limit cycles rather than diverging cleanly, confounding a simple ζ→0 reading. [SOURCE]

Because raw damping is fallible, actual **flutter-margin methods** were developed to give a variable that trends more benignly (ideally linearly) to zero:

- **Zimmerman–Weissenburger Flutter Margin (FM)** — N. H. Zimmerman and J. T. Weissenburger (both McDonnell Aircraft Corp., St. Louis), “Prediction of Flutter Onset Speed Based on Flight Testing at Subcritical Speeds,” *Journal of Aircraft*, Vol. 1, No. 4, July–Aug. 1964, pp. 190–202   (doi:10.2514/3.43581): forms a stability parameter from the frequencies and damping of the two coalescing modes that “decreases almost linearly toward zero with increasing dynamic pressure,” a “superior property as a flutter predictor in comparison with damping coefficients.”  [SOURCE]
- **Nissim–Gilyard** parameter-identification method (NASA TM-2923, 1989). [SOURCE]
- **Envelope-function method** (Cooper et al., *Journal of Aircraft* 1993) — tracks the shape of the pulse-response decay envelope. [SOURCE]
- **Houbolt / Houbolt–Rainey and peak-hold** methods. [SOURCE]
- **Discrete-time ARMA-based prediction** (Torii–Matsuzaki, *Journal of Aircraft* 1997/2001). [SOURCE]
- **Flutterometer / mu-method robust flutter margin** (Lind & Brenner, *Journal of Aircraft* 2000) — model-based, discussed in §20. [SOURCE]

A NASA/AIAA comparison found the data-based methods (damping, envelope, FM, ARMA) “unable to predict flutter accurately using data from low-speed test points, but converge to the accurate solution as airspeed is increased,”  whereas the flutterometer is “immediately conservative”  but does not converge to the true speed — a genuine, documented trade-off. [SOURCE]

### 10. ONLINE SYSTEM IDENTIFICATION

Flutter clearance uses **near-real-time** identification. Processing split:

- **Onboard**: usually just sensing, some preprocessing/telemetry encoding; historically some strip-chart/oscillograph display in the aircraft. [SOURCE]
- **Ground, real time (telemetry room)**: FFT spectra, strip charts, and parameter-ID algorithms run as the point is flown; the flutter crew clears the point before the pilot advances. A data-driven paper describes the loop verbatim: after excitation, “the pilot takes the aircraft to a safe speed while analysts at the ground station analyze the damping characteristics… After the point is cleared by the flutter telemetry crew, the pilot takes the aircraft to the next point.”   [SOURCE]
- **Postflight**: definitive curve-fits, control-law margins, model updates. The X-56A computed control-system gain/phase margins (>3 dB, >30°) in postflight analysis.  [SOURCE]

Methods span peak-picking, least-squares curve fits, spectral/FRF estimation, recursive least-squares and recursive maximum-likelihood (Walker & Gupta, NASA CR-170412, “Real-Time Flutter Analysis,” 1984;  extended with an extended Kalman filter by Roy & Walker, NASA CR-3933, 1985), Eigensystem Realization Algorithm, subspace ID, PolyMAX/LSCF, operational modal analysis, and wavelet methods. [SOURCE] NASA Dryden’s dedicated program (Brenner, Lind & Voracek, NASA TM-4792, 1997) pushed excitation, time/frequency/wavelet signal processing, and robust boundary prediction specifically to “reduce the test matrix for flutter clearance.”   [SOURCE] Historically, DAST (1979–80) demonstrated near-real-time damping estimation from fast-frequency aileron sweeps in the ground Structural Analysis Facility.  [SOURCE]

### 11. CLEARANCE DECISION

This is the crux. What licenses advancing to the next point is a **conjunction**, not a single number:

- Measured **damping** at the current point is positive and adequate. [SOURCE]
- The **damping/margin trend** does not predict flutter or unacceptable damping at the next planned point. [SOURCE]
- **Agreement between model and measurement** (frequencies and damping track predictions). [SOURCE]
- **Absence of unexpected modes** or anomalies. [SOURCE]
- Structural loads/limits respected. [SOURCE]
- Predefined **go/no-go criteria** met, backstopped by engineering judgment. [SOURCE]

Documented thresholds:

- **FAR/CS 25.629**: the aeroelastic-stability envelope is V_D/M_D enlarged by **15% equivalent airspeed** at constant Mach and constant altitude; a “proper margin of stability” must exist up to V_D/M_D with “no large and rapid reduction in stability”  (in flight test, “no large and rapid reduction in damping as V_DF/M_DF is approached”).  [SOURCE]
- **AC 25.629-1**: acceptable damping is commonly taken with g = 0.03 (≈1.5% critical viscous damping) as the assumed available structural-damping baseline  for the margin. [SOURCE]
- **MIL-A-8870**: minimum flutter margin **15% in V_D** at constant altitude and Mach, **and** damping coefficient g ≥ 3% (“at least three percent”) for any critical flutter mode  across the envelope. [SOURCE]
- **Flight-test practice**: a common technique is to **stop at ~3% net damping**, because below that the structure’s ~3% structural damping is already offsetting negative aerodynamic damping.  [SOURCE]
- **Program-specific**: the X-56A required **closed-loop damping ratio > 0.04** to proceed,  plus control-law margins >3 dB / >30°. [SOURCE]

One successful perturbation is generally **not** enough: the flight-test literature stresses repeating test points, using multiple curve-fit methods, and evaluating variance when data are scattered, precisely because damping estimates from a single fit can vary “wildly.”  [SOURCE]

### 12. STEP SIZE

Increments are **adaptive and shrink toward the predicted boundary**. The build-up approach “slowly step[s] out to the edge of the envelope in preplanned speed increments.”   [SOURCE] Steps are taken along lines of constant Mach or constant calibrated airspeed/altitude, “initially done in a region… where high stability is predicted and subsequently extended.”  [SOURCE] Poor data quality forces smaller steps: “the resulting curve-fits become worse, leading to less confidence in the estimated parameters and thus the speed increments between flight test points must be relatively small.”  [SOURCE]

Concrete documented increments — X-56A: “Successive test points increased the airspeed in **10-kn increments** until airspeed was within 10 kn of estimated flutter, and then in **5-kn increments** as the aircraft passed through and beyond flutter.”   [SOURCE] Prediction success permits larger steps; prediction error or scatter causes smaller steps, repeats, or retreat. [SOURCE]

### 13. RETREAT AND ABORT LOGIC

When response is worse than predicted, the documented responses are: immediate **speed reduction** back to a cleared condition, **cease test maneuvers** (“terminate”/knock-it-off), configuration change, test termination, and engineering review before any re-attempt. [SOURCE]

Concrete cases:

- **KC-135 winglet flutter test** (Kehoe TM-4720, citing AFFTC-TR-81-4): two modes at 2.6 Hz and 3.0 Hz coupled as airspeed increased and “the damping level decreased with increasing airspeed until it was no longer safe to continue the test.”  This is the textbook **orderly retreat** — expansion stopped before instability because the gradual damping decrease gave adequate warning. Kehoe uses it explicitly to contrast with cases where damping drops abruptly and this method would *not* give timely warning. [SOURCE]
- **DAST ARW-1** (June 12, 1980; Merlin, NASA SP-2013-600, *Crash Course*; Edwards, AIAA 81-0655): the FSS was inadvertently at half gain; the ground pilot was cleared toward Mach 0.825; when strip charts showed low damper response and chase video showed the wing “fluttering wildly,”  the test conductor called “Slow down, slow down, slow down,” then “Terminate, terminate”;  tip masses were jettisoned but the right wing failed within seconds (“The DAST-1 experienced explosive flutter at Mach 0.825… Less than 6 seconds after oscillations began, the right wing broke into several pieces”).  The measured system-on flutter appeared well inside the region predicted safe at design gain. [SOURCE]
- A contemporary clearance program (ISMA 2010) documents the routine version: “a drop in damping was noticed for the flutter critical modes. Clearance was obtained for this region by looking at the test data and predicted trends,”  with test-point aborts generated by the flight-test interface when needed. [SOURCE]

### 14. CLEARED REGION VERSUS TESTED POINT

A tested point clears a **local region**, not merely the exact point, and licenses **interpolation between adjacent cleared points** along the swept line — but **not unrestricted extrapolation** beyond the last cleared point toward higher q/Mach. [SOURCE/DERIVED] The cleared region is built up as a lattice: sweeps at **constant altitude** (increasing airspeed), **constant Mach** (varying altitude/q), or constant calibrated airspeed, filling the Mach–altitude (or Mach–q) plane. [SOURCE] Interpolation is licensed by the assumption of smooth, monotonic modal behavior between closely spaced cleared points; extrapolation is forbidden precisely where that assumption fails — near the transonic dip, near mode coalescence, or wherever damping is changing rapidly — because “subcritical damping trends cannot be accurately extrapolated.” [SOURCE] The 15% margin requirement means the *cleared operational envelope* deliberately sits inside the *demonstrated* envelope. [SOURCE/DERIVED]

### 15. ENVELOPE EXPANSION AS A STATE MACHINE

The procedure *can* be represented as discrete states with failure transitions, and aerospace practice already has its own equivalent vocabulary, which is used here instead of any imported terminology:

- **Uncleared region** → authorized via a **test card** and **flight clearance / Airworthiness Release** after a **Test Hazard Analysis (THA)** and **Safety Review Board (SRB)**. [SOURCE]
- **Test point stabilized** → the crew holds the authorized condition. [SOURCE]
- **Excited** → bounded excitation applied. [SOURCE]
- **Response validated** → telemetry-room modal ID meets go criteria. [SOURCE]
- **Cleared** → next increment authorized; failure transitions (“knock-it-off,” abort) return the aircraft to a previously cleared, safer condition. [SOURCE]

The governing named concepts are the **build-up approach** (“creep-up”), **test cards**, **THA**, **SRB/Technical Review Board**, and **flight clearance/Airworthiness Release**. [SOURCE] The Air Force Test Center test-safety instruction (AFTCI/AFI 91-202-series) formalizes the risk-review gates, including that a test point whose flutter/loads margin “is well within acceptable levels… need not be considered elevated risk.”  [SOURCE]

### 16. IRREVERSIBILITY AND CATASTROPHIC BOUNDARIES (critical section)

The whole method exists to learn a boundary that cannot be crossed even once. It avoids “probe until failure” by substituting several layers for boundary-crossing:

- **Predictive margins**: validated models place the boundary before flight; testing only *confirms* margin. [SOURCE]
- **Trend extrapolation from subcritical data**: damping/margin parameters are extrapolated toward the boundary from a safe distance rather than measured at it. [SOURCE]
- **Regulatory safety factors**: the 15% EAS margin and 3% damping floor keep the *operational* limit strictly inside the *demonstrated* limit. [SOURCE]
- **Abort margins and small steps near the boundary**: increments shrink and repeats increase as prediction uncertainty or scatter grows. [SOURCE]
- **Precursor observables**: falling damping, mode coalescence, rising response amplitude, control-surface “buzz,” and softening of stick response are watched as leading indicators. [SOURCE]
- **Model validation at every point**: measured-vs-predicted agreement is itself a gate; a mismatch halts expansion even if damping looks adequate. [SOURCE]

What ultimately prevents “probe until failure” is that **the boundary is never the test target** — the target is *confirming a predicted margin*. The residual danger is explicitly acknowledged: Kehoe warns the method still requires flying “close to actual flutter speeds,” and that hard flutter may not give timely warning; the DAST and Electra cases show what happens when the model or configuration is wrong. [SOURCE/SYNTHESIS]

### 17. HIDDEN-STATE PROBLEM

The central epistemic risk is a response that *looks* acceptable while an unobserved variable approaches failure. Documented mechanisms:

- **Nodal placement**: an accelerometer at a mode’s node misses that mode entirely. [SOURCE/DERIVED]
- **Uninstrumented / unexpected modes** and **aeroservoelastic coupling** (structure ↔ flight-control system). [SOURCE]
- **Freeplay** in control surfaces and **nonlinear/LCO** behavior invisible at small amplitude (the X-56A saw a small pitch-axis LCO from actuator deadbands that made the aircraft “essentially open loop… unstable until the oscillation amplitude grew”).  [SOURCE]
- **Structural fatigue** accumulating below detection. [SOURCE/DERIVED]
- **Inadequate excitation** masking low damping (Transavia; turbulence bias). [SOURCE]

Defenses aerospace uses against **false clearance**: redundant/ample instrumentation at multiple locations, independent analytical models, GVT and wind-tunnel cross-checks, multiple observables (frequency *and* damping *and* margin parameters), conservative regulatory margins, repeat points and multiple curve-fit methods, structural inspections between flights, and model updating. [SOURCE/SYNTHESIS] The DAST mishap board explicitly recommended end-to-end systems tests, strict configuration control, and prominent real-time display of Mach/q and damping with warning thresholds — direct institutional responses to a hidden-state failure. [SOURCE]

### 18. MODEL UPDATING

Measured flight response *is* fed back into the model, but the literature keeps three operations distinct:

1. **Updating the model** — GVT and flight data correct the FEM/aero model (Pak, NASA, “unsteady aerodynamic model tuning”; Lind–Brenner update the uncertainty operators Δ with flight data). DAST ARW-1R’s explicit objective after the crash was “to produce the best possible structural model for flutter analysis.”  [SOURCE]
1. **Changing the flight limit** — a regulatory/airworthiness act that adjusts the placarded envelope; distinct from and downstream of model fidelity. [SOURCE/DERIVED]
1. **Clearing the next point** — a real-time go/no-go decision about the *next increment*, which uses the (possibly updated) model but is not the same as either re-fitting the model or re-placarding limits. [SOURCE/DERIVED]

The loop is: predict → fly/measure → residual (measured − predicted) → update model / reduce uncertainty → re-predict next-point margin → clear or not. Conflating these three is a documented error mode; each has a different owner and time-scale. [SYNTHESIS]

### 19. RELATIONSHIP TO DUAL CONTROL

Reconstructed independently above, flutter clearance *does* share Feldbaum’s core structure in one respect: the excitation input **simultaneously perturbs the aircraft (control) and generates information (probing)** — a genuine dual-effect input. [SYNTHESIS] Feldbaum’s dual control formalizes exactly this tension between “investigating and directing,”  resolved (in theory) by dynamic programming. [SOURCE]

But the mapping is **partial and should not be forced**:

- Flutter clearance is **deliberately sequential** (stabilize *then* excite *then* decide), not jointly optimal. The probing and the caution are separated in time by design. [SYNTHESIS]
- The dominant objective is not optimizing a control cost while learning; it is **experiment design / system identification under a hard, irreversible safety constraint**. It is closer to sequential optimal experiment design (Goodwin & Payne) than to closed-loop dual control. [SYNTHESIS]
- Catastrophic, irreversible risk is precisely why aerospace **rejects** joint optimization in favor of conservative sequential separation: you do not trade information value against control performance when one bad trade destroys the aircraft. [SYNTHESIS]

So: the excitation is a dual-effect action, but flutter clearance is better described as guarded sequential experiment design than as Feldbaum dual control. [SYNTHESIS]

### 20. RELATIONSHIP TO ROBUST CONTROL

Two distinct activities that meet at one point:

- **Robust control** designs a controller with guaranteed stability margins (gain/phase margins, uncertainty sets, worst-case/mu-analysis) so the *closed loop* tolerates modeled uncertainty. [SOURCE]
- **Envelope clearance** experimentally certifies an *operating region* of an aircraft. [DERIVED]

They genuinely meet in **Lind & Brenner’s robust flutter margin / flutterometer**: it applies the structured singular value **μ** to an aeroelastic model with uncertainty operators Δ updated by flight data, producing a **worst-case flutter margin** that is conservative with respect to  modeling error — importing robust-control machinery directly into clearance. [SOURCE] The X-56A likewise imposed classical robust-control gate criteria (>3 dB gain, >30° phase margin) as clearance conditions. [SOURCE] The conceptual difference remains: robust control makes the *system* tolerant of uncertainty; clearance makes *knowledge of the boundary* tolerant of uncertainty (via conservative margins). [SYNTHESIS]

### 21. RELATIONSHIP TO TRUST REGIONS

There is a **structural analogy only** — stated plainly. Both trust-region optimization and envelope expansion share a generic pattern: a trusted local region, a bounded step near/outside it, a comparison of predicted vs. observed behavior, and expansion or contraction of the allowed step based on agreement. [SYNTHESIS] In trust-region methods the “trust ratio” of actual-to-predicted reduction grows or shrinks the region; in envelope expansion, agreement between measured and predicted damping grows the step (or shrinks it / forces retreat on disagreement). [SYNTHESIS] **This is an analogy of control structure, not an identity.** Flutter clearance is not minimizing an objective, has no gradient/model-reduction step, and — decisively — its “bad step” is catastrophic and irreversible, whereas a trust-region method simply rejects a bad step and re-tries with a smaller radius. The shared pattern is real but must not be read as equivalence. [SYNTHESIS/OPEN]

### 22. HISTORICAL CASE STUDIES

**Case 1 — DAST ARW-1 (NASA, 1979–1980)**

- Aircraft: modified BQM-34 Firebee II drone with supercritical Aeroelastic Research Wing + active FSS.
- Known safe region: subcritical, verified to Mach 0.91 on earlier flights.
- Predicted boundary: “Langley outfitted a drone with an aeroelastic, supercritical research wing suitable for a Mach 0.98 cruise transport with a predicted flutter speed of Mach 0.95 at an altitude of 25,000 feet”;   the FSS was intended to raise it ~20%; the June-12 point was predicted flutter-free at design gain.
- Excitation method: fast-frequency aileron sweeps + control pulses.
- Measured variable: near-real-time damping from wing accelerometers.
- Go/no-go rule: satisfactory damping vs. predicted trend, cleared point-by-point from the ground.
- Increment strategy: incremental Mach build-up.
- Unexpected finding: FSS inadvertently at half gain → system-on flutter at Mach 0.825, inside the “safe” region.
- Outcome: right wing failed within ~6 s; vehicle lost; rebuilt as ARW-1R with an improved structural model.  [SOURCE]

**Case 2 — X-56A MUTT (NASA/AFRL/Lockheed, 2017–2019)**

- Aircraft: 28-ft-span, 525-lb remotely piloted tailless flying wing  with flexible wings.
- Known safe region: from 60 kn upward.
- Predicted boundary: body-freedom flutter (short-period ↔ 1st symmetric wing bending) ~111 kn (low fuel/fwd CG) to ~114 kn (high fuel/aft CG); a second mechanism (1SWB↔1SWT) predicted ~138–144 kn.
- Excitation method: 0.25-s control-surface raps (1.0–1.5°); orthogonal multisines on symmetric surface pairs.
- Measured variable: frequency and damping of short-period and 1SWB from LOES models; Zimmerman stability parameter F.
- Go/no-go rule: closed-loop damping ratio > 0.04; control-law margins >3 dB / >30°.
- Increment strategy: 10-kn steps to within 10 kn of predicted flutter, then 5-kn steps through and beyond.
- Unexpected finding: small pitch-axis LCO from actuator deadbands near flutter.
- Outcome: flew to 120 kn, **beyond** open-loop flutter, with active suppression;  Zimmerman prediction converged to within 1 kn at 10 kn out. [SOURCE]

**Case 3 — F/A-18 Active Aeroelastic Wing / X-53 (NASA/USAF/Boeing, 2002–2005)**

- Aircraft: F/A-18A with thinner, more flexible wings.
- Known safe region: standard F/A-18 envelope.
- Predicted boundary: flutter-free within the flight envelope (goal was roll control via wing twist, not suppression). 
- Excitation method: onboard excitation system (OBES) aeroservoelastic maneuvers to clear the flutter envelope;  doublets.
- Measured variable: modal response; loads.
- Go/no-go rule: flutter clearance before loads/roll testing.
- Increment strategy: point-by-point envelope expansion (transonic/supersonic test points).
- Unexpected finding: large true-Mach and altitude deviations at supersonic indicated conditions.
- Outcome: envelope cleared; wing-twist roll control demonstrated transonic/supersonic.  [SOURCE]

**Case 4 — Lockheed L-188 Electra (whirl-mode flutter, 1959–1961)**

- Aircraft: four-engine turboprop airliner.
- Known safe region: normal cruise — believed flutter-free.
- Predicted boundary: whirl-mode flutter *not modeled* in original analysis.
- Excitation method: service loads / hard-landing damage + turbulence (not a deliberate test).
- Measured variable: (post-accident) wind-tunnel + reprogrammed flutter analysis including whirl mode.
- Go/no-go rule: n/a (in-service failures).
- Increment strategy: n/a.
- Unexpected finding: a weakened engine mount lowered the propeller whirl-mode frequency until it coincided with wing flapping, driving destructive wing flutter.  
- Outcome: two fatal breakups (Braniff 542, Northwest 710);  the Lockheed Electra Achievement Program (LEAP) stiffened nacelles/wings; no recurrence.  [SOURCE]

**Case 5 — Helios Prototype HP03 (NASA/AeroVironment, 2003)**

- Aircraft: ultra-flexible solar flying wing.
- Known safe region: prior HP01 configuration.
- Predicted boundary: available analysis could not predict the vehicle’s heightened sensitivity to turbulence in the long-endurance configuration.
- Excitation method: atmospheric turbulence (operational, not a flutter test).
- Measured variable: wing dihedral, airspeed (telemetry).
- Go/no-go rule: n/a (mission flight).
- Increment strategy: n/a.
- Unexpected finding: turbulence produced persistent high dihedral → unstable pitch oscillation  (a nonlinear aeroelastic/flight-dynamic coupling), airspeed diverged, design speed exceeded.
- Outcome: structure failed, vehicle lost; the board found “the mishap resulted from the inability to predict, using available analysis methods, the aircraft’s increased sensitivity to atmospheric disturbances such as turbulence, following vehicle configuration changes required for the long-duration flight demonstration”   (NASA HQ Release HQ 04-283, Sept. 3, 2004). [SOURCE]

**Case 6 (supporting) — KC-135 winglet flutter test (USAF/AFFTC, 1981)** — orderly in-flight retreat when coupled 2.6/3.0-Hz modes lost damping “until it was no longer safe to continue the test.” [SOURCE]

### 23. A DETAILED WORKED CASE — X-56A body-freedom flutter

The X-56A is the best-documented public case with actual numbers. Reconstructed expansion sequence (forward-CG/low-fuel condition):

- The program expanded airspeed from 60 kn, taking **10-kn steps**. At each new airspeed the team applied a 0.25-s outboard-surface rap (1.0–1.5°), estimated closed-loop damping in the control room, required **ζ > 0.04** to proceed, then ran multisine system-ID to build a 6th-order LOES model (short period, 1SWB, 1SWT).  [SOURCE]
- As data accumulated, the **Zimmerman stability parameter F** was computed from the identified short-period and 1SWB frequencies and decay rates and fit with a second-order curve vs. airspeed; the x-axis crossing predicted flutter onset.  [SOURCE]
- **Prediction convergence** (the licensing evidence): “the method became more accurate as more data points were taken in flight and was within **1 kn** at 10-kn away from flutter.”  Early low-speed extrapolations were off “significantly because of the large extrapolation required.”  [SOURCE]
- When predicted flutter came within 10 kn of the current cleared speed, increments were **reduced to 5 kn**. [SOURCE]
- Observed result: short-period frequency rose with airspeed while 1SWB fell; by ~100 kn they began to couple; at **~111 kn (fwd CG)** one mode’s damping reached zero — flutter onset (and ~114 kn at aft CG). Data past onset showed continued decreasing damping.  [SOURCE]
- The decision on whether the *next* speed was admissible rested on: (a) current ζ > 0.04; (b) the Zimmerman-F second-order fit not predicting a zero-crossing within the next increment; (c) control-law margins >3 dB/>30°; and (d) general agreement between the a-priori state-space model and the in-flight LOES model. [SOURCE]

Numbers **not** in the source (stated explicitly rather than invented): the public TM presents V-f and V-ζ trends and the Zimmerman-F curves graphically and does not tabulate the exact ζ at each individual 10-kn step, so a literal “V1→ζ1, V2→ζ2, V3→ζ3” numeric table cannot be reproduced verbatim from the public report. The reconstructable hard numbers are the 10-kn/5-kn increments, the ζ>0.04 gate, the ~111/114-kn onsets, and the “within 1 kn at 10 kn out” convergence. [OPEN]

### 24. FAILURE HISTORY (essential)

- **Lockheed Electra (1959–60)**: whirl-mode flutter absent from the original model destroyed two airliners; fix = stiffer nacelles/wings (LEAP); lesson = an unmodeled mechanism defeats any amount of subcritical testing. [SOURCE]
- **DAST ARW-1 (1980)**: a configuration/gain error put the aircraft into system-on flutter inside the “safe” region; lessons = end-to-end systems test, configuration control, and real-time display of Mach/q and damping with warning thresholds. [SOURCE]
- **Helios HP03 (2003)**: nonlinear aeroelastic/flight-dynamic sensitivity to turbulence was unpredicted; the vehicle broke up; lesson = for very flexible vehicles, linear analysis and prior-configuration confidence are inadequate — NASA subsequently invested in nonlinear aeroelastic/aeroservoelastic tools. [SOURCE]
- **T-46A (1986)**: experienced aileron flutter during a flight test flown to find the correct mass balance (free-floating, tab-driven ailerons)  — a documented in-test flutter encounter cited by Kehoe. [SOURCE]
- **Transavia PL-12/T-400 (1986)**: passed a flutter test (inadequate excitation) then suffered violent rudder/tailboom oscillation in rough air; lesson = inadequate excitation yields false clearance. [SOURCE]
- **Historical primary-surface losses**: Junkers JU90 (1938) crash during flutter testing; 1950s panel-flutter and control-surface-buzz losses; F-117 and E-6 vertical-fin flutter incidents — cited by Kehoe as evidence “no speed regime is truly immune.”  [SOURCE]

Across these, the recurring procedural changes were: better/updated models and mandatory GVT; configuration control and end-to-end systems checks; conservative excitation adequacy; and improved real-time monitoring/warning. [SYNTHESIS]

### 25. MODERN PRACTICE

Modern clearance differs from the 1950s–70s in: (1) far better computational models (CFD-based unsteady aero, high-fidelity FEM, GVT-updated); (2) digital fly-by-wire enabling **FCS-commanded excitation** (multisine/chirp) with no added hardware; (3) **near-real-time identification** and margin tracking in the telemetry room (recursive ID, wavelet methods); (4) **model-based robust prediction** (Lind–Brenner μ-method flutterometer, worst-case margins) to shrink the test matrix; (5) **uncertainty quantification / probabilistic clearance** (Bayesian flutter-margin methods sampling modal-parameter uncertainty). [SOURCE] Machine-learning use is emerging but reported cautiously here: recent peer-reviewed work applies data-driven/dynamic-mode-decomposition and operational-modal-analysis methods to rapid aeroelastic-mode detection from flight data, and an Israel Air Force study (“Assessment of Advanced Flutter Flight-Test Techniques and Flutter Boundary Prediction Methods,” *Journal of Aircraft*, doi:10.2514/1.C034716) evaluated ARMA and OMA system-ID against classical methods on “data from a dedicated transonic flight test of the F-16 platform,”  finding “all of the tested methods are able to accurately predict the instability onset”  — these are genuine citations, not speculative AI claims. [SOURCE] Governing standards: **FAR/CS 25.629** and **AC 25.629-1** (transport), **FAR 23.629** (normal category), **MIL-A-8870C** and **JSSG-2006** (military). [SOURCE]

### 26. TERMINOLOGY AUDIT

- **Flight envelope** — approved region in altitude–speed/Mach (or Mach–q). [SOURCE]
- **Envelope expansion** — incrementally demonstrating safe operation into previously untested conditions. [SOURCE]
- **Flutter** — self-excited divergent aeroelastic oscillation from aero/elastic/inertial coupling. [SOURCE]
- **Flutter boundary** — the condition (speed/q/Mach) where net modal damping crosses zero. [SOURCE]
- **Flutter clearance** — certification demonstration of adequate damping/margin across the envelope. [SOURCE]
- **Flutter margin** — distance to the boundary; either a speed/q margin (15% rule) or a derived parameter (Zimmerman FM). [SOURCE]
- **Modal damping** — rate of decay of a structural mode’s oscillation; the primary observable. [SOURCE]
- **Excitation** — deliberate energy input to make modes observable. [SOURCE]
- **Test point** — a specific stabilized flight condition. [SOURCE]
- **Cleared point** — a test point demonstrated to meet criteria. [SOURCE]
- **Go/no-go criterion** — the predefined threshold (e.g., ζ>0.04, g≥3%, 15% margin) authorizing progression. [SOURCE]
- **Ground vibration test (GVT)** — full-airframe modal test used to validate/update the FEM. [SOURCE]
- **Aeroelastic model** — coupled structural + unsteady-aerodynamic model predicting flutter. [SOURCE]
- **System identification** — extracting modal parameters from measured input/response. [SOURCE]

**Loosely-used terms to flag**: “flutter” is often misapplied to **buffet** (separated-flow forced response), **LCO** (bounded nonlinear oscillation), or **divergence** (static aeroelastic instability) — all distinct. [SOURCE] “Damping” is reported inconsistently as structural-damping coefficient **g**, viscous **damping ratio ζ**, or **percent critical** (note g ≈ 2ζ for light damping; the FAA “3% g” ≈ 1.5% critical is a frequent point of confusion). [SOURCE] “Cleared” vs. “demonstrated” vs. “certified” are not synonyms: a point may be flight-*demonstrated*, a region *cleared* for further test, and the type-design *certified* — different acts by different authorities. [SYNTHESIS]

### 27. FINAL RECONSTRUCTION

Reduced to its smallest accurate operating loop, flutter clearance is:

**Predict the boundary and a margin → stabilize at an authorized condition safely inside the predicted margin → inject a small, known, bounded excitation → measure the modal response → identify frequency and damping (and a margin parameter) → compare against the prediction and the go-criteria → if agreement and adequate margin, advance one increment (smaller near the predicted boundary); if disagreement or falling margin, hold, repeat, update the model, or retreat to a cleared condition.**

This differs from the user’s straw-man mainly in three respects the literature insists on: (a) what is compared is **prediction vs. measurement of a margin**, not just a raw damping number; (b) the **step size is adaptive and the boundary is never the target** — the target is confirming a predicted margin; and (c) **model updating, limit-changing, and next-point clearance are three separate acts**.

Direct answers:

- **What is being stabilized?** The flight condition — Mach, altitude/dynamic pressure, configuration, and fuel/mass state — so that the measured aeroelastic response is attributable to that condition alone. [SOURCE]
- **What is being perturbed?** The aircraft’s structural modes, via a small bounded, known excitation (control-surface rap/sweep, multisine, exciter, or characterized turbulence) — a dual-effect input that both disturbs and informs. [SOURCE]
- **What observation carries the most authority?** The **trend of modal damping (and derived flutter-margin parameters) as speed/Mach increases**, measured by ground-based near-real-time system identification and checked against prediction — not any single response amplitude. [SOURCE]
- **What evidence licenses expansion into previously uncleared territory?** The **conjunction** of: measured damping/margin at the current point meeting the go-criteria (e.g., g≥3% / ζ above threshold, 15% speed margin), a damping/margin *trend* that does not predict instability at the next increment, agreement between the validated model and the measurement, and the absence of unexpected modes or anomalies — all ratified through the test-card / telemetry-room / review-board governance chain. [SOURCE/SYNTHESIS]

-----

## Recommendations

Staged, concrete guidance for anyone planning or reasoning about flutter/aeroelastic envelope expansion:

1. **Anchor on prediction + margin before flying.** Build a GVT-updated FEM + unsteady-aero model, compute V-g/V-f by p-k, and register explicit predicted frequency, damping, and flutter speed with a sensitivity analysis. Benchmark to change plans: if GVT-vs-FEM frequency errors exceed a few percent, update the model before flight rather than relying on flight test to catch it. [SOURCE]
1. **Instrument for the modes, not the geometry.** Place accelerometers to avoid nodal blind spots for every predicted critical mode; carry redundancy. Threshold: if any predicted critical mode lacks two independent well-placed sensors, add instrumentation. [SOURCE/DERIVED]
1. **Excite deliberately; do not rely on turbulence.** Use FCS-commanded multisine/sweeps or a dedicated exciter sized to beat turbulence SNR (recall the B-58’s 3–4× requirement). Choose the minimum amplitude that yields repeatable modal ID below any nonlinear threshold. [SOURCE]
1. **Adopt explicit go/no-go thresholds and the build-up increment rule.** Use the regulatory floors (15% margin; g≥3%) plus a program damping gate; step in coarse increments far from the boundary and shrink (e.g., halve) within a fixed distance of predicted flutter. The X-56A 10-kn→5-kn rule is a concrete template. [SOURCE]
1. **Track a margin parameter, not just raw damping.** Compute Zimmerman–Weissenburger FM (or a μ-based worst-case margin) online; treat divergence between the FM trend and the damping trend as a trigger to hold and investigate. This directly hedges the hard-flutter/transonic-dip failure of raw-damping extrapolation. [SOURCE]
1. **Pre-script the retreat.** Define abort/“knock-it-off” criteria (damping below gate, adverse margin trend, or model-measurement mismatch), the immediate action (decelerate to last cleared condition), and the review gate before re-attempt. The DAST board’s recommendations (real-time Mach/q and damping display with warning thresholds, configuration control, end-to-end systems test) are the minimum standard. [SOURCE]
1. **Keep model-update, limit-change, and next-point-clearance as separate signed decisions**, with different owners (analysis team, airworthiness authority, test director). Never let a favorable model update silently authorize a larger step. [SYNTHESIS]
1. **For very flexible or novel configurations, distrust linear confidence.** Helios shows linear tools and prior-configuration heritage can miss nonlinear aeroelastic/flight-dynamic coupling; add nonlinear analysis and treat turbulence sensitivity as a first-class hazard. [SOURCE]

**Thresholds that would change the recommendations:** if online robust-margin tools (flutterometer) mature and are validated to converge non-conservatively, test matrices can shrink and increments enlarge; if a program exhibits hard/explosive flutter or a transonic dip, increments must shrink further and subcritical extrapolation must be distrusted regardless of apparent damping.

## Caveats

- **Exact stabilization tolerance bands** (e.g., Mach ±0.01, altitude ±X ft) are program-specific and were not fixed numerically in the public sources reviewed; the AAW case shows real-world deviations can reach thousands of feet and non-trivial Mach errors. [OPEN]
- **The X-56A worked case** is public but partly redacted/graphical; per-step ζ values are not tabulated in the public TM, so a fine-grained V→ζ table cannot be reproduced verbatim. [OPEN]
- **X-56A and DAST involve active flutter suppression**, which the user asked to de-emphasize; they are used here for their *clearance/envelope-expansion methodology and numbers*, not for their suppression control laws. [DERIVED]
- **Dual-control and trust-region comparisons are analogies of structure, not identities**; the report states where each mapping is weak and does not force equivalence. [SYNTHESIS]
- **Some corroborating figures** (e.g., DAST’s “Mach 0.95 at 25,000 ft” design boundary vs. “Mach 0.825” system-on flutter) come from NASA program descriptions and a NASA history volume rather than a single primary flutter report, and refer to different configurations (open-loop design boundary vs. half-gain closed-loop event); they are consistent but should be cited precisely. [SOURCE/OPEN]
- **Machine-learning applications** are reported only where genuine peer-reviewed citations exist (DMD/OMA/ARMA for mode detection; Israel Air Force F-16 study); broader “AI flutter prediction” claims were deliberately excluded as unsupported. [DERIVED]