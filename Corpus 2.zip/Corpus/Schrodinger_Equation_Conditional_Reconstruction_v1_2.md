---
title: "A Conditional Reconstruction of the Free Nonrelativistic Schrödinger Equation"
subtitle: "From Operational State-Transition Principles to a Localized Massive Particle"
version: "Draft 1.2"
date: "2026-07-29"
status: "Audited formal reconstruction and assumption ledger"
---

# A Conditional Reconstruction of the Free Nonrelativistic Schrödinger Equation

## From Operational State-Transition Principles to a Localized Massive Particle

**Draft 1.2 — 2026-07-29**

---

## Abstract

This document contains two connected but distinct conditional reconstructions.

**The first** reconstructs finite-dimensional complex unitary quantum mechanics — density-matrix state space, trace-represented probabilities, and continuous unitary dynamics — from operational, convex-geometric, and compositional assumptions about state spaces.

**The second** reconstructs the free nonrelativistic particle Hamiltonian from the representation theory of the Galilei group together with covariant localization and an empirical energy calibration.

Combined, under their stated assumptions, they yield:

`i * hbar * partial_t psi(x,t) = -(hbar^2 / 2m) * nabla^2 psi(x,t)`

The equation is not derived from logic alone, nor from state-transition consistency alone. The reconstruction instead identifies a sequence of explicit purchases about the kind of state-transition structure realized by the world. Under the declared assumptions, the complex quantum state space, the trace representation of already-allowed effects, unitary dynamics, the von Neumann equation, the canonical commutator, and the free kinetic operator are consequences of those assumptions rather than independent postulates introduced at the final stage. The reconstruction is therefore conditional rather than assumption-free.

The reconstruction is finite-dimensional through the complex-matrix classification. Its extension to a particle localized in continuous Euclidean space requires additional analytic and physical assumptions. An interaction term `V(x,t)` is not fixed by the free symmetry argument and remains a system-specific empirical input.

This is a synthesis of established mathematical results, not a claim of a new theorem. Its contribution is the explicit dependency structure: every conclusion is paired with the assumptions and theorems that authorize it, and every unearned claim remains visible.

---

# 0. Purpose

## 0.1 What this document is for

The purpose is **auditing, not proving**.

This is not an attempt to show that quantum mechanics is inevitable, nor that it follows from pure reason, information theory, or logical consistency. It is a map of the price. It answers one question: *what exactly must be assumed about the world in order for the free Schrödinger equation to follow, and which theorem authorizes each step?*

Accordingly, the document is organized as a ledger. Every claim carries a label — definition, logical consequence, framework-level empirical purchase, system-level empirical purchase, or external theorem — and no claim is permitted to be stronger than the assumptions beneath it. Where a step is unearned, it is marked unearned and left visible rather than smoothed over.

The intended use is as a scope constraint on downstream work. If a numerical implementation, a physical claim, or a philosophical conclusion depends on this chain, the ledger fixes how strong that conclusion is allowed to be.

## 0.2 The argument in one page

**Part One — operational reconstruction (Steps 1 through 14).**
Assume states are individuated by measurement statistics, that preparations can be randomized, that isolated dynamics is continuous and reversible, that no pure state is privileged, that enough reversible filters exist to reach any interior state, that composites are locally tomographic with compatible self-duality, and that a qubit exists. Then the state space of a finite system is forced to be the density matrices on a complex Hilbert space, probabilities are trace pairings, and continuous reversible dynamics is unitary. This part is a synthesis of the generalized-probabilistic-theory reconstruction literature.

**Part Two — identification of the generator (Step 15).**
The first part fixes the *form* of dynamics but says nothing about *which* Hamiltonian a particle in space has. Assume additionally an infinite-dimensional extension, that the time-translation generator is energy calibrated by `hbar`, and that the system is a covariantly localized irreducible massive Galilean particle with no internal dynamics. Then the Bargmann central extension supplies mass, the boost-position identification supplies the canonical commutator, Stone-von Neumann supplies `P = -i hbar nabla`, and the Galilei algebra fixes the free Hamiltonian to `P^2/(2m)` up to an additive constant.

Chaining the two yields the free position-space equation. Neither part alone does.

## 0.3 Where the argument is weakest

Two assumptions carry disproportionate load, and a reader evaluating this document should attack them first.

**A6 — reversible-filter reachability.** This is the largest single purchase in Part One. In the generalized-probabilistic setting used here it is equivalent to strict-positive-state interconvertibility, and therefore operationally restates cone homogeneity rather than deriving it from something visibly weaker. The step from A6 to homogeneity should be read as a translation between two formulations of the same condition, not as a derivation that reduces the assumption's cost.

**A13 — localized irreducible massive Galilean particle with no nontrivial internal Hamiltonian.** This is the largest single purchase in Part Two, and it is close to its own conclusion. In particular, the clause excluding nontrivial internal dynamics is precisely what forces the remainder `H - P^2/(2m)` to be a scalar. The derivation of the kinetic term is genuine representation theory, but the assumption already specifies a free elementary particle.

Neither observation invalidates the chain. Both are stated here so that the chain is not mistaken for a cheaper result than it is.

---

# 1. Scope, target, and claim strength

## 1.1 Target equation

The target is the position-space equation for a single nonrelativistic particle:

`i * hbar * partial_t psi(x,t) = [-(hbar^2 / 2m) * nabla^2 + V(x,t)] psi(x,t)`

The structural reconstruction reaches the free part:

`i * hbar * partial_t psi(x,t) = -(hbar^2 / 2m) * nabla^2 psi(x,t)`

The interaction term `V(x,t)` is not selected by the free symmetry structure. It describes the particular environment or interaction being modelled.

## 1.2 What is reconstructed

The chain reconstructs, conditionally:

- convex operational state spaces;
- affine and then linear state-transition maps;
- reversible one-parameter dynamics;
- homogeneous and self-dual state cones;
- simple Euclidean Jordan structure;
- complex Hermitian matrix state spaces;
- density matrices and trace-pairing probabilities;
- projective-unitary continuous dynamics;
- the von Neumann equation for density operators, and its lift to the abstract finite-dimensional Schrödinger equation for state vectors;
- the Galilean central extension and the role of mass as its central charge;
- canonical position-momentum commutation relations;
- the free kinetic Hamiltonian;
- the free position-space Schrödinger equation.

## 1.3 What is not claimed

This document does not claim:

- that the assumptions are logically necessary for every possible physical world;
- that the reconstruction is unique;
- that the operational principles were derived without empirical input;
- that the finite-dimensional classification automatically proves the continuum theory;
- that all mathematically admissible effects are physically realizable;
- that an arbitrary potential follows from Galilean symmetry;
- that open, irreversible, driven, relativistic, or quantum-field dynamics are covered;
- that the numerical value of the mass, or which mass sector nature realizes, is determined;
- that the derivation of cone homogeneity from A6 reduces the cost of that assumption.

## 1.4 Assumption classes

The derivation labels inputs by role:

| Class | Meaning |
|---|---|
| **D** | Definition or bookkeeping convention |
| **L** | Logical or mathematical consequence of earlier premises |
| **F** | Framework-level empirical principle about allowed state-transition structures |
| **S** | System-level empirical input about the particular physical system |
| **T** | External mathematical theorem with stated hypotheses |

A conclusion is only as strong as the assumptions and theorem hypotheses supporting it.

## 1.5 Finite-dimensional working framework

### Assumption A0 — Finite-dimensional compact state space [F/D]

For Steps 1 through 14, each system's normalized operational states admit a faithful representation as a compact subset `Omega` of a finite-dimensional real affine space `V`.

This is a working framework assumption, not a consequence of state-transition consistency. Convexity is derived later from closure under classical randomization; finite dimensionality and compactness are purchased here. They are required by the compact-group averaging argument and by the finite-dimensional reconstruction and classification theorems used in Steps 11 through 13.

Assumption A11 in Step 15 explicitly replaces this finite-dimensional working scope with a strongly continuous infinite-dimensional Hilbert-space extension for continuous particle degrees of freedom. A11 is not derived from A0.

---

# 2. Step 1 — Dynamical sufficiency of present state

## 2.1 State concept

Assume that, for the system and scope under consideration, there exists a present-state description `S` sufficient to determine the admissible statistics of subsequent evolution once the relevant interaction conditions are specified.

This does not require that `S` be directly observable or classically sharp. It requires only that no additional retained preparation record changes future operational predictions once `S` is fixed.

### Assumption A1 — Operational dynamical sufficiency [F]

If two preparations define the same operational state, then future outcome statistics under the same admissible intervention are identical.

This is stronger than merely claiming that some hidden complete state exists. It says that the operational state used by the theory is itself dynamically sufficient for the predictions the theory makes.

## 2.2 State-transition notation

For a time-homogeneous isolated system, write:

`T_t(S) = state after elapsed time t`

At this stage:

- `S` need not be a vector;
- `T_t` need not be linear;
- no complex numbers are assumed;
- no wavefunction is assumed.

---

# 3. Step 2 — Identity, composition, and continuity

## 3.1 Identity

Zero elapsed time changes nothing:

`T_0(S) = S`

## 3.2 Composition

Time partitioning must be consistent:

`T_(t+s)(S) = T_t(T_s(S))`

This is the one-parameter semigroup law for autonomous evolution.

## 3.3 Continuity

Assume that sufficiently small changes in elapsed time produce sufficiently small changes in state.

### Assumption A2 — Continuous autonomous evolution [F]

The map `t -> T_t` is continuous, and the transition rule depends only on elapsed time rather than absolute clock time.

Time-dependent external driving is excluded at this stage and would require a two-time propagator.

---

# 4. Step 3 — Local generator without a vector-space assumption

A derivative does not require the full state space to be a vector space. A differentiable state manifold is enough.

If the state space is a differentiable manifold `M`, then the continuous flow has a local tangent generator:

`dS/dt = X(S)`

where `X` is a vector field on `M`.

This establishes only that continuous time-homogeneous evolution has a local generator. It does not establish linearity, probability conservation, or quantum structure.

---

# 5. Step 4 — Operational identification and convex state space

## 5.1 Operational equivalence

Two preparations represent the same state when every allowed measurement assigns them the same outcome probabilities.

This introduces probability operationally. Probability is therefore present before the complex quantum formalism appears.

## 5.2 Classical randomization

Suppose a classical random device prepares state `A` with probability `p` and state `B` with probability `1-p`.

The resulting operational state is represented by:

`S = pA + (1-p)B`

for `0 <= p <= 1`.

By Assumption A0, the normalized state set is compact and faithfully represented in a finite-dimensional real affine space `V`. Closure under classical randomization now makes that set convex. Therefore the normalized states form a compact convex set `Omega`.

The physical state set is not a vector space. Only convex mixtures are automatically states. Expressions such as `2A-B` need not be physical.

## 5.3 Affinity of dynamics

Classical randomization can occur before or after applying the transition rule. Operational sufficiency requires the two procedures to agree:

`T_t(pA + (1-p)B) = pT_t(A) + (1-p)T_t(B)`

Therefore `T_t` is affine on `Omega`.

This is probability-state affinity, not yet quantum amplitude linearity.

### Dependency

This conclusion uses:

- classical randomization;
- operational identification;
- no hidden branch dependence after the randomized label is discarded.

---

# 6. Step 5 — The positive cone and linear extension

## 6.1 Subnormalized states

Construct the cone of subnormalized states:

`C = {lambda * S : lambda >= 0, S in Omega}`

Let `u` be the normalization functional:

`u(S) = 1` for normalized states,

and more generally:

`u(lambda S) = lambda`.

## 6.2 Linear extension

An affine normalization-preserving map on `Omega` extends linearly to the cone and then to the real span of the cone.

Thus the transition becomes a positive linear map:

`T_t : C -> C`

with:

`u(T_t(x)) = u(x)`

for isolated deterministic evolution.

The cone construction is representation bookkeeping. It does not by itself select quantum theory.

---

# 7. Step 6 — Reversible isolated dynamics

### Assumption A3 — Physical reversibility [F]

For an isolated system, each `T_t` is a bijection of the physical state space and its inverse is the physical evolution `T_-t`.

Then:

`T_(t+s) = T_t T_s`

`T_0 = id`

`T_t^-1 = T_-t`

The dynamics form a continuous one-parameter group of affine automorphisms of `Omega`.

Reversible affine maps preserve extreme points. Hence pure states evolve to pure states.

The infinitesimal generator belongs to the Lie algebra of the normalized reversible automorphism group:

`generator in Lie(Aut(Omega))`

## 7.1 Classical finite-simplex contrast

For a finite classical state space, `Omega` is a simplex. Its affine automorphisms only permute vertices. The permutation group is discrete, so there is no nontrivial continuous reversible affine motion.

This does not exclude infinite-dimensional classical Hamiltonian systems. It only shows that finite classical probability simplices cannot support the required continuous reversible dynamics.

---

# 8. Step 7 — Continuous pure-state transitivity

### Assumption A4 — Continuous pure-state transitivity [F]

For any two pure states of the same system, there exists a continuous reversible path connecting them.

Equivalently, the connected reversible group acts transitively on the pure states.

This says that no pure state is structurally privileged.

It does **not** imply cone homogeneity. Pure-state transitivity concerns extreme normalized states; cone homogeneity concerns all interior positive elements under normalization-changing order automorphisms.

## 8.1 Invariant state

By A0, the normalized state space is compact and finite-dimensional. The compact closure of the normalized reversible group therefore admits Haar averaging. Averaging any state over the group produces an invariant state `M`.

Because the group acts transitively on pure states and every normalized state is a convex combination of pure states, the group average of every normalized state is the same `M`. Therefore the invariant state is unique.

For every normalized reversible map `g`:

`g(M) = M`

This fixed point proves that normalized reversible maps cannot act transitively on the interior of `Omega`.

## 8.2 Invariant real inner product

Averaging any positive-definite real inner product over the compact normalized reversible group yields a group-invariant positive-definite real inner product.

This is a weak result:

- it need not be unique;
- it need not self-dualize the cone;
- it does not identify states with effects;
- it does not imply the Born trace formula.

---

# 9. Step 8 — Effects and measurements

## 9.1 Effects

An effect is an affine outcome-probability functional:

`e : Omega -> [0,1]`

Classical randomization implies affinity. On the cone, `e` extends to a positive linear functional.

The unit effect is:

`u(S) = 1`

for every normalized state.

A measurement is a finite collection `{e_i}` satisfying:

`sum_i e_i = u`

## 9.2 Physical and mathematical effect cones

Let `C*` be the full mathematical dual cone of positive linear functionals.

The physically allowed positive effect cone may be smaller:

`E_+ subseteq C*`

The no-restriction hypothesis would assert:

`E_+ = C*`

No-restriction is not assumed in this reconstruction.

## 9.3 Effects do not determine disturbance

An effect provides only an outcome probability. It does not specify the post-outcome state. Sequential measurement therefore requires additional transformation structure.

---

# 10. Step 9 — Instruments and conditioning

### Assumption A5 — Sequential instrument structure [F]

For each physically allowed sequential measurement, there are positive linear event maps:

`F_i : C_A -> C_B`

such that:

`u_B(F_i(S)) = e_i(S)`

and the nonselective sum is a deterministic channel:

`sum_i F_i : C_A -> C_B`

`u_B(sum_i F_i(S)) = u_A(S)`

The output system `B` need not equal the input system `A`. Same-system filters are a stronger special case.

## 10.1 Conditioning

When `e_i(S) > 0`, the normalized conditional state is:

`S_i = F_i(S) / e_i(S)`

The event map `F_i` is linear on the cone. The normalized conditioning rule is generally nonlinear on `Omega` because of division by the outcome probability.

## 10.2 Bayes reweighting

For:

`S = pA + (1-p)B`

linearity gives:

`F_i(S) = pF_i(A) + (1-p)F_i(B)`

After normalization, the posterior weight of branch `A` is:

`p' = [p * e_i(A)] / [p * e_i(A) + (1-p) * e_i(B)]`

This is Bayes reweighting derived from linear subnormalized conditioning.

## 10.3 Important restrictions

The following do not follow from instrument existence:

- every mathematical effect has a physical instrument;
- every allowed effect has a same-system instrument;
- measure-and-prepare closure;
- repeatability;
- minimal disturbance;
- projective or Lüders updating.

The mathematically valid map:

`F(S) = e(S) * M`

is physically available only if the theory permits the required measurement, discard, preparation, sequential composition, and classical control operations.

---

# 11. Step 10 — Probabilistically reversible filters and cone homogeneity

## 11.1 Exact physical inverses cannot be lossy

Suppose a same-system event `F` and its exact inverse `F^-1` are both physical events. Physical events are normalization-nonincreasing:

`u(F(S)) <= u(S)`

Applying the inverse event to `F(S)` gives:

`u(S) = u(F^-1(F(S))) <= u(F(S))`

Therefore:

`u(F(S)) = u(S)`

So exact physical invertibility forces `F` to be a deterministic reversible channel. Such maps fix `M` and cannot generate interior transitivity.

## 11.2 Probabilistic reversibility

A same-system filter `F` is probabilistically reversible when there exists a physical recovery event `R` such that:

`R F = p * id`

for some `p > 0`.

If one initially writes `R F(S) = p(S)S`, then in dimension at least two, applying linearity to two nonparallel interior states forces `p(S)` to be constant on the interior and hence on the span. The one-dimensional case is trivial and is handled separately.

Therefore:

`F^-1 = R / p`

is a positive mathematical inverse. Thus `F` is an order automorphism of the cone:

`F(C) = C`

The inverse need not itself be a physical event without attenuation. The order automorphism is mathematical; its scaled realization is physical.

### Assumption A6 — Reversible-filter reachability [F]

For every interior normalized state `A`, there exists a physically allowed same-system probabilistically reversible filter `F_A` and a scalar `q_A > 0` such that:

`F_A(M) = q_A A`

## 11.3 Derivation of cone homogeneity

Given interior states `A` and `B`, the mathematical order automorphism:

`F_B F_A^-1`

maps the ray of `A` to the ray of `B`. A positive scalar rescaling then maps `A` exactly to `B`.

Therefore the full mathematical order-automorphism group is transitive on the interior of `C`.

### Conclusion C10 [L]

`C` is homogeneous.

This is the largest single framework purchase in the reconstruction. In the finite-dimensional GPT setting and with probabilistic reversibility defined as above, homogeneity is equivalent to the probabilistic reversible interconvertibility of strictly positive states. Assumption A6 chooses the invariant state `M` as a basepoint and is therefore an operational restatement of that transitivity, not merely something close to it. Step 10 translates the purchased operational property into the geometric statement of cone homogeneity. [R1]

---

# 12. Step 11 — Self-duality and Euclidean Jordan structure

A recent theorem establishes the required bridge.

### Theorem T11 — Homogeneity plus pure transitivity [T]

In a finite-dimensional ordered vector space, cone homogeneity together with pure-state transitivity implies self-duality and Euclidean Jordan-algebra structure. The stronger continuous pure-state transitivity used here yields the simple case rather than a nontrivial direct sum of isomorphic sectors. [R1]

The inputs are now available:

- cone homogeneity from Step 10;
- continuous pure-state transitivity from Step 7;
- finite dimensionality from the working framework.

## 12.1 Self-duality

There exists a positive-definite real inner product `<.,.>_sd` such that:

`x in C`

if and only if:

`<x,y>_sd >= 0 for every y in C`

The self-dualizing inner product need not be the inexpensive group-averaged inner product constructed in Step 7.

Self-duality identifies the state cone with the full mathematical dual cone `C*`. It does not prove that the physically allowed effect cone equals `C*`.

## 12.2 Euclidean Jordan algebra

By the Koecher-Vinberg classification, a finite-dimensional homogeneous self-dual cone is the cone of squares of a Euclidean Jordan algebra.

Because continuous pure transitivity excludes nontrivial direct sums, the algebra is simple.

The simple finite-dimensional possibilities are:

- real Hermitian matrices `H_n(R)`;
- complex Hermitian matrices `H_n(C)`;
- quaternionic Hermitian matrices `H_n(H)`;
- spin factors;
- the exceptional Albert algebra `H_3(O)`.

Complex quantum mechanics has not yet been selected.

---

# 13. Step 12 — Minimal composite-system structure

Everything through Step 11 concerns a single system. Composition is additional structure.

### Assumption A7 — Composite systems [F]

For systems `A` and `B`, there exists a system `AB` such that:

1. independent preparations define product states;
2. local effects can be jointly applied;
3. joint states assign consistent probabilities to product effects;
4. local marginal statistics do not depend on which measurement is chosen remotely.

Condition 4 is no-signalling.

## 13.1 What is earned

Each joint state defines a bilinear table:

`omega(e,f)`

for allowed local effects `e` on `A` and `f` on `B`.

Independent states define products:

`(alpha tensor beta)(e,f) = alpha(e) * beta(f)`

## 13.2 What is not yet earned

Without local tomography, distinct joint states may agree on every product-effect probability. Therefore the full composite need not embed faithfully in:

`V_A tensor V_B`

Only its locally observable image is represented there.

Because no-restriction remains unearned, any maximal local-statistics construction must be defined relative to the physically allowed effect cones, not automatically the full dual cones.

No Jordan product on the composite has yet been established.

---

# 14. Step 13 — Local tomography, compatible self-duality, and a qubit

This step introduces a package of composite assumptions.

### Assumption A8 — Local tomography [F]

A joint state is completely determined by all joint probabilities assigned to pairs of local effects.

Therefore the local-statistics representation is faithful, and under the standard finite-dimensional composite framework:

`V_AB = V_A tensor V_B`

`dim(V_AB) = dim(V_A) * dim(V_B)`

### Assumption A9 — Factorizable self-duality [F]

The self-dualizing inner products can be selected compatibly with products:

`<a tensor b, c tensor d>_AB = <a,c>_A * <b,d>_B`

Single-system self-duality does not force this cross-system compatibility.

### Assumption A10 — Existence of a qubit [F]

The theory contains a system with Jordan algebra:

`H_2(C)`

whose normalized state space is the three-dimensional Bloch ball, and this system forms the required locally tomographic, compatibly self-dual composites with the other systems.

## 14.1 Hanche-Olsen / Barnum-Wilce conclusion

Under the Barnum-Wilce composite hypotheses, local tomography, compatible self-duality, and a qubit provide the compatibility conditions required by Hanche-Olsen's theorem. The resulting systems are the self-adjoint parts of finite-dimensional complex C*-algebras. [R2]

Step 11 already supplied simplicity. Therefore a nontrivial system has:

`V = H_n(C)`

The normalized states are positive matrices of unit trace:

`rho >= 0`

`Tr(rho) = 1`

## 14.2 Trace representation of allowed effects

Self-duality and the complex matrix representation imply that every already-allowed affine effect has a positive-matrix representative `E` satisfying:

`e(rho) = Tr(rho E)`

For an outcome probability bounded by one:

`0 <= E <= I`

for every physically allowed effect `E`.

This is the trace representation of an already-assumed operational probability functional. It does not derive probability from geometry, and it does not prove no-restriction.

## 14.3 Dimension-counting intuition

For matrix size `n`:

`dim H_n(R) = n(n+1)/2`

`dim H_n(C) = n^2`

`dim H_n(H) = n(2n-1)`

For two size-two systems, local dimension multiplication gives:

- real: `3 * 3 = 9`, but `dim H_4(R) = 10`;
- complex: `4 * 4 = 16`, and `dim H_4(C) = 16`;
- quaternionic: `6 * 6 = 36`, but `dim H_4(H) = 28`.

This explains why the complex family is dimensionally compatible with ordinary same-family locally tomographic composition. It is intuition, not a replacement for the composite theorem.

---

# 15. Step 14 — Continuous reversible dynamics on complex state space

We now know the normalized state space exactly: density matrices on `C^n`.

## 15.1 Affine automorphisms

The affine automorphisms of the density-matrix state space are induced by either unitary or antiunitary Hilbert-space transformations. This is the state-space form of the Kadison/Wigner-Uhlhorn symmetry classification. In matrix form they are:

`rho -> U rho U^dagger`

or:

`rho -> U rho^T U^dagger`

where the second family is induced by antiunitary conjugation. [R3, R3S]

## 15.2 Connected component

The physical evolution `T_t` is a continuous path beginning at the identity. Therefore it remains in the connected identity component and cannot cross into the antiunitary-induced component.

This does not exclude time-reversal symmetry as a discrete relation such as:

`Theta U_t Theta^-1 = U_-t`

It only excludes antiunitary-induced maps from being the continuously connected forward propagator itself.

## 15.3 Projective unitary implementation

Density matrices are insensitive to global phase. Therefore the implementing unitaries are initially defined projectively:

`U_(t+s) = exp(i * alpha(t,s)) U_t U_s`

Every continuous one-parameter subgroup of `PU(n)` has a Lie-algebra lift. After a consistent phase choice:

`U_t = exp(-i t K)`

with:

`K^dagger = K`

The scalar part of `K` is invisible on density matrices:

`K -> K + cI`

## 15.4 Von Neumann equation

For:

`rho(t) = U_t rho(0) U_t^dagger`

differentiation gives:

`d rho/dt = -i [K,rho]`

## 15.5 Abstract finite-dimensional Schrödinger equation

Operationally, the reconstructed dynamics is the unitary evolution of density operators, given by the von Neumann equation of Section 15.4. That equation is the primary object: it is phase-invariant and is stated directly in terms of the reconstructed state space.

The familiar vector equation is obtained by lifting. For a pure state:

`rho = |psi><psi|`

choose a consistent phase lift of the projective one-parameter group — available by Section 15.3, since every continuous one-parameter subgroup of `PU(n)` admits a Lie-algebra lift — and take the resulting representative of each ray:

`|psi(t)> = U_t |psi(0)>`

Then:

`d|psi>/dt = -i K |psi>`

or:

`i d|psi>/dt = K |psi>`

This is the abstract finite-dimensional Schrödinger equation. It is a representation choice rather than additional physical content: the lift is fixed only up to the scalar freedom `K -> K + cI`, which is invisible on density operators.

At this point `K` has dimensions of inverse time. It has not yet been identified with physical energy divided by `hbar`.

---

# 16. Step 15 — From the abstract equation to a particle in space

**At this point the operational reconstruction is complete.** Under A0 through A10, the preceding sections establish finite-dimensional complex quantum state space, trace-represented probabilities, and continuous unitary dynamics.

The remaining steps do not continue that operational derivation. The character of the argument changes here. Part One asked what state spaces must look like; Part Two identifies the generator appropriate to a free, localized, nonrelativistic particle by introducing additional physical assumptions about spacetime symmetry and localization. These assumptions are not consequences of the operational premises, and the finite-dimensional structural chain does not extend to them.

Readers auditing the dependency graph should treat Section 16 as a second, separately conditioned reconstruction that takes the output of the first as input.

## 16.1 Infinite-dimensional extension

### Assumption A11 — Strongly continuous Hilbert-space extension [F/S]

The complex finite-dimensional theory extends to a Hilbert-space theory appropriate to continuous degrees of freedom, with strongly continuous unitary time evolution.

A11 is an explicit scope extension that replaces A0 for the continuous particle sector. The finite-dimensional Jordan classification does not prove this extension. Infinite-dimensional Jordan and operator-algebra theories exist, but the particular reconstruction chain above has not been carried through to `L^2(R^3)`.

Stone's theorem supplies the analytic replacement for the finite matrix exponential statement: every strongly continuous one-parameter unitary group has a self-adjoint generator, generally unbounded and defined on a dense domain.

Thus:

`U_t = exp(-i t K)`

and on the generator domain:

`i d|psi>/dt = K|psi>`

## 16.2 Energy calibration and `hbar`

### Assumption A12 — Energy-generator identification [S]

The physical conserved quantity called energy is represented by `hbar` times the time-translation generator:

`H = hbar K`

where `hbar` is the empirically calibrated constant with dimensions of action.

Then:

`i hbar d|psi>/dt = H|psi>`

Setting `hbar = 1` is a unit convention only after this physical conversion has been established.

## 16.3 Localization in Euclidean space

### Assumption A13 — Localized elementary particle [S]

The system is an elementary particle localized in Euclidean three-space and carries:

- a covariant position observable;
- spatial translations and rotations;
- Galilean boosts;
- an irreducible projective unitary representation of the Galilei group in a fixed massive sector.

A covariant localization observable is additional structure. Symmetry alone does not install a position operator. Mackey's system-of-imprimitivity framework relates transitive spatial symmetry and covariant localization to a function-space representation such as:

`L^2(R^3, C^d)`

where `C^d` can carry spin.

## 16.4 Bargmann central extension and mass

Quantum symmetries act on rays, so Galilei transformations are represented projectively. The projective multiplier is represented ordinarily on the Bargmann central extension.

For the ordinary massive `3+1`-dimensional Galilean particle, the central generator has fixed value:

`M = mI`

Within an irreducible massive Galilean representation, mass is identified as the central-charge label of the representation. [R4, R5]

The scope of this identification should be stated precisely. The reconstruction determines the *role* of mass within that representation — it appears as the central charge of the Bargmann extension, and it is what makes the boost-position identification of Section 16.6 available. It does **not** determine which mass sector nature realizes, nor the numerical value of the mass. Both remain empirical inputs.

This is a cohomological extension, not merely the topological covering issue associated with rotations and spin.

Within the standard fixed-mass irreducible representation framework, different masses label inequivalent sectors. This is the conditional content of the Bargmann mass-superselection rule; it is not an unrestricted prohibition in enlarged theories where mass is dynamical. [R4]

## 16.5 Galilei Lie algebra

Using conventional signs, the relevant commutators include:

`[G_i, P_j] = i hbar m delta_ij`

`[G_i, H] = i hbar P_i`

`[P_i, H] = 0`

for a free particle, together with the usual rotation relations.

Here:

- `P_i` generates spatial translations;
- `G_i` is the conserved boost generator;
- `H` generates time translations.

## 16.6 Position-momentum commutator

For a fixed nonzero mass sector, the conserved boost generator may be written:

`G_i = m X_i - t P_i`

At `t = 0`:

`X_i = G_i / m`

Therefore:

`[X_i, P_j] = i hbar delta_ij`

The canonical commutator follows from the Bargmann algebra plus the physical identification of the conserved boost generator with `mX - tP`.

Under the regularity and irreducibility conditions of the Stone-von Neumann theorem, the Weyl commutation relations have the Schrödinger representation, unique up to unitary equivalence: [R6]

`(X_i psi)(x) = x_i psi(x)`

`(P_i psi)(x) = -i hbar partial_i psi(x)`

Therefore:

`P = -i hbar nabla`

## 16.7 Free Hamiltonian

From the Galilei commutators:

`H - P^2/(2m)`

commutes with boosts, translations, and rotations. In an irreducible elementary sector with no nontrivial internal dynamics, this remainder is a scalar:

`H = P^2/(2m) + E_0 I`

The constant `E_0` is an internal-energy or zero-energy label. It can be removed within a fixed sector by a global time-dependent phase.

Note the dependency: the step to a scalar remainder is authorized by the clause in A13 excluding nontrivial internal dynamics, not by the Galilei algebra alone. An irreducible sector carrying internal structure would permit a nonscalar remainder. The conclusion is therefore that, **within the standard irreducible massive Galilean particle model, the free Hamiltonian is fixed, up to an additive constant, to the quadratic kinetic operator.**

After choosing `E_0 = 0`:

`H_free = P^2/(2m)`

Using:

`P = -i hbar nabla`

gives:

`H_free = -(hbar^2 / 2m) nabla^2`

## 16.8 Free Schrödinger equation

Substituting the free Hamiltonian into the abstract equation yields:

`i hbar partial_t psi(x,t) = -(hbar^2 / 2m) nabla^2 psi(x,t)`

This is the free nonrelativistic Schrödinger equation for a localized elementary massive particle.

## 16.9 Interaction term

A general external potential is not fixed by free Galilean symmetry.

Adding:

`V(x,t)`

is a further empirical specification of the system and environment:

`i hbar partial_t psi(x,t) = [-(hbar^2 / 2m) nabla^2 + V(x,t)] psi(x,t)`

An arbitrary external potential may break translation, rotation, or boost symmetry. Interacting many-particle systems may retain Galilean invariance when the interaction depends only on appropriate relative variables.

---

# 17. Main conditional theorem

## Theorem — Conditional reconstruction of the free equation

Assume:

1. for Steps 1 through 14, a compact finite-dimensional normalized state space as specified by A0;
2. operationally sufficient states;
3. closure under classical randomization;
4. continuous, time-homogeneous, reversible isolated dynamics;
5. continuous pure-state transitivity;
6. sequential instrument structure;
7. enough probabilistically reversible same-system filters to reach every interior state from the invariant state;
8. composite systems with product preparations, product effects, and no-signalling;
9. local tomography;
10. compatible factorization of self-dualizing pairings;
11. existence of a qubit with the required composites;
12. a strongly continuous infinite-dimensional Hilbert-space extension that replaces A0 for the continuous particle sector;
13. empirical calibration of the time-translation generator as energy through `hbar`;
14. a covariantly localized, irreducible, massive Galilean particle sector with no nontrivial internal Hamiltonian.

Then, up to a removable scalar energy offset, the particle state in the position representation obeys:

`i hbar partial_t psi(x,t) = -(hbar^2 / 2m) nabla^2 psi(x,t)`

An interaction term `V(x,t)` requires an additional system-specific empirical model.

## Proof dependency summary

`operational equivalence + randomization`

`-> convex normalized state space`

`-> affine state transformations`

`-> positive linear cone maps`

`+ reversibility`

`-> continuous automorphism group`

`+ pure-state transitivity`

`-> unique invariant state`

`+ probabilistically reversible filter reachability`

`-> cone homogeneity`

`+ pure-state transitivity`

`-> self-duality + simple Euclidean Jordan algebra`

`+ local tomography + compatible self-duality + qubit`

`-> H_n(C)`

`-> density matrices + trace representation of allowed effects`

`+ continuous reversible dynamics`

`-> projective unitary one-parameter group`

`-> i d|psi>/dt = K|psi>`

`+ energy calibration`

`-> i hbar d|psi>/dt = H|psi>`

`+ infinite-dimensional localization + Galilei/Bargmann representation`

`-> [X_i,P_j] = i hbar delta_ij`

`-> P = -i hbar nabla`

`-> H_free = P^2/(2m)`

`-> i hbar partial_t psi = -(hbar^2/2m)nabla^2 psi`

---

# 18. Assumption and dependency ledger

| ID | Assumption or theorem | Type | Direct purchase | Major downstream dependence |
|---|---|---|---|---|
| A0 | Finite-dimensional compact normalized state space | F/D | Finite-dimensional compact working framework | Haar averaging; finite-dimensional T11, Koecher-Vinberg, and Barnum-Wilce chain |
| A1 | Operational dynamical sufficiency | F | Operational state closes future predictions | Affinity, instrument linearity |
| A2 | Continuous autonomous evolution | F | One-parameter flow | Generator |
| A3 | Physical reversibility | F | Group rather than semigroup | Pure-state preservation, Lie dynamics |
| A4 | Continuous pure-state transitivity | F | No privileged pure state | Invariant state, simplicity, self-duality theorem |
| A5 | Sequential instruments | F | Post-outcome transformations | Conditioning and filters |
| A6 | Reversible-filter reachability — **heaviest purchase in Part One** | F | Interior reachability from `M`; equivalent to cone homogeneity, not weaker than it | Cone homogeneity |
| T11 | Homogeneity + pure transitivity theorem | T | Self-duality and Jordan structure | EJA classification |
| A7 | Basic composite framework | F | Product operations and no-signalling | Composite state statistics |
| A8 | Local tomography | F | Faithful tensor representation | Complex selection package |
| A9 | Factorizable self-duality | F | Compatible composite geometry | Hanche-Olsen compatibility |
| A10 | Qubit exists | F | `H_2(C)` reference system | Complex C*-algebra selection |
| T13 | Barnum-Wilce / Hanche-Olsen | T | Complex matrix-algebra structure | Density matrices and trace form |
| T14 | Affine automorphism classification | T | Unitary/antiunitary implementation | Abstract Schrödinger dynamics |
| A11 | Infinite-dimensional extension replacing A0 for the particle sector | F/S | Continuous degrees of freedom | `L^2` particle theory |
| A12 | Energy calibration by `hbar` | S | Frequency-to-energy conversion | Physical Hamiltonian equation |
| A13 | Localized irreducible massive Galilean particle, no internal dynamics — **heaviest purchase in Part Two** | S | Position, momentum, mass sector; the no-internal-dynamics clause forces the scalar remainder | Free kinetic Hamiltonian |
| T15a | Mackey imprimitivity | T | Covariant localization representation | `L^2(R^3,C^d)` |
| T15b | Bargmann central extension | T | Mass central charge | Boost-momentum commutator |
| T15c | Stone-von Neumann | T | Uniqueness of regular irreducible CCR representation | `P = -i hbar nabla` |

---

# 19. What was derived, what was represented, and what was assumed

## 19.1 Derived conditionally

Given the ledger assumptions:

- convexity of operational states;
- affinity of deterministic dynamics;
- linearity on the cone;
- Bayes reweighting under conditioning;
- fixed-point structure of normalized reversible dynamics;
- cone homogeneity from probabilistic reversible filters;
- self-duality and simple EJA structure;
- complex Hermitian matrix structure;
- trace representation of already-allowed effects;
- unitary connected dynamics;
- von Neumann evolution of density operators;
- scalar-generator gauge freedom;
- the role of mass as the central charge of the Bargmann extension, within a fixed massive sector;
- canonical commutator;
- free kinetic Hamiltonian, up to an additive constant, within the standard irreducible massive Galilean particle model;
- free position-space Schrödinger equation.

Explicitly **not** derived, and listed here to prevent the preceding items from being read too strongly:

- the numerical value of the mass, or which mass sector is realized;
- the vector-state Schrödinger equation as distinct content beyond the von Neumann equation — it is a phase-lift representation choice (Section 15.5);
- the physical realizability of every mathematically admissible effect (Section 20);
- the interaction term `V(x,t)`.

## 19.2 Representation choices

The following are mathematical representations once the relevant structure is earned:

- embedding the convex state space into a real vector space;
- passing to the positive cone of subnormalized states;
- representing self-dual states and effects with matrices;
- choosing a phase lift of projective unitary evolution, which converts the von Neumann equation into the vector-state Schrödinger equation;
- choosing the position representation of the canonical commutation relations;
- choosing the zero of energy in a fixed sector.

## 19.3 Empirical framework purchases

The major framework-level purchases are:

- the finite-dimensional compact working state-space framework A0;
- operational sufficiency and branch independence;
- reversibility of isolated dynamics;
- continuous pure-state transitivity;
- sequential instrument structure;
- reversible-filter reachability;
- local tomography;
- compatible self-duality across composites;
- existence of a qubit.

The largest single purchase is reversible-filter reachability (A6). In the GPT setting used here, it is equivalent to strict-positive-state interconvertibility and therefore operationally restates cone homogeneity rather than deriving it from a visibly weaker condition. The move from A6 to homogeneity in Step 10 should be read as a translation between two formulations of one assumption, not as a reduction in what is being assumed. This is stated again in Section 0.3 because it is the point at which the chain is most vulnerable, and burying it here would misrepresent the cost of Part One.

## 19.4 System-specific purchases

The final particle equation additionally requires:

- a continuous spatial degree of freedom;
- covariant localization in Euclidean three-space;
- a massive irreducible Galilean sector;
- the energy interpretation of time translation;
- the empirical conversion scale `hbar`;
- the absence of nontrivial internal free dynamics for the spinless elementary model.

The largest single purchase here is A13. It is close to its own conclusion: the clause excluding nontrivial internal dynamics is exactly what forces the remainder `H - P^2/(2m)` to be scalar in Section 16.7. The representation theory is genuine, but a reader should not take Part Two to derive a free particle from symmetry alone — it derives the *form* of the free Hamiltonian once a free elementary particle sector has been assumed.

The interaction `V(x,t)` remains a separate description of the particular physical world.

---

# 20. Born-rule accounting

Probability was introduced operationally when states were identified by measurement statistics and mixtures were represented convexly.

What the reconstruction later derives is the complex-matrix representation of those affine probability functionals:

`e(rho) = Tr(rho E)`

This is not a derivation of probability from non-probabilistic premises.

It also does not prove that every mathematical matrix satisfying:

`0 <= E <= I`

is physically realizable. That stronger claim is the no-restriction hypothesis and remains unearned.

A precise statement is therefore:

> Given the operational probability framework and the reconstructed complex state geometry, every already-allowed effect has a trace-pairing representation.

---

# 21. Scope boundaries

## 21.1 Finite to infinite dimensions

The complex-matrix classification is finite-dimensional. The extension to `L^2(R^3)` is assumed and then governed by infinite-dimensional operator theory.

A controlled lattice or spectral approximation may converge to a continuum theory, but no such convergence theorem is supplied by the present reconstruction.

## 21.2 Open systems

Irreversible open-system evolution is not an automorphism group. It is generally described by channels, semigroups, master equations, or dilations. The present derivation covers isolated reversible dynamics.

## 21.3 Time-dependent driving

A driven system generally has:

`H = H(t)`

and a two-time propagator rather than a time-homogeneous one-parameter group.

## 21.4 Relativistic systems

The Galilei group is the nonrelativistic spacetime symmetry. Relativistic one-particle theory uses the Poincare group, where mass appears as a Casimir label rather than the Bargmann central charge. Quantum field theory requires further structure beyond either one-particle reconstruction.

## 21.5 Potentials and interactions

The free kinetic term is symmetry-constrained. A potential or interaction is a model of the specific environment and may reduce the symmetry group.

---

# 22. Falsification and code-verification consequences

The derivation can be encoded as a dependency graph rather than stored only as prose.

For every claim, hard code should record:

- claim identifier;
- exact mathematical statement;
- supporting assumptions;
- supporting theorem and hypotheses;
- domain and dimensionality;
- representation choices;
- excluded cases;
- numerical invariants where applicable;
- allowed claim strength after verification.

Examples:

- Removing A6 should break the authorization path to homogeneity.
- Removing local tomography should prevent faithful identification of the composite with a tensor product.
- Removing compatible self-duality should block the Hanche-Olsen route.
- Removing the qubit should leave the Jordan families unselected.
- Removing localization should block the position representation.
- Removing Galilean covariance should block the symmetry derivation of `P^2/(2m)`.
- Removing energy calibration should leave only the inverse-time generator `K`.

A numerical implementation of the particle equation can then be audited against the exact theoretical scope:

- Does the code solve the free or interacting equation?
- Are boundary conditions part of the physical model or numerical box?
- Is normalization preserved to the expected tolerance?
- Is the Hamiltonian self-adjoint under the discretization?
- Does refinement recover the expected convergence order?
- Are conserved quantities monitored only where the model symmetry authorizes them?
- Are finite-box modes being mistaken for continuum physics?
- Does the result support stability, existence, a spectral claim, or a new physical claim?

The code should never authorize a stronger scientific conclusion than the derivation and verification gates support.

---

# 23. Final statement

The free nonrelativistic Schrödinger equation is not forced by state-transition consistency alone.

What this document establishes is a chain of two connected but distinct conditional reconstructions. The first reconstructs finite-dimensional complex unitary quantum mechanics from operational, geometric, and compositional assumptions. The second reconstructs the free nonrelativistic particle Hamiltonian from the representation theory of the Galilei group together with covariant localization and an energy calibration. Combined, these yield the standard free Schrödinger equation under their stated assumptions — and only under those assumptions.

In detail, a substantially stronger conditional statement than "consistency implies quantum mechanics" is justified:

> In a world whose operational state spaces are convex, reversibly dynamical, continuously pure-transitive, sufficiently filterable, locally tomographic, compatibly self-dual, and qubit-containing, finite systems acquire complex quantum state geometry and abstract Schrödinger evolution. When that framework contains a strongly continuous, covariantly localized, irreducible massive Galilean particle sector and the time-translation generator is calibrated as energy through `hbar`, the free position-space Schrödinger equation follows.

In compact form:

`state-transition structure`

`+ operational probability`

`+ reversible-filter geometry`

`+ composite-system compatibility`

`+ localized Galilean particle structure`

`= free nonrelativistic Schrödinger dynamics`

Within the standard irreducible massive Galilean particle model, the free Hamiltonian is fixed, up to an additive constant, to the quadratic kinetic operator.

The interaction term is a description of the particular world.

Neither result is assumption-free, and the document should not be cited as showing that quantum mechanics is inevitable. It shows what inevitability would cost.

---

# References

## Primary reconstruction and classification sources

**[R1]** H. Barnum, C. Ududec, and J. van de Wetering, *Self-duality and Jordan structure of quantum theory follow from homogeneity and pure transitivity*, arXiv:2306.00362 (2023).

**[R2]** H. Barnum and A. Wilce, *Local tomography and the Jordan structure of quantum theory*, arXiv:1202.4513 (2012).

**[R3]** R. V. Kadison, *Transformations of states in operator theory and dynamics*, Topology 3, Supplement 2, 177–198 (1965).

**[R3S]** Z. Bai and S. Du, *Characterization of affine automorphisms and ortho-order automorphisms of quantum probabilistic maps*, arXiv:1302.3356 (2013). Secondary finite-dimensional characterization.

## Galilean representation and localization sources

**[R4]** D. Giulini, *On Galilei invariance in quantum mechanics and the Bargmann superselection rule*, arXiv:quant-ph/9508002 (1995).

**[R5]** J. M. Figueroa-O'Farrill, S. Pekar, A. Perez, and S. Prohazka, *Galilei particles revisited*, arXiv:2401.03241 (2024).

**[R6]** B. Bekka, *Canonical Commutation Relations: A quick proof of the Stone-von Neumann theorem and an extension to general rings*, arXiv:2502.00387 (2025).

## Classical theorem sources and standard monographs

**[R7]** M. Koecher and E. B. Vinberg, foundational results on homogeneous self-dual cones and Euclidean Jordan algebras; see J. Faraut and A. Koranyi, *Analysis on Symmetric Cones*, Oxford University Press (1994).

**[R8]** H. Hanche-Olsen, results on Jordan-algebra composites with the complex qubit, used in the Barnum-Wilce reconstruction.

**[R9]** G. W. Mackey, *Induced Representations of Groups and Quantum Mechanics*, W. A. Benjamin (1968).

**[R10]** M. H. Stone, theorem on strongly continuous one-parameter unitary groups and self-adjoint generators (1932).

**[R11]** J. von Neumann, uniqueness theorem for regular irreducible representations of the Weyl canonical commutation relations (1931).

## Generalized probabilistic framework background

**[R12]** J. Barrett, *Information processing in generalized probabilistic theories*, arXiv:quant-ph/0508211; Physical Review A 75, 032304 (2007).

---

# Appendix A — Compact canonical ledger

| Claim | Status | Authorized by | Not authorized without |
|---|---|---|---|
| Finite-dimensional compact working state space | Assumed framework | A0 | Explicit finite-dimensional/compactness purchase |
| States form a convex set | Derived | Operational equivalence + randomization | Randomization closure |
| Dynamics is affine | Derived | Branch independence | Operational sufficiency |
| Cone dynamics is linear | Derived representation | Convex affinity + cone construction | Cone representation |
| Pure states remain pure | Derived | Reversible affine automorphism | Reversibility |
| Unique invariant state `M` | Derived | Compact averaging + pure transitivity | Pure transitivity |
| Instrument conditioning is linear before normalization | Derived from instrument model | Positive linear event maps | Sequential instrument structure |
| Bayes reweighting | Derived | Cone linearity + normalization | Instrument structure |
| Cone homogeneity | Restatement of A6, not a cost reduction | Reversible-filter reachability | A6 |
| Self-duality | Theorem-derived | Homogeneity + pure transitivity | T11 hypotheses |
| Simple EJA | Theorem-derived | Continuous pure transitivity + homogeneity | Finite dimensionality |
| Complex matrix algebra | Theorem-derived | LT + factorized SD + qubit | Composite package |
| Trace representation | Derived representation | Complex matrices + self-duality | Operational probability premise |
| Continuous dynamics is unitary-induced | Theorem-derived | Affine automorphism classification + continuity | Reversibility/continuity |
| von Neumann equation | Derived | Unitary conjugation of density operators | Reversibility/continuity |
| Abstract Schrödinger equation (vector form) | Representation choice | Consistent phase lift of the projective group | Pure-state representative; no content beyond von Neumann |
| Physical Hamiltonian equation | Empirically calibrated | `H = hbar K` | Energy identification |
| Role of mass as Bargmann central charge | Derived conditionally | Bargmann central extension | Fixed massive sector |
| Mass value / realized sector | Not derived | — | Empirical input |
| Canonical commutator | Derived conditionally | Bargmann algebra + boost-position identification | Localization + fixed mass |
| `P = -i hbar nabla` | Theorem-derived | Regular irreducible CCR representation | Stone-von Neumann hypotheses |
| `H_free = P^2/(2m)` up to additive constant | Derived conditionally | Galilei algebra + irreducibility + no internal dynamics | A13 free elementary sector clause |
| Free Schrödinger PDE | Derived conditionally | All preceding particle assumptions | Infinite-dimensional/localization inputs |
| `V(x,t)` | Empirical model | Particular interaction | Not fixed by free symmetry |

---

# Appendix B — Copy-safe equation list

`T_0(S) = S`

`T_(t+s)(S) = T_t(T_s(S))`

`T_t(pA + (1-p)B) = pT_t(A) + (1-p)T_t(B)`

`C = {lambda S : lambda >= 0, S in Omega}`

`sum_i e_i = u`

`u_B(F_i(S)) = e_i(S)`

`S_i = F_i(S) / e_i(S)`

`R F = p id`

`F_A(M) = q_A A`

`V = H_n(C)`

`e(rho) = Tr(rho E)`

`U_t = exp(-i t K)`

`d rho/dt = -i [K,rho]`

`i d|psi>/dt = K|psi>`

`H = hbar K`

`i hbar d|psi>/dt = H|psi>`

`[G_i,P_j] = i hbar m delta_ij`

`G_i = mX_i - tP_i`

`[X_i,P_j] = i hbar delta_ij`

`P = -i hbar nabla`

`H_free = P^2/(2m)`

`H_free = -(hbar^2 / 2m) nabla^2`

`i hbar partial_t psi(x,t) = -(hbar^2 / 2m) nabla^2 psi(x,t)`

`i hbar partial_t psi(x,t) = [-(hbar^2 / 2m) nabla^2 + V(x,t)] psi(x,t)`
