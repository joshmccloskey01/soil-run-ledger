"""
canon1_protocol.py — the rejection contract for canon/1.

Deliberately standalone. The serializer must not import the test runner, and
the runner must not own the exception type: if both sides define or import it
from different modules, `except` fails to catch even a correct rejection,
because the two class objects are not identical.

Importing this module from a *copy* at a different path reintroduces the same
defect. `PROTOCOL_SHA256` is recorded in the vector package so a divergent copy
is detectable rather than silent.
"""
from __future__ import annotations

PROTOCOL_VERSION = "canon1-protocol/2"

# v1 -> v2, forced by an implementation finding (Contract §6.3):
#   canon/1 §1.3 bounds integers to int64, but v1 had no code for violating it.
#   The first serializer had to use UNSUPPORTED, which conflated a contractual
#   profile rule with an implementation limit. Amended before any records
#   existed, which is the whole point of exercising the protocol first.

# Rejection codes. A serializer MUST raise the code matching the actual defect;
# a generic refusal is not evidence that the profile rule was applied.
FLOAT_IN_HASHED_FIELD = "FLOAT_IN_HASHED_FIELD"   # §1.3 — no floats
INTEGER_OUT_OF_RANGE = "INTEGER_OUT_OF_RANGE"     # §1.3 — outside int64 (v2)
MALFORMED_JSON = "MALFORMED_JSON"
INVALID_UTF8 = "INVALID_UTF8"
UNSUPPORTED = "UNSUPPORTED"

#: Profile rules — valid JSON that canon/1 excludes by contract.
PROFILE_CODES = frozenset({FLOAT_IN_HASHED_FIELD, INTEGER_OUT_OF_RANGE})
#: Input defects — not valid JSON, or not valid UTF-8.
INPUT_CODES = frozenset({MALFORMED_JSON, INVALID_UTF8})
#: Implementation declines. MUST NOT be used for a contractual profile rule.
CAPABILITY_CODES = frozenset({UNSUPPORTED})

CODES = PROFILE_CODES | INPUT_CODES | CAPABILITY_CODES


class CanonRejected(Exception):
    """Raised for input outside the canon/1 profile.

    The code is not decoration. Two negative vectors can be satisfied by a
    serializer that refuses everything for any reason; requiring the specific
    code is what makes rejection evidence that the float rule was applied.

    The three groups above are the distinction v2 exists to preserve. A verifier
    must be able to tell *valid JSON outside the canon/1 numeric domain* from
    *this implementation declines*. Collapsing a contractual profile rule into
    UNSUPPORTED destroys that, so UNSUPPORTED is reserved for capability limits
    and MUST NOT carry a profile rule.
    """

    def __init__(self, code: str, detail: str = ""):
        if code not in CODES:
            raise ValueError(f"unknown rejection code: {code!r}")
        super().__init__(f"{code}: {detail}" if detail else code)
        self.code = code
        self.detail = detail
