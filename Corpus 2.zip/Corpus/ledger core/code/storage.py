"""
storage.py — step 3. Startup configuration refusal.

Contract §3.4: the storage-safety configuration is pinned, applied, **read back
from SQLite**, and startup is refused on any mismatch. Contract §3.4.4: for a new
ledger the check completes before the genesis transaction begins.

Startup sequence, in this order and no other:

    1. open the connection
    2. apply the required configuration
    3. read back SQLite's effective values — never trust that SET succeeded
    4. refuse on any mismatch
    5. only then may schema creation, migration, genesis or ordinary writes occur

`open_authoritative()` performs 1-4 and returns a connection. It creates no
schema and writes no event. There is deliberately no way to obtain a writable
connection that skipped verification.

What this proves, exactly
-------------------------
That the program refuses to operate unless SQLite reports the pinned
configuration, on **every** authoritative connection.

It does **not** prove that the storage device, operating system, or hardware
honours power-loss durability. That claim stays in the finite asserted set
(Contract §8.2). The code earns control over what it can observe; it does not
certify the substrate beneath the observation.

Scope of "no authoritative byte before verification"
----------------------------------------------------
Applying `journal_mode` necessarily writes database-format bytes — the file is
created and its header set — before any read-back can occur. That is
unavoidable: verification is read-after-apply. The guarantee is narrower and
worth stating precisely: **no ledger event is written under an unverified
regime.** A failed startup leaves a database containing no events, which is
discardable.

The default can hide a missing apply
------------------------------------
Read-back cannot distinguish *we applied it* from *the build default happened to
match*. This machine compiles SQLite with `DEFAULT_SYNCHRONOUS=2` and
`DEFAULT_WAL_SYNCHRONOUS=2`, so `synchronous=FULL` is already in force on a
fresh connection: omitting the apply step would be **invisible here** and would
silently run at NORMAL on a build that defaults to 1 — the regime §3.4.3 names
as losing committed transactions to power loss.

Three consequences. The apply step is retained even where it appears redundant,
because its redundancy is a property of this build and not of the contract.
Build defaults are recorded beside the effective values. And — the part that
actually resolves the doubt rather than merely noting it — an **apply
transcript** is retained, because the running process holds evidence that a
later reader cannot reconstruct.

For `journal_mode` the assignment returns the resulting mode. For `synchronous`
and `foreign_keys` it returns no row at all, so the useful evidence is not a
returned value but the pair: *the statement was attempted and completed without
SQLite error*, and *the subsequent read-back reported the required value*.

That permits the exact later statement: the build default matched the
requirement, so read-back alone was ambiguous; however this process records that
the apply statement completed before the effective value was read. It still does
not independently certify the statement ran — genesis is reporting its own
startup path — but it preserves the evidence instead of preserving only the
reason for doubt.

Why every connection re-establishes the regime
-----------------------------------------------
SQLite settings differ in lifetime, and the difference is invisible if you only
ever test one connection:

    journal_mode   database-persistent — survives in the file header
    synchronous    connection-local    — resets to the build default
    foreign_keys   connection-local    — defaults OFF, resets every time

A process that verified once and reconnected later would inherit confidence it
no longer has. `verify()` is therefore run on every authoritative connection,
not once at install time.
"""
from __future__ import annotations

import sqlite3
from dataclasses import dataclass
from pathlib import Path

__all__ = [
    "REQUIRED_REGIME",
    "RegimeError",
    "RegimeFinding",
    "open_authoritative",
    "verify",
    "regime_fingerprint",
]

#: Contract §3.4.1. pragma -> (expected read-back value, purpose, lifetime)
REQUIRED_REGIME: dict[str, tuple[object, str, str]] = {
    "journal_mode": ("wal", "durability", "database"),
    "synchronous": (2, "durability", "connection"),      # 2 == FULL
    "foreign_keys": (1, "integrity", "connection"),
}

# Deliberately absent: busy_timeout, cache_size, mmap_size, temp_store. The
# contract pins these three. Adding more here would create an implementation-
# specific regime that a conforming counterpart could fail — the same error as
# the depth cap in canon/1.

_SET_TEMPLATE = {
    "journal_mode": "PRAGMA journal_mode = WAL",
    "synchronous": "PRAGMA synchronous = FULL",
    "foreign_keys": "PRAGMA foreign_keys = ON",
}

#: The three failure classes must stay distinguishable.
DECLINED = "DECLINED"          # the SET statement did not take the value
DRIFTED = "DRIFTED"            # SET reported success, read-back disagrees
NOT_RECONSTRUCTED = "NOT_RECONSTRUCTED"   # never applied on this connection


@dataclass(frozen=True)
class RegimeFinding:
    pragma: str
    expected: object
    set_returned: object
    read_back: object
    failure: str
    purpose: str
    lifetime: str

    def __str__(self) -> str:
        return (
            f"{self.pragma}: {self.failure} — expected {self.expected!r}, "
            f"SET returned {self.set_returned!r}, read back {self.read_back!r} "
            f"({self.purpose}, {self.lifetime}-scoped)"
        )


class RegimeError(RuntimeError):
    """Startup refused. The connection is closed before this is raised."""

    def __init__(self, path: str, findings: list[RegimeFinding]):
        self.path = path
        self.findings = findings
        detail = "; ".join(str(f) for f in findings)
        super().__init__(f"storage regime not established for {path!r}: {detail}")


def _scalar(conn: sqlite3.Connection, sql: str):
    row = conn.execute(sql).fetchone()
    if row is None:
        return None
    value = row[0]
    return value.lower() if isinstance(value, str) else value


def _apply(conn: sqlite3.Connection) -> dict[str, dict]:
    """Run the SET pragmas, retaining what each attempt reported.

    `statement_completed` is the load-bearing field where the assignment returns
    no row, which is the normal case for `synchronous` and `foreign_keys`.
    """
    transcript: dict[str, dict] = {}
    for pragma, sql in _SET_TEMPLATE.items():
        entry: dict[str, object] = {"statement": sql}
        try:
            entry["set_returned"] = _scalar(conn, sql)
            entry["statement_completed"] = True
        except sqlite3.Error as exc:
            entry["set_returned"] = None
            entry["statement_completed"] = False
            entry["error"] = str(exc)
        transcript[pragma] = entry
    return transcript


def verify(
    conn: sqlite3.Connection,
    *,
    transcript: dict[str, dict] | None = None,
) -> list[RegimeFinding]:
    """Read back effective values. Empty list means the regime holds.

    `transcript` distinguishes DECLINED from DRIFTED. Omit it to check a
    connection on which nothing was applied — the NOT_RECONSTRUCTED case.
    """
    findings: list[RegimeFinding] = []
    for pragma, (expected, purpose, lifetime) in REQUIRED_REGIME.items():
        actual = _scalar(conn, f"PRAGMA {pragma}")
        if actual == expected:
            continue
        if transcript is None:
            failure, reported = NOT_RECONSTRUCTED, None
        else:
            entry = transcript.get(pragma, {})
            reported = entry.get("set_returned")
            completed = entry.get("statement_completed", False)
            # A returned value that disagrees, or a statement that never
            # completed, is a declined request. Anything else is drift between
            # a successful apply and a later read.
            declined = not completed or (
                reported is not None and reported != expected
            )
            failure = DECLINED if declined else DRIFTED
        findings.append(
            RegimeFinding(pragma, expected, reported, actual, failure, purpose, lifetime)
        )
    return findings


@dataclass(frozen=True)
class VerifiedConnection:
    """A connection that passed verification, carrying its own evidence.

    The transcript travels with the connection deliberately. Genesis must record
    it (§2.4), and a caller that received only the connection would have to
    reconstruct evidence that no longer exists.
    """

    conn: sqlite3.Connection
    transcript: dict[str, dict]

    def close(self) -> None:
        self.conn.close()

    def execute(self, *args, **kwargs):
        return self.conn.execute(*args, **kwargs)


def open_authoritative(path: str | Path) -> VerifiedConnection:
    """Steps 1-4. Returns a verified connection, or raises and closes.

    Creates no schema and writes no event. `isolation_level=None` keeps SQLite
    in autocommit so the caller owns every transaction boundary — required by
    Contract §3.2, where the commit is one explicit `BEGIN IMMEDIATE`.
    """
    path = str(path)
    conn = sqlite3.connect(path, isolation_level=None)
    try:
        transcript = _apply(conn)
        findings = verify(conn, transcript=transcript)
        if findings:
            raise RegimeError(path, findings)
    except BaseException:
        conn.close()
        raise
    return VerifiedConnection(conn, transcript)


_RECORDED_COMPILE_OPTIONS = (
    "DEFAULT_SYNCHRONOUS",
    "DEFAULT_WAL_SYNCHRONOUS",
    "DEFAULT_WAL_AUTOCHECKPOINT",
    "DEFAULT_JOURNAL_MODE",
    "DEFAULT_FOREIGN_KEYS",
    "THREADSAFE",
)

#: Which compile option supplies each pragma's default, and the value SQLite
#: uses when that option is absent from the build.
_DEFAULT_SOURCE = {
    "synchronous": ("DEFAULT_WAL_SYNCHRONOUS", "2"),   # WAL mode consults this
    "journal_mode": ("DEFAULT_JOURNAL_MODE", "delete"),
    "foreign_keys": ("DEFAULT_FOREIGN_KEYS", "0"),
}


def _default_matches(defaults: dict, pragma: str, expected: object) -> bool:
    """True when this build's default already equals the requirement.

    When that holds, read-back alone cannot say whether the effective value was
    applied or inherited. The apply transcript is what resolves it.
    """
    option, fallback = _DEFAULT_SOURCE.get(pragma, (None, None))
    if option is None:
        return False
    default = defaults.get(option, fallback)
    return str(default) == str(expected)


def regime_fingerprint(vc: "VerifiedConnection") -> dict[str, object]:
    """The full storage-regime record for genesis (Contract §2.4).

    Effective values are read from SQLite rather than copied from
    REQUIRED_REGIME, so genesis records what was in force rather than what was
    intended. The apply transcript and build defaults travel with them, so a
    later reader can distinguish an applied value from an inherited one.
    """
    conn = vc.conn
    effective = {p: _scalar(conn, f"PRAGMA {p}") for p in REQUIRED_REGIME}
    try:
        options = [r[0] for r in conn.execute("PRAGMA compile_options").fetchall()]
    except sqlite3.Error:
        options = []
    defaults = {
        opt.split("=", 1)[0]: (opt.split("=", 1)[1] if "=" in opt else True)
        for opt in options
        if any(opt.startswith(k) for k in _RECORDED_COMPILE_OPTIONS)
    }
    return {
        "requested": {p: v for p, (v, _, _) in REQUIRED_REGIME.items()},
        "apply": vc.transcript,
        "effective": effective,
        "sqlite_version": sqlite3.sqlite_version,
        "build_defaults": defaults,
        "default_matches_requirement": sorted(
            p for p, (expected, _, _) in REQUIRED_REGIME.items()
            if _default_matches(defaults, p, expected)
        ),
    }
