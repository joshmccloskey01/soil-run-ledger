"""
genesis.py — step 4. The first irreversible claim.

Genesis records **identities and startup evidence**. It does not certify the
truth of the external assertions those identities name. The contract's own §8.2
register says which claims are asserted rather than proven, and the contract is
inside this record by digest, so the scope statement travels with the ledger
instead of being restated as prose in every genesis body.

Transaction boundary, mechanically sharp:

    1. BEGIN IMMEDIATE
    2. verify the database is empty and has no prior genesis
    3. create schema
    4. construct canonical genesis bytes entirely in memory
    5. compute the event id from those exact bytes
    6. INSERT the genesis event
    7. INSERT ledger_head pointing at that exact event
    8. COMMIT
    9. reopen and verify both rows through a fresh query path

Schema creation sits **inside** the transaction. SQLite makes DDL
transactional, so there is no reachable state in which the schema exists without
genesis. That closes the gap where a later migration or default insertion could
change what "the first committed state" meant.

The DDL is issued statement by statement. `Connection.executescript()` commits
any pending transaction before it runs, which defeated the atomicity above
without any error until the following COMMIT failed.

Invariant this step establishes:

    After genesis commits, every fact needed to verify why it was admissible is
    already inside the chain.

Authority inside the events table
---------------------------------
Only `body_canon` is authoritative. `event_id`, `seq` and `parent_id` are
indexed projections of bytes already inside it, kept as columns so the store can
enforce uniqueness and foreign keys. They can therefore disagree with the body,
so `verify_chain()` re-parses the body and refuses on any mismatch. Contract
§7.2 applied one level below where it was written.
"""
from __future__ import annotations

import hashlib
import json
import sqlite3
import time
import uuid
from datetime import datetime, timezone
from pathlib import Path

from canon1 import canonicalize
from storage import VerifiedConnection, open_authoritative, regime_fingerprint

__all__ = [
    "GenesisError",
    "LedgerExists",
    "create_ledger",
    "compute_event_id",
    "verify_chain",
    "CHAIN_CONSTANTS",
]

# ------------------------------------------------------------------ constants

GENESIS_SEQ = 0
GENESIS_PARENT_ID = None
INITIAL_FENCING_TOKEN = 1
SCHEMA_VERSION = "ledger-schema/2"
GENESIS_SCHEMA = "ledger-genesis/1"
CANON_VERSION = "canon/1"
HASH_ALG = "sha256"

#: Recorded verbatim in the genesis body so a reader never has to infer the
#: convention from the data.
CHAIN_CONSTANTS = {
    "genesis_seq": GENESIS_SEQ,
    "genesis_parent_id": GENESIS_PARENT_ID,
    "initial_fencing_token": INITIAL_FENCING_TOKEN,
    "schema_version": SCHEMA_VERSION,
    "canon_version": CANON_VERSION,
    "hash_alg": HASH_ALG,
}

#: ledger-schema/2 adds UNIQUE on parent_id: this ledger permits exactly one
#: committed successor per event, so a fork cannot even be represented in the
#: store. SQLite treats NULLs as distinct under UNIQUE, so multiple root events
#: remain expressible in SQL and are refused by verify_chain() instead.
#:
#: Split into separate statements deliberately. `Connection.executescript()`
#: issues a COMMIT before running, which would end the genesis transaction and
#: leave a database whose schema exists without genesis — the exact state this
#: step is meant to make unreachable.
_SCHEMA_STATEMENTS = (
    """CREATE TABLE events (
    event_id   TEXT    PRIMARY KEY NOT NULL,
    parent_id  TEXT    UNIQUE REFERENCES events(event_id),
    seq        INTEGER NOT NULL UNIQUE,
    body_canon BLOB    NOT NULL
)""",
    """CREATE TABLE ledger_head (
    id            INTEGER PRIMARY KEY CHECK (id = 1),
    event_id      TEXT    NOT NULL REFERENCES events(event_id),
    seq           INTEGER NOT NULL,
    fencing_token INTEGER NOT NULL
)""",
)


class GenesisError(RuntimeError):
    """Genesis refused. Nothing was committed."""


class LedgerExists(GenesisError):
    """The database is not empty. Genesis is not re-runnable."""


# ------------------------------------------------------------ identity + time

def compute_event_id(body_canon: bytes) -> str:
    """Contract §2.2. The id is a function of the exact stored bytes."""
    return f"{HASH_ALG}:" + hashlib.sha256(body_canon).hexdigest()


def _canonical(obj: dict) -> bytes:
    """Serialize, then canonicalize. Floats are rejected at the boundary.

    `allow_nan=False` turns a NaN or Infinity into an exception here rather than
    invalid JSON downstream; any genuine float reaches canonicalize() and is
    refused as FLOAT_IN_HASHED_FIELD, so the ban is enforced by canon/1 and not
    by Python typing.
    """
    return canonicalize(json.dumps(obj, ensure_ascii=False, allow_nan=False).encode())


def _clock_epoch() -> tuple[str, str]:
    """(epoch id, source). Contract §2.3.3.

    A boot id makes monotonic values comparable across processes on one boot. A
    per-process id is strictly more conservative — it never permits a comparison
    that a boot id would forbid — so the fallback is safe and the source is
    recorded so a verifier knows which reading applies.
    """
    try:
        boot = Path("/proc/sys/kernel/random/boot_id").read_text().strip()
        if boot:
            return boot, "linux_boot_id"
    except OSError:
        pass
    return str(uuid.uuid4()), "process_uuid"


def _envelope(event_type: str, body: dict, epoch_id: str) -> dict:
    """Contract §2.1, minus event_id, which is derived from these bytes."""
    now = datetime.now(timezone.utc)
    local = now.astimezone()
    offset = local.utcoffset()
    return {
        "parent_id": GENESIS_PARENT_ID,
        "seq": GENESIS_SEQ,
        "fencing_token": INITIAL_FENCING_TOKEN,
        "schema_version": SCHEMA_VERSION,
        "canon_version": CANON_VERSION,
        "hash_alg": HASH_ALG,
        "event_type": event_type,
        "wall_time_utc": now.strftime("%Y-%m-%dT%H:%M:%S.") + f"{now.microsecond // 1000:03d}Z",
        "utc_offset_minutes": int(offset.total_seconds() // 60) if offset else 0,
        "clock_epoch_id": epoch_id,
        "monotonic_ticks": time.monotonic_ns(),
        "body": body,
    }


# ------------------------------------------------------------------- identity

def _sha256_file(path: str | Path) -> str:
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def build_genesis_body(
    vc: VerifiedConnection,
    *,
    contract_path: str | Path,
    canon_module_path: str | Path,
    protocol_module_path: str | Path,
    vector_package_path: str | Path,
    vector_manifest_path: str | Path,
    epoch_source: str,
) -> dict:
    """Identities and startup evidence, all fixed at this boundary."""
    package = json.loads(Path(vector_package_path).read_text())
    protocol = package["protocol"]
    return {
        "genesis_schema": GENESIS_SCHEMA,
        "contract": {
            "name": Path(contract_path).name,
            "sha256": _sha256_file(contract_path),
        },
        "canon": {
            "profile": CANON_VERSION,
            "module": Path(canon_module_path).name,
            "implementation_sha256": _sha256_file(canon_module_path),
        },
        "protocol": {
            "version": protocol["version"],
            "sha256": protocol["sha256"],
            "module": Path(protocol_module_path).name,
            "module_sha256": _sha256_file(protocol_module_path),
            "supersedes": protocol.get("supersedes"),
        },
        "vectors": {
            "package": package["package"],
            "package_sha256": _sha256_file(vector_package_path),
            "manifest_sha256": _sha256_file(vector_manifest_path),
            "source_repository": package["provenance"]["repository"],
            "source_commit": package["provenance"]["commit"],
            "independence": package["provenance"]["statement"],
        },
        "storage": regime_fingerprint(vc),
        "clock": {"epoch_source": epoch_source},
        "chain_constants": CHAIN_CONSTANTS,
    }


# -------------------------------------------------------------------- genesis

def create_ledger(path: str | Path, **identity) -> dict:
    """Steps 1-9. Returns the committed genesis event.

    Raises before committing anything if the database is not empty.
    """
    path = Path(path)
    vc = open_authoritative(path)            # §3.4.4: verified before genesis
    try:
        conn = vc.conn
        conn.execute("BEGIN IMMEDIATE")      # 1
        try:
            existing = conn.execute(
                "SELECT count(*) FROM sqlite_master WHERE type='table'"
            ).fetchone()[0]                                                 # 2
            if existing:
                raise LedgerExists(
                    f"{path} already has {existing} table(s); genesis is not re-runnable"
                )

            for statement in _SCHEMA_STATEMENTS:   # 3 — inside the transaction
                conn.execute(statement)

            epoch_id, epoch_source = _clock_epoch()
            body = build_genesis_body(vc, epoch_source=epoch_source, **identity)
            event = _envelope("GENESIS", body, epoch_id)
            body_canon = _canonical(event)                                  # 4
            event_id = compute_event_id(body_canon)                         # 5

            conn.execute(
                "INSERT INTO events (event_id, parent_id, seq, body_canon) "
                "VALUES (?, ?, ?, ?)",
                (event_id, GENESIS_PARENT_ID, GENESIS_SEQ, body_canon),
            )                                                               # 6
            conn.execute(
                "INSERT INTO ledger_head (id, event_id, seq, fencing_token) "
                "VALUES (1, ?, ?, ?)",
                (event_id, GENESIS_SEQ, INITIAL_FENCING_TOKEN),
            )                                                               # 7
            conn.execute("COMMIT")                                          # 8
        except BaseException:
            conn.execute("ROLLBACK")
            raise
    finally:
        vc.close()

    findings = verify_chain(path)                                           # 9
    if findings:
        raise GenesisError(f"genesis failed read-back: {'; '.join(findings)}")
    return {"event_id": event_id, **event}


# ------------------------------------------------------------------ verifying

def verify_chain(path: str | Path) -> list[str]:
    """Reopen and re-derive everything. Empty list means the chain holds.

    Nothing is trusted from the writing process: the id is recomputed from the
    stored bytes, and every indexed column is checked against the body it was
    projected from.
    """
    problems: list[str] = []
    vc = open_authoritative(path)
    try:
        conn = vc.conn
        rows = conn.execute(
            "SELECT event_id, parent_id, seq, body_canon FROM events ORDER BY seq"
        ).fetchall()
        if not rows:
            return ["no events"]

        for event_id, parent_id, seq, body_canon in rows:
            recomputed = compute_event_id(body_canon)
            if recomputed != event_id:
                problems.append(f"seq {seq}: id {event_id} != recomputed {recomputed}")
                continue
            try:
                body = json.loads(body_canon)
            except json.JSONDecodeError as exc:
                problems.append(f"seq {seq}: stored bytes are not JSON ({exc})")
                continue
            # Stored bytes must already be canonical: re-canonicalizing is a
            # fixed point, or the writer emitted something canon/1 would not.
            if _canonical(body) != body_canon:
                problems.append(f"seq {seq}: stored bytes are not canonical")
            # Indexed columns are projections; they must agree with the body.
            if body.get("seq") != seq:
                problems.append(f"seq column {seq} != body {body.get('seq')}")
            if body.get("parent_id") != parent_id:
                problems.append(
                    f"seq {seq}: parent column {parent_id!r} != body {body.get('parent_id')!r}"
                )

        head = conn.execute(
            "SELECT event_id, seq, fencing_token FROM ledger_head WHERE id = 1"
        ).fetchone()
        if head is None:
            problems.append("no ledger_head row")
        else:
            head_id, head_seq, token = head
            known = {r[0]: r[2] for r in rows}
            if head_id not in known:
                problems.append(f"head {head_id} is not a committed event")
            elif known[head_id] != head_seq:
                problems.append(f"head seq {head_seq} != event seq {known[head_id]}")
            if head_seq != max(r[2] for r in rows):
                problems.append(f"head seq {head_seq} is not the maximum")
            if token < INITIAL_FENCING_TOKEN:
                problems.append(f"fencing token {token} below initial")
            # The head token must equal a replay of the committed advance rule.
            # Before lease activation the rule is "constant"; after it, the
            # token advances only on grant and renewal. Imported late to keep
            # the module dependency one-way.
            from lease import expected_token

            parsed_chain, malformed = [], False
            for r in rows:
                try:
                    obj = json.loads(r[3])
                except json.JSONDecodeError:
                    malformed = True
                    continue
                if "seq" not in obj or "event_type" not in obj:
                    malformed = True
                    continue
                obj["event_id"] = r[0]
                parsed_chain.append(obj)
            # A malformed body is already reported above; replaying the token
            # over it would only add a derived complaint about a known defect.
            if not malformed:
                parsed_chain.sort(key=lambda e: e["seq"])
                want_token = expected_token(parsed_chain, INITIAL_FENCING_TOKEN)
                if token != want_token:
                    problems.append(
                        f"head fencing token {token} != replayed {want_token} "
                        "under the committed advance rule"
                    )

        genesis = rows[0]
        if genesis[1] is not None:
            problems.append(f"genesis parent is {genesis[1]!r}, expected null")
        if genesis[2] != GENESIS_SEQ:
            problems.append(f"genesis seq is {genesis[2]}, expected {GENESIS_SEQ}")

        # Exactly one root. SQLite treats NULLs as distinct under UNIQUE, so the
        # store cannot forbid a second root event and the verifier must.
        roots = [r for r in rows if r[1] is None]
        if len(roots) != 1:
            problems.append(f"{len(roots)} root events; exactly one is permitted")

        # Every event must be reachable from the head by parent links, with
        # contiguous sequence. An event present in the table but off the chain
        # is an orphan: durable, but never authoritative.
        by_id = {r[0]: r for r in rows}
        if head is not None and head[0] in by_id:
            walked, cursor = 0, head[0]
            seen: set[str] = set()
            while cursor is not None:
                if cursor in seen:
                    problems.append("cycle in parent chain")
                    break
                seen.add(cursor)
                row = by_id.get(cursor)
                if row is None:
                    problems.append(f"parent {cursor} missing from events")
                    break
                walked += 1
                cursor = row[1]
            if walked != len(rows):
                problems.append(
                    f"{len(rows) - walked} event(s) unreachable from head "
                    "(orphaned, never authoritative)"
                )
            expected = list(range(GENESIS_SEQ, GENESIS_SEQ + len(rows)))
            if sorted(r[2] for r in rows) != expected:
                problems.append("sequence is not contiguous from genesis")
    finally:
        vc.close()
    return problems


def read_genesis(path: str | Path) -> dict:
    """The committed genesis event, parsed from its stored bytes."""
    vc = open_authoritative(path)
    try:
        row = vc.conn.execute(
            "SELECT event_id, body_canon FROM events WHERE seq = ?", (GENESIS_SEQ,)
        ).fetchone()
    finally:
        vc.close()
    if row is None:
        raise GenesisError("no genesis event")
    return {"event_id": row[0], **json.loads(row[1])}
