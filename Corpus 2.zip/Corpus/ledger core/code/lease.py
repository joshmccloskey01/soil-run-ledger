"""
lease.py — observation obligations, fencing leases, and derived gaps.

Three distinct objects, deliberately not merged:

1. **Committed obligation** — what observation work was authorized, and by when.
2. **Fencing token** — which authority generation may write.
3. **Derived expiry** — what a later reader infers from missing required receipts.

What this is not
----------------
At v0.1 there is exactly one thing that can commit, so ``LEASE_GRANTED`` is
written by the writer itself. That is **self-precommitment, not external
authorization**. Its value is temporal: the bound was fixed before the gap, so a
later self cannot widen it after seeing how long it slept. It is the cold
trigger, not a delegation of authority.

The ledger also cannot narrate its own death. Under single-writer plus CAS,
nothing can be committed once the writer stops — including the fact that it
stopped. **Lease expiry is therefore derived, never constitutive.** It is
computed by a later reader from the last committed receipt, the schedule active
during that interval, and the clock context. The resuming writer may assert a
*cause*; it cannot alter the *extent*, because the last receipt's sequence and
the schedule were both committed before the silence began.

What the token does and does not do
------------------------------------
It fences stale generations: a process holding an old token cannot commit after
another authority has renewed. It does **not** authenticate principals. Any
process able to open the database can read the current token and commit a
takeover, and the store cannot distinguish a zombie from a legitimate successor
— first valid committer wins, which is correct CAS behaviour and not access
control. Who may open the file is enforced by the operating environment, which
is an §8.2 assertion about the substrate.

The activation boundary
-----------------------
``fencing_token`` has existed in every envelope since genesis, but until
activation its only historical meaning is *present and constant*. History is not
required to have anticipated the future; it needs a clear sequence at which the
new rule became binding::

    pre-activation   token constant, no lease semantics
    activation event committed rule begins
    post-activation  token advances only under that rule

`gap_report()` refuses to classify any interval that began before activation.
"""
from __future__ import annotations

import hashlib
import json
from datetime import datetime, timedelta, timezone

from append import Head, append, read_head
from genesis import _canonical, compute_event_id
from storage import VerifiedConnection

__all__ = [
    "LeaseError",
    "TOKEN_ADVANCE_RULE",
    "activate_lease_semantics",
    "define_schedule",
    "grant_lease",
    "renew_lease",
    "suspend_lease",
    "record_receipt",
    "commit_checkpoint_cadence",
    "activation_seq",
    "gap_report",
    "expected_token",
]

#: The rule whose *wording* is committed at activation. It is R1: a reader
#: interpreting a five-year-old gap needs the rule in force then, not the one
#: configured now.
TOKEN_ADVANCE_RULE = {
    "rule": "token_advances_on_lease_grant_and_renewal_only",
    "increment": 1,
    "envelope_token_meaning": "token in force at authorization, not the token established",
    "all_other_events": "carry the current token unchanged",
}

CLOCK_EPOCH_TREATMENT = {
    "gap_existence": "ordered by seq; mechanically detectable from committed obligations",
    "elapsed_duration": "measured only within one clock_epoch_id; estimative across epochs",
}

_ACTIVATION = "LEASE_SEMANTICS_ACTIVATED"
_SCHEDULE = "OBSERVATION_SCHEDULE_DEFINED"
_GRANT = "LEASE_GRANTED"
_RENEW = "LEASE_RENEWED"
_SUSPEND = "LEASE_SUSPENDED"
_RECEIPT = "SOURCE_POLL_COMPLETED"
_CADENCE = "CHECKPOINT_VERIFICATION_CADENCE"

_TOKEN_ADVANCING = (_GRANT, _RENEW)


class LeaseError(RuntimeError):
    """Refused before anything was committed."""


def _content_id(obj: dict) -> str:
    return "sha256:" + hashlib.sha256(_canonical(obj)).hexdigest()


def _parse_utc(stamp: str) -> datetime:
    return datetime.strptime(stamp, "%Y-%m-%dT%H:%M:%S.%fZ").replace(tzinfo=timezone.utc)


# --------------------------------------------------------------- activation

def activate_lease_semantics(vc: VerifiedConnection) -> dict:
    """Commit the boundary at which the token acquires advancement semantics."""
    events = _chain(vc.conn)
    if any(e["event_type"] == _ACTIVATION for e in events):
        raise LeaseError("lease semantics already activated")
    body = {
        "token_advance_rule": TOKEN_ADVANCE_RULE,
        "clock_epoch_treatment": CLOCK_EPOCH_TREATMENT,
        "prior_token_meaning": "present and constant; no lease semantics",
        "self_precommitment": (
            "granted by the sole writer, not by an external authority; the "
            "binding is temporal, not delegated"
        ),
        "expiry_is_derived": (
            "the writer cannot commit its own death; expiry is computed by a "
            "later reader from the last receipt and the active schedule"
        ),
    }
    body["rule_id"] = _content_id(body)
    return append(vc, event_type=_ACTIVATION, body=body)


def activation_seq(events: list[dict]) -> int | None:
    for event in events:
        if event["event_type"] == _ACTIVATION:
            return event["seq"]
    return None


# ----------------------------------------------------------------- schedule

def define_schedule(
    vc: VerifiedConnection,
    *,
    interval_seconds: int,
    tolerated_lateness_seconds: int,
    required_sources: list[str],
    suspension_conditions: list[str] | None = None,
    supersedes: str | None = None,
) -> dict:
    """The denominator. Fixed contemporaneously or a missing receipt means nothing."""
    if activation_seq(_chain(vc.conn)) is None:
        raise LeaseError("lease semantics must be activated before a schedule")
    if interval_seconds <= 0 or tolerated_lateness_seconds < 0:
        raise LeaseError("interval must be positive and lateness non-negative")
    if not required_sources:
        raise LeaseError("a schedule with no required sources cannot be missed")
    definition = {
        "interval_seconds": interval_seconds,
        "tolerated_lateness_seconds": tolerated_lateness_seconds,
        "required_sources": sorted(required_sources),
        "suspension_conditions": sorted(suspension_conditions or []),
        "supersedes": supersedes,
    }
    body = {"schedule_id": _content_id(definition), "definition": definition}
    return append(vc, event_type=_SCHEDULE, body=body)


def commit_checkpoint_cadence(
    vc: VerifiedConnection, *, full_rebuild_every_n_checkpoints: int
) -> dict:
    """How often a checkpoint-assisted rebuild must be compared with a full one.

    In config this could be relaxed retroactively to claim the comparison was
    frequent enough. Committed, it cannot.
    """
    if full_rebuild_every_n_checkpoints < 1:
        raise LeaseError("cadence must be at least 1")
    body = {
        "full_rebuild_every_n_checkpoints": full_rebuild_every_n_checkpoints,
        "checkpoint_status": "performance aid; full-chain derivation remains authority",
        "a7_requirement": (
            "deleting every checkpoint and projection and deriving from genesis "
            "must still reach the same final state"
        ),
    }
    body["cadence_id"] = _content_id(body)
    return append(vc, event_type=_CADENCE, body=body)


# -------------------------------------------------------------------- lease

def grant_lease(vc: VerifiedConnection, *, schedule_id: str, holder: str,
                duration_seconds: int) -> dict:
    return _lease_event(vc, _GRANT, schedule_id, holder, duration_seconds)


def renew_lease(vc: VerifiedConnection, *, schedule_id: str, holder: str,
                duration_seconds: int) -> dict:
    return _lease_event(vc, _RENEW, schedule_id, holder, duration_seconds)


def _lease_event(vc, kind, schedule_id, holder, duration_seconds) -> dict:
    events = _chain(vc.conn)
    if activation_seq(events) is None:
        raise LeaseError("lease semantics not activated; the token has no advance rule")
    if not any(
        e["event_type"] == _SCHEDULE and e["body"]["schedule_id"] == schedule_id
        for e in events
    ):
        raise LeaseError(f"schedule {schedule_id} is not committed")
    head = read_head(vc.conn)
    return append(
        vc,
        event_type=kind,
        body={
            "schedule_id": schedule_id,
            "holder": holder,
            "duration_seconds": duration_seconds,
            "new_fencing_token": head.fencing_token + 1,
        },
        advance_token=True,
    )


def suspend_lease(vc: VerifiedConnection, *, schedule_id: str, reason: str,
                  until_utc: str | None = None) -> dict:
    """Planned sleep. An explicit suspension is not a gap."""
    return append(
        vc,
        event_type=_SUSPEND,
        body={"schedule_id": schedule_id, "reason": reason, "until_utc": until_utc},
    )


# ------------------------------------------------------------------ receipt

def record_receipt(vc: VerifiedConnection, *, schedule_id: str,
                   scheduled_for_utc: str, started_at_utc: str,
                   sources: list[dict]) -> dict:
    """An execution receipt, not a liveness assertion.

    "Cycle complete" is self-certifying and cannot be contradicted. "Polled A,
    B, C; A returned 3 items, B returned 0, C timed out" names external
    referents that someone else can reproduce or dispute. Every source entry
    must therefore carry a result and, where it succeeded, a response
    fingerprint.

    Provenance: independent only up to the source receipts and any external
    re-observation. Common mode begins at this watcher's acquisition and
    reporting path.
    """
    if not sources:
        raise LeaseError("a receipt naming no sources asserts only that code ran")
    for entry in sources:
        if "source_id" not in entry or "result" not in entry:
            raise LeaseError(f"source entry needs source_id and result: {entry!r}")
        if entry["result"] == "OK" and "response_fingerprint" not in entry:
            raise LeaseError(
                f"source {entry['source_id']}: an OK result must carry a response "
                "fingerprint, or it names no external referent"
            )
    return append(
        vc,
        event_type=_RECEIPT,
        body={
            "schedule_id": schedule_id,
            "scheduled_for_utc": scheduled_for_utc,
            "started_at_utc": started_at_utc,
            "sources": sources,
        },
    )


# ------------------------------------------------------------- derived state

def _chain(conn) -> list[dict]:
    events = []
    for row in conn.execute("SELECT body_canon FROM events"):
        parsed = json.loads(row[0])
        parsed["event_id"] = compute_event_id(row[0])
        events.append(parsed)
    events.sort(key=lambda e: e["seq"])
    return events


def expected_token(events: list[dict], initial: int = 1) -> int:
    """Replay the committed advance rule. The head must agree with this."""
    activated = activation_seq(events)
    token = initial
    for event in events:
        if activated is None or event["seq"] <= activated:
            continue
        if event["event_type"] in _TOKEN_ADVANCING:
            token += 1
    return token


def gap_report(events: list[dict], *, observed_at_utc: str,
               observed_clock_epoch_id: str) -> list[dict]:
    """Derived expiry. Never committed at the moment it occurs.

    Gap **existence** is mechanical: the interval between consecutive receipts,
    or between the last receipt and the observation point, exceeded the
    obligation active during that interval.

    Gap **duration** is only measured within one `clock_epoch_id`. Across
    epochs, `seq` still orders the events but wall-clock arithmetic does not
    survive a clock reset (§2.3.4), so the elapsed value is marked estimative.
    """
    activated = activation_seq(events)
    if activated is None:
        return []

    schedules = {
        e["body"]["schedule_id"]: e
        for e in events
        if e["event_type"] == _SCHEDULE
    }
    gaps: list[dict] = []

    for schedule_id, definition_event in schedules.items():
        spec = definition_event["body"]["definition"]
        allowance = spec["interval_seconds"] + spec["tolerated_lateness_seconds"]

        marks = [
            e for e in events
            if e["seq"] > definition_event["seq"]
            and e["event_type"] in (_RECEIPT, _SUSPEND)
            and e["body"].get("schedule_id") == schedule_id
        ]

        points: list[tuple] = [
            (definition_event["seq"], definition_event["wall_time_utc"],
             definition_event["clock_epoch_id"], _SCHEDULE)
        ]
        for mark in marks:
            points.append((mark["seq"], mark["wall_time_utc"],
                           mark["clock_epoch_id"], mark["event_type"]))
        points.append((None, observed_at_utc, observed_clock_epoch_id, "OBSERVATION"))

        for (a_seq, a_time, a_epoch, a_kind), (b_seq, b_time, b_epoch, b_kind) in zip(
            points, points[1:]
        ):
            if a_kind == _SUSPEND:
                continue                      # an explicit suspension is not a gap
            elapsed = (_parse_utc(b_time) - _parse_utc(a_time)).total_seconds()
            if elapsed <= allowance:
                continue
            cross_epoch = a_epoch != b_epoch
            gaps.append({
                "schedule_id": schedule_id,
                "after_seq": a_seq,
                "before_seq": b_seq,
                "after_kind": a_kind,
                "before_kind": b_kind,
                "allowance_seconds": allowance,
                "elapsed_seconds": None if cross_epoch else int(elapsed),
                "duration_status": "ESTIMATIVE_CROSS_EPOCH" if cross_epoch else "MEASURED",
                "missed_cycles_lower_bound": (
                    None if cross_epoch
                    else int(elapsed // spec["interval_seconds"]) - 1
                ),
                "existence": "DERIVED_FROM_COMMITTED_OBLIGATION",
                "cause": "NOT_ESTABLISHED",
            })
    return gaps
