"""
append.py — step 5. The conditional head transition.

Contract §3.1-§3.3. An event becomes authoritative at, and only at, a successful
conditional head transition. Durability alone confers nothing.

The invariant this step establishes:

    An event exists authoritatively  <=>  the head transition that admitted it
    committed.

No orphan event survives a failed append, and no head points at an event that
was admitted under a different expected parent.

Shape
-----
::

    BEGIN IMMEDIATE
    read current head
    compare with the caller's expected head        (for a precise error)
    construct the canonical event from that head
    INSERT the event
    UPDATE ledger_head ... WHERE event_id = ? AND seq = ? AND fencing_token = ?
    require rowcount == 1
    COMMIT

**The conditional UPDATE carries the comparison even though the head was already
read.** The earlier read exists to build the event and to report a useful error.
It is the WHERE clause that stops the transaction from depending on that earlier
observation still being true.

Under `BEGIN IMMEDIATE` SQLite takes a write lock at once, so in this
single-file deployment the window between the read and the update is already
closed and the CAS can look redundant. It is not: §3.3 requires fencing to be a
property of the **store**, so that correctness does not depend on which
transaction mode a future caller picks or which engine sits underneath. A
fencing token recorded in an event and not enforced by the storage operation is
decorative.

Two failures that must not be confused
--------------------------------------
``StoreBusy``     another writer holds the lock. Nothing happened. Retryable.
``HeadAdvanced``  the expected head is stale. The world moved. **Not** retryable
                  without re-reading and re-planning, because a blind retry
                  would be a different append wearing the original's intent.

`append()` never retries internally. That is the caller's decision and it
requires fresh facts.
"""
from __future__ import annotations

import json
import sqlite3
import time
from pathlib import Path
from typing import Callable

from genesis import (
    _canonical,
    _clock_epoch,
    compute_event_id,
)
from storage import VerifiedConnection

__all__ = [
    "AppendRefused",
    "HeadAdvanced",
    "StoreBusy",
    "Head",
    "read_head",
    "append",
]


class AppendRefused(RuntimeError):
    """Nothing was committed."""


class StoreBusy(AppendRefused):
    """Another writer holds the lock. Nothing happened; a retry is sound."""


class HeadAdvanced(AppendRefused):
    """The expected head is not current. Re-read before deciding anything."""

    def __init__(self, expected: "Head | None", actual: "Head | None"):
        self.expected = expected
        self.actual = actual
        super().__init__(f"expected head {expected}, store holds {actual}")


class Head:
    """The committed head. Immutable snapshot, not a live view."""

    __slots__ = ("event_id", "seq", "fencing_token")

    def __init__(self, event_id: str, seq: int, fencing_token: int):
        self.event_id = event_id
        self.seq = seq
        self.fencing_token = fencing_token

    def __eq__(self, other) -> bool:
        return (
            isinstance(other, Head)
            and (self.event_id, self.seq, self.fencing_token)
            == (other.event_id, other.seq, other.fencing_token)
        )

    def __repr__(self) -> str:
        return f"Head(seq={self.seq}, id={self.event_id[:19]}…, token={self.fencing_token})"


def read_head(conn: sqlite3.Connection) -> Head | None:
    row = conn.execute(
        "SELECT event_id, seq, fencing_token FROM ledger_head WHERE id = 1"
    ).fetchone()
    return Head(*row) if row else None


def _envelope(
    *,
    parent: Head,
    seq: int,
    event_type: str,
    body: dict,
    schema_version: str,
    canon_version: str,
    hash_alg: str,
    epoch_id: str,
) -> dict:
    from datetime import datetime, timezone

    now = datetime.now(timezone.utc)
    offset = now.astimezone().utcoffset()
    return {
        "parent_id": parent.event_id,
        "seq": seq,
        "fencing_token": parent.fencing_token,
        "schema_version": schema_version,
        "canon_version": canon_version,
        "hash_alg": hash_alg,
        "event_type": event_type,
        "wall_time_utc": now.strftime("%Y-%m-%dT%H:%M:%S.")
        + f"{now.microsecond // 1000:03d}Z",
        "utc_offset_minutes": int(offset.total_seconds() // 60) if offset else 0,
        "clock_epoch_id": epoch_id,
        "monotonic_ticks": time.monotonic_ns(),
        "body": body,
    }


def append(
    vc: VerifiedConnection,
    *,
    event_type: str,
    body: dict,
    expected_head: Head | None = None,
    advance_token: bool = False,
    _fault_after_insert: Callable[[], None] | None = None,
) -> dict:
    """Commit one event as the unique child of the expected head.

    `expected_head=None` means "whatever is current", read inside the
    transaction. Supplying one makes the caller's assumption explicit and
    produces `HeadAdvanced` rather than a silent rebase onto a head they never
    saw.

    `advance_token` increments the fencing token as part of the same atomic
    transition. The envelope still records the token **in force at
    authorization** — the old one — because that is the authority under which
    the write was permitted. The new token is named in the body of the event
    that establishes it, and the head carries it forward. Only lease grant and
    renewal may advance it, and only under the rule committed at activation.

    `_fault_after_insert` is a test hook: it runs between the INSERT and the
    conditional UPDATE, so an exception there exercises the rollback path. It is
    never used outside tests and has no production caller.
    """
    conn = vc.conn
    try:
        conn.execute("BEGIN IMMEDIATE")
    except sqlite3.OperationalError as exc:
        raise StoreBusy(str(exc)) from None

    try:
        current = read_head(conn)
        if current is None:
            raise AppendRefused("no ledger_head; the ledger has no genesis")
        if expected_head is not None and expected_head != current:
            raise HeadAdvanced(expected_head, current)

        # Chain constants come from genesis, not from this module's defaults, so
        # an event can never be written under identities the ledger never
        # committed to.
        genesis_body = json.loads(
            conn.execute(
                "SELECT body_canon FROM events WHERE seq = 0"
            ).fetchone()[0]
        )["body"]["chain_constants"]

        epoch_id, _ = _clock_epoch()
        event = _envelope(
            parent=current,
            seq=current.seq + 1,
            event_type=event_type,
            body=body,
            schema_version=genesis_body["schema_version"],
            canon_version=genesis_body["canon_version"],
            hash_alg=genesis_body["hash_alg"],
            epoch_id=epoch_id,
        )
        body_canon = _canonical(event)
        event_id = compute_event_id(body_canon)
        new_token = current.fencing_token + 1 if advance_token else current.fencing_token

        conn.execute(
            "INSERT INTO events (event_id, parent_id, seq, body_canon) "
            "VALUES (?, ?, ?, ?)",
            (event_id, current.event_id, event["seq"], body_canon),
        )

        if _fault_after_insert is not None:
            _fault_after_insert()

        # The condition lives in the statement. Everything above is preparation.
        cur = conn.execute(
            "UPDATE ledger_head SET event_id = ?, seq = ?, fencing_token = ? "
            "WHERE id = 1 AND event_id = ? AND seq = ? AND fencing_token = ?",
            (
                event_id,
                event["seq"],
                new_token,
                current.event_id,
                current.seq,
                current.fencing_token,
            ),
        )
        if cur.rowcount != 1:
            raise HeadAdvanced(current, read_head(conn))

        conn.execute("COMMIT")
    except BaseException:
        try:
            conn.execute("ROLLBACK")
        except sqlite3.OperationalError:
            pass
        raise

    return {"event_id": event_id, **event}
