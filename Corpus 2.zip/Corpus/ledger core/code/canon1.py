"""
canon1.py — canonical serializer for `canon/1`.

    canon/1 = RFC 8785 (JCS) MINUS IEEE-754 floats

Interface, frozen by step 1:

    canonicalize(raw: bytes) -> bytes
    raises canon1_protocol.CanonRejected(code)

Import `canon1_protocol` from the frozen vector package. Do not vendor a copy:
two module identities produce two class objects and `except` stops matching.

Scope. Bytes in, canonical bytes out, or a typed rejection. No hashing, no
event envelope, no storage.

Why the JSON module is not used
-------------------------------
`json.loads` converts number tokens to Python floats at parse time:
`333333333.33333329` loses precision and `1E30` loses its token form, so a float
ban cannot be enforced downstream of it. It also accepts `NaN`/`Infinity` and
keeps the last of duplicate keys silently. The parser below works on token text.

Why parsing and emitting are iterative
--------------------------------------
A recursive implementation imposes a maximum nesting depth, and that depth is a
property of the runtime rather than of the format. Two conforming
implementations would then disagree about input that is identical in canonical
meaning. **Nesting depth does not change canonical meaning, so it has not earned
a place in the profile.** Both the parser and the emitter therefore use explicit
stacks and impose no depth rule at all.

Resource exhaustion remains a real concern. It belongs to the outer admission
envelope — a bound on accepted payload size, applied before canonicalization —
not to canonical identity. Nothing here refuses input for being deep.

Rules implemented (from RFC 8785, not from the test vectors)
------------------------------------------------------------
1. Input is UTF-8. Invalid encoding is rejected, as is a leading BOM.
2. Object keys sort by **UTF-16 code units**, not code points. These differ:
   U+1F602 encodes as surrogate D83D, which sorts *below* U+FB33 although the
   code point is far higher.
3. Strings escape only `"`, `\\`, and C0 controls — short forms `\\b \\t \\n \\f
   \\r` where defined, otherwise `\\u00xx` with lowercase hex. Everything else is
   literal UTF-8, including U+007F and all non-ASCII. `/` is not escaped.
4. No insignificant whitespace.
5. Integers only (canon/1 §1.3). A token containing `.`, `e` or `E` is rejected
   as FLOAT_IN_HASHED_FIELD; an integer outside int64 as INTEGER_OUT_OF_RANGE.
   `-0` serializes as `0`, per the ES6 rule RFC 8785 inherits.

Decisions not covered by any published vector
---------------------------------------------
Flagged rather than buried; each is strict and each is reversible only by
amendment once records exist.

- **Duplicate object keys** rejected as MALFORMED_JSON. Last-wins would silently
  discard committed content.
- **Lone surrogates** rejected as MALFORMED_JSON. ES2019 `JSON.stringify`
  escapes them; for a ledger, refusing is the safer reading.
- **Leading BOM** rejected as MALFORMED_JSON, per RFC 8259.
"""
from __future__ import annotations

import re

from canon1_protocol import (
    FLOAT_IN_HASHED_FIELD,
    INTEGER_OUT_OF_RANGE,
    INVALID_UTF8,
    MALFORMED_JSON,
    UNSUPPORTED,
    CanonRejected,
)

__all__ = ["canonicalize", "INT64_MIN", "INT64_MAX"]

INT64_MIN = -(2**63)
INT64_MAX = 2**63 - 1

_WS = " \t\n\r"
_HEX = "0123456789abcdefABCDEF"
_NUMBER = re.compile(r"-?(?:0|[1-9][0-9]*)(\.[0-9]+)?(?:[eE][+-]?[0-9]+)?")
_SHORT_ESCAPES = {
    '"': '\\"',
    "\\": "\\\\",
    "\b": "\\b",
    "\t": "\\t",
    "\n": "\\n",
    "\f": "\\f",
    "\r": "\\r",
}
_SIMPLE_UNESCAPE = {
    '"': '"', "\\": "\\", "/": "/",
    "b": "\b", "f": "\f", "n": "\n", "r": "\r", "t": "\t",
}


# ---------------------------------------------------------------- parsing

class _Parser:
    """Iterative recursive-descent. No call recursion, so no depth limit."""

    def __init__(self, text: str):
        self.s = text
        self.i = 0
        self.n = len(text)

    # -- primitives -------------------------------------------------------

    def fail(self, msg: str) -> None:
        raise CanonRejected(MALFORMED_JSON, f"{msg} at offset {self.i}")

    def ws(self) -> None:
        s, n = self.s, self.n
        while self.i < n and s[self.i] in _WS:
            self.i += 1

    def peek(self) -> str:
        return self.s[self.i] if self.i < self.n else ""

    def expect(self, ch: str) -> None:
        if self.peek() != ch:
            self.fail(f"expected {ch!r}")
        self.i += 1

    # -- scalars ----------------------------------------------------------

    def literal(self, word: str, val):
        if self.s[self.i:self.i + len(word)] != word:
            self.fail(f"expected {word}")
        self.i += len(word)
        return val

    def number(self):
        start = self.i
        m = _NUMBER.match(self.s, self.i)
        if not m or m.start() != self.i:
            self.fail("malformed number")
        token = m.group(0)
        # Decide on the token, before any numeric conversion can lose it.
        if m.group(1) or "e" in token or "E" in token:
            raise CanonRejected(FLOAT_IN_HASHED_FIELD, f"{token!r} at offset {start}")
        self.i = m.end()
        value = int(token)
        if not (INT64_MIN <= value <= INT64_MAX):
            raise CanonRejected(
                INTEGER_OUT_OF_RANGE, f"{token} outside int64 at offset {start}"
            )
        return value

    def string(self) -> str:
        self.expect('"')
        out: list[str] = []
        s = self.s
        while True:
            if self.i >= self.n:
                self.fail("unterminated string")
            ch = s[self.i]
            if ch == '"':
                self.i += 1
                return "".join(out)
            if ch == "\\":
                self.i += 1
                out.append(self.escape())
                continue
            if ch < "\x20":
                self.fail("raw control character in string")
            out.append(ch)
            self.i += 1

    def escape(self) -> str:
        if self.i >= self.n:
            self.fail("truncated escape")
        e = self.s[self.i]
        if e in _SIMPLE_UNESCAPE:
            self.i += 1
            return _SIMPLE_UNESCAPE[e]
        if e != "u":
            self.fail(f"invalid escape \\{e}")
        self.i += 1                      # consume 'u'
        cu = self.hex4()
        if 0xDC00 <= cu <= 0xDFFF:
            self.fail("low surrogate without preceding high surrogate")
        if 0xD800 <= cu <= 0xDBFF:
            if self.s[self.i:self.i + 2] != "\\u":
                self.fail("high surrogate without following low surrogate")
            self.i += 2                  # consume '\' and 'u'
            lo = self.hex4()
            if not (0xDC00 <= lo <= 0xDFFF):
                self.fail("high surrogate not followed by low surrogate")
            return chr(0x10000 + ((cu - 0xD800) << 10) + (lo - 0xDC00))
        return chr(cu)

    def hex4(self) -> int:
        """Read exactly four hex digits. The caller consumes the 'u'."""
        digits = self.s[self.i:self.i + 4]
        if len(digits) != 4 or any(d not in _HEX for d in digits):
            self.fail("malformed \\u escape")
        self.i += 4
        return int(digits, 16)

    # -- structure --------------------------------------------------------

    def read_key(self, frame: list) -> None:
        self.ws()
        if self.peek() != '"':
            self.fail("object key must be a string")
        key = self.string()
        if key in frame[1]:
            self.fail(f"duplicate key {key!r}")
        self.ws()
        self.expect(":")
        frame[2] = key

    def parse(self):
        self.ws()
        root = self.value()
        self.ws()
        if self.i != self.n:
            self.fail("trailing content")
        return root

    def value(self):
        stack: list[list] = []           # ["obj", dict, key] | ["arr", list]

        while True:
            # --- open a container, or read a scalar ---
            self.ws()
            ch = self.peek()
            if ch == "{":
                self.i += 1
                node: dict = {}
                self.ws()
                if self.peek() == "}":
                    self.i += 1
                    val = node
                else:
                    frame = ["obj", node, None]
                    stack.append(frame)
                    self.read_key(frame)
                    continue
            elif ch == "[":
                self.i += 1
                arr: list = []
                self.ws()
                if self.peek() == "]":
                    self.i += 1
                    val = arr
                else:
                    stack.append(["arr", arr])
                    continue
            elif ch == '"':
                val = self.string()
            elif ch == "t":
                val = self.literal("true", True)
            elif ch == "f":
                val = self.literal("false", False)
            elif ch == "n":
                val = self.literal("null", None)
            elif ch == "-" or ch.isdigit():
                val = self.number()
            else:
                self.fail("unexpected character" if ch else "unexpected end of input")

            # --- attach, and close containers that are now complete ---
            while True:
                if not stack:
                    return val
                top = stack[-1]
                if top[0] == "obj":
                    top[1][top[2]] = val
                else:
                    top[1].append(val)

                self.ws()
                ch = self.peek()
                if ch == ",":
                    self.i += 1
                    if top[0] == "obj":
                        self.read_key(top)
                    break                       # parse the next value
                close = "}" if top[0] == "obj" else "]"
                if ch != close:
                    self.fail(f"expected ',' or '{close}'")
                self.i += 1
                val = top[1]
                stack.pop()                     # container complete; re-reduce


# ---------------------------------------------------------------- emitting

def _emit_string(s: str) -> str:
    out = ['"']
    for ch in s:
        esc = _SHORT_ESCAPES.get(ch)
        if esc is not None:
            out.append(esc)
        elif ch < "\x20":
            out.append("\\u%04x" % ord(ch))
        else:
            out.append(ch)              # literal UTF-8, incl. U+007F and non-ASCII
    out.append('"')
    return "".join(out)


def _sort_key(key: str) -> bytes:
    """RFC 8785 orders keys by UTF-16 code unit, not by code point."""
    return key.encode("utf-16-be", errors="surrogatepass")


def _emit(root) -> str:
    """Iterative post-order emit. Deep structures cost memory, never stack."""
    out: list[str] = []
    work: list[tuple[bool, object]] = [(False, root)]   # (is_literal, payload)

    while work:
        literal, item = work.pop()
        if literal:
            out.append(item)                            # type: ignore[arg-type]
            continue

        if item is None:
            out.append("null")
        elif item is True:
            out.append("true")
        elif item is False:
            out.append("false")
        elif isinstance(item, int):
            out.append("0" if item == 0 else str(item))  # covers -0 -> 0
        elif isinstance(item, str):
            out.append(_emit_string(item))
        elif isinstance(item, list):
            if not item:
                out.append("[]")
                continue
            work.append((True, "]"))
            for idx in range(len(item) - 1, -1, -1):
                work.append((False, item[idx]))
                if idx:
                    work.append((True, ","))
            work.append((True, "["))
        elif isinstance(item, dict):
            if not item:
                out.append("{}")
                continue
            members = sorted(item.items(), key=lambda kv: _sort_key(kv[0]))
            work.append((True, "}"))
            for idx in range(len(members) - 1, -1, -1):
                key, val = members[idx]
                work.append((False, val))
                work.append((True, _emit_string(key) + ":"))
                if idx:
                    work.append((True, ","))
            work.append((True, "{"))
        else:
            raise CanonRejected(
                UNSUPPORTED, f"unserializable type {type(item).__name__}"
            )

    return "".join(out)


# ---------------------------------------------------------------- entry point

def canonicalize(raw: bytes) -> bytes:
    """Raw JSON bytes -> canon/1 bytes. Raises CanonRejected off-profile."""
    if not isinstance(raw, (bytes, bytearray)):
        raise TypeError("canonicalize expects bytes")
    try:
        text = bytes(raw).decode("utf-8")
    except UnicodeDecodeError as exc:
        raise CanonRejected(INVALID_UTF8, str(exc)) from None
    if text.startswith("\ufeff"):
        raise CanonRejected(MALFORMED_JSON, "leading byte order mark")
    return _emit(_Parser(text).parse()).encode("utf-8")
