# Ledger Core

The minimum that builds a ledger from nothing and appends to it. Six Python modules, two data files, one contract. Nothing else is required and nothing else is present.

Verified working: genesis creates an empty ledger, `verify_chain` returns no findings, two events append and the chain still verifies.

## Files

```
code/
  canon1_protocol.py   canonicalization protocol constants        (no deps)
  canon1.py            JCS canonicalization                       -> canon1_protocol
  storage.py           SQLite regime verification, connections    (no deps)
  genesis.py           create ledger, event ids, chain verify     -> canon1, storage
  append.py            commit one event as child of head          -> genesis, storage
  lease.py             fencing tokens                             -> append, genesis, storage
vectors/
  jcs_vectors_v1.json  canonicalization test vectors (hashed into genesis)
  PACKAGE.sha256       vector manifest (hashed into genesis)
docs/
  Irreversible_Ledger_Contract_v0.1.md   the contract (hashed into genesis)
  Trace_Record_Contract.md               what gets recorded about an execution
```

The three genesis-bound files are `docs/Irreversible_Ledger_Contract_v0.1.md`, `vectors/jcs_vectors_v1.json`, and `vectors/PACKAGE.sha256`. They are not documentation. `build_genesis_body` hashes all three into the genesis event, so the ledger's identity depends on them. Remove them and it will not start.

`Trace_Record_Contract.md` is not hashed into genesis and the core does not read it. It is the frozen schema for what a trace records — formerly `phase1_observation_format_v1.md`, renamed. Contents are unchanged, including the internal title and version, because its own §0 amendment rule governs the body and a rename is not a body edit. Bump it yourself if you want the header to match the filename.

`lease.py` is in the core only because `genesis.verify_chain` imports `expected_token` from it lazily, inside the function body. A static read of the imports misses this; the smoke test catches it.

## Build from nothing

```python
from genesis import create_ledger, verify_chain
from storage import open_authoritative
from append import append, read_head

create_ledger("ledger.db",
    contract_path="../docs/Irreversible_Ledger_Contract_v0.1.md",
    canon_module_path="canon1.py",
    protocol_module_path="canon1_protocol.py",
    vector_package_path="../vectors/jcs_vectors_v1.json",
    vector_manifest_path="../vectors/PACKAGE.sha256")

vc = open_authoritative("ledger.db")
append(vc, event_type="observation",
       body={"joint": "left_knee", "score": 0},
       expected_head=read_head(vc.conn))

verify_chain("ledger.db")   # [] means clean
```

Paths above are relative to `code/`.

## Removed, and what each did

| Removed | What it was |
|---|---|
| `reconstruct.py` | rebuild current state by replaying the log |
| `rebuild.py` | recover the database from the event log |
| `amendment.py` | supersession — correcting the record without rewriting it |
| `proposal.py` | proposals from outside the gate, including which model emitted what |
| `predictions.py` | recorded predictions and their resolution |
| `regime.py` | retroactive amendment plus token advancement together |
| `tests/` | nine test modules, `selftest.py`, `run_all.py` |
| `docs/step*_README.md` | per-step design notes |
| `brown_janssen/` | the COMB argument-encoding apparatus — a separate project |
| `jcs_vectors_v1/` | duplicate of `ledger_baseline_v1/vectors/`, plus the vector runner |

Neither of the two most consequential removals does the job it might first appear to:

- **`amendment.py`** carries supersession — correcting a record that was itself wrong, without deleting it. It is *not* what makes an earlier flag and a later clear both permanent; plain appends already do that.
- **`reconstruct.py`** answers "what is true now" from the log. The core can write history but not report current state, so that query has to be hand-rolled.

Neither is what the training model most needs from the layer above. That is regime identity, below.

The core is the write path and its integrity guarantees. That is all it is.

## What the core guarantees, and what it does not

**Guaranteed:** occurrence and order. Events happened, in this sequence, and the chain proves it.

**Not guaranteed:** comparability. Nothing in the core records which rule-set was in force when an event was committed.

That gap is `regime_digest` — §6.2 of the trace record contract. It matters because several readings in the training model depend on knowing which events belong to the same governed block:

- the same edge load held across a block
- advancement read as *stopped behaving differently*
- counting recurring flag events
- the held-dose falsifier
- promotion resetting the series

Without regime identity in the record, promotion is invisible to the audit trail — the ledger can prove events happened while silently grouping incomparable days into one apparently clean block.

Two costs come with closing it, and both are real:

- **Recording friction.** Promotion becomes an audited transition rather than an informal adjustment. If capturing it takes a second bookkeeping step, some promotions won't get recorded, and a partially-recorded trail is worse than none.
- **Partitioned history.** Only same-regime events are comparable, so frequent promotion can leave no block with enough events to read. The right response is that some questions are unanswerable from short regimes — not that training should slow down so the instrument gets its sample.

## Where this sits

| Layer | Job |
|---|---|
| Irreversible Ledger Contract | what can become durable authoritative history, and how its integrity is guaranteed |
| Trace Record Contract | what must be represented about an execution, observation, or decision |
| Regime layer *(not built)* | which rules are active, and which records are comparable |

The core implements the first. The second is specified and frozen. The third does not exist yet.
