# Regime Identity Contract v0.1

**Version:** 0.1.0
**Status:** DRAFT — NOT FROZEN
**Date drafted:** 2026-08-12
**Author of record:** Josh McCloskey
**Layer:** third. Sits above the Irreversible Ledger Contract (what may become history) and the Trace Record Contract (what must be represented about an execution).

---

## §0 Status of this document

This is a **draft**, not a freeze. It has not been reviewed and no code written
against it may be described as an implementation of a frozen contract. The
demonstration shipped alongside it (`regime.py`, `regime_report.py`) exists to
make the clauses attackable, not to establish them.

**Freezing is a separate act.** It happens when §12 is satisfied, and it is
performed by committing this document's digest into a ledger — the same way the
Irreversible Ledger Contract entered genesis. Until then this document has no
authority over any record.

**Amendment rule (inherited, unchanged).** Implementation discoveries are
recorded as numbered deviations in §11 against this baseline. They are **not**
edited into the body. If the body changes, the version number changes and the
prior version is retained. Supersession, never revision.

**Admission rule for this document (inherited from the Ledger Contract).** A
clause belongs here only if both hold:

- **(R1) Irrecoverability.** If it is absent when the first regimed event is
  committed, the evidence it carries cannot be reconstructed later from the
  record itself.
- **(R2) Falsifiability.** The clause is falsifiable by a verifier invariant or
  by an adversarial attack in §9.

A clause satisfying only R1 is a wish. A clause satisfying only R2 belongs in
the amendable layer. Anything failing both is out. The closed set of clauses
that satisfy R1 and fail R2 — assertions about correspondence to the world
rather than properties of the record — is §8, and it may not be extended
without amendment.

MUST / MUST NOT / MAY carry RFC 2119 force.

---

## §1 The invariant

> **Two events are comparable only if the record proves they were committed
> under the same rules.**

Everything else in this document exists to protect that statement.

The layer below already guarantees **occurrence and order**: these events
happened, in this sequence, and the chain proves it. It guarantees nothing about
**comparability**. Without this layer a verifier can produce a clean chain that
silently groups incomparable days into one apparently uniform block — every
individual event valid, the aggregate meaningless.

That failure is not detectable after the fact. Which rules were in force at
commit is not recoverable from a record that never wrote it down. Hence R1.

---

## §2 What a regime is

**§2.1** A **regime** is a JSON object holding the complete parameterization
that governs interpretation of the events committed under it.

**§2.2** A regime MUST be `canon/1`-admissible. In particular it MUST NOT
contain IEEE-754 floats in any field (Ledger Contract §1.3). A threshold of
`0.85` is written as the string `"0.85"` or the rational `{"n": 17, "d": 20}`.

**§2.3** A regime MUST carry a `supersedes` field: the `regime_digest` of the
regime it replaces, or `null` for the first.

**§2.4** What else goes inside a regime object is **not frozen** (§10). This
contract governs regime *identity and authority*, never regime *content*.

---

## §3 Identity is content, not name

**§3.1** Inherited from Trace Record Contract §6.2, restated because this
document depends on it:

```
regime_digest = "sha256:" + hex(SHA-256(canon/1(regime)))
```

**§3.2** A regime MUST NOT carry an identifier of its own. A symbolic name can
drift while the parameters underneath change; the digest cannot. A friendly
label MAY accompany a regime in `regime_label`, and it participates in nothing.

**§3.3** In-place edit of a regime is unrepresentable: any edit produces a
different digest and therefore a different regime. There is no operation that
changes a regime.

---

## §4 Regime identity lives in the body, never the envelope

**§4.1** An event whose interpretation depends on a rule-set MUST carry
`regime_digest` **in its `body`**.

**§4.2** `regime_digest` MUST NOT be added to the event envelope (Ledger
Contract §2.1).

> **Why.** The envelope field set is fixed by `schema_version`, which derives
> from the chain constants committed at genesis. Adding an envelope field means
> a new `schema_version`, which means a new genesis, which means no migration
> path for any existing record. The body is the layer designed to carry
> type-specific payload and is the only place this can go without destroying
> the ledgers that already exist.

**§4.3** An event carrying no `regime_digest` is **unregimed**. An unregimed
event is durable, ordered, and comparable to nothing — including to other
unregimed events. This is a defined state, not an error, and the verifier
reports the count rather than refusing the record.

---

## §5 Status is derived, never stored

**§5.1** A regime's status is a function of the committed chain and nothing
else. It MUST NOT be stored in a table, a field, or a file. Any such store is a
projection under Ledger Contract §7.2: deletable, rebuildable, never read as
input.

**§5.2** Four statuses:

| Status | Meaning |
| --- | --- |
| **candidate** | Declared. Holds no authority. May be promoted or abandoned. |
| **authoritative** | Holds authority now. Exactly zero or one regime is authoritative at any `seq`. |
| **superseded** | Held authority; a later regime was promoted over it. |
| **abandoned** | Was a candidate; explicitly discarded. Never held authority. |

**§5.3 Forcing error against the Freeze Record (2026-08-10, §2).** The freeze
record specifies status as three-valued — authoritative, candidate, abandoned —
and does not say what a regime becomes when its successor is promoted. Three
values cannot carry it. Routing a former authoritative regime to `abandoned`
would make `abandoned` unable to distinguish a regime that never held authority
from one that did, and the second is the one whose events are still in the
record and still interpretable. `superseded` is added here for that reason. This
is a change to the freeze record, not a reading of it.

**§5.4** Status is recomputed by folding the regime events in `seq` order. A
verifier that cannot reproduce the same statuses from `events` and
`ledger_head` alone has found a defect, not a disagreement.

---

## §6 Transitions are events

**§6.1** Three event types, and no others, change regime status:

| Event type | Body | Effect |
| --- | --- | --- |
| `REGIME_DECLARED` | the full regime object, plus its digest | → **candidate** |
| `REGIME_PROMOTED` | the digest, plus `evidence_refs[]` | candidate → **authoritative**; the prior authoritative → **superseded** |
| `REGIME_ABANDONED` | the digest, plus `reason` | candidate → **abandoned** |

**§6.2** Declaration never confers authority, including for the first regime.
Promotion is always an explicit act. One rule, no bootstrap exception — an
exception here would be the one case where authority was conferred by something
other than a decision, and it would be the case nobody audits.

**§6.3** `REGIME_PROMOTED` MUST cite a digest that a prior `REGIME_DECLARED`
committed, and that is currently a candidate. Promoting an undeclared,
superseded, or abandoned digest is refused.

**§6.4** `REGIME_DECLARED` MUST commit the regime object in full, not a digest
alone. A digest naming content that exists nowhere in the record is a pointer
into a void; the record must be able to answer *what were the rules* without
consulting anything outside itself.

**§6.5 Requalification evidence belongs to the candidate.** Evidence gathered to
justify a promotion is committed under the **candidate** regime, not under the
prior authoritative regime (the rules changed) and not under the next
authoritative regime (that regime is created by the promotion the evidence
feeds). A promotion citing evidence committed under any other regime is refused.

---

## §7 The comparability rule

**§7.1** A **block** is the maximal run of events sharing one `regime_digest`.

**§7.2** Any claim aggregating more than one event MUST be computed within a
single block. Blocks MUST NOT be merged, interpolated between, or summarized
across.

**§7.3** A question that requires more events than the longest relevant block
contains is **unanswerable from this record**. That is the correct answer and
it MUST be reported as such. It is not a reason to merge blocks, and it is not a
reason to slow promotion so the instrument gets its sample.

**§7.4** Promotion resets every running series. A count, a trend, or a held-load
reading does not continue across a promotion; it starts again.

---

## §8 Asserted, not proven

These clauses assert correspondence to the world rather than a property of the
record. No verifier and no attack can reach them. No document, report, or
dashboard derived from this record may describe them as proven. This table is
closed; extending it requires an amendment under §11.

| Clause | Asserted | Best available mitigation |
| --- | --- | --- |
| §4.1 | The digest an event carries names the rules the executing process was actually running | The regime is committed before use, so the digest resolves to content the record holds. Nothing forces the running code to match it. A wrong digest is internally consistent and undetectable. |
| §6.1 | A promotion that occurred was recorded | Making promotion an audited transition is the whole mechanism. An unrecorded promotion is invisible, and a partially-recorded trail is worse than none — the record will show one long clean block that never existed. |
| §6.5 | The cited evidence is what the promotion decision actually rested on | `evidence_refs` is checkable for regime membership. That the decision-maker read it is not checkable. |

---

## §9 Test inventory

Every normative clause above MUST be falsifiable by a verifier invariant or by
one of these. An attack that cannot fail is not testing anything.

| # | Attack | Binds | Acceptance |
| --- | --- | --- | --- |
| **R1** | Declare a regime, then edit one field and declare again. | §3.1, §3.3 | Two different digests. No operation exists that mutates the first. |
| **R2** | Promote a digest that was never declared. | §6.3 | Refused. |
| **R3** | Promote a digest that is already superseded or abandoned. | §6.3 | Refused. |
| **R4** | Commit events under regime A, promote regime B, commit more events, then request a single aggregate. | §7.1, §7.2 | Two blocks reported. No merged block is producible. |
| **R5** | Promote a candidate citing evidence committed under the prior authoritative regime. | §6.5 | Refused. |
| **R6** | Drop every table except `events` and `ledger_head`; recompute every regime status. | §5.1, §5.4 | Identical statuses. Any status that does not survive the rebuild was never in the record. |
| **R7** | Commit an event with no `regime_digest`, then request a block containing it. | §4.3 | Reported as unregimed. Belongs to no block. |

---

## §10 Explicitly NOT frozen

Named so the boundary is legible from outside, and so nothing acquires frozen
status by proximity:

What fields a regime object contains · promotion policy and thresholds · how
much evidence justifies a promotion · minimum viable block length · probe-family
specification · requalification gate design · statistical warrant for sampled
requalification · reporting, dashboards, labels.

All of the above evolve without amending this document.

---

## §11 Deviation log

Numbered deviations found during implementation are recorded here against the
baseline body, never edited into it.

*(none yet)*

---

## §12 Exit condition

Freeze this document when, and only when:

> Every clause exists because future evidence would otherwise be unrecoverable,
> and every clause has a test capable of falsifying it.

Not when the document feels complete.

**Currently unsatisfied.** §6.5 is the weakest clause: the freeze record's own
open items include the exact regime-status transition contract, and requiring
requalification evidence to sit under the candidate is a design choice made here
rather than one forced by anything already established. It should be attacked
before it is frozen.
