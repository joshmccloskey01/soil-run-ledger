import os
from genesis import create_ledger
from storage import open_authoritative
from append import append, read_head
from regime import (declare_regime, promote_regime, abandon_regime,
                    RegimeRefused, regime_digest, authoritative_regime)

DB = "/tmp/demo.db"
if os.path.exists(DB): os.remove(DB)

create_ledger(DB,
    contract_path="../docs/Irreversible_Ledger_Contract_v0.1.md",
    canon_module_path="canon1.py", protocol_module_path="canon1_protocol.py",
    vector_package_path="../vectors/jcs_vectors_v1.json",
    vector_manifest_path="../vectors/PACKAGE.sha256")

vc = open_authoritative(DB)

R1 = {"supersedes": None, "regime_label": "base build",
      "weekly_load_cap": 40, "flag_threshold": "0.75"}
d1 = declare_regime(vc, R1)
promote_regime(vc, d1)

for score in (0, 1, 0, 2):
    append(vc, event_type="observation",
           body={"joint": "left_knee", "score": score, "regime_digest": d1},
           expected_head=read_head(vc.conn))

# a candidate that gets thrown away
Rx = {"supersedes": d1, "regime_label": "too aggressive", "weekly_load_cap": 90,
      "flag_threshold": "0.75"}
dx = declare_regime(vc, Rx)
abandon_regime(vc, dx, reason="cap not justified by any block")

R2 = {"supersedes": d1, "regime_label": "promoted build",
      "weekly_load_cap": 55, "flag_threshold": "0.75"}
d2 = declare_regime(vc, R2)
ev = append(vc, event_type="requalification",
            body={"passed": True, "regime_digest": d2},
            expected_head=read_head(vc.conn))
promote_regime(vc, d2, evidence_refs=[ev["event_id"]])

for score in (1, 1):
    append(vc, event_type="observation",
           body={"joint": "left_knee", "score": score, "regime_digest": d2},
           expected_head=read_head(vc.conn))

# an entry someone forgot to stamp
append(vc, event_type="observation", body={"joint": "left_knee", "score": 3},
       expected_head=read_head(vc.conn))

print("--- REFUSALS (each of these must fail) ---")
for label, fn in [
    ("re-promote a superseded rule-set", lambda: promote_regime(vc, d1)),
    ("promote an abandoned candidate",   lambda: promote_regime(vc, dx)),
    ("promote something never declared", lambda: promote_regime(vc, "sha256:" + "0"*64)),
]:
    try:
        fn(); print(f"  !! NOT REFUSED: {label}")
    except RegimeRefused as e:
        print(f"  refused: {label}\n      -> {e}")

# R1: edit one field, get a different identity
assert regime_digest({**R1, "weekly_load_cap": 41}) != d1
print("  refused: in-place edit — one changed field yields a different rule-set")

# R5: evidence from the wrong regime
R3 = {"supersedes": d2, "regime_label": "third", "weekly_load_cap": 60, "flag_threshold": "0.75"}
d3 = declare_regime(vc, R3)
try:
    promote_regime(vc, d3, evidence_refs=[ev["event_id"]])
    print("  !! NOT REFUSED: evidence from another regime")
except RegimeRefused as e:
    print(f"  refused: evidence borrowed from another rule-set\n      -> {e}")

vc.close()
print()
