# The Reading Check Loop — v0.1

**Status:** DRAFT — untested
**Purpose:** give an LLM a second pass before an answer commits, so obvious misses get caught by the machinery instead of by the reader.

---

## 1. The failure this targets

A reading of the input forms in one pass. The response is then written *around
that reading* rather than *against the input*. There is no gap between the
reading forming and the answer emitting, so nothing checks whether the reading
was right.

This is not a knowledge failure. In every logged instance below, the model had
everything it needed.

**Logged instances (2026-08-12 session):**

| # | Input | What fired | What was actually said |
|---|---|---|---|
| 1 | 800 m second-lap training | Standard doctrine: rehearse the depleted state | Under the position on the table, that trains operating without reserve — it inverts |
| 2 | List of sports where the method appears | Standard objection: survivorship bias | Those are acute injuries, not accumulation failures; the objection needed a mechanism that wasn't present |
| 3 | Ice blocks and tongs | Read as varied-versus-repetitive loading | The build was daily light deadlifts; variety was never the variable |
| 4 | Same case, second attempt | Read the tongs as the training | The tongs were the readout; PTTP was the case |
| 5 | Quantum mechanics as a target | Argued the adaptation shape doesn't transfer — no store, no retained history | The shape being carried was the *evidence* shape, which transfers exactly |

Five failures, one mechanism: **the first plausible reading was treated as the
input.**

---

## 2. The core move

Do not try to slow the reading down. It cannot be slowed.

Instead, demote it:

> **The fast reading is a proposal, not the answer.**

This is the same split already used elsewhere in this system — one part
proposes, a different part authorizes, and the proposer does not get to
authorize itself. Applied here at the scale of a single response.

The check is cheap because it is not a second act of thinking. It is a
comparison between two things that already exist: what was said, and what is
about to be answered.

---

## 3. The loop

Six steps. Steps 1–4 happen before anything is sent.

**1 — State the reading.**
Say what the person is taken to be claiming, in their words, not in restated
form. Commit it, so it can be wrong. A reading that is never stated cannot be
caught.

**2 — Name the retrieval.**
Is this answer the standard one for this surface feature? "800 m" retrieves
race-pace doctrine. "List of anecdotes" retrieves survivorship. If the answer
is the default for the topic rather than for the argument, say so.

**3 — Run the conflict check.**
- What does the position on the table claim?
- What does the answer require to be true?
- Do they conflict?

Failure #1 dies at this step. So does #2, in the version where the objection is
checked for whether its mechanism is actually present.

**4 — Predict the hole.**
Name the *specific* step not taken — the one thing a reader would say is
missing. One, committed, before sending.

**5 — Send.**

**6 — Score.**
Two binary outcomes, recorded:
- Did the stated reading match what was meant?
- Was the predicted hole the one the reader actually saw?

Step 6 is what makes this a loop rather than a prompt. Without it, nothing
accumulates and nothing can be shown to work.

---

## 4. The hedging trap

Step 4 is gameable. Listing every direction not taken satisfies the letter of
it and defeats the purpose — an answer that gestures at its own incompleteness
in six directions has named nothing.

**Rule:** one hole, specific enough to be wrong. "This may be incomplete" does
not score. "I did not check whether the mechanism is acute or accumulated" does.

---

## 5. What this cannot do

- It does not slow the reading. The first reading still forms instantly.
- It does not produce insight. Nothing here makes an unseen thing visible.
- It does not survive a long conversation on its own. Held as a habit, it
  decays. That is what the machinery is for.
- It catches **default retrieval** — the answer that fired on a surface
  feature. That is most of the observed failures, not all of them.

---

## 6. Falsifier

> If the predicted hole is rarely the one the reader saw, one of two things is
> true, and they must be distinguished before the loop is adjusted:
>
> **(a)** the model cannot see where it stopped — which is information about the
> reach of the method, not a defect in it; or
> **(b)** step 4 is being satisfied by hedging, in which case the loop is
> producing a score with nothing under it.

Case (a) is the more interesting outcome and should not be treated as failure.

---

## 7. Open

- Where the reading is stated *to the reader* versus held internally. Stating it
  every turn is noise; never stating it removes the check.
- Whether steps 2 and 3 collapse into one in practice.
- Whether scoring requires the reader, or whether disagreement between two
  independent readings is enough.
- What the loop does when the input is genuinely ambiguous rather than misread.

---

## 8. Test before building anything

This runs today as a prompt, with no code. Ten exchanges, scored by hand on the
two binary outcomes in step 6.

The number that matters is how many of the ten the reader would have had to
correct without it. If the loop does not move that number, the machinery is not
worth building yet.
