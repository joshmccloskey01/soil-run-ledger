"""
regime.py — the third layer. Which rules were in force, and which records are
comparable.

Implements Regime Identity Contract v0.1 (DRAFT). The contract is not frozen, so
nothing here is an implementation of a frozen contract.

What the layer below guarantees: occurrence and order. What it does not: that
two events are comparable. This module closes that and nothing else.

Nothing is stored. Every status in here is folded from the committed chain on
each call, per contract §5.1. There is no regime table to drift, and no cache to
disagree with the record. If a status cannot be recomputed from `events` and
`ledger_head` alone, it was never in the record.

Refusals raise. They do not return findings — a refused promotion must not
commit and then get reported, because a committed refusal is not a refusal.
`verify_regime()` is the read-side counterpart and returns findings, because a
record that already contains a defect cannot be un-committed.
"""
from __future__ import annotations

import hashlib
import json
from pathlib import Path

from append import append, read_head
from canon1 import canonicalize
from genesis import HASH_ALG
from storage import VerifiedConnection, open_authoritative

__all__ = [
    "RegimeRefused",
    "regime_digest",
    "declare_regime",
    "promote_regime",
    "abandon_regime",
    "regime_status",
    "authoritative_regime",
    "regime_object",
    "comparable_blocks",
    "verify_regime",
    "DECLARED",
    "PROMOTED",
    "ABANDONED",
]

DECLARED = "REGIME_DECLARED"
PROMOTED = "REGIME_PROMOTED"
ABANDONED = "REGIME_ABANDONED"

#: Contract §5.2.
CANDIDATE = "candidate"
AUTHORITATIVE = "authoritative"
SUPERSEDED = "superseded"
ABANDONED_STATUS = "abandoned"


class RegimeRefused(RuntimeError):
    """The transition was refused. Nothing was committed."""


# ----------------------------------------------------------------- identity

def regime_digest(regime: dict) -> str:
    """Contract §3.1. Identity is a function of the canonical bytes.

    Floats are refused here by canon/1, not by Python typing, so a threshold
    written as 0.85 fails at this boundary instead of producing a digest that a
    second implementation would compute differently.
    """
    raw = json.dumps(regime, ensure_ascii=False, allow_nan=False).encode()
    return f"{HASH_ALG}:" + hashlib.sha256(canonicalize(raw)).hexdigest()


# -------------------------------------------------------------- chain reading

def _chain(path: str | Path) -> list[dict]:
    """Every committed event, in seq order, parsed from its stored bytes."""
    vc = open_authoritative(path)
    try:
        rows = vc.conn.execute(
            "SELECT event_id, body_canon FROM events ORDER BY seq"
        ).fetchall()
    finally:
        vc.close()
    events = []
    for event_id, body_canon in rows:
        obj = json.loads(body_canon)
        obj["event_id"] = event_id
        events.append(obj)
    return events


def _fold(events: list[dict]) -> tuple[dict[str, str], list[str]]:
    """Contract §5.4. Replay the regime events in order.

    Returns (status by digest, findings). Findings are defects already committed
    — a refused transition never reaches here.
    """
    status: dict[str, str] = {}
    findings: list[str] = []
    for e in events:
        kind = e.get("event_type")
        body = e.get("body") or {}
        seq = e.get("seq")
        if kind == DECLARED:
            digest = body.get("regime_digest")
            regime = body.get("regime")
            if digest is None or regime is None:
                findings.append(f"seq {seq}: {DECLARED} missing regime or digest")
                continue
            recomputed = regime_digest(regime)
            if recomputed != digest:
                findings.append(
                    f"seq {seq}: declared digest {digest} != recomputed {recomputed}"
                )
                continue
            if digest in status:
                findings.append(f"seq {seq}: regime {digest[:19]} declared twice")
                continue
            status[digest] = CANDIDATE
        elif kind == PROMOTED:
            digest = body.get("regime_digest")
            if status.get(digest) != CANDIDATE:
                findings.append(
                    f"seq {seq}: promoted {str(digest)[:19]} from state "
                    f"{status.get(digest, 'undeclared')!r}; only a candidate may be promoted"
                )
                continue
            for other, state in status.items():
                if state == AUTHORITATIVE:
                    status[other] = SUPERSEDED
            status[digest] = AUTHORITATIVE
        elif kind == ABANDONED:
            digest = body.get("regime_digest")
            if status.get(digest) != CANDIDATE:
                findings.append(
                    f"seq {seq}: abandoned {str(digest)[:19]} from state "
                    f"{status.get(digest, 'undeclared')!r}; only a candidate may be abandoned"
                )
                continue
            status[digest] = ABANDONED_STATUS
    live = [d for d, s in status.items() if s == AUTHORITATIVE]
    if len(live) > 1:
        findings.append(f"{len(live)} regimes authoritative at once; at most one is permitted")
    return status, findings


# ---------------------------------------------------------------- derived reads

def regime_status(path: str | Path) -> dict[str, str]:
    """Every regime the record has ever named, and its status now."""
    return _fold(_chain(path))[0]


def authoritative_regime(path: str | Path) -> str | None:
    """Freeze Record §14, build object A: which regime is authoritative now?

    None means no regime has ever been promoted. Every event committed while
    this returns None is unregimed unless it carries a digest anyway.
    """
    for digest, state in regime_status(path).items():
        if state == AUTHORITATIVE:
            return digest
    return None


def regime_object(path: str | Path, digest: str) -> dict | None:
    """The rules themselves, read back out of the record (contract §6.4)."""
    for e in _chain(path):
        if e.get("event_type") == DECLARED:
            body = e.get("body") or {}
            if body.get("regime_digest") == digest:
                return body.get("regime")
    return None


def comparable_blocks(path: str | Path) -> list[dict]:
    """Contract §7.1. Maximal runs of events sharing one regime_digest.

    Regime transition events carry no regime themselves and are excluded: they
    are the boundary, not content inside it. Unregimed events (§4.3) are
    reported separately and belong to no block.
    """
    events = _chain(path)
    blocks: list[dict] = []
    unregimed: list[int] = []
    current: dict | None = None
    for e in events:
        if e.get("event_type") in (DECLARED, PROMOTED, ABANDONED, "GENESIS"):
            continue
        digest = (e.get("body") or {}).get("regime_digest")
        if digest is None:
            unregimed.append(e.get("seq"))
            current = None
            continue
        if current is not None and current["regime_digest"] == digest:
            current["seqs"].append(e.get("seq"))
        else:
            current = {"regime_digest": digest, "seqs": [e.get("seq")]}
            blocks.append(current)
    return [
        *({**b, "count": len(b["seqs"])} for b in blocks),
        *([{"regime_digest": None, "seqs": unregimed, "count": len(unregimed)}] if unregimed else []),
    ]


def verify_regime(path: str | Path) -> list[str]:
    """Findings against the committed record. Empty list means it holds.

    This is the regime counterpart to `genesis.verify_chain`, and it is
    deliberately separate: a chain can be perfectly intact and still group
    incomparable events, which is the exact failure this layer exists to catch.
    """
    events = _chain(path)
    _, findings = _fold(events)
    for e in events:
        if e.get("event_type") != PROMOTED:
            continue
        body = e.get("body") or {}
        digest = body.get("regime_digest")
        for ref in body.get("evidence_refs") or []:
            source = next((x for x in events if x.get("event_id") == ref), None)
            if source is None:
                findings.append(f"seq {e.get('seq')}: evidence {ref[:19]} is not a committed event")
            elif (source.get("body") or {}).get("regime_digest") != digest:
                findings.append(
                    f"seq {e.get('seq')}: evidence at seq {source.get('seq')} was committed "
                    "under a different regime; requalification evidence belongs to the "
                    "candidate (§6.5)"
                )
    return findings


# ------------------------------------------------------------------ transitions

def declare_regime(vc: VerifiedConnection, regime: dict) -> str:
    """Commit a regime as a candidate (§6.1). Returns its digest.

    The regime object is committed in full, not by reference: a digest naming
    content held nowhere in the record is a pointer into a void (§6.4).
    """
    if "supersedes" not in regime:
        raise RegimeRefused("regime must carry `supersedes` (digest or null) — §2.3")
    digest = regime_digest(regime)
    path = _path_of(vc)
    if digest in regime_status(path):
        raise RegimeRefused(f"regime {digest[:19]} is already declared")
    append(vc, event_type=DECLARED,
           body={"regime_digest": digest, "regime": regime},
           expected_head=read_head(vc.conn))
    return digest


def promote_regime(vc: VerifiedConnection, digest: str,
                   *, evidence_refs: list[str] | None = None) -> str:
    """Candidate -> authoritative (§6.1). The prior authoritative is superseded."""
    path = _path_of(vc)
    events = _chain(path)
    status, _ = _fold(events)
    state = status.get(digest)
    if state is None:
        raise RegimeRefused(f"regime {digest[:19]} was never declared — §6.3")
    if state != CANDIDATE:
        raise RegimeRefused(
            f"regime {digest[:19]} is {state}; only a candidate may be promoted — §6.3"
        )
    refs = list(evidence_refs or [])
    for ref in refs:
        source = next((x for x in events if x.get("event_id") == ref), None)
        if source is None:
            raise RegimeRefused(f"evidence {ref[:19]} is not a committed event")
        if (source.get("body") or {}).get("regime_digest") != digest:
            raise RegimeRefused(
                f"evidence at seq {source.get('seq')} was committed under a different "
                "regime; requalification evidence belongs to the candidate — §6.5"
            )
    append(vc, event_type=PROMOTED,
           body={"regime_digest": digest, "evidence_refs": refs},
           expected_head=read_head(vc.conn))
    return digest


def abandon_regime(vc: VerifiedConnection, digest: str, *, reason: str) -> str:
    """Candidate -> abandoned (§6.1). Abandoned regimes remain in the record."""
    path = _path_of(vc)
    state = regime_status(path).get(digest)
    if state is None:
        raise RegimeRefused(f"regime {digest[:19]} was never declared — §6.3")
    if state != CANDIDATE:
        raise RegimeRefused(
            f"regime {digest[:19]} is {state}; only a candidate may be abandoned — §6.3"
        )
    append(vc, event_type=ABANDONED,
           body={"regime_digest": digest, "reason": reason},
           expected_head=read_head(vc.conn))
    return digest


def _path_of(vc: VerifiedConnection) -> str:
    row = vc.conn.execute("PRAGMA database_list").fetchone()
    return row[2]
