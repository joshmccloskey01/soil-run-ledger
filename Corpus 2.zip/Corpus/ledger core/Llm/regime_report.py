"""
regime_report.py — the check you run.

    python3 regime_report.py ledger.db

Prints, in plain English: which rules are in force, which rules were ever in
force, which stretches of the record are comparable to each other, and what is
wrong with it. The point of this file is that the layer can be judged without
reading any of the other files.

Every number below is recomputed from the committed chain when you run it.
Nothing is read from a table that could have drifted.
"""
from __future__ import annotations

import sys

from genesis import verify_chain
from regime import (
    authoritative_regime,
    comparable_blocks,
    regime_object,
    regime_status,
    verify_regime,
)


def short(digest: str | None) -> str:
    return "none" if digest is None else digest.split(":")[-1][:12]


def label_of(path: str, digest: str) -> str:
    regime = regime_object(path, digest) or {}
    name = regime.get("regime_label")
    return f"{short(digest)}  ({name})" if name else short(digest)


def main(path: str) -> int:
    print(f"\nLEDGER: {path}")
    print("=" * 64)

    chain = verify_chain(path)
    print("\nCHAIN")
    if chain:
        print("  BROKEN. The record itself cannot be trusted:")
        for f in chain:
            print(f"    - {f}")
        print("\n  Stopping here. Nothing below is meaningful on a broken chain.")
        return 1
    print("  Intact. Every entry hashes to what it says it does, in order.")

    live = authoritative_regime(path)
    print("\nRULES IN FORCE NOW")
    if live is None:
        print("  None. No rule-set has been promoted, so no entry written now")
        print("  is comparable to any other.")
    else:
        print(f"  {label_of(path, live)}")
        regime = regime_object(path, live) or {}
        for k, v in regime.items():
            if k in ("supersedes", "regime_label"):
                continue
            print(f"    {k}: {v}")

    status = regime_status(path)
    print("\nEVERY RULE-SET THIS RECORD HAS NAMED")
    if not status:
        print("  None.")
    for digest, state in status.items():
        meaning = {
            "candidate": "proposed, holds no authority yet",
            "authoritative": "in force now",
            "superseded": "was in force; replaced by a later one",
            "abandoned": "proposed, then discarded; never in force",
        }[state]
        print(f"  {label_of(path, digest)}")
        print(f"    {state} — {meaning}")

    blocks = comparable_blocks(path)
    print("\nWHAT IS COMPARABLE TO WHAT")
    if not blocks:
        print("  Nothing recorded yet.")
    for b in blocks:
        seqs = b["seqs"]
        if len(seqs) == 1:
            span = f"entry {seqs[0]}"
        elif seqs == list(range(seqs[0], seqs[-1] + 1)):
            span = f"entries {seqs[0]}-{seqs[-1]}"
        else:
            span = "entries " + ", ".join(str(s) for s in seqs)
        if b["regime_digest"] is None:
            print(f"  {span}  ({b['count']}) — NO RULE-SET RECORDED.")
            print("    Comparable to nothing, including to each other.")
        else:
            print(f"  {span}  ({b['count']}) — under {label_of(path, b['regime_digest'])}")
    if len([b for b in blocks if b["regime_digest"]]) > 1:
        print("\n  These are separate blocks. Do not average, trend, or count across")
        print("  them. A question needing more entries than the longest block holds")
        print("  is unanswerable from this record — that is the answer, not a")
        print("  reason to merge them.")

    problems = verify_regime(path)
    print("\nPROBLEMS")
    if not problems:
        print("  None found.")
    for p in problems:
        print(f"  - {p}")

    print()
    return 1 if problems else 0


if __name__ == "__main__":
    if len(sys.argv) != 2:
        print(__doc__)
        sys.exit(2)
    sys.exit(main(sys.argv[1]))
