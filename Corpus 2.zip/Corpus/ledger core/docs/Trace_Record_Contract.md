# Phase 1 Observation Format — FROZEN BASELINE

**Version:** 1.0.0
**Status:** FROZEN
**Date frozen:** 2026-08-09
**Frozen before:** first live API execution
**Author of record:** Josh McCloskey

---

## 0. Status of this document

This is a **falsification target**, not a finished ontology.

It was designed entirely before any live model invocation. It has never met an
API. It is expected to be wrong somewhere specific, and the purpose of building
the plain ungoverned loop is to find out where.

**Amendment rule:** implementation discoveries are recorded as numbered
deviations in §9 against this baseline. They are **not** edited into the body of
this document. If the body changes, the version number changes and the prior
version is retained. Supersession, never revision.

The reason for the rule: if the spec drifts as the code is written, there is no
longer a fixed object that the implementation can be said to have falsified. You
arrive somewhere without knowing what broke.

---

## 1. The invariant

> **A PolicyDecision is a pure function of content-addressed inputs.**

Every other rule in this document exists to protect that statement.

Formally:

```
D = F(R, E, X)
```

- `R` — the exact regime bytes identified by `regime_digest`
- `E` — the exact referenced evidence objects
- `X` — explicitly recorded non-evidence inputs
- `D` — the resulting decision

If `X` is empty, the policy function is pure with respect to the trace.

### 1.1 Correction: recorded impurity is still impurity

Converting a wall-clock read, random value, environment lookup, or mutable
runtime state into an Observation does not make the originating event intrinsic
or timeless. It makes the dependency **explicit and replayable against the
historical execution**.

```
unrecorded impurity  ->  not reproducible
recorded impurity    ->  reproducible historical input
recorded impurity   !->  fact independent of execution
```

A new regime reusing a recorded timestamp answers:

> What would this regime decide given the inputs that actually existed at that
> historical point?

It does **not** answer:

> What timestamp or external condition would have existed had that alternate
> regime actually been running?

That second question is on the same side of the counterfactual boundary as
model outputs that were never produced.

### 1.2 Correction: counterfactual replay is prefix-valid

Decisions are not independently evaluable. If `D_i = F(R, E_i)` and any member
of `E_i` depends on a prior decision `D_j`, then `D_i` is counterfactually
evaluable only while the entire dependency path leading to it remains identical.

**The replayable object is the maximal common historical prefix.** See §7.

---

## 2. Four species

Phase 1 records four logically distinct kinds of object. They must not be
collapsed.

| Species | What it is |
|---|---|
| **ModelAct** | Record of one model invocation and its returned raw artifact, if any. |
| **Observation** | Deterministic facts discovered about existing evidence. |
| **DerivedArtifact** | Deterministically constructed interpretations of prior evidence. |
| **PolicyDecision** | A choice produced by applying the current regime to evidence and state. |

The governing separation:

```
evidence  !=  interpretation  !=  authority
```

Phase 1 needs the first two. Phase 2 is where the third becomes explicit.

Only **Observation** and **ModelAct** are invariant under replay.
**PolicyDecision** is regime-dependent by construction.

---

## 3. ModelAct

```
ModelAct
  turn             monotonically increasing invocation number
  invocation_kind  runtime-assigned: task | repair | (others as discovered)
  parent_turn?     the act this invocation responds to, if any
  raw_output?      exactly what the API returned, before any parsing
```

### 3.1 ModelAct is a hybrid record

**This is not a pure serialization of model output.** It is:

```
what the runtime asked  +  what the model returned
```

`invocation_kind` is runtime-assigned. The runtime decided to call this a
repair. That is context attached to the invocation record, not evidence
produced by the model. This is stated explicitly so that the purity argument
that moved `payload` out of ModelAct (see §5) does not later come back for
`invocation_kind` as though it were an oversight.

### 3.2 raw_output is nullable

Three materially different cases, none hidden:

```
raw_output = null
    invocation occurred, no model output obtained
    (timeout, API error, runtime exception)

raw_output != null, no ParsedAct
    response obtained, not interpretable under schema

raw_output != null, ParsedAct exists
    response obtained and successfully interpreted
```

No turn is ever reused. No invocation disappears. An invocation that returned
nothing is still an act the runtime took.

### 3.3 What is NOT on ModelAct

- **No `payload`.** The API returned bytes; the runtime produced structure by
  parsing them. Structure is a DerivedArtifact (§5).
- **No `parse_status`.** The parse is an operation the runtime performed, not
  something the model emitted. It is an Observation (§4).
- **No `act_type` asserting what the act is.** What the model claimed lives on
  the ParsedAct as `asserted_act_type` (§5).
- **No `valid`, `correct`, `authorized`, `true`, or any equivalent.** Those are
  exactly what a later gate may derive. Phase 1 records enough structure to
  discover where such distinctions become necessary; it does not pre-judge them.

---

## 4. Observation

Deterministic facts discovered about evidence that already exists.

```
Observation
  kind         parse_failure | parse_success | timeout | clock_read | ...
  target_turn  the ModelAct or object observed
  ...          kind-specific fields (schema id, error, value)
```

An Observation asserts what was found. It does not decide what to do about it.

### 4.1 Impure reads become Observations

Where a decision would otherwise depend on something outside the trace, the
preferred route is to make the read itself an Observation and reference it,
rather than stuffing the value into `external_inputs`:

```
    Observation
      kind: clock_read
      value: ...
```

Subject to §1.1: this makes the dependency visible and replayable. It does not
make it pure.

---

## 5. DerivedArtifact

Structured objects produced by deterministic interpretation of earlier evidence.

```
ParsedAct
  source_turn         the ModelAct whose raw_output was parsed
  payload             substantive structured content
  asserted_act_type?  what the model represented the content as
```

A failed parse produces **no** ParsedAct. The ModelAct remains complete.

### 5.1 asserted vs. runtime classification

`asserted_act_type` is what the model said it was doing. It may be wrong, or a
parser guess. It carries no authority.

How the runtime actually treated the act is recorded separately as
`runtime_classification`. Divergence between them is useful evidence, not
something the schema should erase:

```
asserted_act_type    = "final"
runtime_classification = "proposal"

asserted_act_type    = "tool_request"
runtime_classification = "invalid_tool_request"
```

**[OPEN — flagged, not resolved]** Whether `runtime_classification` is a
DerivedArtifact or a PolicyDecision depends on whether classification is a
deterministic function of payload structure alone or consults regime
parameters. Phase 1 exists partly to determine this. Record it wherever it
first lands and log the answer as a deviation.

A third distinction may eventually be needed — asserted type, syntactically
classified type, authorized semantic role. It is deliberately **not** in Phase 1.

---

## 6. PolicyDecision

```
PolicyDecision
  decision_id
  regime_digest    sha256 of canonicalized regime
  regime_label?    friendly name; participates in nothing
  evidence_refs[]  complete set of trace objects the policy function consulted
  external_inputs{} present only where the decision depended on something not
                    represented by the referenced objects
  outcome
  comment?         explanatory metadata, zero authority
```

### 6.1 Record inputs, not reasons

`reason: "repair_depth < D_max"` is prose. It tells a story about the
computation; it does not allow the computation to be reproduced. A human
comment may exist alongside, but only `evidence_refs` + `regime_digest` +
`external_inputs` participate in reconstruction.

### 6.2 Regimes are identified by content

```
regime_digest = H(canonicalize(regime))
```

A symbolic name can drift while the parameters underneath change. The digest
identifies the actual stored parameterization. Only the digest participates in
reconstruction. Same pattern as `canon1.py`: ids as a function of stored bytes.

### 6.3 Hidden dependencies are forbidden

A PolicyDecision MUST be a pure function of its referenced regime and
referenced trace evidence, unless every additional input affecting the result is
explicitly captured in `external_inputs` or referenced as another immutable
trace object.

Illegal if unrecorded:

- current wall clock
- process-local retry counter
- environment variable
- random generator state
- unordered iteration order
- current filesystem contents
- API availability state
- mutable configuration

`external_inputs` is an **escape hatch that exposes impurity**, not the normal
route. The preferred fix is to turn the input into evidence first (§4.1).

### 6.4 State transitions are PolicyDecisions

Transitioning to `TERMINAL_REPAIR_FAILURE` is not something observed in the
world. It is what the current regime decided should happen given the
observations. Likewise: accept, retry, repair, terminate, request tool, advance
loop.

---

## 7. Repair

### 7.1 Repair is a model act, not a parser operation

The repaired object must never masquerade as the original output. Both are
preserved. Otherwise the system can later report that the model returned valid
JSON when it did not.

```
turn 17  invocation_kind=task    parent_turn=null  raw_output=<malformed>
turn 18  invocation_kind=repair  parent_turn=17    raw_output=<repair output>
turn 19  invocation_kind=repair  parent_turn=18    raw_output=<malformed again>
```

### 7.2 Repair sees only the malformed string and the target schema

No task context. This makes repair a syntactic/structural transformation rather
than a second opportunity to reason about the task. It prevents:

```
original answer malformed
  -> repair model sees task
  -> repair model quietly changes the substantive answer
  -> parser accepts the new answer
```

Repair may infer what malformed text meant strongly enough to fit the schema.
It may not retrieve missing task information or independently derive a better
solution. **If meaning is missing from the malformed string, repair fails
rather than inventing it.**

### 7.3 Depth is derived, never stored

From the parent chain: `d(17)=0`, `d(18)=1`, `d(19)=2`.

Storing `repair_depth` duplicates state that can disagree with the chain. The
chain is the evidence; depth is a derived property. The cap `D_max` is policy;
the sequence of attempts is history.

### 7.4 Failed repair still produces its ModelAct

```
turn 18: repair returned malformed output
Observation: parse_failure, target 18
PolicyDecision: retry_repair
turn 19: repair returned malformed output
Observation: parse_failure, target 19
PolicyDecision: terminate, outcome TERMINAL_REPAIR_FAILURE
```

Nothing disappears merely because it was unusable.

---

## 8. Replay boundary

### 8.1 Three different questions

| Question | Grounded in recorded evidence? |
|---|---|
| **Historical derivation** — given the regime actually governing this trace, what did these recorded events mean? | Yes |
| **Counterfactual replay** — how far would another regime reproduce this same historical path? | Yes |
| **Simulation** — what might happen after the alternate regime chooses another path? | **No** |

Simulation begins exactly where counterfactual replay ends.

### 8.2 The prefix rule

If the first divergence is at `D_k`:

```
D_0' = D_0, ..., D_{k-1}' = D_{k-1}
D_k' != D_k
```

then the valid counterfactual replay is:

```
T[0:k]  plus the newly computed D_k'
```

The historical suffix `T[k+1:n]` still exists as fact about the actual
execution. It is **not** part of the alternate execution and cannot be
recursively reused as though it were.

This applies to everything downstream whose existence or inputs depend on the
divergent decision: retry counters, parent chains, state transitions, later
observations, tool calls, subsequent model invocations.

### 8.3 Worked example

History:

```
A0  task invocation
A1  malformed model output
O1  parse failure
D1  retry repair
A2  repair invocation
A3  valid repair
O2  parse success
D2  accept
```

Apply a regime with repair limit zero. Everything through `O1` is reusable
historical evidence. The new policy computes `D1' = terminate` instead of
`D1 = retry repair`. **Replay stops there.**

`A2`, `A3`, `O2`, `D2` remain facts about the historical branch. They cannot be
dragged across the divergence and treated as belonging to the alternate branch.

```
historical suffix still exists
  !=
counterfactual suffix is admissible
```

### 8.4 What counterfactual replay delivers

It identifies **the first counterfactual divergence**. It does not reconstruct
the counterfactual future after that point. Any continuation is simulation and
must be represented as such.

This is the same boundary `regime.py` already draws: `derive_historical`
reconstructs meaning under the old rules; it does not report what the old
system would have done under new ones.

---

## 9. Deviation log

Implementation discoveries are recorded here. The body above is not edited.

Each entry records: what the spec said, what the implementation found, and
whether the deviation is a spec error, an unnecessary distinction, a missing
field, or a boundary error.

| # | Date | Section | Spec said | Found | Class |
|---|---|---|---|---|---|
| — | — | — | — | *(no entries — frozen before first execution)* | — |

---

## 10. Principle summary

Derived from the §1 invariant, in dependency order:

```
PolicyDecision = F(content-addressed inputs)
  therefore inputs must be recorded
  therefore runtime observation must be separated from policy
  therefore regimes must be identified by bytes rather than names
  therefore hidden inputs are forbidden
  therefore repair history cannot be erased
  therefore decisions can be reconstructed
  therefore counterfactual replay ends at the first causal divergence
```

These are consequences, not seven independent rules.

---

## 11. Scope

This is the provisional Phase 1 observation format. It is not the final system
ontology and it grants no authority to anything.

Phase 1 exists partly to falsify this schema: to expose unnecessary
distinctions, hidden dependencies, missing fields, and boundary errors before
Phase 2 gives any of them authority.

The plain loop is now allowed to break it.
