# Irreversible Ledger Contract v0.1

**Status:** FROZEN at first committed event. Amendable only by the procedure in §10.
**Scope:** the evidence contract. Not an architecture, not an ontology, not a governor.

**Admission rule for this document.** A clause belongs here only if both hold:

- **(R1) Irrecoverability.** If it is absent from event zero, the evidence it carries cannot be reconstructed later from the record itself.
- **(R2) Falsifiability.** The clause is falsifiable by the verifier's invariant checks, by the compatibility suite (§11), or by an adversarial attack (§8). The attacks in §8.1 target the principal failure modes; they are **not** the complete normative test inventory. Calling every schema check an "attack" would drain the word of its meaning.

A clause satisfying only R1 is a wish. A clause satisfying only R2 belongs in the amendable layer. Anything failing both is out.

**The one exception, stated rather than buried.** A finite, enumerated set of clauses satisfies R1 and fails R2, because it asserts correspondence to the world rather than a property of the record. These are listed in §8.2, may not be added to without amendment, and MUST be labelled *asserted, not proven* wherever they appear. Without this exception written down, the document would violate its own admission rule while handling the underlying epistemics honestly — and a hostile reader would be right to say so.

**Where the four additions live.** Canonical numeric policy → §1. Time capture → Contract 1 (§2.3). Durability configuration → Contract 2 (§3.4). Observability availability → Contract 3 (§4.3).

---

## §0 Conventions

MUST / MUST NOT / MAY carry RFC 2119 force.

| Term | Meaning here |
| --- | --- |
| **event** | An immutable record admitted to authoritative history. |
| **head** | The single mutable pointer naming the most recently committed event. |
| **committed** | Reachable from the current head by parent links. Nothing else is history. |
| **inert object** | A durable but uncommitted event body. Carries no authority. |
| **verifier** | A process that reads the record and recomputes every derived value in this document. |

**Ordering.** `seq` is constitutive; wall-clock time is estimative. Where they disagree, `seq` governs, always, without exception (§2.3.4).

---

## §1 Canonical representation — `canon/1`

Two implementations are compatible only if they serialize identically. This section is the whole of that guarantee.

**§1.1** `canon/1` is **RFC 8785 (JSON Canonicalization Scheme) with floating-point numbers prohibited**. RFC 8785's most fragile requirement is its number-serialization rule; §1.3 removes the need for it.

**§1.2** Canonical bytes are UTF-8. Object keys sorted per RFC 8785. No insignificant whitespace.

**§1.3 Numeric policy.** In any field that enters a hash:

- **Integers** MUST be JSON numbers with no fractional part and no exponent, in range −2⁶³ … 2⁶³−1.
- **Fixed-scale decimals** MUST be JSON *strings* matching `^-?(0|[1-9][0-9]*)(\.[0-9]+)?$`. Trailing zeros are significant and MUST NOT be normalized away — the scale is part of the value.
- **Rationals** MUST be objects `{"n": <integer>, "d": <integer>}` with `d > 0` and `gcd(n,d) = 1`.
- **IEEE-754 binary floats MUST NOT appear.** A JSON number containing `.`, `e`, or `E` in a hashed field renders the event inadmissible.

**§1.4** Field *types* are fixed by `schema_version`. `canon/1` constrains encoding only, never interpretation.

**§1.5** `canon_version` is recorded in every event (§2.1). A new canonicalizer MUST take a new version string and MUST NOT be applied retroactively.

**§1.6** `predicate_lang_version` (§4.3.1) is versioned on identical terms and for the identical reason: a predicate whose semantics drift makes every historical observability boundary unrecomputable. New semantics take a new version string; evaluation of an old event MUST use the version that event carries.

> **Why frozen (R1).** One double in one hashed field makes every historical hash platform-dependent, and no later fix can restore verifiability of events already written. This is the single most irrecoverable clause in the document.

---

## §2 Contract 1 — Event identity and ancestry

**§2.1 Envelope.** Every event MUST carry exactly these envelope fields:

| Field | Type | Note |
| --- | --- | --- |
| `event_id` | string | `sha256:<64 hex>` — derived, §2.2 |
| `parent_id` | string \| null | null only for genesis |
| `seq` | integer | genesis = 0; each child = parent + 1; no gaps |
| `fencing_token` | integer | writer lease in force at commit |
| `schema_version` | string | governs field types |
| `canon_version` | string | `canon/1` |
| `hash_alg` | string | `sha256` |
| `event_type` | string | |
| `body` | object | type-specific payload |
| `wall_time_utc` | string | §2.3 |
| `utc_offset_minutes` | integer | §2.3 |
| `clock_epoch_id` | string | §2.3 |
| `monotonic_ticks` | integer | §2.3 |

**§2.2 Identity derivation.** `event_id` = `"sha256:" + hex(SHA-256(canon/1(event minus event_id)))`.

Because `parent_id` and `seq` are inside the hashed body, ancestry is bound into identity. An implementation that computes a different `event_id` for the same admitted content is non-compatible, and §11 detects it.

**§2.3 Time capture.**

- **§2.3.1** `wall_time_utc` MUST be RFC 3339 with `Z` and fixed millisecond precision (`YYYY-MM-DDTHH:MM:SS.sssZ`). Estimative.
- **§2.3.2** `utc_offset_minutes` MUST be the signed local offset **in force at capture**. Without it, local-day assignment is unrecoverable once the capturing device has moved between zones.
- **§2.3.3** `clock_epoch_id` MUST be a fresh opaque identifier per boot or process epoch. `monotonic_ticks` MUST be integer nanoseconds within that epoch. Monotonic values MUST NOT be compared across differing `clock_epoch_id`.
- **§2.3.4** Ordering is by `seq`. Wall-clock time MUST NOT be used to order committed events, including when it appears to contradict `seq`.
- **§2.3.5 Local-day rule.** Local day = the date component of `wall_time_utc + utc_offset_minutes`. An interval-shaped record belongs to the local day of its **start**. Frozen because an interval crossing local midnight is otherwise assigned differently by different readers.

**§2.4 Genesis.** The genesis event MUST record: this contract's version, `canon_version`, `predicate_lang_version`, `hash_alg`, and the storage-safety configuration of §3.4. A reader of old history MUST be able to determine, from the record alone, which regime produced it — current configuration is not evidence of historical write configuration. Bootstrapping order is fixed by §3.4.4.

> **Why frozen (R1).** Identity, ancestry, order and capture-time offset are unreconstructible after the fact. **Test (R2):** attacks 1, 2, 6; interop check §11.

---

## §3 Contract 2 — Atomic conditional commit

**§3.1 Two states only.** An event body MAY be written as an inert content-addressed object. Durability alone confers **no** constitutive status. Authority begins at, and only at, a successful conditional head transition:

```
CAS(head.event_id = expected_parent, head.seq = expected_seq,
    head.fencing_token = token  →  child)
```

**§3.2** The head transition and the durability of the object it names MUST occur in one atomic transaction. Reference realization:

```sql
BEGIN IMMEDIATE;
INSERT INTO events (event_id, parent_id, seq, fencing_token, body_canon) VALUES (...);
UPDATE ledger_head
   SET event_id = :new_id, seq = :new_seq, fencing_token = :token
 WHERE event_id = :expected_parent
   AND seq = :expected_seq
   AND fencing_token = :token;
-- REQUIRE changes() = 1, else ROLLBACK
COMMIT;
```

**§3.3 Fencing is a storage property.** Recording a token inside an event does nothing. The **store** MUST reject stale tokens by refusing the conditional update. A store that cannot perform a conditional update on the head is non-compliant; fencing implemented above the store is decorative.

**§3.4 Storage-safety configuration.**

- **§3.4.1** The `storage_safety_configuration` MUST be pinned in the frozen contract and recorded in genesis (§2.4). For the SQLite realization it has two parts, which are not the same kind of setting and MUST NOT be described as one:
  - *durability:* `journal_mode = WAL`, `synchronous = FULL`
  - *integrity:* `foreign_keys = ON`
- **§3.4.2** The process MUST read live settings at startup and **refuse to run** if they differ from the frozen values. Not warn — refuse.
- **§3.4.3** Stated plainly, because the distinction matters to anyone reading this record later: under `synchronous = NORMAL` in WAL mode a committed transaction can be lost to OS or power failure, and a process-kill loop passes anyway. **Attack 1 cannot reach that failure.** What §3.4.2 achieves is narrower than it may appear — it converts *reliance on an untested environmental assumption* into a *mechanically checkable configuration precondition*. The durability outcome remains unproven. What is proven is that the implementation refused to operate outside the asserted regime. Nothing here tests sudden electrical loss, volatile drive-cache loss, dishonest controllers, filesystem failure, or reordering below the process boundary. See §8.2.
- **§3.4.4 Bootstrapping order.** For creation of a new ledger, the §3.4.2 check MUST complete **before the genesis transaction begins**. Otherwise genesis could truthfully record `synchronous = FULL` while having itself been committed under `NORMAL`.

**§3.5 Recovery.** After any failure, the new event MUST be either reachable from the committed head and fully valid, or absent from authoritative history. No third state. Unreachable inert objects MAY be garbage-collected.

**§3.6 Halt, never repair.** On detected inconsistency the writer MUST halt. Automatic repair is prohibited at v0.1.

> **Why frozen (R1).** Whether an event was ever authoritative cannot be recovered later from a record that permits an ambiguous intermediate state. **Test (R2):** attacks 1, 2, 3.

---

## §4 Contract 3 — Complete prediction admission

**§4.1 Admission rule.** No scored proposition, no ledger entry. A prediction enters history only by an `ADMIT_PREDICTION` event carrying **all** of:

| Field | Note |
| --- | --- |
| `prediction_id` | |
| `prediction_class_id` | content-derived; MUST resolve to a committed definition, §4.2 |
| `proposition` | the scored statement |
| `scoring_rule` | |
| `observation_contract` | what counts as observing the outcome |
| `observability_rule` | §4.3 |
| `deadline_policy` | §4.4 |
| `selection_probability` | propensity at authorization; enables inverse-propensity weighting |
| `intervention_flag` | whether the system acted on the prediction |

**§4.2 Class identity is content-derived *and* bound into history.**

- **§4.2.1** `prediction_class_id` = `sha256:` over `canon/1` of the class definition.
- **§4.2.2** A class definition MUST be committed as a `DEFINE_PREDICTION_CLASS` event carrying both `prediction_class_id` and the full canonical `class_definition`. The verifier MUST recompute the ID from the committed definition; **mismatch renders the definition event inadmissible.**
- **§4.2.3** `ADMIT_PREDICTION` MUST cite a `prediction_class_id` for which some `DEFINE_PREDICTION_CLASS` event is already committed at a lower `seq`. Duplicate definition events with byte-identical content are harmless and idempotent.
- **§4.2.4** Consequence: renaming or redefining mints a new ID by construction, and — because the definition itself is in the record — the verifier can *prove* it. Without §4.2.2 the record would hold only an ID pointing at a mutable external registry, the registry could be edited without touching any event, and the verifier would have nothing to recompute. Content-addressing converts immutability from policy into identity **only once the addressed content is retained**; the earlier claim that in-place editing is "arithmetically impossible" outran the storage binding until this clause existed.

**§4.3 Observability.**

- **§4.3.1** `observability_rule` is frozen at admission as exactly one of:
  - `{"kind": "SEQ_REACHED", "seq": N}`
  - `{"kind": "EVENT_WITNESSED", "predicate_lang_version": "...", "predicate_id": "sha256:...", "predicate": {...}, "scan_from_seq": N}`

  For `EVENT_WITNESSED`, the predicate MUST be expressed in a **frozen deterministic predicate language** identified by `predicate_lang_version` (§1.6), and `predicate_id` MUST be the `sha256:` of its `canon/1` form. Evaluation MUST depend **only** on canonical committed event content — never on wall-clock time, process state, external lookup, or evaluation order. "Mechanically evaluable" is not a sufficient standard: two verifiers can honestly evaluate a loosely-specified predicate differently and disagree about the earliest witness, which would reintroduce discretion as ambiguity.

  `scan_from_seq` MUST be present and frozen at admission. An explicit origin is preferred over a prospective-only rule because it keeps retrospective propositions expressible — a prediction may legitimately concern an already-existing but unknown fact. What it MUST NOT do is move afterwards.
- **§4.3.2** An `OBSERVABILITY_AVAILABLE` event MUST cite `prediction_id`, the `observability_rule` it satisfies, and `witness_event_id` — the exact committed event that satisfied the precondition. A bare declaration is inadmissible.
- **§4.3.3** The verifier MUST independently re-evaluate the predicate against the committed record. If the cited witness does not satisfy it, the availability event is inadmissible and MUST be refused at commit.
- **§4.3.4 Anti-withholding.** `outcome_observable_from_seq` is **derived, never declared**:
  - `SEQ_REACHED` → the frozen `N`.
  - `EVENT_WITNESSED` → `min { e.seq : e is committed ∧ e.seq ≥ scan_from_seq ∧ P(e) }`, where `P` is the frozen predicate evaluated under its frozen `predicate_lang_version`. If the set is empty the outcome is not yet observable.

  The availability event is *evidence that someone noticed*, not the authority for when. Late filing, or withholding it past one's own invalidation, cannot move the boundary — the earliest witness governs regardless of when it was cited, or whether it was cited at all. This is what stops the deleted attestation from reappearing one level up.

- **§4.3.5 No self-witnessing.** An observability predicate MUST NOT range over `OBSERVABILITY_AVAILABLE` events. This is stronger than forbidding an availability event from satisfying the predicate it cites, and deliberately so: the narrow rule still admits cross-prediction fixed points, where A's availability witnesses B's and B's witnesses A's. A prediction whose observability genuinely depends on another observation should name the **underlying** event, not the detection of it. The cost is that one prediction's observability cannot be defined in terms of another's detection; at v0.1 that is a capability worth losing.

**§4.4 Deadline crossing is constitutive.** A `DEADLINE_CROSSED` event MUST be committed, carrying `prediction_id`, `deadline_policy_version`, observed wall time, clock source and uncertainty, and its own `seq`. Expiry MUST NOT be re-inferred at read time. A later NTP correction MAY produce a `CLOCK_ANOMALY` event; it MUST NOT erase the earlier transition. Clock time estimates when the boundary was crossed; the committed event establishes that the system acted as though it had been.

> **Why frozen (R1).** A prediction admitted without its scoring rule, propensity, or observability rule is permanently unscoreable — the counterfactual is gone. **Test (R2):** attacks 4, 5.

---

## §5 Contract 4 — Terminal accounting

**§5.1** Every admitted prediction MUST reach exactly one committed terminal state, drawn from this complete set:

`RESOLVED_TRUE` · `RESOLVED_FALSE` · `CENSORED` · `EXPIRED_UNOBSERVED` · `PRE_OUTCOME_INVALIDATED` · `POST_OUTCOME_INVALIDATED`

**§5.2 No disappearance.** Every admitted prediction MUST remain countable for the life of the record. A prediction with no terminal event is OPEN and MUST be reported as such; it MUST NOT be dropped from any denominator.

**§5.3 Invalidation carries no classification.** An invalidation event contains only `prediction_id`, `reason_code`, `invalidated_at_seq`, and supporting event references. Classification is **computed**:

```
PRE_OUTCOME_INVALIDATED   iff invalidated_at_seq < outcome_observable_from_seq
POST_OUTCOME_INVALIDATED  otherwise
```

with `outcome_observable_from_seq` derived per §4.3.4. No attestation field. No discretionary flag. No opportunity for an invalidator to classify its own conduct.

**§5.4 Reporting.** Any calibration figure computed from this record MUST be published beside its censoring rate and its open count. A reliability number without them is not interpretable.

> **Why frozen (R1).** A terminal taxonomy with a missing route silently reclassifies events into the wrong bucket, and the original distinction is unrecoverable. **Test (R2):** attack 5.

---

## §6 Contract 5 — Amendment without rewrite

**§6.1** No committed event is ever edited or deleted.

**§6.2** Definitions are superseded, never revised. A new meaning mints a new ID (§4.2 makes this mechanical for prediction classes).

**§6.3** An `AMENDMENT` event MUST cite:

- the superseded ID and the superseding ID;
- the **observations or failures that forced it** — event references, not prose;
- whether the change alters a code path or is language-only.

**§6.4 Amendment telemetry.** The record MUST support counting, without reconstruction: amendment rate; anomalies that produced **no** amendment; code-path versus language-only changes; repeated amendments to the same distinction.

> An unamended contract may be unfalsifiable rather than mature. §6.4 exists so that distinction is visible in the data rather than argued.

**§6.5 Earned-distinction rule.** A distinction becomes a machine-level class only if it changes validation, authorization, storage, recovery, or response. A distinction that changes only vocabulary stays in the glossary.

> **Why frozen (R1).** What forced a change is unrecoverable once memory of it fades. **Test (R2):** attack 4.

---

## §7 Derived values are cache, never ledger

Any value computed from retained inputs MUST be stored as `input_event_ids` + `function_id@version`, with the output marked disposable and reproducible.

**A non-deterministic output is not derived.** A model emission is a **constitutive event** — "planner emitted X at seq N" — because it cannot be recomputed. Replayability is the authority boundary, and it is where the two classes divide.

**§7.1 Reconstruction completeness.** Every claim this record supports MUST be reconstructible along `head → parent chain → canonical events`. No other path is authoritative.

**§7.2 Tables are projections.** The prediction table, and every table other than `events` and `ledger_head`, is a disposable cache. The verifier MUST rebuild its state from the event chain and genesis alone, then **compare** against the projection — never read the projection as input. Any projection MUST be deletable and rebuildable without changing a single claim.

> **Why frozen (R1).** A terminal state written only to a projection is a silent §5.1 violation, and which state it was, at which `seq`, is unrecoverable once that projection is rebuilt or lost. Two sources of truth do not announce themselves; they are discovered later as a disagreement with no adjudicator. **Test (R2):** attack 7.

---

## §8 Test inventory

**§8.0 Three layers, not one.** Every normative frozen clause MUST be falsifiable by one of:

| Layer | Covers | Examples |
| --- | --- | --- |
| **Verifier invariants** | Recomputation and schema conformance on every read | numeric grammar §1.3; RFC 3339 precision §2.3.1; `event_id` recomputation §2.2; class-ID recomputation §4.2.2; observability boundary §4.3.4; terminal classification §5.3; derived-value reproducibility §7 |
| **Compatibility suite (§11)** | Cross-implementation agreement | canonical bytes, identical `event_id`, identical predicate evaluation, identical terminal classification |
| **Adversarial attacks (§8.1)** | The principal failure modes | commit atomicity, concurrency, fencing, class mutation, terminal accounting, clock epochs, projection drift |

The attacks are not the complete inventory, and the earlier draft was wrong to imply they were.

**§8.1 The executable attacks.** Every attack MUST be code that fails loudly, run in the same gate as the verifier.

| # | Attack | Binds | Acceptance |
| --- | --- | --- | --- |
| **A1** | Kill the process repeatedly at every persistence boundary, including between write and fsync. | §3.1, §3.5 | Recovery reveals old head or new valid head. Never an intermediate. **Plus:** startup assertion of §3.4.1 must fail the run when pragmas are altered — this is the clause A1 cannot otherwise reach. |
| **A2** | Two writers start from the same expected parent. | §3.1, §3.3 | Exactly one conditional update succeeds. |
| **A3** | Write using a stale fencing token. | §3.3 | Fails **at the storage boundary**, not in application code. |
| **A4** | Mutate a prediction-class definition in place. | §4.2, §6.2 | Yields a different `prediction_class_id`. In-place edit is unrepresentable. |
| **A5** | Admit predictions and force every terminal route, including clock reversal and post-outcome invalidation. | §4.4, §5.1–§5.3 | Every prediction countable; every classification recomputed from admission-time facts and event order; **withholding an availability event does not change the computed class.** |
| **A6** | Restart the process, then compare monotonic values. | §2.3.3 | Cross-epoch monotonic comparison is refused. Ordering falls back to `seq`. |
| **A7** | Drop every table except `events` and `ledger_head`, rebuild from the chain. | §7.1, §7.2 | Every reconstructed prediction, terminal state and classification is identical. Any field that does not survive the rebuild was never in the record. |

The acceptance condition is attackable, not asserted. If an attack cannot fail, it is not testing anything.

**§8.2 Asserted, not proven.** These clauses assert correspondence to the world, not a property of the record. No verifier, compatibility suite, or attack can reach them, and no document, report, or dashboard derived from this record may describe them as proven:

| Clause | Asserted | Best available mitigation |
| --- | --- | --- |
| §3.4.1 durability | Committed transactions survive power loss | Pinned regime + startup refusal (§3.4.2); genesis declaration (§2.4) |
| §2.3.2 | `utc_offset_minutes` is the offset actually in force at capture | Captured from the OS at capture time; a wrong offset is internally consistent and undetectable |
| §4.1 `selection_probability` | The logged propensity is the true authorization probability | Randomized holdout; unrecoverable if the logged value was never the real one |

Listing them is the point. A contract that quietly mixed proven and asserted claims would be exactly the failure it was written to prevent. This table is the closed exception permitted by the admission rule; extending it requires an amendment under §10.

---

## §9 Explicitly NOT frozen

Named so the boundary is legible from outside, and so nothing here acquires frozen status by proximity:

Governor logic · thresholds · scientific ontology · domain vocabulary · calibration maps and dashboards · UI · storage engine · indexing · retention and GC policy · distributed consensus · multi-writer coordination · fork *adjudication* (fork *formation* is prevented at v0.1 by single writer + CAS; parent-plus-child already lets the record represent a fork if one ever forms) · repair automation.

All of the above evolve under §6.

---

## §10 Amending this document

A clause here is amended only by: a committed `AMENDMENT` event citing the failure that forced it; a new contract version; and a demonstration that the old record remains interpretable under the new version. Retroactive reinterpretation of committed events is prohibited.

---

## §11 Compatibility criterion

Two independent implementations are compatible **iff**, given the same admitted inputs, they produce **byte-identical `canon/1` bodies and identical `event_id` values** for every event.

This is a runnable check, not a claim: exchange a record, then recompute every `event_id` (§2.2), every `prediction_class_id` from its committed definition (§4.2.2), every `outcome_observable_from_seq` by scan (§4.3.4), and every terminal classification (§5.3). Any divergence is a defect in one of the two. §1 is where most will be; §4.3.1 is where the subtle ones will be.

---

## §12 Exit condition

Proceed to implementation when, and only when:

> Every field in the freeze exists because future evidence would otherwise be unrecoverable, and every claim in the freeze has a test capable of falsifying it.

Not when the document feels complete.

**Next artifact:** the dumb SQLite version. One head row, one writer token, one event table, one prediction *projection*, one terminal-event path, one amendment event, one verifier, seven attacks. No governor, no ontology, no dashboard, no model layer, no scheduler, no API server, no abstract storage interface.

Build order:

1. canonical serializer and hash test vectors — **vectors sourced externally, written before the serializer exists**;
2. schema plus startup refusal (§3.4.2);
3. genesis (§3.4.4 ordering);
4. conditional append (§3.1);
5. verifier reconstruction (§7.1);
6. prediction admission and terminal transitions;
7. amendment path;
8. attacks A1–A7;
9. clean-database rebuild and hash comparison.

Step 1's ordering is not stylistic. Vectors generated by the serializer they are meant to test agree with it by construction, including when both are wrong — the check and the thing checked share a failure mode. Take them from RFC 8785's published suite, or hand-compute them, before any code exists to disagree with.

The contract is finished when the code has no freedom left except to preserve the evidence or halt.

Do not build tomorrow's distributed system before today's single writer has earned one trustworthy event.
