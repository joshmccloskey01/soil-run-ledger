# Frozen Sequence — 2026-08-14

Status: DECISION FROZEN. Not yet executed. No observational support.

---

## The sequence

1. **Knee clears** (criterion below — currently undefined, blocking)
2. **Establish probe + baseline step length at 215 cadence**
3. **Force capacity block** (locomotion minimal)
4. **215 cadence phase** — transfer test

The baseline at step 2 is unrecoverable if skipped. Nothing after it means
anything without it.

---

## Why this order

Under the reframe of 2026-08-14, the engine is force per contact, not
sprinting. Step length at fixed cadence is the readout, not the lever.

If the gym progresses during the 215 phase, step-length movement cannot be
attributed. Sequencing solves this without holding the gym flat: force
capacity is already at plateau when the 215 phase begins, so movement during
that phase is attributable to the phase.

The open question the 215 phase answers:

> Does step length move on its own from running at 215, or only when force
> capacity moves?

- If it drifts up from running alone → coordination, and it is cheap.
- If it does not move without gym work → running holds the pattern, the gym
  does the work. Confirms the reframe.

Either answer is useful.

---

## Conditions for readability

- Cadence must actually be 215, not approximately. Metronome.
- Step length AND cadence logged separately every bout. Not inferred at the end.
- Force capacity block must reach plateau before the 215 phase starts, or the
  attribution argument fails.

---

## Strength base (decided same session)

Three exercises: **Bench, Deadlift, Pistol.**

- Push / hinge / single-leg. No redundancy.
- One axial load only (deadlift). Pistol gets knee and single-leg work without
  stacking a second spinal compression.
- Pistol is self-limiting on capacity — cannot be muscled through. NOT
  self-limiting on cost.
- Pavel's Power to the People minimum, with the third slot spent on the
  demand the event actually makes (400 single-leg contacts).

**Spacing — REVISED SAME SESSION.** The three movements were originally chosen
under a daily-recurrence assumption. That assumption was dropped later the
same night. See "Spacing revision" below. Current: **upper/lower alternating**
— bench upper; deadlift and pistol lower. This is a starting frequency to be
read off the response, NOT a structure to defend. If the knee wants more space
than every second day, it gets more space.

**Progression rule:** start with three, add one at a time. Trigger to add =
response flattening on the existing set AND spare capacity in the day. Both
conditions required. Adding one at a time keeps each addition attributable.

**Gap:** no horizontal pull. First candidate when adding a fourth (rings).

**Daily layer, does not split:** fixed set of 5–6 yoga positions (hips, ankles,
thoracic, shoulders). Same ones daily. Selection by what is soothing — which
self-selects for what is tight, NOT for what is weak. End-range control is the
gap that rule leaves; loaded work covers it.

---

## Locomotion policy after clearance

Running is a structural input at low dose, not the organizing principle.

Working design (NOT frozen — starting hypothesis only):
~30 s/day of quality running, split into two bouts separated by ~8 hours.
Distributed beats massed. The 4–8 h figure is a saturation limit, not a
spacing authorization; a second bout later in the day is not wasted the way
another rep in the same bout would be.

Two honest constraints:

1. **30 s/day is not small on the slow ledger.** At 215 cadence that is ~100
   contacts daily, every day. Brief duration does not make it light. The
   number is a hypothesis to be read off the response, not a target to defend.
2. **Warm-up dominates.** 15 s of quality running needs a warm-up that dwarfs
   it. Twice daily = two warm-ups. This is where the plan fails in practice —
   on time cost, not on dose.

**Stated minimum required.** "Enough to keep it up" drifts to zero because it
never has a bad day. The floor can be small. It must be specified.

**Impact debt is delayed, not discharged.** Bone tolerance for foot strikes
does not come from the gym. Whenever the ramp resumes, it starts near where
you are now, not where you were.

---

## Blocking items (unchanged, still unwritten)

1. **Knee-clear criterion** — what observation says baseline is reached.
   Everything waits on this. See rehab criterion structure below.
2. **Strength document** — partially resolved: three exercises is enough to
   start. Document gets written by the process, not before it.
3. **Measurement protocol** — frozen before any data exists.
4. **Typical error** — from a consecutive-day test-retest block.

---

## Background load (new this session)

Habitual jumping — off tractors, equipment, heights — roughly 10x/day,
unlogged, ungoverned. "No running" never covered it.

This is a boundary error, not a discipline failure. Rehab mode means no
high-impact contacts, prescribed or not.

Fix is substitution, not suppression: "climb down facing it, three points of
contact" becomes automatic with reps. "Don't jump" requires recall in the
half-second when you are not thinking.

Three weeks in. Thirty-year default. Expect months.

Candidate ledger category: background load. Unrecorded exposure makes the
deliberate dose look cleaner than it is.

---

## Origin case — the exposure that produced the framework

**Corrected timeline.** Running began **February 2026**, not 2025. Training age
at time of writing: **six months.** (The 2025 half marathon was run with no
training and does not count as a training history.)

The sequence:

- Week 1: **0 → 40 km**, from no running base at all.
- Week 3: **60 km**.
- Weeks 4–9: back to **40 km**, held ~6 weeks.
- Week 8: fast running added.
- Week 10: sprinting.

**Why this is the mechanism, not just the history.** There is no ramp here —
it is a step function onto tissue with no loading history. Bone stress injury
is accumulated microdamage outrunning remodelling, and a remodelling cycle
takes months. Week 3 was already past what the tibia could resolve; the six
weeks at 40 km did not let it catch up, it held the rate steady above the
resolution rate. Then the load did not step down, it **changed type** — each
addition higher force per contact than the last, onto an account already
behind.

**Why sensation was useless.** Muscle adapted to 40 km within weeks and stopped
complaining. The slow tissue never got the chance and had no channel to report
through.

This is the whole framework in one paragraph. Every component — the slow
ledger, floor and ceiling, the fast subsystem as unreliable reporter,
adaptation as normalization rather than accumulation — is a direct answer to
something in this ten-week sequence.

> Running was taken up to learn that the fast subsystem is not the one to
> listen to. That lesson does not arrive from reading; the fast subsystem is
> convincing precisely because it is accurate about itself.

**Note on density.** Six months, not eighteen, makes the 750 km a much denser
exposure than a longer window would imply. Low accumulated wear overall; the
current knee problem is early-career overload, not years of it.

---

## Current numbers (starting figures, NOT protocol-established)

| Condition | Cadence | Step length | Speed |
|---|---|---|---|
| 400 m in 75 s | 183 | 1.75 m | 5.33 m/s |
| Current at 215 | 215 | ~1.90 m | 6.81 m/s |
| Sprint (~2:09/km) | 235 | ~1.98 m | 7.75 m/s |
| **Target** | **215** | **~2.32 m** | **~8.3 m/s** |

**Step length rises with cadence** (1.75 → 1.90 → 1.98). So 215 is not a
compromise between jog and sprint — it sits inside a range already produced.
The open question is what step length comes out at 215 at *effort*.

**The gap: 0.42 m — a 22% increase in step length at fixed cadence, i.e.
roughly 22% more vertical impulse per contact, held for 800 m.** Simple to
state is not the same as small. ~8.3 m/s is near world-record *cruise* pace
once acceleration cost is included.

**Flag on 183.** Cadence during the 400 was well below both other figures.
Either turnover is not held under load, or that 75 s was not maximal. Which one
matters — it says whether the 215 target is limited by capacity or by pacing.
Unresolved.

**Two load-bearing assumptions, both interrogated by the frozen sequence:**

1. That 215 is sustainable. Checkable in about a week once the knee clears —
   metronome, hold it, see.
2. That 0.42 m is reachable. Not checkable up front. What *is* checkable is
   the **rate**: does step length at fixed cadence move at all when force
   capacity moves. If it does not move, the model needs revisiting.

---

## Rehab criterion structure (source material)

George, Sheerin & Reid 2024, *Sports Medicine* — scoping review, return to
running after tibial bone stress injury. DOI 10.1007/s40279-024-02051-y

Four criteria themes before running:

1. **Symptom resolution.** All studies: pain-free walking and ADLs first,
   2–28 days. ~30% attached a walking test (1 mile to 45 min) — i.e. a
   defined sub-threshold loading probe, not "feels fine."
2. **Bony tenderness resolved.** 40% of studies; three specified ≥1 week. But
   an RCT and a case series found persistent local tenderness did not affect
   progression. A criterion that mostly failed when tested.
3. **Strength, functional and loading tests.** Only 33% mentioned. Single-leg
   hop in 8% — yet the one RCT testing it found it the most sensitive
   predictor of return to pain-free activity. Harmon: 75–80% strength on
   injured vs uninjured side. Least-used criterion, best evidence.
4. **Contributing factors** — all studies. Cause must be identified and
   addressed or the loop repeats.

Process: walk-run intervals; 42% start alternate days, held 2–4 weeks;
distance progressed before speed; symptoms at the injury site → rest until
resolved, resume at a lower level (the regression branch).

**Evidence status:** 39 of 50 studies were reviews or clinical commentaries.
Two RCTs. Authors rate the whole set level IV. This is organized clinical
consensus, not validated criteria. Note the pattern: where they agree most
(tenderness) the evidence is weakest; where almost nobody looked (hop test)
it held up.

---

## Spacing revision — same session, later

**The change:** "Daily" was carrying a frequency assumption the model never
required. Dropped. Spacing is now something the tissue sets, read off the
response, not chosen in advance.

**What did NOT change:** stress-recovery is real physiology. What fails is the
*timing* claim — that you can locate the supercompensation peak and land on
it. Peak timing differs by tissue, is not observable, and the signal you would
use to find it reports the fast subsystem only. Keep the mechanism, drop the
scheduling claim.

**Three-way separation (new, and the actual content here):**

1. **Performance readiness** — could I do it today?
2. **Supercompensation timing** — would today be the theoretically optimal
   moment?
3. **Resolution / spacing** — should another exposure enter the system yet?

Everyone else's training theory answers 1 and 2. Only 3 is the governor
question. A day off can be required even when performance is fine.

**Originating observation:** a serious acute injury can heal in 6–8 weeks when
load is genuinely removed; a minor one can persist for years when load keeps
being reapplied. The body recovers remarkably when the input actually stops.

**Scope limit on that observation.** It is about *damaged tissue returning to
baseline*, where removing the input is the entire treatment. It does not
transfer to healthy tissue seeking adaptation, which requires the input.
Healing and adapting are different jobs.

**Standing warning — THE FLOOR.** Two separate arguments for days off were
constructed this session and *neither included the floor*. An argument for
spacing with no floor has no stopping point: the same reasoning licenses two
days, four, indefinitely. The floor exists because chronic underexposure
produces loss that does not self-report. Any future spacing revision must
state the floor or it is incomplete.

**Unresolved tension.** The locomotion design above uses two 15 s bouts
separated by ~8 h on the grounds that distributed beats massed — a spacing
argument pointing the *opposite* direction at a shorter timescale. Both may be
right (different tissues, different windows), but "recurrence needs spacing"
as a single principle does not distinguish them. The content is in *which*
spacing, for *which* tissue.

**Also unobservable.** "Wait until the previous exposure resolves" is the right
question and an unanswerable one for bone, by the same argument that makes the
structural ceiling unanswerable. Better framing, not an operational rule.

**Immediately actionable.** The knee has had *reduced* load, not *removed*
load — three weeks of "no running" that never covered habitual jumping, plus a
2 km run eleven days ago still producing signal. It has never had the
condition described above. That experiment is available now and requires
nothing.

---

## Provenance

- [SYNTHESIS] The sequence itself. Derived from the step-length reframe of
  2026-08-14. No observational support.
- [DIRECT EVIDENCE] Weyand: faster top speeds come from greater ground force,
  not faster turnover. Supports step-length-as-readout.
- [OBSERVATIONAL] Power to the People, 2007–09, n=1, everything else
  different. Establishes that a minimal program once worked for this subject.
  Does not establish that minimalism is correct.
- [MECHANISTIC] Recurrence-dilution argument for the small exercise set —
  each added movement divides the recurrence density. Derived from the model,
  not measured.
- [LEVEL IV] The rehab criterion structure above. Consensus, not validation.
- [UNKNOWN] Whether step length moves from running at 215 alone. This is what
  the sequence is built to find out.
- [OBSERVATIONAL / CLINICAL] Acute-vs-chronic injury contrast. Widely reported
  clinical pattern; consistent with stress-injury and tendon load-management
  literature. Not a controlled comparison.
- [SYNTHESIS] The three-way separation (readiness / supercompensation timing /
  resolution). Josh's, this session. No observational support.
- [SYNTHESIS] Upper/lower spacing. Chosen tonight under a revised assumption,
  untested.
- [UNKNOWN] Whether resolution can be detected for bone at all. If not, the
  spacing rule stays a framing rather than a governor.
