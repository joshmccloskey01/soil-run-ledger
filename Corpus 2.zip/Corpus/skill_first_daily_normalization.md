# Skill-First Daily Normalization — Biological and Operating Model

**Canonical. 11 August 2026.** This document supersedes three separate statements and absorbs them:

| Absorbed | SHA-256 at absorption |
|---|---|
| `05_Biological_Adaptation.md` | `f3f475d2bd16b0212d6dbf4d921fb09a51af7bd33655e0c776e155968daf854a` |
| `base_edge_operating_model.md` | `19b5c20810abc1da6b447f66d866d74119836d8cd07ae06f07d35d88c5c9105b` |
| `supercompensation_vs_daily_normalization.md` (frozen) | `3fd3b9e6eb6c728e92b15dbdb71834b4f86cdd895c4970f5231cbd10afb30f23` |

The three source files are not deleted. They are archived artifacts, content-addressed above, and remain the record of what the theory looked like before the merge. This document is the reader from here forward; they are not.

**What the merge found.** Three documents maintained in parallel had drifted into disagreement with each other on four load-bearing points. Those disagreements are not resolved silently below. They are marked in place and collected in §11. A merged document that read smoothly across them would be worse than the three separate ones, because the drift would stop being visible.

**Scope.** This document states what the model *is*. It does not review evidence for or against it. The sprint evidence review and any later research documents stay separate, and their unknowns do not enter the definitions here.

---

## 1. Core claim — the interface

The athlete cannot command adaptation. There is no channel through which the organism can be instructed to change. What the athlete can do is perform actions, and actions place demands on the body, and the body changes as a consequence of resolving demands that recur.

That gives the causal spine:

> skill → recurring demand → resolution → retained capacity → expanded skill

The chain cannot be entered in the middle. Load without the skill to express it is not the same demand. Capacity built with no skill to use it has nowhere to go.

**The narrow claim survives; the strong one does not.** *Skill first* is true as a statement about the **interface** — commands enter the body only through performed actions, so every demand is delivered by a skill whether or not anyone names it. It is false as a statement that everything is strictly downstream of skill. Skill is also one ledger among many, with its own floor, ceiling, and update rate, and it is a peer being updated rather than the port. The floor work in §7 is the decisive case: a bone floor is a requirement on magnitude and recurrence, and no skill requirement entails it. A demand can be perfect as skill and insufficient as loading.

Both halves are needed. Without the interface claim, the model starts prescribing loads that no action delivers. Without the peer claim, the ledgers lose their independent requirements and the floors have nothing to attach to. [See CONFLICT-A — this resolution is proposed, not adjudicated.]

---

## 2. Biological adaptation

Biological adaptation is the usable-work-funded resolution of recurring demand into ledger-specific structure and control. The body is not trying to accumulate stress. It is trying to preserve life away from equilibrium by solving the problems it is repeatedly given, at the lowest future cost.

**Demand, stress, signal, cost.** Demand creates stress when it meets current capacity. Signal is the readable error inside that stress — the mismatch between what a ledger normally expresses and what recurring demand now asks of it. Cost is what the system spends to resolve the stress, repair consequence, and install the update.

**The adaptive band.** Too little demand leaves no signal and no residue; too much produces saturation, disorder, or damage. The band between them is real. It is a constraint on what may be given — not the organizer of when to give it. That demotion is the whole difference between this model and the one in §9.

**Heterogeneous ledgers.** Nervous control, muscle, tendon, bone, cardiovascular output, metabolism, skill, rhythm, prediction, coordination. Each carries its own floor, ceiling, update rate, constraints, and failure mode. So performance can improve quickly while slower ledgers remain unresolved, and improvement on a fast ledger is not evidence about a slow one.

**The four regimes.** The body maintains what recurring demand matches; builds or refines when demand rises above habitual output while remaining below the ledger's ceiling; decays when demand falls below the floor required to justify upkeep; degrades when demand outruns resolution capacity.

**Funding.** Resolution is paid for out of food, oxygen, sleep, recovery time, hormones, and remodeling bandwidth. An unfunded demand is not a stimulus but a debt.

**Maintenance demand is not the absence of demand.** Walking does not erase load or subtract stress. It is low-cost maintenance demand preserving circulation, tissue motion, rhythm, aerobic engagement, and readiness while higher-cost work resolves.

**Retained capacity is the object.** Adaptation is not survival, effort, or one good performance. Adaptation is retained, repeatable capacity after consequence has cleared.

---

## 3. Daily normalization

**Progress is not completing harder work.** Progress is the same demand returning with less disorder, lower cost, faster recovery, greater control, or higher future capacity. *Normalized* is a property of a demand across a run of days, never of one exposure.

**Cadence is fixed; dose is the variable.** There is no schedule. The base exposure is sized so the state it leaves is admissible for the same exposure tomorrow. If a candidate exposure only fits every third day it is too large *to be base*, and the answer is a smaller base exposure rather than a longer gap.

This does not claim physiology never dips. A transient disturbance that clears before the next occurrence falsifies nothing. What is rejected is the dip-and-rebound curve as the object the schedule is built from.

**Sizing replaces timing.** The traditional question is how large a stress can be imposed and when the rebound can be exploited. This model asks how small the exposure must be to remain admissible on the intended cadence.

Minimization alone is degenerate — zero exposure wins every time — so sizing is bounded on both sides:

> D_min,role(S_t) ≤ D ≤ D_max,cadence(S_t)

Both bounds are **state-relative**. Neither is a property of the movement.

**The floor is compound.** D_min,role is the minimum demand still performing the assigned role: for base, still the skill *and*, where assigned, still holding the relevant ledger; for edge, still contacting the ceiling it is assigned to preserve. Where more than one role is assigned, the floor is the maximum of them. A compound floor narrows the feasible interval, so infeasibility becomes more common rather than less.

**Empty interval.** Where D_min,role > D_max,cadence, no sizing solution exists. The correct report is *inadmissible from this state* — not *reduce further*. Without this the model can always escape falsification by prescribing less.

**The empty interval is a filter with a direction.** Movements that scale down gracefully stay in the loop; movements whose minimum role-performing dose carries systemic cost beyond the cadence bound drop out. The anchor list is therefore partly *determined* by the cadence rule rather than chosen, and the rule predicts which movements will fail before they are tried.

*Worked instance — archer chin, 18 July 2026.* One repetition already exceeded the daily-recurrence bound, and no smaller unit still performed the edge function. The interval was empty. The movement then left the loop for twenty-two days, breaking both coupling arrows at once: no edge contact holding the ceiling, and nothing for the base to promote into. The correct statement is that no archer-chin exposure was admissible *from S₁₈ ⱼᵤₗ*, not that the movement is inadmissible.

**The formalism.**

> S_t + I_t → S_{t+1}

There is no output. What is controllable is the exposure offered, not the transition. Measured variables — glycogen, force, clearance time, soreness, pace — are observable components of state, not adaptation outputs. **The error is promoting one observable's trajectory into the transition law itself.**

The operational consequence: **adaptation changes the admissible action set.** A changed state matters because it admits inputs the previous state did not. Promotion is a changed boundary on what the next state can legally receive, not more output in a separate channel.

*Convergence, not source.* Ashby's machine-with-input has the same shape — a transformation on states, an input parameter selecting which transformation applies, no output in the definition. That was noticed afterward.

**The identification rule.**

> hold I_commanded ⇒ observed change is attributable to changed state

Changing the input while trying to infer the transition law confounds the thing being identified. Only the *commanded* input is held: sleep, food, ambient load and temperature vary and are not controlled. That makes the read statistical rather than exact — *stopped behaving differently* is a judgement across a run of days, not a comparison between two.

Three operating consequences follow. Advancement and diagnosis cannot occupy the same comparison cycle: either hold the dose and read the trend, or advance and accept that the cycle is blind. Promotion resets the series, so comparison runs within a block and never across one. Stop days are marked, not omitted — where the governor closes loading, the exposure did not occur, and dropping the day silently makes the days either side read as adjacent.

**The limit, stated.** A stable block establishes stability of the governed observables under the held regime. It is not proof that every hidden or slow ledger has stabilized. The rule licenses one direction only: observed change implies changed state. It does not license the converse, and a quiet observable is exactly what a slow ledger looks like while it is still loading.

**Provenance — related prior structure, not authority.** Feldbaum's dual control: in an incompletely known system, control actions simultaneously regulate the plant and reveal information about it, so an informative probe may be poor control and the best immediate control action may teach little. This model does not implement dual control. Its held-input rule separates some identification and advancement operations sequentially instead — one policy response to a related conflict. The tension is borrowed; the resolution is not.

---

## 4. Base and Edge

**Base is owned demand.** Executionally controlled and repeatably resolvable, while slow structural adaptation may still be incomplete. Ownership here is a fast-ledger property and is not a claim of completed adaptation.

**Edge is unowned demand, and edge dose is bounded exposure to it.** The edge itself never becomes manageable. The old edge becomes base and stops being edge. Maximal effort is permanently edge, because it is defined at the ceiling — only the floor moves. The project is to make *fast* ordinary, not to make maximal cheap.

**The graded ladder.** Base < Base+ (candidate next base) < Minor Edge < Sharp Edge. These are states and roles, not fixed percentages.

**Percentage of max is rejected as the control variable.** The denominator requires a maximal test, which is itself an edge exposure, and a stale denominator errs unsafe precisely when capability has fallen. The control variable is absolute observed demand; percentage is descriptive after measurement.

**One axis, two roles.** Base and edge are not two categories of movement. They are two positions on one load axis of the same movement — loaded heavily enough, base work *is* edge work. The base's operating definition is the light end, light enough that volume stays cheap; the edge is the heavy end that still recurs daily. Three consequences: promotion is only meaningful because the axis is shared, so across genuinely different mechanisms — isometrics and running — there is nothing to promote into; the ramp is the traverse of the band between them, which is why ramp singles belong to the edge entry and not the base total; and a movement needs a nonzero base–edge gap to run the loop at all.

**Ownership is a status earned by history.** A demand does not enter as base because it reads clean. It enters as edge and is promoted when it repeatedly resolves, or it stays edge. The default is restrictive: an unclassified demand is edge until demonstrated otherwise, so caution is the entry state rather than something a flag has to trigger. [See CONFLICT-B — this and *one axis, two roles* are not obviously the same account.]

**Base.** Frequent, intentional, cheap practice. Distributed rather than concentrated. Tracked as total accumulation. The economics is to maximize useful intentional practice per unit of biological cost. *Floor:* the repetition must sit at a demand where it is still the skill. Below that it is movement, not practice, and leaves no residue.

**Edge.** One high-force single per lift per day, ramped to. *Ceiling:* below peak, so it can recur daily. *Floor:* tension high enough to hold recruitment access. Daily recurrence pushes edge size down the way the cost ratio pushes base cost down, and without a floor the edge converges on an exposure that recurs perfectly and touches nothing — a failure that is invisible, because the exposure looks fine every day.

Both layers have the same structure: a floor defining what still counts, and an economics driving toward it.

**No maximal tier on the strength side.** Control failure is what defines a maximum, so a controlled single cannot be one. "Below peak" does not mean a maximum voluntarily held back; there is no maximal tier to hold back from. The sprint sharp edge is the only uncapped exposure in the system.

**The heavy line.** Truly heavy is the load at which one repetition materially moves the state. At or above that line, one repetition — the mismatch is fully declared at rep 1, and rep 2 is the same external load meeting a state that has already moved by an unknown amount, so information per rep collapses while cost per rep rises and the probe destroys its own baseline. Reps within a session do not make a problem recurrent; recurrence lives on the day axis. The loop sits below this line deliberately. *Exception:* multiple repetitions where repeated execution is itself the skill. *Scope:* this is an operating rule for peak-demand edge work, not a universal statement about repetitions on every ledger.

**The loop.**

> base practice → small daily edge single → observe → repeat if admissible → normalize → promote into base → edge moves up

The rise is not located in either layer. It is in the exchange: the edge holds access to maximum tension so a given load stays practicable in the base, the base makes that load ordinary, and the edge then sits higher without chasing a number. Both arrows are load-bearing. Preservation is what the edge does between promotions, not its purpose.

**The ramp.** Divide the gap between current base load and current edge load into fixed increments and ramp in singles. Ramp steps sit below the heavy line by construction, so raggedness is not a problem — put the odd increment at the bottom and keep the steps nearest the edge consistent. Within a block both endpoints are fixed, so the ramp is identical every day across the comparison window. It is derivable, not stored. **Step count is a free reading:** at fixed increment, step count *is* the base–edge gap. Falling steps mean the base is catching up; zero steps mean base has met edge and promotion is overdue.

**Advancement.** Advance when the exposure stops behaving differently from the days preceding it. This is the ramp criterion on the day axis instead of the load axis, and the comparison is cleaner because the reference is the identical load repeatedly rather than a set of different loads. Not on calendar. Not because one rep felt easy. **Completion is not ownership.**

**Promotion.** When an edge load has become ordinary it enters the base as practicable load and the edge moves up. Promotion resets the series.

**Anchor selection.** A movement qualifies as an anchor only if it scales down to a size that recurs daily. A movement whose minimum unit already sits at or above the heavy line stays out until the state changes. Bodyweight movements with no loadable gap have no ramp and need a separate edge definition or sit out.

---

## 5. Error and instrument calibration

The operating rule states the edge single and its size constraint. The size constraint is not its function.

**Base adapts. Edge probes.** The accumulation lives in the base. A single minimal exposure is not the driver pulling the organism upward, and nothing here is built on its being one. It may contribute adaptation; no weight rests on that contribution.

**The edge's function is to produce catchable error.** An exposure entirely inside the base generates none — execution is clean, nothing deviates, and the sensing stops improving because there is nothing to detect. Error is the calibration signal. The edge is where error is available.

**Which sets the dose criterion from the opposite direction.** Not how much can be absorbed, but how much error can be produced and attributed. Below the band there is nothing to sense. Above it the error arrives faster than the catch.

**Why one.** The first repetition is the only uncontaminated read. A second is performed in the residue of the first, so a deviation there cannot be attributed to the demand rather than to the residue, and unattributable error calibrates nothing. The single is not restraint. It is **the minimum exposure that yields an uncontaminated, attributable error signal** — the least damage required to acquire useful error, not the most that can be taken before the signal fouls. *Largest clean dose* points the optimization at the contamination boundary, which is the wrong direction to be pushing from.

**Different justifications for the two layers.** Base is justified by capacity development. Edge is justified because an instrument cannot be calibrated inside conditions it already controls. They are not two doses of the same argument.

**Recurrence, not repetition.** What makes a demand a problem the body solves is that it returns, not that it was performed many times inside one session.

---

## 6. Ledger, instrument, governor

Three objects, three jobs, three clocks. Confusing any two of them is the most common way this model degrades in use.

**The instrument** is online sensing: the catch, the abort, the adjustment made while the exposure is happening. It is the only controller *inside* an exposure. It is fast enough to act and blind across days.

**The ledger** is history. It holds no authority during an exposure and supplies the longitudinal comparison afterward, which is where normalization is read. It is append-only, timestamped, and not rewritten.

**The governor** is a permanent constraint on rate. It authorizes nothing and verifies nothing.

**Two authorities, kept separate.** Demonstrated resolution determines whether movement is permitted. The governor determines how fast permitted movement may occur.

**Two calibration loops, and what each cannot do.** The online loop is the only control that reaches inside a single exposure, and therefore the only thing standing between a bad exposure and its consequence. The longitudinal loop calibrates from misses and subsequent trajectory — it cannot score saves, because a successful catch is counterfactual and leaves no record of what it prevented. So the loop that matters most in the moment is the one the record can least evaluate.

**Why the governor does not retire.** Normalization is what creates the temptation to accelerate: demand feels ordinary, so it rises; feels ordinary again, so it rises again. Successful adaptation drives runaway progression on its own. The governor is not scaffolding to be removed once things feel routine — feeling routine is when it is the only thing still working.

**And a structural reason the ledger cannot absorb it: latency exceeds the decision interval.** The gap between a promotion and the evidence that would evaluate it is longer than the gap between promotions, so authorization always runs several steps ahead of the last verifiable one. The governor covers the interval the record cannot have closed yet. It is not redundant with the ledger; it is what stands where the ledger has not yet reported.

**A rate criterion, from the 400 m record.** Roughly 1:38 in mid-March 2026 to 1:15 on 8 June, with seventeen of those seconds inside the final month. No structural tissue moves at that rate, so the gain was almost entirely neural, coordinative and metabolic — meaning expressed capacity was pulling away from absorbable capacity throughout. The curve read as validation and was closer to a divergence readout. **If expressed capacity is rising faster than the slow ledger's maximum possible adaptation rate, margin is contracting regardless of how anything feels.** [SYNTHESIS — the maximum plausible rate is not quantified.]

**A better controller is itself a risk.** Controller improvement and plant improvement both present as *can do more* and are not distinguishable from the outside. A better controller grants access to demands the plant has not grown into, so skill improvement actively enables structural risk. Structure-first inverts the ordering so that skill arrives inside an already-built region.

**Admission is event-based and asymmetric.** Any joint score flags: loading stops on that joint for the day, immediately, with no duration estimated. Entry is instant because a score firing is a positive read — something crossed. Exit is not the converse. A score failing to fire is the quiet observable, and a quiet observable is what a slow ledger looks like while it is still loading. Clearance therefore runs on a separate and stricter standard: zero held across a sustained window, swept through deep range, not a point sample. Instant in, slow out. [See CONFLICT-C — the exit standard is contested across the sources.]

**Passing the governor is an admission, not proof that every slow ledger resolved.** The wording that matters: the criterion is *no bad residue*. Residue is the adaptation. What is being excluded is damage, not consequence.

**Sampling density and its domain.** Daily cadence gives the densest readings, the fastest detection of a bad configuration, and the smallest exposure between checks. That is the strongest property on this side. Its domain is the admission decision. Density works where the sampled state clears between samples, and the exposure is sized so it does. Density buys nothing against a quantity that does not vary on the sampling clock — bone remodels across months, so sampling a daily observable more often returns noise around a value that has not moved. Density costs, because each probe is itself an exposure. And density is not the progression trigger at any rate: normalization is a comparison across a block, and no sampling rate constitutes it.

**Compliance is not a footnote.** Two governor violations are on record — five one-arm pull repetitions on 18 July 2026, and three near-maximal 400s inside eleven days ending 8 June. Both were accumulations of the edge, which is the one thing the edge rule forbids. Neither was a design failure; the prescription existed. It existed in memory, which is not a place a cap can be enforced from, and both violations looked identical from inside the moment: the demand was available, nothing hurt, and nothing in the loop between deciding and doing forced an encounter with the rule. **An unrecorded governor is unenforceable.**

---

## 7. Floors and ceilings under partial observability

Every governor above bounds from one side. The flag rule, the dose cap, the rate cap and the clearance window all answer *how much loading is too much*, and all are satisfied by less. For a ledger with a working observable that is adequate, because the observable eventually objects to underloading through lost capacity. For a ledger with no field-readable state channel it is not, because nothing objects to anything. **A ceiling-only controller can drift its exposure toward zero and report itself compliant the entire way down.**

**Physiology and accounting are different objects.** Impact loading does credit bone. This model declines to book that credit, because it cannot read the individual accumulated state well enough to spend against it — so running is priced as cost at every exposure and never amortized into the slow ledger. That is a refusal to spend an unverified asset, not a claim that the asset does not exist. Physiological bone credit and admitted bone credit are separate quantities, and the second must not stand in for the first.

**The bias has a direction.** The refusal protects against overestimating slow-tissue capacity and therefore systematically underestimates it, with the gap widening under time on the policy. The failure it produces is not overload. It is chronic under-allocation of the loading that tissue requires to develop at all.

**The two failures are not equally observable.** Excess loading eventually produces an event — a reaction, a fracture — that reports itself, late and expensively but unambiguously. Insufficient loading produces no event. Nothing announces that capacity went undeveloped; it presents as ordinary and becomes legible only when a later demand exceeds it. Conservatism is therefore not automatically the safe direction. It is a direction, with a cost, and it looks cheaper only because its failures generate no observations.

**The correction is a floor, not a credit channel.** The model cannot say *this much impact yields this much bone capacity*; the coefficient is not available, and inventing one would be exactly the false confidence the refusal exists to prevent. It can say that a minimum mechanically meaningful exposure must recur:

> floor ≤ admissible exposure rate ≤ ceiling

Nothing about tissue state is asserted at either bound. This is the only constraint in the model that does not require reading the tissue it governs — every other one is a response to an observable, and this one is a standing requirement holding whatever the channels report. That is the right shape for a ledger that has no channel.

**The floor is a rate requirement, not accumulated credit.** Not *this many contacts this month, so bone is covered* — that is bookkeeping against an unmeasured balance again, and bone saturates within a bout regardless, so a monthly total is satisfiable by stacking in a way the tissue does not read. The floor specifies that exposure *recurs*, at a cadence, and is therefore auditable without measuring anything: compliance is a fact about the schedule rather than about the athlete.

**It must contain magnitude, not only recurrence.** A floor stated in contacts or minutes is satisfiable by large volumes of low-magnitude running, which is the exposure least likely to supply the demand the constraint exists to preserve. Bone appears to read magnitude and novelty rather than accumulated cycles. [MECHANISTIC for saturation and magnitude-gating; OBSERVATIONAL and weaker for the sprinter-versus-distance bone density contrast, which is cross-sectional and cannot separate training effect from selection. Per-contact force figures are recalled, not verified.] So the floor is a pair — minimum magnitude class and minimum recurrence — with the ceiling above both.

The pair is in tension with the ceiling by construction: the ceiling wants to cap high-magnitude exposure and the floor requires some of it. That is a corridor, not a contradiction. Whether the corridor is wide or narrow is unknown and worth establishing, because a narrow one would mean the two constraints have nearly specified the running dose without anybody choosing it.

**Which ledgers need an explicit floor.** Within the governed set — the tissues and control systems carrying mechanical demand in service of the stated goal — a ceiling is required wherever an available exposure can exceed local capacity, which is every row in practice. An explicit floor is not universal in the same way. Two conditions must hold together: chronic underexposure has to produce a loss worth preventing, and that loss has to fail to report itself in time for the ordinary loop to correct it. Either absent removes the case. An unobservable structure with no underexposure consequence earns no floor from its silence; a consequential one that announces its own decline is already handled by feedback that exists. Muscle takes the second escape — it can certainly be undertrained, but lost capacity surfaces fast enough that a standing blind floor adds little. Bone takes neither. [SYNTHESIS.]

*The two conditions are not independent, at least for bone.* Its underexposure consequence is severe partly *because* the channel is weak: undeveloped capacity is discovered by exceeding it, so the discovery event is the injury. Read as separate factors the rule overstates its resolution. The ranking is unaffected — bone is the first row either way — but the rule orders rows and does not score them.

**A veto overrides the floor and does not erase it.** A joint flag is a hard stop and outranks the floor; when the knee says zero locomotion, zero locomotion wins. What changes is the bookkeeping. The pause is not physiologically neutral and the record should not read as though it were. The correct entry is *bone floor unmet, higher-priority veto in force* — a debt of known duration and unknown depth. The current zero-prescribed-locomotion phase is the first instance and is accruing now.

**Three audit surfaces.** The record previously had one: *what happened*. The floor adds a second: *what was required and did not happen*. The roster below adds a third: *what should have been required and was never encoded*. Only the first is answerable from events alone. Noncompliance leaves a missing event and is findable; a coverage omission leaves nothing, because the event type was never created.

**The tissue roster, and what it does not fix.** Enumerating the governed ledger set is prior to assigning floors and ceilings, and both are prior to specifying commanded inputs. The roster is an external completeness specification with no internal validator, so it can omit a tissue exactly as the ledger omitted a floor, one level up. It does not terminate the regress; it relocates the omission onto a short enumerable surface readable in one pass, which an event stream is not. It should be dated and revisable on the same terms as any other definition here, and its own discovered omissions logged rather than quietly patched.

**And the roster needs a join to be operational.** Its rows are tissues; the exercise library's rows are movements. A structure that no movement names is invisible on one side and unloadable on the other, so coverage is computable only once each tissue is mapped to the exposures that load it. Without the mapping the roster states intent; with it, coverage becomes a query over events already recorded.

**The general claim.** Where ledger state cannot be read directly, safety cannot mean only limiting excess. A valid controller must also prevent chronic underexposure to the demands known to maintain or develop that ledger. [SYNTHESIS.]

---

## 8. Running and sprinting as the hard case

The loop transfers to running. Its self-probing property does not.

**Why running is different in kind.** In the gym a magnitude dial exists independently of the task: a tendon can be loaded at whatever fraction is chosen. In running, contact magnitude is set by mass and speed geometry — there is no way to run at thirty percent impact. The only dial is contact *count*. So the controllable variable is exposure, which is why the governor here is dose-capping rather than normalization. [MECHANISTIC]

**Ledger-relative ownership.** Running is fast-ledger base and slow-ledger edge at the same time, at every pace. The fast channel can retire its side; the bone side has no channel to retire on. Base running cannot support itself unless dosed like edge until it earns base status — and the promotion read is fast-channel, so earned base status is a policy improvement rather than an epistemic one.

**It stays a cost.** Because the promotion cannot be honestly read on the slow ledger, running never converts from a cost into an investment there. It is priced every exposure, capped every exposure, never amortized. All structural credit in the system comes from held tension, which is tendon's mechanism, so bone has a spend channel and no deposit channel. This is an accounting position, not a physiological claim (§7), and it is what the bone floor exists to counterweight.

**The gym edge is self-governed; the running edge is externally governed.** The daily readout in running is an acute signal, and bone cannot complete a remodeling cycle in the window where that signal clears. The governor is therefore separate from the exposure.

**Dose length before dose spacing.** Bone mechanosensitivity saturates within a few dozen loading cycles and resensitizes over hours, and the same total cycles split into separated bouts produce a larger osteogenic response than one continuous bout. The well-supported half of that is the saturation: it sets a **dose-length limit**, cap the bout where further contacts stop buying formation. The recovery interval is the weaker half, and it is a fact about the *sensor*, not the structure — mechanosensitivity returning in hours while remodeling runs on months means a second same-day bout is fully sensitive to a stimulus applied to incompletely repaired tissue. Responsiveness returning is not readiness. So dose length is the earned governor; whether a second bout occurs that day is a separate decision the interval finding does not authorize.

*If exposure is to be added, add a bout rather than extend one.* Extension past saturation adds contacts, damage and time while buying almost no additional formation, so it is dominated. And bout count is an integer: extending a bout is continuous, creeps a minute at a time, and nothing marks the moment it got long, whereas adding a bout is discrete, countable, and appears in the ledger as a distinct object. A governor on a countable thing can be checked; a governor on a continuous one drifts. Both logged violations were creep.

**Bone and tendon are non-substitutable.** Tendon's gate is strain magnitude held for seconds, so jerk buys nothing tendon-wise and imports risk; bone reads strain rate, magnitude and novelty, and saturates fast. The right tool for one is the wrong tool for the other. Bone gets its work from impact; tendon from held tension. The consequence of a zero-locomotion phase is therefore asymmetric — tendon can be maintained, bone detrains — so on return, tendon is ahead and bone behind, and **the return rate is governed by bone**, the ledger that reports nothing until a reaction exists.

**Sprint structure.** Base running built to a level, then a short near-maximal exposure at whatever pace recurs daily; pace is the dependent variable and daily recurrence the fixed constraint. [See CONFLICT-D — a daily near-maximal running exposure and *running is permanently edge, and edge must not accumulate* are not obviously compatible, and the current phase prescribes neither.]

**The hamstring constraint, which the architecture does not answer.** Eccentric hamstring demand rises disproportionately above roughly eighty percent of maximum velocity, so the top fifteen to twenty percent of the velocity range is a qualitative discontinuity rather than a smooth slice — it cannot be normalized past, only conditioned to survive. Fast base running sits inside that band, so a week of daily fast base contains no day on which the hamstring is unloaded, which is a thing high/low supplies for free. The architecture has a *response* — bound the dose, run the online controller for single-exposure error, rehab detected abnormality immediately, cap the rate permanently. A response is not an answer. Nothing here establishes that daily exposure in that band without unloaded days is tolerable, and the online controller, the only element reaching a single-exposure hamstring failure, accumulates its misses and not its saves.

**Exposure versus session.** The evidence usually cited for long recovery after sprinting comes from conventional sessions — multiple reps, starts, fly work, plyometrics, lifting in the same unit. That establishes the cost of a session package, not the cost of one bounded exposure. What follows is that the recovery requirement of a single exposure is *unestablished*, not that it is small. And the shift holds for central cost only. It does not transfer to the hamstring, which fails from single exposures without needing accumulated dose.

**A possible third function for the sprint edge.** Beyond adaptation and calibration, top-end contact may need preserving in its own right — reaching near-maximal speed recurrently is associated with lower hamstring injury risk, and coordination at that end decays without contact. If that function is real it may require a different frequency than a pure calibration read would. Flagged, not decided.

---

## 9. Against supercompensation and high/low

The comparison is a section, not the organizing object. Its purpose is to give a reader a reference architecture against which this model becomes legible.

### The standard model, stated fairly

**Origin.** Yakovlev, 1949–1959: supercompensation of muscle and liver glycogen and muscle phosphocreatine following exercise. Both are storage quantities with regulated setpoints — the class of variable that can genuinely overshoot. Deplete a tank, refill past the line.

**Shape.** A session disturbs the system. Performance dips below baseline, recovers, rebounds above baseline, then decays if nothing follows. **Operating rule:** time the next session at the peak of the rebound. **What the schedule is built from:** the recovery curve. **Load direction:** upward, since each cycle starts higher. **What is being timed:** an excursion — the system is deliberately driven out of its ordinary state and the return trip is scheduled.

### Commitment 1 — reject generalized supercompensation timing

Tendon collagen, bone mineral and recruitment access are not storage quantities. They do not deplete and refill; they remodel. The curve describes one variable type, not the organism.

**The defect is internal, not imported.** The model concedes heterochronism — tendon and bone take considerably longer than muscle — and then still prescribes training at *the* peak. One clock, admitted to be many.

**Conceded:** variable-specific overshoot is real; glycogen supercompensation and carbohydrate loading are not disputed. **Not claimed:** that stress does not drive adaptation. Demand producing stress, stress carrying a readable signal, resolution costing something, and an adaptive band between too little and too much are all retained (§2). What is rejected is the deplete-and-overshoot *shape* generalized into a scheduling clock.

**The replacement is not a better estimate of the peak. It is the removal of the question.** An exposure small enough to recur daily never requires knowing where a rebound lands, because the system is never driven far enough out for the return trip to need scheduling.

**Where the argument closes and where it does not.** Every-third-day spacing was justified by slow-tissue completion inside the gap; slow turnover makes that false, and the justification is removed by argument with no observation required. That is finished. What the elimination does *not* do is support the survivor. An unopposed option acquires nothing from the absence of a competitor. Daily normalization is left standing and unopposed; it is not thereby established, and any third arrangement not named here is equally unopposed.

### Commitment 2 — reject deliberate consequence accumulation

**This model rejects deliberate consequence accumulation that breaks the recurrence bound, including overreach-then-taper peaking.** This is independent of Commitment 1 and owned directly. Fitness–Fatigue supports taper and peaking through a different mechanism and survives the supercompensation critique intact; it is a coherent model rejected as an operating policy, not as an account of physiology.

Rejection lands on the accumulation phase. Low inputs are legal. Deliberately entering states that break the intended recurrence in order to recover from them later is not.

**Cost, stated:** the highest transiently expressible state on a given date is given up in favour of the highest continuously available state. Conventional peaking may produce a race-day expression above the continuously sustainable one. That is a real cost, not a philosophical preference, and it is largest exactly where the objective is.

**No competition exception.** The commitment is flat. If an exception is created later it must be written as an exception, not absorbed into horizon language.

### High/low (Francis)

The strongest of the alternatives, and not a recovery curve. The claim is that high-intensity exposure carries a systemic cost requiring roughly 48–72h, and — separately and more sharply — that submaximal work inside the gap *interferes* with maximal expression rather than merely failing to help. Removing supercompensation does not touch either claim. [COACHING PRACTICE]

**Where the disagreement actually is.** High/low encodes a real constraint — an athlete cannot indiscriminately accumulate demanding work — and attaches it to a fixed calendar. The disagreement is over attachment, not over caution. A calendar cannot move with the athlete. Attaching the same caution to the *rate at which the floor rises* keeps it in force permanently and still lets the floor climb. Not established: whether normalization lowers systemic cost or only local cost. If only local, a week of fast base is a high/high week and Francis's criterion is met on his own terms.

### Other spacing mechanisms that do not descend from supercompensation

**Tendon net balance — the one that could cut against daily.** Collagen degradation is reported to exceed synthesis for roughly the first day after heavy loading before crossing positive (Magnusson / Kjaer). If that holds, conventional 48–72h tendon spacing has a real basis and it is not supercompensation. But the mechanism is strain-gated: the negative window follows high-strain loading and is not a property of any exposure. It defends spacing for doses above a strain threshold and says nothing about a base dose below it. Dose-sizing already handles this, since an exposure small enough to recur daily is by construction below the gate. The threshold value is unknown. [Numbers recalled from the reference set, not verified here.]

**Bone mechanotransduction — the one that favours distribution.** Covered in §8. If it holds, small and frequent is not merely tolerable for bone but the better stimulus.

---

## 10. Evidence status

**Untested.** The daily module described here has not been run as a block. There is no observational content on either side of the comparison in §9, and nothing in the record counts for or against it. The case against supercompensation is mechanistic and negative — the alternative's justification collapsed — and it is exactly that.

**What is being validated, and by what.** Policy control, not causal identification. The model does not need the adaptation mechanism decomposed. It needs: demand presented, resolved repeatedly, demand raised, resolved repeatedly, while function holds. *Resolved* already carries the flag rule — an exposure leaving a problem surfacing in the joint or function system was not resolved, whatever its execution looked like.

**The reference is a constraint, not a number.** Requalification elsewhere asks whether the same system still passes the same test. This system is *supposed* to change, so a probe reading differently is expected rather than alarming, and an original numerical baseline is the wrong object. What must hold through state evolution is a constraint: capacity rising while joint abnormality stays zero and control constraints remain satisfied.

**Inherited flaw, stated.** A constraint built from signal-triggered channels is satisfied vacuously wherever the signal does not exist. For bone and tendon it is met by silence. It reads as always-true in the domain it most needs to bind.

**What the trajectory judges and what it does not.** It judges policy sufficiency. It does not judge the account of *why* — a wrong mechanistic story producing a working policy is confirmed identically to a correct one. The substrate confirms the bundle; only the record can decompose it. This is the argument for keeping the bookkeeping, not a lighter version of it.

**What it cannot separate.** For bone and tendon, safe accumulation and pre-failure read the same — capacity rising, function holding — up to the discontinuity. The criterion is well-posed for anything degrading gradually and reporting as it goes, and reads identically in both branches for the two ledgers where it does not.

**Asymmetry of the evidence.** A good trend under a policy is weak evidence that the policy caused it and cannot rule out that a more aggressive one would have done as well. A bad trend is much stronger evidence against. The record falsifies faster than it confirms. The honest early claim is *not yet contradicted*, not *supported*. And it is one arm: there is no counterfactual athlete under high/low, so sufficiency is available and superiority is not.

**Mechanistic coherence does not upgrade epistemic status.** Material returned with a mechanism attached retains its prior status until independently warranted. A restatement reading as more grounded because it now has machinery under it has not thereby become more grounded.

*Worked warning — the taper reformulation.* Commitment 2 was at one point restated as *do not enter a state from which the intended recurrence cannot be restored within the loop's permitted transition horizon*. Coherent, formally expressed, mechanism attached. But the horizon **is** the recurrence bound — tomorrow, for lifting — so the reformulation reduced to the loop restated while reading as though it had opened room for peaking. It also described taper as a chain of low inputs, omitting the accumulation phase where the disagreement actually lives. A coherent restatement can silently change the commitment it claims to preserve. Status-mark anything that returns this way.

### Falsifiers

**Near-term — event rate, not duration.** Once the governor is event-based, clearance duration is no longer graded and cannot carry a trend. The countable quantity is flag events. **At held dose, if tolerance is rising, event frequency should fall.** If events hold steady or rise while the commanded input is fixed, tolerance is not keeping pace with the load being asked. *Limit:* rate needs a block long enough to count in, and promotion resets the block, so where blocks are short and events rare the falsifier is unavailable rather than passed. State that when it occurs rather than discovering it afterward.

**Directional, against high/low.** Top-exposure output should hold or rise across months while the base floor rises underneath it. If the floor rises and the ceiling does not, the base is consuming the edge and the interference claim is confirmed. This is the falsifiable form of the whole proposal.

**Terminal.** Continuously available performance must eventually prove competitive with what a deliberate taper-and-peak architecture produces. The test is within-athlete. *Running it violates Commitment 2*, since it requires the accumulation phase the commitment forbids, so it can only be run as a declared, bounded, single exception. It also carries an order effect: a taper arm run after years of continuous operation stands on a state the continuous arm built. Both facts weaken the result and neither removes the need to run it.

**Structural.** The model must be able to report that no admissible dose exists rather than prescribe less indefinitely. If infeasibility is never reported, the falsifiers above are unreachable.

---

## 11. Conflicts surfaced by the merge

These are not new objections. They are places where the three source documents, maintained in parallel, had come to say different things. None is resolved by editorial choice below.

**CONFLICT-A — the status of skill-first.** The operating model states flatly that skill-as-sole-interface *does not survive*, because the biological statement lists skill as one ledger among many and therefore a peer being updated rather than the port. The biological statement and the proposed spine both open with skill-first as the core claim. §1 proposes a split — the interface sense survives, the everything-downstream sense does not — and the floor work is the decisive case, since a bone floor is a magnitude-and-recurrence requirement that no skill requirement entails. **Proposed, not adjudicated.**

**CONFLICT-B — what base and edge actually are.** The operating model says they are two positions on one load axis of the same movement, so the role is read off where the load sits. The later work says ownership is a status earned by history and explicitly *not* a property read off the demand. These can perhaps be reconciled — the axis gives position relative to current ownership, and ownership is what moves — but they are not the same account, and only one of them makes *default to edge* meaningful. **Unresolved.**

**CONFLICT-C — the exit criterion.** The operating model: joint flags, loading stops that day, next-day probe normal returns to the loop, still flagging goes to rehab. The frozen comparison: entry to rehab is immediate on detected abnormality, and exit requires zero held across a sustained swept window, with whether that is still fourteen days left open. These are different governors with different exit standards, and both are currently written as the rule. **Unresolved.**

**CONFLICT-D — the running prescription.** The operating model prescribes base running plus a short near-maximal exposure at whatever pace recurs daily. The later work holds that running is permanently edge, that edge must not accumulate, and that running is priced as pure cost. A daily near-maximal exposure is daily edge recurrence, which the edge rule either permits by design or forbids depending on which definition of edge is in force — which routes back to CONFLICT-B. The current phase prescribes neither, since locomotion is at zero under veto. **Unresolved.**

**A convergence, recorded as the counterpart.** The operating model's OPEN-2 asked *what assigns the ledger floors*, noting that an unassigned ledger has no floor and can decay with nothing reporting it. The tissue roster, the two-condition floor-necessity rule and the tissue–movement join in §7 are a partial answer to exactly that question, developed independently. That is the merge paying for itself: an item open in one document was substantially discharged by work done in another, and neither document knew it.

---

## 12. Open problems

Renumbered. Source identifiers are preserved so the archived documents remain traceable.

**O-1 — what counts as a flag.** *(was base_edge OPEN-1.)* The joint score is graded, so *score appears* must state whether it means any nonzero value or a band above zero. Any-nonzero closes the item: the bound is stated and tolerance is zero. A band relocates the item to the band's edge and leaves it open.

**O-2 — governed observables can be quiet while a slow ledger is still loading.** *(was supercomp OPEN-2; overlaps base_edge OPEN-2.)* The flag rule narrows the exposure window; it does not close this. Fourteen days at zero is fourteen days of a fast instrument reading zero. The sharp case is a ledger pair with different update rates: neural recruitment normalizes inside twenty-four hours, tendon collagen does not, so a daily edge single can read clean on the fast ledger while the slow one accumulates and the loop reports nothing until structural failure. **The model's most dangerous silent state, and undischarged.**

**O-3 — recurrence is not classified.** *(was base_edge OPEN-3.)* The governor has two outcomes, transient and persistent, both decided on a one-day window. A joint that flags, clears overnight and flags again days later reads as transient on every instance, so the pattern never reaches rehab — which is the slow-accumulation case the governor exists to catch. A third state keyed to event recurrence across days would close it. Not adjudicated.

**O-4 — instrument drift is confounded with state change.** *(was supercomp OPEN-3.)* A probe family that sharpens over time raises its own flag rate. Nothing currently distinguishes *the body got worse* from *the instrument got better*. The defence is recording and dating the probe definition; not implemented.

**O-5 — compensation is inside the probe, not around it.** *(was supercomp OPEN-4.)* The probe is instrument and load path at once. When strategy shifts, a well-compensated pattern reads *better* while redistributing load, so the reading and the failure mechanism become correlated in the wrong direction. No conscious adversary is required; constraint satisfaction is enough. This is where measurement-as-intervention and Goodhart are one item rather than two.

**O-6 — probe results and governor compliance are not ledger events.** *(was supercomp OPEN-5.)* Promotions are — the preset species is append-only, timestamped, latest-wins, changed only by explicit edit — so a promotion can be located in time but cannot be evaluated against the state it was made in, because probes and scheduled interruptions leave no residue. Governor compliance is the higher-value half: the governor is the safeguard that does not depend on probe coverage, so a scheduled interruption that silently did not happen leaves only the signal-triggered rule, which is blind to bone and tendon. Partially addressed inside the gym application, where the edge cap is now an encountered object; both logged violations occurred outside it.

**O-7 — the clearance window is unresolved.** *(was supercomp OPEN-6; now compounded by CONFLICT-C.)* Whether exit requires fourteen days at zero, or was superseded when entry moved to immediate-on-detected-abnormality, is not decided — and the operating model states a third standard again.

**O-8 — re-entry after an unmet floor is unspecified.** *(was supercomp OPEN-7.)* When a veto clears, does the previous floor resume, or does the known duration of violation alter the return corridor? The missed loading cannot be repaid by volume: depth of lost capacity is unobservable and stacking is precisely what bone does not read. So the answer is almost certainly rate-governed re-entry rather than repayment, which puts the return under the control of the ledger that reports nothing until a reaction exists. The floor is currently unmet by an unbounded duration, since the veto has no scheduled end.

**O-9 — corridor width.** *(new.)* The floor requires high-magnitude exposure and the ceiling caps it. Whether the resulting corridor is wide or nearly determines the running prescription is unknown.

**O-10 — whether consequence and observability are correlated in general.** *(new.)* For bone they are: the underexposure consequence is severe partly because the channel is weak. If that holds across other ledgers, the two-condition floor rule collapses back toward one dimension and gets simpler. Tendon plausibly; joint less obviously. Not worth resolving on speculation.

**O-11 — tissue roster completeness.** *(new.)* The roster is an external specification with no internal validator and can omit a row. Dating it and logging discovered omissions is the only available mitigation.

**O-12 — a possible third function for the sprint edge.** *(new.)* Preservation of top-end contact, distinct from adaptation and calibration, may require a different frequency than a calibration read. Flagged, not decided.

**O-13 — the vocabulary collision.** *(standing.)* *Edge* now carries at least four senses — the graded ladder position, the heavy end of a load axis, unowned demand, and the governance object being capped. Flagged as a standing governance item in both this model and the AI qualification architecture, and unresolved in both.

---

## 13. Correction log

Preserved across the merge. Entries are cumulative and are not smoothed.

- "Denser is always better" was stated without a validity domain and is bounded to the admission decision. Density is a controller property, not evidence about tissue, and each probe carries a cost.
- The flag rule as previously written covered entry to rehab only. Exit was reading clearance off the instrument that cannot certify it. Entry and exit now run on different standards.
- The elimination of supercompensation was at risk of being read as support for daily normalization. It is not.
- The operating rule stated the edge single and its size constraint without its function. The size constraint is not the reason. Error attribution is.
- The top exposure was described as "below peak," which reads as a maximum voluntarily held back. On the strength side there is no maximal tier to hold back from.
- Percentage-of-max was rejected as the control variable; the denominator requires a maximal test and errs unsafe when stale.
- The fortnightly interruption was at risk of being read as verification that margin exists. Nothing is read during it. It is a blind rate governor and its value is entirely in the interruption.
- "No dip and no rebound" overclaimed. The rebound curve is rejected as the organizing object, not the existence of transient disturbance.
- "If an exposure only fits every third day it is too large" applied a base rule to the whole architecture. Scoped to base.
- "Admissible tomorrow on every ledger it touches" asserted knowledge of silent ledgers in a document that denies having it.
- "The largest dose that still yields a clean signal" pointed the optimization at the contamination boundary. The derived rule is the minimum exposure sufficient for attributable error.
- "Whether those catches were predictive" contradicted the counterfactual admission below it. The longitudinal loop calibrates from misses; it cannot score saves.
- The hamstring cost was logged as "not answered here," which read as though the architecture had no response. It has a policy response and no answer, and both are stated separately.
- Conservatism was treated as a direction without a cost. Every governor bounded exposure from above only, which is adequate for ledgers whose observables object to underloading and unbounded below for the ones that do not.
- The refusal to credit bone adaptation from impact was carried as though it were a statement about physiology. It is a statement about admissibility.
- A period under veto was implicitly treated as physiologically neutral. It is a floor violation with a higher-priority cause, and it accrues.
- The blocking dependency was stated as a single item — specify the commanded input — which put the ordering wrong. Roster, then floor and ceiling assignment, then inputs.
- "Ceiling necessity is universal — anything can be overloaded" quantified without a domain. Scoped to the governed set. Same failure as "denser is always better," recurring in a new place.
- Floor necessity was derived from observability alone, which would generate a floor for anything unobservable regardless of whether underexposure costs anything. Two conditions are required. Same shape as the ceiling error, in an adjacent sentence.
- *This revision:* three documents had drifted into four substantive disagreements with each other while each read as internally coherent. Parallel maintenance was the mechanism. The disagreements are recorded in §11 rather than resolved, and the fact that none of them was visible from inside any single document is the argument for the merge.

---

## Status

**Blocking dependencies.** A comparison block requires a held commanded input, which is not yet specified. Prior to that, the governed ledger set must be enumerated: without a tissue roster the record can detect violation of an existing floor but cannot detect omission of a floor that should have existed. Roster → floor and ceiling assignment → tissue–movement join → commanded input → events.

**Current phase.** Zero prescribed locomotion under a knee veto. Gym-only controlled tension. The knee accumulates no new load; the bone floor is unmet and accruing (O-8).

**Deployed instruments.** Gym application with per-exercise daily edge cap enforced at the point of logging, derived from existing events with no interpretive label committed to the record. Running and unified ledgers separate. The append-only event model is the governing architecture: content-addressed, pre-registered, no history mutation.
