# Corpus Governance Contract

**Version:** 0.1
**Author of record:** Josh McCloskey

Governs how this project's own names, concepts, claims, and statuses are allowed to evolve. It governs the corpus, not training, not the ledger runtime, and not any one producer.

Both rules below were derived from specific failures rather than proposed in advance. The worked cases are kept because the rules are easy to agree with and easy to violate, and the failure is what makes them recognizable.

**Amendment:** supersession, never revision. A changed body gets a new version and the prior version is retained.

---

## 1. Invariant-name rule

> **A name fails if it names something that could change while the responsibility stays fixed.**

Phase, producer, consumer, and workflow are the common failure cases. The general form catches the ones not on that list. A name passes only if it refers to the stable responsibility itself.

**Failed — phase-dependent.** `phase1_observation_format_v1.md`. "Phase 1" is a fact about when the file was written. Six months on it tells a reader nothing about what the file governs.

**Failed — producer-dependent.** `LLM_Output_Contract.md`, proposed as the replacement. Three of the four species in that document are runtime-produced, and §6–§8 concern policy decisions and replay validity rather than anything a model emits. The name would bind a general machine interface to its current producer, and would send a reader looking in the wrong file.

**Passed.** `Trace_Record_Contract.md`. The responsibility — what must be represented about an execution — survives a change of producer, phase, or consumer.

### 1.1 Consumer clarification

A responsibility may legitimately be named even where it is also a consumer of another subsystem.

`Domain_Navigation_Contract` passes because navigation is itself a stable responsibility: where the process is, and which transitions are admissible next. It does **not** pass because it happens to consume regime identity. Naming a file for what reads it is the same failure in the other direction, and this precedent should not be cited to license that.

### 1.2 Scope

The rule governs concepts and vocabulary, not only filenames.

Standing violation: **edge** currently carries three meanings across the corpus — high-cost work that resolves (biological fundamental), a non-advancing preservation layer (Base/Edge), and probe the edge (Master Canon). Same collision pattern as the three unreconciled vocabularies in the Canon. Unresolved.

---

## 2. Provenance and status rule

> **Mechanistic coherence does not upgrade epistemic status.**

A claim returned with a stronger explanation, a cleaner mechanism, or more persuasive wording retains its prior status until independently warranted. The words improved; the warrant did not.

**Restatement can move status in either direction, and both are failures.**

**Worked case — deflation.** A commitment rejecting deliberate consequence accumulation was restated as *do not enter a state from which the intended recurrence cannot be restored within the loop's permitted transition horizon*. Coherent, formally expressed, mechanism attached. But the horizon **is** the recurrence bound, so the restatement reduced to the loop restated while reading as though it had opened room for peaking. A coherent restatement silently dissolved the commitment it claimed to preserve.

**Worked case — inflation.** A scoped rejection — *an observable's trajectory must not be promoted into the transition law* — was restated in conversation as the categorical claim that output is a category error for any continuing system. The scoped version was already correct and already written down. The restatement escalated its reach while appearing to sharpen it.

Both failures are a status change made silently during restatement. Anything returning from a second apparatus with mechanism attached is status-marked on arrival, and the mark is the prior status.

---

## 3. Candidate, not adopted

**Commitments carry their costs.** A commitment is recorded with what it gives up, and the concession is part of the commitment rather than commentary on it. Applied twice already — Commitment 2 carries the loss of a competition peak, and Commitment 1 concedes that variable-specific overshoot is real.

Not adopted here because it has not yet failed in a way that shows its shape. Left as a candidate.
