# Exact Pictures in Linear Algebra

Which representations preserve the structure of a linear-algebraic object—and which quietly claim more than the object contains.

## 1. The criterion

> **A representation is faithful only when it preserves the relationships relevant to the question without asserting structure the object does not warrant.**

This gives the governing thesis:

$$
\boxed{\text{Linear algebra does not lose representation beyond three dimensions.}}
$$

What changes is not the mathematics, but which representation is faithful.

The recurring failure is **representational inflation**: a picture or notation preserves some feature while implying others that are not actually present. Coordinate slices, the cross product, the idea of a universal rotation axis, naïve rotate–stretch–rotate language, and exact numerical rank can all inflate the structure of the object.

## 2. Three dimensions are drawable—not fundamental

$\mathbb{R}^2$ and $\mathbb{R}^3$ are not mathematically privileged as “spatial” dimensions. They are privileged because human vision can draw them.

The definitions of length, angle, and orthogonality work in every dimension:

$$
\|u\|=\sqrt{u\cdot u},
$$

$$
\cos\theta=\frac{u\cdot v}{\|u\|\|v\|},
$$

$$
u\perp v \iff u\cdot v=0.
$$

Cauchy–Schwarz guarantees that the angle formula remains valid in $\mathbb{R}^n$, regardless of $n$. Geometry beyond three dimensions is therefore not absent; it is computed rather than seen.

Some familiar 3D ideas do not generalize:

- The cross product is not a general operation on $\mathbb{R}^n$.
- A rotation in higher dimensions need not have a fixed axis.
- In $\mathbb{R}^4$, a rotation can act independently in two perpendicular planes.
- Random high-dimensional vectors are typically nearly orthogonal, a fact that 3D intuition does not prepare us for.

## 3. Picture the relevant span

When a problem involves only a few vectors, do not try to picture the entire ambient space.

Two vectors in $\mathbb{R}^{100}$ lie in

$$
\operatorname{span}\{u,v\},
$$

which has dimension at most two. Their lengths, angle, projection, distance, orthogonality, and Gram–Schmidt relationship all occur inside that span.

Drawing the span is not merely a metaphor or a projection. It is the actual subspace containing the relationships under consideration.

$$
\boxed{\text{Large ambient dimension does not imply large local dimension.}}
$$

Three vectors require at most a three-dimensional span. A genuinely higher-dimensional representation becomes necessary only when the question involves more independent directions.

### Coordinate slices

Coordinate slices are often mistaken for general pictures of high-dimensional spaces. They privilege the selected coordinate axes and may hide ordinary subspaces that are not aligned with those axes.

For example, in $\mathbb{R}^4$,

$$
\operatorname{span}\{(1,1,0,0),(0,0,1,1)\}
$$

is a perfectly ordinary two-dimensional subspace, but no coordinate-aligned slice represents it faithfully.

Slices are still appropriate when coordinates themselves are the subject—for example, partial derivatives or coordinate sensitivity. Their validity depends on the question.

## 4. Maps require input and output together

The span rule changes when a linear map acts.

If

$$
 x\in\operatorname{span}\{u,v\},
$$

then $Ax$ generally lies in a different subspace. To represent what the map does, the relevant object may be

$$
\operatorname{span}\{u,v,Au,Av\},
$$

whose dimension can be as high as four.

Thus:

- Relations among vectors can often be represented by the span of those vectors.
- The action of a map requires both the input directions and their images.
- An invariant subspace is especially valuable because the map remains inside it.

An eigenvector is the one-dimensional case of invariance:

$$
Av=\lambda v.
$$

The line through $v$ is preserved, and the map acts there by scaling, possibly with a sign reversal.

The general objective is not to find eigenvectors at any cost. It is:

> **Find invariant subspaces in which the transformation becomes as simple as the structure permits.**

A real planar rotation may have no real eigenvector, but its two-dimensional plane is invariant. A non-diagonalizable map may require a Jordan block, where scaling is coupled with a nilpotent slide.

## 5. Symmetry gives the cleanest picture

For a real symmetric matrix,

$$
A=Q\Lambda Q^T,
$$

where $Q$ is orthogonal and $\Lambda$ is diagonal.

This means that an orthonormal change of coordinates is followed by independent scaling along perpendicular directions, and then the coordinate change is reversed.

The representation is exact because symmetry guarantees:

- real eigenvalues,
- an orthonormal eigenbasis,
- no missing eigendirections,
- no Jordan coupling.

Strictly speaking, an orthogonal matrix may represent either a rotation or a reflection, since

$$
\det Q=\pm1.
$$

Also, negative entries in $\Lambda$ represent sign reversals as well as ordinary scaling. “Rotate–stretch–rotate” is therefore useful shorthand, but not the complete statement.

## 6. SVD is the general representation

For any real matrix $A$, including rectangular and non-symmetric matrices,

$$
A=U\Sigma V^T.
$$

This follows from the symmetric positive-semidefinite matrix $A^TA$:

$$
A^TA=V\Sigma^2V^T.
$$

The singular value decomposition represents every linear map as

$$
\text{orthogonal input coordinates}
\;\longrightarrow\;
\text{nonnegative scaling}
\;\longrightarrow\;
\text{orthogonal output coordinates}.
$$

This works even when eigenvectors are unavailable or inappropriate.

The distinction is structural:

- Eigenvalues require $A:V\to V$, because $Av=\lambda v$ compares vectors in the same space.
- SVD allows $A:V\to W$, with independent orthonormal bases for the input and output spaces.
- Eigenstructure describes repeated application:
  $$A,\;A^2,\;A^3,\ldots$$
- Singular structure describes one-step transfer:
  $$x\mapsto Ax.$$

For non-normal matrices, these questions can produce very different answers. A map can have spectral radius less than one and therefore decay under repeated iteration, while still producing large transient amplification during an individual application.

## 7. Rank is a spectrum, not merely a number

For a consistent system with $n$ unknowns,

$$
\dim(\text{solution set})=n-\operatorname{rank}(A).
$$

Only independent constraints reduce the dimension of the solution set. Repeated or dependent equations add no new restriction.

Exactly,

$$
\operatorname{rank}(A)=\#\{\sigma_i\neq0\}.
$$

Numerically, however, exact rank is unstable: an arbitrarily small perturbation can turn a zero singular value into a nonzero one. The faithful numerical representation is therefore the full singular-value spectrum,

$$
\sigma_1\ge\sigma_2\ge\cdots,
$$

together with a stated tolerance.

A visible gap in the spectrum can justify a numerical-rank decision. Small singular values also measure nearness to rank deficiency, and truncating them gives a principled lower-rank approximation.

## 8. The representation hierarchy

| Question | Structure to preserve | Faithful representation |
|---|---|---|
| Relations among a few vectors | Lengths, angles, and dependence | Their exact span |
| A map acting on vectors | Where input directions are sent | Span of inputs and images |
| A map with an invariant subspace | Closure under the map | The invariant subspace |
| A diagonalizable map | Independent scaling directions | Eigenvector lines |
| A real rotation or complex pair | Rotation without a fixed real axis | An invariant two-plane |
| A non-diagonalizable map | Coupling between directions | Jordan blocks |
| A symmetric map | Orthogonality and scaling | An orthonormal eigenbasis |
| Any linear map | Input-to-output transfer | SVD |
| Coordinate dependence | The chosen coordinates | Coordinate slices |
| Global probability or volume | Whole-space counting structure | Calculation |

Calculation is not a fallback when visualization fails. For concentration of measure or the near-orthogonality of random high-dimensional vectors, calculation is the representation that preserves the relevant global structure.

## 9. What transfers—and what does not

Linear algebra can contribute the idea of **dimension** as the number of independent directions of variation. But applying that idea to a biological or state-based model requires a separate domain claim: the relevant state variables must actually vary independently.

Superposition does not transfer automatically.

Writing

$$
S_t+I_t\to S_{t+1}
$$

does not establish that $S_t$ and $I_t$ belong to the same vector space, or that addition is defined. The more honest notation is

$$
F(S_t,I_t)=S_{t+1}.
$$

From this notation, we may conclude only that linearity has not been established. We may not conclude that the transition is nonlinear, path-dependent, or order-sensitive without evidence from the domain.

$$
\boxed{\text{Not assumed}\neq\text{false}}
$$

That distinction is itself an application of the representation criterion: preserve what has been established, and do not inflate an absence of information into a positive assertion.

## Key takeaway

A representation earns authority only through the relationships it preserves.

Do not ask first, “How can I picture this?” Ask:

> **What structure is relevant here, and which representation preserves exactly that structure?**

The faithful representation may be a low-dimensional span, an invariant subspace, a Jordan block, an SVD, a singular-value spectrum, a coordinate slice, or a calculation. The correct choice is determined by the question—not by the limits of the picture.
