# Agentic Wiring Harness Architecture for a RoPEU Transformer

## Executive summary

The strongest architecture for your RoPEU project is to treat **agentic wiring as a separate control plane that intersects the Transformer data plane at explicitly typed injection points**, rather than trying to encode agency directly into RoPE itself. RoPE should remain the positional geometry mechanism; agentic control should primarily alter token context, layer activations, module routing, or attention scores. This separation preserves compatibility with pretrained RoPE models, makes ablation and auditing possible, and reduces the chance that a control feature silently corrupts long-context positional behaviour. RoPE’s core property is that position-dependent rotations of queries and keys convert absolute positions into relative-position structure in their dot products. citeturn0search0turn1search10

I found **no established primary-source positional encoding named “RoPEU”** corresponding to the term in your prompt. Accordingly, this report uses **RoPEU as a project-local name for a generalized/extended RoPE layer** capable of supporting standard RoPE plus configurable scaling or extension methods. This maps naturally onto the current Hugging Face abstraction, which already distinguishes standard, linear, dynamic/NTK-aware, YaRN, LongRoPE, and Llama-3-style RoPE configurations. citeturn9view0turn6search0turn6search1turn6search2

The research base strongly supports the individual mechanisms needed for such a harness even though “agentic wiring harness” is not itself a standard Transformer term. Discrete control codes were demonstrated by CTRL; prompt tuning and prefix tuning provide token/virtual-token control; adapters, LoRA, and IA³ supply module-level interventions; mixture-of-experts research establishes learned routing; and modern attention APIs allow explicit score modification. citeturn2search0turn3search2turn2search1turn2academia30turn2search2turn3search0turn3search5turn5search2

The three most useful wiring families are:

| Architecture | Control acts on | RoPEU interaction | Training requirement | Runtime overhead | Implementation risk | Recommended role |
|---|---|---|---|---|---|---|
| **Token-level control** | Input/virtual tokens, KV prefixes | Control tokens receive explicit positional policy | Usually PEFT/SFT; discrete text control may work without it | Low–moderate; prefix KV increases cache | Low | Prototype and interpretable control |
| **Module-level control** | Attention/FFN residuals, adapters, gates, LoRA/IA³ | Almost completely orthogonal to RoPEU | PEFT normally required | Very low for scalar/channel gates; moderate adapters | Low–medium | **Primary production control mechanism** |
| **Attention-map modulation** | Pre-softmax attention scores | RoPE remains in Q/K; control adds a score bias afterward | Optional, depending on controller | Potentially very low if fused; potentially high if dense bias materialized | Medium–high | Fine-grained routing and agent memory |
| **Hybrid harness** | All three through typed ABI | RoPEU remains positional substrate | Staged | Configurable | Medium | **Recommended end-state** |

My recommended first production design is therefore **module-level gating + optional control prefixes**, with attention-map modulation introduced only after the base control ABI is stable. Module gating is particularly attractive because it can be initialized as an exact or near-exact no-op, does not require modifying the rotary transform, is compatible with LoRA/IA³-style PEFT, and can often remain outside the fused attention kernel. IA³ itself demonstrates that learned activation scaling can be injected into attention and FFN pathways with extremely few trainable parameters, while LoRA shows that useful layer adaptation can be expressed through low-rank updates without modifying the frozen base weights. citeturn3search0turn4search1turn2search2

A good architectural rule for RoPEU is:

\[
\boxed{\text{position} \neq \text{authority} \neq \text{agent state}}
\]

Do not make position IDs double as agent-control IDs. Keep a typed `ControlState` alongside `position_ids`. That distinction becomes especially important for tool-using or autonomous systems because prompt-injection research demonstrates that untrusted input can redirect agent behaviour; a control channel encoded only as ordinary text is therefore not a security boundary. AgentDojo specifically evaluates prompt injection against tool-using agents, and NIST treats direct and indirect prompt injection as relevant adversarial-ML attack classes for generative systems. citeturn8search0turn8search14

A suitable high-level system is:

```mermaid
flowchart LR
    U[User / Environment] --> TOK[Tokenizer]
    C[Trusted Agent Controller] --> CS[Typed ControlState]

    TOK --> EMB[Token Embeddings]
    EMB --> R[Transformer Stack]
    CS --> H[Agentic Wiring Harness]

    H --> CT[Control / Prefix Tokens]
    H --> MG[Module Gates / Adapters]
    H --> AM[Attention Score Modulation]

    CT --> R
    MG --> R
    AM --> R

    P[Position IDs] --> RU[RoPEU]
    RU --> R

    R --> LM[LM Head]
    LM --> O[Output / Tool Decision]

    O --> C
```

The key point is that `ControlState`, `position_ids`, and ordinary token IDs remain separate objects until the specific Transformer block that consumes them.

## RoPE, RoPEU, and the control-plane abstraction

### Rotary positional encoding

For a rotary head dimension \(d_r\), RoPE partitions query and key channels into two-dimensional pairs. For pair \(i\), position \(m\) rotates a vector through angle

\[
\phi_{m,i}=m\omega_i
\]

with frequencies conventionally distributed geometrically across dimensions. In matrix notation,

\[
q'_m = R_m q_m,\qquad k'_n=R_n k_n.
\]

Because rotation matrices are orthogonal,

\[
(q'_m)^T k'_n
=
q_m^T R_m^T R_n k_n
=
q_m^T R_{n-m} k_n.
\]

Thus the attention interaction naturally contains the relative offset \(n-m\), despite each vector having been rotated according to an absolute position. This is the central construction introduced in RoFormer. citeturn0search0turn1search5

Importantly, being mathematically evaluable at positions longer than the training window does **not** imply reliable long-context extrapolation. Position Interpolation was motivated precisely by poor behaviour beyond trained context lengths; YaRN and LongRoPE subsequently developed more sophisticated RoPE-extension strategies. citeturn6search0turn6search1turn6search2

For implementation purposes, I would define RoPEU as:

\[
\operatorname{RoPEU}(x,p,\mathcal R)
=
R_{\Phi(p;\mathcal R)}x,
\]

where \(\mathcal R\) is a serialized positional regime rather than hard-wired constants.

A useful configuration object is:

```python
@dataclass(frozen=True)
class RoPEUConfig:
    rope_type: str = "default"
    theta: float = 10_000.0
    rotary_fraction: float = 1.0

    # Extension parameters.
    factor: float = 1.0
    original_max_position: int | None = None

    # Project extension/versioning.
    ropeu_version: int = 1
    frequency_policy: str = "standard"
    control_position_policy: str = "ordinary"

    # Strict compatibility mode.
    standard_rope_compatible: bool = True
```

That closely mirrors a useful existing ecosystem boundary: current Transformers exposes RoPE parameters including `rope_type`, `rope_theta`, and partial rotary factors, with support for default, linear, dynamic, YaRN, LongRoPE, and Llama-3 variants. It also supports different RoPE configurations for different layer types. citeturn9view0

### What “agentic wiring harness” should mean technically

I would formalize your term as follows:

> **Agentic wiring harness:** an explicitly versioned control-plane layer through which externally or internally generated control state can affect specified Transformer computations without being conflated with ordinary linguistic context or positional state.

Let

\[
C = \{c_{\mathrm{global}},c_t,c_l,c_{l,h},c_{\mathrm{route}},c_{\mathrm{policy}}\}
\]

represent global, token, layer, head, routing, and policy control signals.

The harness converts these into interventions:

\[
\mathcal H(C)
\rightarrow
\{
E_C,\;
K_C,V_C,\;
g_l,\;
\Delta W_l,\;
B_{l,h,i,j},\;
r_l
\}.
\]

These correspond respectively to:

* control-token embeddings;
* prefix KV states;
* residual/module gates;
* adapter or LoRA updates;
* attention-score modifications;
* expert/submodule routing.

This formulation is not arbitrary. Discrete control codes have been used to condition Transformer generation; learned prompts condition frozen models; prefix tuning injects learned task vectors through Transformer layers; LoRA injects low-rank updates; IA³ scales internal activations; and Switch Transformers route tokens through selected expert modules. citeturn2search0turn3search2turn2search1turn2search2turn3search0turn3search5

The resulting block should conceptually look like this:

```mermaid
flowchart TB
    X[Residual stream h_l]

    X --> N1[RMSNorm]
    N1 --> QKV[Q/K/V projections]
    QKV --> RU[RoPEU on Q and K]
    RU --> ATT[Attention]

    C[ControlState] --> G1[Attention gate]
    C --> B[Attention score policy]
    C --> A[Adapter / LoRA selector]

    B --> ATT
    ATT --> G1
    G1 --> RES1[Residual add]

    X --> RES1
    RES1 --> N2[RMSNorm]
    N2 --> FFN[FFN / MoE]
    C --> G2[FFN gate / router]
    G2 --> FFN
    FFN --> RES2[Residual add]
    RES1 --> RES2

    A --> QKV
    A --> FFN
```

The crucial architectural boundary is **RoPEU remains between Q/K projection and attention**, while most agentic control acts beside or after it.

### Why RoPEU should not become the primary agent channel

One tempting design is to make the controller manipulate rotary phases themselves:

\[
\phi_{t,i}
=
p_t\omega_i+\Delta\phi_i(C).
\]

It is mathematically possible, and recent research continues to explore richer and context-dependent rotary formulations. citeturn0search23turn1search7

I would nevertheless keep this out of the first RoPEU agentic harness.

Changing rotary phase changes the model's **coordinate system for attention**, not merely the importance of information. A gate or bias can be zeroed to return to the original model. A control-dependent positional transform can alter every Q–K interaction involving that state. Long-context research already shows that apparently modest changes to rotary frequency/interpolation schemes can materially alter extrapolation behaviour. citeturn6search0turn6search1turn6search2

Therefore:

\[
\boxed{
\text{RoPEU controls where information is situated;}
\quad
\text{Harness controls what the model should do with it.}
}
\]

Only after the three basic wiring architectures have been characterized would I test **controlled rotary phase modulation** as a fourth experimental family.

## Architectural patterns and concrete wiring designs

### Token-level control

This is the least invasive design and should be your reference implementation.

CTRL showed that explicitly trained control codes can condition generation, while prompt tuning showed that learned soft-token embeddings can condition a frozen language model. Prefix tuning takes the concept deeper by supplying learned vectors to every Transformer layer rather than only adding vectors at the input. citeturn2search0turn3search2turn2search1

There are three versions worth supporting:

\[
\text{discrete token}
\subset
\text{soft input token}
\subset
\text{layerwise KV prefix}.
\]

#### Wiring

```mermaid
flowchart LR
    C[Agent controller] --> CE[Control encoder]

    CE --> P1["<PLAN>"]
    CE --> P2["<TOOL>"]
    CE --> P3["<MODE:k>"]

    U[User tokens] --> CAT[Sequence assembly]
    P1 --> CAT
    P2 --> CAT
    P3 --> CAT

    CAT --> POS[Position assignment]
    POS --> E[Embeddings]
    E --> T[Transformer blocks]

    POS --> R[RoPEU positions]
    R --> T
```

Example logical input:

```text
<CTRL_BOS>
<ROLE:PLANNER>
<TOOL_POLICY:READ_ONLY>
<MEMORY_MODE:RETRIEVE>
<CTRL_EOS>
[user text ...]
```

The tokenizer-visible version is useful for debugging, but **do not make the string representation itself authoritative**. Trusted control IDs should be injected after parsing through a side-band API. Otherwise an attacker can simply place text resembling a control token into untrusted input, a particularly dangerous design in an agent exposed to indirect prompt injection. citeturn8search0turn8search14

#### RoPEU positional handling

Suppose there are \(C\) control tokens followed by \(T\) content tokens.

The cleanest baseline is

\[
p_{\rm ctrl} = [0,\ldots,C-1]
\]

and

\[
p_{\rm text} = [C,\ldots,C+T-1].
\]

For **fixed-frequency standard RoPE**, shifting every original text token by the same constant does not change text-to-text relative offsets:

\[
(C+j)-(C+i)=j-i.
\]

Therefore the theoretical relative-position geometry among the original text tokens is unchanged. This follows directly from RoPE's \(R_{n-m}\) relationship. citeturn0search0

But this equivalence requires care with extended schemes. A length-dependent/dynamic RoPEU implementation may recompute frequency parameters based on the effective sequence length, so pushing the maximum position over a scaling threshold can change more than a simple constant offset. Hugging Face consequently treats dynamic and other scaled variants as distinct RoPE regimes with additional configuration parameters. citeturn9view0

For that reason, expose position policy explicitly:

```python
class ControlPositionMode(Enum):
    ORDINARY_PREFIX = "ordinary_prefix"
    SHARED_ZERO = "shared_zero"
    PRE_ROTATED_KV = "pre_rotated_kv"
    POSITIONLESS_SIDE_CHANNEL = "positionless_side_channel"
```

I recommend `ORDINARY_PREFIX` for actual sequence tokens and `PRE_ROTATED_KV` for layer prefixes.

Do **not** casually use negative positions. They are mathematically definable for sine/cosine RoPE but are outside the normal pretrained position distribution and complicate caches, kernels, serialization, and framework assumptions.

#### Advantages and disadvantages

Token control gives excellent observability and almost no structural model change. Its weakness is that the model has to learn the semantics of those signals indirectly through attention. A critical control command therefore competes with ordinary context.

Layerwise prefix tuning is stronger because virtual vectors are inserted through the stack; current PEFT documentation describes prefix parameters as effectively virtual tokens available across model layers and supports initializing prefix KV state from existing text-derived KV values. citeturn9view3

### Module-level control

This should be the **core RoPEU agentic harness**.

Rather than asking the model to infer a control token's implications, the controller directly changes gains, adapters, or routing paths.

For a pre-norm Transformer:

\[
u_l =
h_l +
g^{(A)}_l(C)\odot
\operatorname{Attn}_l(
\operatorname{Norm}(h_l)
),
\]

\[
h_{l+1}
=
u_l+
g^{(F)}_l(C)\odot
\operatorname{FFN}_l(
\operatorname{Norm}(u_l)
).
\]

The gate can be scalar, per-head, per-channel, or derived dynamically from controller state.

IA³ provides a strong precedent for this kind of intervention: it learns vectors that scale attention and feed-forward activations while leaving the base model frozen. Hugging Face's implementation follows the original scheme by targeting key, value, and feed-forward pathways. citeturn3search0turn4search1

#### Wiring

```mermaid
flowchart LR
    C[ControlState] --> ENC[Control encoder]
    ENC --> GA[Attention gates]
    ENC --> GF[FFN gates]
    ENC --> R[Adapter router]

    H[h_l] --> N1[Norm]
    N1 --> A[QKV]
    A --> RP[RoPEU Q/K]
    RP --> AT[Attention]
    GA --> AT
    AT --> ADD1[Residual]

    H --> ADD1
    ADD1 --> N2[Norm]
    N2 --> F[FFN / Expert bank]
    GF --> F
    R --> F
    F --> ADD2[Residual]
    ADD1 --> ADD2

    ADD2 --> OUT[h_l+1]
```

A practical parameterization is

\[
g_l(C)=1+\epsilon\tanh(W_l C),
\]

which has a natural near-identity state.

For strict backward compatibility, use

\[
W_l=0
\Rightarrow
g_l=1.
\]

Adapters should similarly initialize with zero output:

\[
h' = h + \alpha A_l(h,C),
\qquad
\alpha=0
\]

at initialization.

That gives you an important engineering invariant:

\[
\boxed{
C=C_{\rm null}
\Longrightarrow
f_{\rm RoPEU+harness}(x)
=
f_{\rm base}(x)
}
\]

up to expected floating-point implementation tolerances.

That invariant should become a mandatory unit test.

#### Adapter and LoRA bank

Instead of one adapter:

\[
\Delta W = BA,
\]

use an indexed bank:

\[
\Delta W(C)
=
\sum_{r=1}^{R}
\pi_r(C)B_rA_r.
\]

This creates agentic “submodules” such as:

```text
planner
retriever
tool_selector
code_reasoner
verifier
summarizer
safety_guard
```

LoRA is attractive here because the base model weights can remain frozen while trainable low-rank updates represent task adaptations. citeturn2search2

For initially deterministic routing, I would avoid learned soft mixtures and simply select one or more adapters:

```python
control.adapters = ("planner", "safety")
```

Later:

\[
\pi=\operatorname{softmax}(W_r C)
\]

can provide learned routing.

Switch Transformer provides strong precedent for token-conditioned routing but also demonstrates that hard routing creates optimization/stability issues that must be actively managed. citeturn3search1turn3search5

### Attention-map modulation

This is the highest-control, highest-risk design.

After Q/K projection and RoPEU:

\[
Q'=R(P)Q,\qquad
K'=R(P)K.
\]

Standard attention logits are

\[
S_{b,h,i,j}
=
\frac{
Q'_{b,h,i,:}
K'^{T}_{b,h,j,:}
}{\sqrt{d_h}}
+
M_{i,j}.
\]

Agentic wiring adds:

\[
S'_{b,h,i,j}
=
S_{b,h,i,j}
+
B^{\rm ctrl}_{b,h,i,j}.
\]

Then

\[
A = \operatorname{softmax}(S').
\]

This is architecturally attractive because **RoPEU itself is untouched**. The controller alters the model's selection of information rather than the coordinate transformation that encodes position.

#### Wiring

```mermaid
flowchart TB
    H[h_l] --> QKV[Q K V projection]
    P[position_ids] --> RU[RoPEU]
    QKV --> RU

    RU --> DOT["QK^T / sqrt(d)"]

    C[ControlState] --> CM[Control map generator]
    CM --> B["B_ctrl[b,h,q,k]"]

    MASK[Causal / padding mask] --> SUM[Add]
    DOT --> SUM
    B --> SUM

    SUM --> SM[Softmax]
    QKV --> V[V]
    V --> MUL["A x V"]
    SM --> MUL
    MUL --> O[Attention output]
```

Examples include:

**Memory emphasis**

\[
B_{h,i,j}
=
\begin{cases}
+\beta_h & j\in\mathcal M\\
0 & \text{otherwise}
\end{cases}
\]

**Tool-state isolation**

\[
B_{i,j}
=
-\infty
\]

for prohibited information-flow edges.

**Agent-local attention**

\[
B_{i,j}
=
-\lambda |s_i-s_j|
\]

where \(s_i\) represents an agent/workspace partition.

**Head-specific steering**

\[
B_{b,h,i,j}
=
\gamma_{b,h}f(i,j,C).
\]

The major systems issue is that an arbitrary dense

\[
[B,H,T,T]
\]

bias destroys much of the reason for using FlashAttention in the first place.

PyTorch SDPA accepts an attention mask/bias interface, while FlexAttention explicitly supports user-defined attention-score modification, making it particularly attractive for experimental agentic modulation. citeturn5search1turn5search2

FlashAttention requires more discipline. Its official implementation obtains efficiency by avoiding ordinary attention-matrix materialization; its supported optimized feature set includes structured features such as causal attention, variable sequence lengths, GQA/MQA, rotary embeddings, and in some backends ALiBi and related structured operations. Arbitrary \(T\times T\) control tensors may require a custom kernel rather than dropping transparently into the existing fast path. citeturn9view1

Therefore represent control bias **functionally**, not densely:

```python
def score_mod(score, batch, head, q_idx, kv_idx):
    ...
    return modified_score
```

rather than:

```python
bias = torch.empty(B, H, T, T)
```

whenever possible.

That distinction can change the memory behaviour from conceptually quadratic control state to an \(O(1)\), \(O(T)\), or block-sparse descriptor.

### Recommended hybrid architecture

The three designs are complementary:

```mermaid
flowchart TB
    C[Trusted Controller]
    C --> CT[Semantic control tokens]
    C --> MG[Hard module gates]
    C --> AB[Adapter / LoRA selection]
    C --> BP[Structured attention policy]

    X[Normal token stream] --> STACK[RoPEU Transformer]

    CT --> STACK
    MG --> STACK
    AB --> STACK
    BP --> STACK

    STACK --> Y[Language / tool output]

    Y --> C
```

I would assign responsibilities as follows:

| Function | Best wiring mechanism |
|---|---|
| Explain mode/intent to model | Control token |
| Switch planner/retriever/etc. capabilities | Adapter/LoRA selection |
| Enable/disable internal pathway | Module gate |
| Amplify/suppress a residual pathway | IA³-style channel gate |
| Isolate memory domains | Attention policy |
| Restrict information flow | Attention mask + external policy enforcement |
| Extend context | RoPEU itself |
| Select long-context RoPE regime | RoPEU configuration, **not token text** |
| Select tool permissions | External authority layer + typed harness state |
| Trace agent state | Control ABI/log, not hidden prompt text |

This preserves a clean separation between *semantic signalling*, *neural intervention*, *attention routing*, and *security authorization*.

## Implementation architecture, tensor ABI, and prototype code

### Control-state ABI

Avoid a Python dictionary that changes shape from one experiment to another. Define a versioned structure.

```python
@dataclass
class ControlState:
    abi_version: int

    # [B, C] global controller representation
    global_state: torch.Tensor | None

    # [B, T, C] optional per-token controller state
    token_state: torch.Tensor | None

    # Reserved semantic control IDs injected by trusted code.
    control_token_ids: torch.Tensor | None

    # Adapter/expert IDs.
    route_ids: torch.Tensor | None

    # Optional scalar strengths, normally [B, L] or [B, L, H].
    attention_gate: torch.Tensor | None
    ffn_gate: torch.Tensor | None

    # Structured attention policy rather than dense BxHxTxT tensor.
    attention_policy: "AttentionPolicy | None"

    # Independent positional-policy metadata.
    control_position_mode: str

    # Security/provenance metadata.
    authority_class: int
    regime_id: bytes
```

The ABI rule should be:

> The model must never infer whether a tensor is trusted merely from its value.

Trust/provenance is metadata generated by the calling environment.

### Standard tensor contracts

For a decoder Transformer:

| Tensor | Shape |
|---|---|
| token IDs | `[B,T]` |
| hidden state | `[B,T,D]` |
| Q | `[B,Hq,T,Dh]` |
| K/V with GQA | `[B,Hkv,T,Dh]` |
| position IDs | `[B,T]` |
| RoPE cos/sin | implementation-dependent, conceptually `[B,T,Dr/2]` |
| global control | `[B,C]` |
| token control | `[B,T,C]` |
| layer scalar gates | `[B,L,1]` |
| head gates | `[B,L,H,1]` |
| channel gates | `[B,L,D]` |
| dense attention bias, avoid where possible | `[B,H,Tq,Tk]` |
| prefix K/V | `[B,Hkv,P,Dh]` per layer |

Grouped-query attention must be designed explicitly because many modern models have

\[
H_{KV}<H_Q.
\]

Do not accidentally generate controller gates indexed by query-head count and apply them directly to K/V tensors.

### RoPEU API

A strong positional ABI is:

```python
class RoPEU(nn.Module):
    def forward(
        self,
        q: Tensor,
        k: Tensor,
        *,
        position_ids: Tensor,
        regime: RoPEUConfig,
        cache_position: Tensor | None = None,
    ) -> tuple[Tensor, Tensor]:
        ...
```

The control harness should **not** appear in this call initially.

Instead:

```python
q, k = ropeu(
    q,
    k,
    position_ids=position_ids,
    regime=rope_config,
    cache_position=cache_position,
)

attn_out = attention(
    q,
    k,
    v,
    control=control_state,
)
```

That boundary gives you a clean test of standard-RoPE equivalence.

### KV-cache ABI

Caching is one of the most important design details.

Each cache should carry the positional regime under which its K vectors were generated:

```python
@dataclass
class KVCacheMetadata:
    ropeu_version: int
    rope_regime_hash: bytes
    control_regime_hash: bytes

    # Absolute logical next position.
    cache_position: int

    # Prefix parameters.
    prefix_length: int
    prefix_mode: str

    # Whether cached K is already rotated.
    k_position_state: Literal["raw", "rotated"]
```

Never reuse a KV cache across incompatible RoPEU regimes.

For example:

```text
YaRN factor=8
```

and

```text
standard RoPE
```

may have identical tensor dimensions while representing different K vectors.

A shape check alone cannot catch that.

### Module gate

```python
class AgentGate(nn.Module):
    """Near-identity control gate."""

    def __init__(self, control_dim: int, width: int):
        super().__init__()
        self.proj = nn.Linear(control_dim, width, bias=False)

        # Exact initial identity:
        nn.init.zeros_(self.proj.weight)

    def forward(
        self,
        x: torch.Tensor,          # [B,T,width] or [B,H,T,Dh]
        control: torch.Tensor,    # [B,C]
    ) -> torch.Tensor:
        delta = torch.tanh(self.proj(control))

        if x.ndim == 3:
            # [B,1,width]
            gate = 1.0 + delta[:, None, :]
        elif x.ndim == 4:
            # Example requires `width == H`.
            gate = 1.0 + delta[:, :, None, None]
        else:
            raise ValueError(f"Unsupported tensor rank: {x.ndim}")

        return x * gate
```

The zero initialization ensures the initial gate is exactly one.

### Control-token position assembler

```python
@dataclass
class PackedSequence:
    inputs_embeds: torch.Tensor
    position_ids: torch.Tensor
    attention_mask: torch.Tensor


def prepend_control_embeddings(
    text_embeddings: torch.Tensor,     # [B,T,D]
    control_embeddings: torch.Tensor,  # [B,C,D]
    text_mask: torch.Tensor,           # [B,T]
) -> PackedSequence:
    if text_embeddings.ndim != 3:
        raise ValueError("text_embeddings must be [B,T,D]")

    b, t, d = text_embeddings.shape
    bc, c, dc = control_embeddings.shape

    if (b, d) != (bc, dc):
        raise ValueError("Embedding dimensions do not match")

    x = torch.cat((control_embeddings, text_embeddings), dim=1)

    position_ids = torch.arange(
        c + t,
        device=x.device,
        dtype=torch.long,
    )[None, :].expand(b, -1)

    ctrl_mask = torch.ones(
        (b, c),
        dtype=text_mask.dtype,
        device=text_mask.device,
    )

    mask = torch.cat((ctrl_mask, text_mask), dim=1)

    return PackedSequence(
        inputs_embeds=x,
        position_ids=position_ids,
        attention_mask=mask,
    )
```

### Structured attention modulation

The reference implementation can initially be eager:

```python
class AttentionControl(nn.Module):
    def forward(
        self,
        q: torch.Tensor,           # [B,H,Tq,Dh]
        k: torch.Tensor,           # [B,H,Tk,Dh]
        v: torch.Tensor,           # [B,H,Tk,Dh]
        *,
        causal_mask: torch.Tensor,
        control_bias: torch.Tensor | None = None,
    ) -> torch.Tensor:

        scale = q.shape[-1] ** -0.5
        scores = torch.matmul(q, k.transpose(-2, -1)) * scale

        scores = scores + causal_mask

        if control_bias is not None:
            scores = scores + control_bias

        weights = torch.softmax(scores.float(), dim=-1).to(q.dtype)
        return torch.matmul(weights, v)
```

But this is only the **correctness oracle**, not the production kernel.

PyTorch's SDPA can consume supported masks, while FlexAttention is designed for score-modification functions, making the latter an excellent backend for the experimental attention-control branch. citeturn5search1turn5search2

Production pseudocode therefore looks more like:

```python
def control_score_mod(
    score,
    batch_idx,
    head_idx,
    q_idx,
    kv_idx,
):
    # Example: memory interval [mem_lo, mem_hi)
    in_memory = (
        (kv_idx >= MEMORY_START)
        & (kv_idx < MEMORY_END)
    )

    bonus = torch.where(
        in_memory,
        MEMORY_BONUS[head_idx],
        0.0,
    )

    return score + bonus
```

That formulation avoids constructing a full attention matrix merely to describe the policy.

### Adapter routing

```python
class AgentAdapter(nn.Module):
    def __init__(self, d_model: int, bottleneck: int):
        super().__init__()
        self.down = nn.Linear(d_model, bottleneck, bias=False)
        self.up = nn.Linear(bottleneck, d_model, bias=False)

        # No-op at initialization.
        nn.init.zeros_(self.up.weight)

    def forward(self, x):
        return self.up(F.silu(self.down(x)))


class AdapterBank(nn.Module):
    def __init__(
        self,
        names: list[str],
        d_model: int,
        bottleneck: int,
    ):
        super().__init__()

        self.adapters = nn.ModuleDict({
            name: AgentAdapter(d_model, bottleneck)
            for name in names
        })

    def forward(self, x, active: str | None):
        if active is None:
            return x

        if active not in self.adapters:
            raise KeyError(f"Unknown adapter {active!r}")

        return x + self.adapters[active](x)
```

LoRA is another natural implementation of the same conceptual layer-level wiring and benefits from a very mature PEFT ecosystem. citeturn2search2turn4search4

### Recommended initialization hierarchy

Use increasingly intrusive initializations only when required:

| Mechanism | Initial state |
|---|---|
| Scalar residual gate | `1.0` |
| Channel/head gate | all ones |
| Additive adapter | zero final projection |
| LoRA | standard zero-effective-update initialization |
| Attention bias | zero |
| Soft control token | text-derived or low-magnitude initialization |
| Prefix KV | zero/no-op or text-derived initialization |
| Learned router | deterministic default route initially |
| RoPEU extension | exactly standard RoPE under compatibility configuration |

Current PEFT documentation explicitly supports near-no-op/zero prefix initialization and initialization from an existing textual KV prefix, which makes both useful experimental baselines. citeturn9view3

### Training regimes

I would use four successive regimes rather than jointly training everything.

**Frozen-base harness fitting.** Freeze the entire backbone and RoPEU. Train only control embeddings, gates, adapters, and optionally attention-policy parameters. This follows the PEFT principle represented by prompt tuning, prefix tuning, LoRA, and IA³. citeturn3search2turn2search1turn2search2turn3search0

**Control-discrimination training.** Present identical underlying tasks with different control states:

\[
(x,C_a,y_a),\qquad
(x,C_b,y_b).
\]

This forces the model to use the control path rather than merely infer behaviour from task content.

**Long-context RoPEU adaptation.** Only after agentic control works at normal context length should the long-context positional regime be trained. Position Interpolation, YaRN, and LongRoPE all demonstrate that useful context extension can be achieved with targeted adaptation rather than necessarily re-pretraining an entire model. citeturn6search0turn6search1turn6search2

**Joint stabilization.** Finally unfreeze selected normalization, Q/K/V/O, or FFN components only if necessary.

Do not start by simultaneously changing RoPEU, control tokens, routing, and the entire base model. You would lose causal attribution during failures.

## Evaluation, performance, and framework compatibility

### Evaluation matrix

The harness needs to answer four independent questions:

\[
\text{Does control work?}
\]

\[
\text{Does the uncontrolled model stay unchanged?}
\]

\[
\text{Does RoPEU still work at long context?}
\]

\[
\text{Can untrusted data seize the control channel?}
\]

A single downstream benchmark cannot answer all four.

### Mandatory unit tests

The highest-value tests are deterministic structural tests.

**Null-control equivalence**

```python
y_base = base_model(x, position_ids=p)

y_wired = wired_model(
    x,
    position_ids=p,
    control=NULL_CONTROL,
)

torch.testing.assert_close(
    y_base.logits,
    y_wired.logits,
    rtol=...,
    atol=...,
)
```

Run this at every supported sequence length and dtype.

**Standard-RoPE compatibility**

For:

```text
rope_type = default
factor = 1
control = null
```

require:

\[
Q'_{\rm RoPEU}=Q'_{\rm reference}
\]

and

\[
K'_{\rm RoPEU}=K'_{\rm reference}.
\]

**Constant-position-shift test**

For fixed-frequency RoPE:

\[
S(Q,K,p)
\approx
S(Q,K,p+c)
\]

for text-to-text attention logits, assuming both Q and K positions receive the same offset. This directly tests the expected relative-position property. citeturn0search0

**Cache equivalence**

Compare:

```text
full sequence forward
```

against:

```text
prefill + token-by-token decode
```

for every RoPEU/control combination.

This is especially important for virtual prefixes.

**Control-isolation test**

Change only control state:

```text
same text
same positions
same random seed
different ControlState
```

and ensure precisely the intended intervention tensors change.

**Batch isolation**

Two examples in one batch with different agent states must reproduce separately evaluated results.

This catches accidental broadcasting:

```text
[B,C] -> [1,C]
```

or cross-sample router leakage.

### Agent-control metrics

Useful custom metrics are:

\[
\text{Control Fidelity}
=
P(\text{desired controlled property}\mid C)
\]

\[
\text{Control Leakage}
=
P(\text{controlled behaviour}\mid C_{\rm null})
\]

and

\[
\text{Control Contrast}
=
M(x,C_a)-M(x,C_b).
\]

Also record a **base preservation score**

\[
\Delta_{\rm base}
=
M_{\rm wired,null}-M_{\rm base}.
\]

The objective is not simply maximum control fidelity. It is high fidelity with:

\[
\Delta_{\rm base}\approx0
\]

and low leakage.

IFEval is useful where agent controls correspond to objectively testable output constraints because it was explicitly designed around automatically verifiable instructions rather than subjective LLM judging. citeturn7search2

For a tool-selection controller, add function/tool-call evaluation rather than relying solely on language-model perplexity.

### RoPEU long-context evaluation

At minimum use:

**RULER.** It combines retrieval, multi-hop tracing, aggregation, and QA across increasing context lengths; its creators showed that advertised context capacity can substantially exceed effective task capacity. citeturn7search0turn7search4

**LongBench.** It covers multiple long-context task categories including single- and multi-document QA, summarization, few-shot learning, synthetic tasks, and code. citeturn7search1

**LongBench v2** can be added for harder long-context reasoning; it was designed around deeper long-context understanding and includes contexts extending far beyond ordinary short-context evaluation. citeturn7search13

Also evaluate perplexity versus sequence length and synthetic passkey/retrieval tests, as context-extension work such as Position Interpolation and LongRoPE used these kinds of measurements to separate basic positional viability from downstream utility. citeturn6search0turn6search2

Do not report only a single maximum-context number.

Plot:

\[
M(L),\quad
L\in
\{1K,2K,4K,8K,\ldots,L_{\max}\}.
\]

The area under that degradation curve is more informative than “supports 128K.”

### Critical ablations

Run the following experimentally distinct models:

| Variant | RoPEU | Tokens | Module gates | Adapter | Attention mod |
|---|---:|---:|---:|---:|---:|
| Base | standard | — | — | — | — |
| Positional only | extended | — | — | — | — |
| Token | extended | ✓ | — | — | — |
| Gate | extended | — | ✓ | — | — |
| Adapter | extended | — | — | ✓ | — |
| Attention | extended | — | — | — | ✓ |
| Token + gate | extended | ✓ | ✓ | — | — |
| Gate + adapter | extended | — | ✓ | ✓ | — |
| Full | extended | ✓ | ✓ | ✓ | ✓ |

Also cross:

```text
short context × long context
null control × valid control × conflicting control
trusted control × counterfeit textual control
single-turn × agent loop
```

Without these cross-ablation terms you will not know whether an improvement came from RoPEU or the control harness.

### Complexity and memory

For ordinary self-attention,

\[
QK^T
\]

is fundamentally quadratic in sequence length unless a sparse/structured attention mechanism changes the computation. FlashAttention improves IO and memory behaviour without changing the exact mathematical attention result. citeturn9view1

Approximate incremental costs are:

| Wiring | Parameter cost | Activation/cache cost | Kernel impact |
|---|---|---|---|
| C discrete control tokens | negligible | attention sees `T+C`; KV cache grows by C | None |
| Soft input tokens | `C×D` | same as above | None |
| Layer prefix KV | roughly `L×2×P×Hkv×Dh` values | prefix KV retained | Usually manageable |
| Scalar layer gates | `O(L×C)` | negligible | Outside attention |
| Per-channel gates | `O(L×C×D)` projection or smaller factorization | `O(BLD)` transient | Usually easy to fuse |
| LoRA | `O(r(Din+Dout))` per target | low | Often mergeable |
| Adapter | bottleneck-dependent | extra MLP activations | Extra kernels |
| Dense attention bias | potentially `O(BHT²)` | **dangerous** | Often destroys efficient path |
| Functional score mod | small descriptor | potentially negligible | Backend-dependent |

The dense-bias row is the one to avoid.

### Hugging Face Transformers

Current Transformers has unusually good primitives for this architecture.

Its RoPE utilities already expose multiple RoPE regimes and per-layer-type positional configurations. citeturn9view0

Its PEFT ecosystem supports LoRA, IA³, prompt/prefix approaches, and trainable token indices, so much of the token/module wiring can be implemented without inventing another adapter storage format. citeturn4search1turn4search4turn9view3

Transformers also now exposes an `AttentionInterface` intended to decouple the model from particular optimized attention implementations and permit customized attention functions. citeturn10search0

I would therefore implement:

```text
RoPEU
    -> custom/model-local rotary module

AgenticHarness
    -> ordinary nn.Module

LoRA / IA3 / Prefix
    -> PEFT where compatible

Attention modulation
    -> AttentionInterface / FlexAttention backend
```

rather than forking the entire Llama implementation.

For a novel model class, Transformers' Auto classes support registration of custom configuration/model classes. citeturn10search5

### FlashAttention

The safest compatibility architecture is:

```text
Q/K projection
    ↓
RoPEU
    ↓
FlashAttention
    ↓
attention-output gate
```

A gate **after** the attention kernel does not require modification of its internal score computation.

FlashAttention's current official repository supports modern CUDA GPUs and provides optimized variants; its implementation tests numerical output and gradients against reference PyTorch attention. Its ROCm/Triton backend lists support for rotary embeddings and several structured attention features. citeturn9view1

Thus:

**Excellent compatibility:** control tokens, RoPEU, post-attention gates, LoRA, most adapters.

**Moderate compatibility:** structured masks/biases already supported by the backend.

**Poor compatibility without custom kernel:** arbitrary dynamic \(B\times H\times T\times T\) score modulation.

That should influence your design strongly.

### Triton

Triton becomes useful only after profiling shows harness kernels are materially expensive.

Its documentation emphasizes kernel fusion and custom blocked operations, including fused softmax and high-performance matrix multiplication. citeturn5search4turn5search8

Good fusion targets are:

```text
RMSNorm + control gate
```

```text
adapter activation + up projection
```

or potentially:

```text
RoPEU rotation + Q/K formatting
```

and, much later,

```text
attention score + structured controller modulation
```

Do not write a custom Triton attention kernel before validating the architecture with PyTorch/FlexAttention. You would otherwise mix model-design debugging and GPU-kernel debugging.

### DeepSpeed

Module gates and PEFT adapters are naturally compatible with data parallel and ZeRO because they are ordinary model parameters. DeepSpeed provides ZeRO-style state partitioning and tensor/sequence parallel facilities, and its current documentation includes automatic tensor parallelism for compatible Hugging Face models. citeturn4search7turn4search9turn4search15

With tensor parallelism, decide whether control tensors are:

```text
replicated
```

or

```text
sharded with the affected model dimension.
```

Global control vectors `[B,C]` should normally be replicated.

Head/channel gates should be sharded according to the corresponding Q/K/V/output projection layout.

For very long RoPEU training, sequence parallelism matters. DeepSpeed-Ulysses partitions tensors along the sequence dimension and uses all-to-all communication for distributed attention, specifically targeting very long Transformer sequences. citeturn4search17

### GPU considerations

The preferred path is:

```text
BF16/FP16 base model
+
FP32 controller calculations where numerically sensitive
+
cast gates/biases to model dtype at application point.
```

Keep RoPE frequency/phase generation numerically conservative at long positions. Long-context RoPE behaviour is sensitive to positional calculations, and recent research has specifically investigated numerical problems involving BF16 and long-context rotary computation. citeturn6search32

Consequently I would compute critical trigonometric arguments or cached sin/cos tables in FP32 even when Q/K are BF16, then cast outputs appropriately.

### TPU considerations

The conceptual design carries over to TPU/JAX or PyTorch/XLA, but dynamic Python control flow is a poor fit.

Google's TPU guidance emphasizes static/stable tensor shapes, matrix-heavy computation, and efficient tiling; dynamic shapes and excessive reshape/concatenate-style work can hurt utilization. citeturn5search7turn5search19

Therefore prefer:

```text
fixed control_dim
fixed maximum prefix length
fixed adapter bank dimensions
integer route tensors
mask inactive slots
```

rather than changing tensor shapes whenever an agent selects a different mode.

TPUs are particularly well suited to dense matrix workloads; tiny highly dynamic control operators should therefore be fused or vectorized rather than implemented as many small dispatches. citeturn5search3turn5search7

## Security, safety, and failure modes

### The control channel is an authority boundary

The most consequential architectural recommendation in this report is:

\[
\boxed{
\text{Never encode authoritative agent control solely as prompt text.}
}
\]

Prompt injection has been demonstrated specifically against tool-integrated/agentic systems, and AgentDojo provides a benchmark environment for evaluating such attacks and defenses. citeturn8search0turn8search3

NIST's adversarial-ML taxonomy explicitly covers direct prompting and indirect prompt injection against generative systems, including attacks in which malicious external resources cause models to deviate from the primary user's intended task or expose restricted information. citeturn8search14

Therefore:

```text
user text
retrieved text
web pages
tool outputs
documents
```

must never be allowed directly to construct a trusted `ControlState`.

The secure flow is:

```mermaid
flowchart LR
    EXT[Untrusted context] --> LM[LLM reasoning]

    POLICY[Deterministic authority service] --> CS[Signed / typed ControlState]

    CS --> H[Harness]
    LM --> REQ[Requested transition]

    REQ --> POLICY

    POLICY -->|authorized| CS
    POLICY -->|denied| D[No state change]

    H --> MODEL[Transformer]
```

The LLM may **request** a capability change.

It should not directly grant itself one.

### Counterfeit control tokens

Suppose the model vocabulary contains:

```text
<AGENT_ADMIN>
```

and the user types that exact text.

There must be a distinction between:

```python
tokenizer.encode("<AGENT_ADMIN>")
```

and:

```python
control_plane.inject(ADMIN_TOKEN_ID)
```

The first is untrusted linguistic content.

The second is controller-authorized metadata.

One implementation is to reserve IDs that the normal tokenizer can never emit.

Another is to avoid discrete authority tokens entirely and inject trusted soft embeddings after normal embedding lookup.

### Confused-deputy behaviour

Agentic control may combine:

```text
trusted user objective
untrusted retrieved content
powerful tool capability
```

in the same Transformer.

That produces a classic privilege-confusion problem: the model has to distinguish information from instructions while all appear in the same residual stream.

Attention partitioning can mitigate information flow, but neural masking should not be considered a complete security boundary. NIST's treatment of prompt injection and AgentDojo's results both support assuming that model-level prompt defences are fallible. citeturn8search0turn8search14

Tool authorization should therefore remain outside the model.

### Gate saturation

For:

\[
g=1+\epsilon\tanh(z)
\]

large \(z\) saturates and reduces useful gradients.

Monitor:

```text
gate mean
gate variance
fraction near minimum
fraction near maximum
per-layer gate entropy
```

A controller that drives every gate to its extremes has effectively ceased to provide graded control.

### Adapter interference

With:

\[
\Delta W
=
\sum_r\pi_rB_rA_r,
\]

multiple adapters can interfere destructively.

Initially permit:

```text
zero or one primary adapter
+
one safety adapter
```

rather than arbitrary combinations.

Composition should become an explicit evaluation dimension.

### Router collapse

Learned routing may converge on one frequently useful agent/module and stop exploiting others. Sparse expert routing literature already documents optimization and routing stability as substantive issues. citeturn3search1

Log:

\[
P(\text{route}=r),
\]

routing entropy, overflow/drop rates if applicable, and task-conditional routing.

### RoPE/control entanglement

A particularly subtle failure is:

```text
works at 4K
fails at 64K only when control prefix enabled.
```

Possible causes include:

* prefix positions triggering a different dynamic RoPE regime;
* incorrect cache offsets;
* prefix K being rotated twice;
* control positions being counted differently between prefill and decode;
* head gate dimensions mismatching GQA K/V heads;
* long-position numerical errors.

Hence every context-length experiment should include both:

```text
null control
```

and:

```text
active control.
```

### Control-induced hidden backdoors

A compact adapter or control vector can represent a large behavioural change. That modularity is a feature operationally but also creates a supply-chain surface.

Adapters, prefixes, RoPE regimes, controller weights, and tokenizer/control tables should therefore be immutable versioned artifacts with cryptographic hashes at deployment.

Your supplied Ledger Core architecture is actually well aligned with this need: its emphasis on irreversible ordered records and regime identity suggests using a distinct **model/control regime digest** rather than treating “same base checkpoint” as sufficient identity.

Conceptually:

```text
model_regime =
hash(
    base_checkpoint,
    ropeu_config,
    harness_abi,
    controller_checkpoint,
    adapter_manifest,
    tokenizer/control-token map,
    attention-policy version
)
```

A KV cache, trace, evaluation run, and deployed endpoint should all be attributable to that regime.

### Safety tests

Run AgentDojo or an equivalent tool-agent injection suite once the harness can invoke tools. AgentDojo was explicitly designed to measure both benign task utility and robustness to prompt injection. citeturn8search0

Additionally test:

```text
fake control tokens in user input
fake control tokens in retrieved documents
tool output containing agent commands
adapter-selection attempts in normal text
very long malicious prefix
Unicode/control-token lookalikes
control-state replay
stale controller state
cross-batch state leakage
cross-session KV-cache reuse
unauthorized adapter loading
RoPE-regime mismatch
overflow / NaN controller values
```

The desired security invariant is not:

> “The model usually ignores malicious instructions.”

It is:

> **Untrusted input cannot directly mutate privileged control state, regardless of what the language model predicts.**

That is substantially stronger.

## Migration and deployment roadmap

The following is an engineering estimate rather than a measured benchmark. It assumes one engineer comfortable with PyTorch/Transformers, access to a modest GPU development environment, and an existing decoder-only RoPE model. Larger-model distributed training would increase operational effort considerably.

| Phase | Deliverable | Approx. effort | Primary exit criterion |
|---|---|---:|---|
| Baseline | Standalone RoPEU + reference tests | 3–5 engineer-days | Bit/numerical equivalence with standard RoPE |
| Harness ABI | Typed `ControlState`, null-control path, trace format | 2–4 days | Null harness reproduces base model |
| Token wiring | Reserved/soft tokens + positional policies | 3–5 days | Controlled behaviour demonstrated |
| Module wiring | Gates + adapter/LoRA bank | 5–8 days | Stable no-op init and measurable control |
| Attention wiring | Reference bias implementation + FlexAttention path | 5–10 days | Correctness versus eager implementation |
| PEFT training | Controlled dataset + harness training | 1–2 weeks | High control fidelity, low leakage |
| Long-context | RoPEU scaling/adaptation and RULER/LongBench | 1–3 weeks | Target degradation curve accepted |
| Security | injection, state isolation, cache/regime testing | 1–2 weeks | No direct privilege-channel bypass |
| Optimization | Flash/Triton/DeepSpeed profiling and fusion | 1–3 weeks | Target throughput/latency met |
| Qualification | frozen benchmark + deployment regime | ~1 week | Reproducible signed release |

These phases overlap, so a focused initial research prototype is plausibly a **few-week project**, whereas a well-qualified distributed production implementation is more reasonably a **multi-month engineering programme**.

### Recommended first milestone

Build only this:

```text
Llama-like base
     │
     ├── RoPEU abstraction
     │      └── standard RoPE mode
     │
     ├── ControlState v1
     │      ├── global_state
     │      ├── control token IDs
     │      └── per-layer scalar gates
     │
     ├── Prefix control
     │
     └── null-control equivalence tests
```

Do **not** initially add:

```text
learned routing
attention-map modulation
dynamic RoPE control
multiple simultaneous adapters
tool authority
custom Triton kernels
```

This first milestone answers the foundational question: *can your model receive a distinct, typed agent control channel while preserving the base RoPE model exactly when that channel is disabled?*

### Recommended second milestone

Add module wiring:

```text
global controller [B,C]
       │
       ├── attention head gains
       ├── FFN channel gains
       └── adapter selector
```

Train only these parameters.

Compare:

```text
control-token-only
vs
module-only
vs
token + module
```

This is likely where the strongest cost/benefit result will emerge because IA³, LoRA, adapters, and deep-prefix methods all support the broader premise that small interventions can efficiently steer frozen Transformer backbones. citeturn3search0turn2search2turn2academia30turn3search3

### Recommended third milestone

Introduce attention policies through FlexAttention/reference eager attention:

```text
memory region boost
workspace isolation
agent-specific visibility
```

PyTorch's programmable attention score modification makes this substantially cleaner to prototype now than it would have been with a fixed FlashAttention-only architecture. citeturn5search2

Only after those policies demonstrate real value should you fuse them into Triton or another specialized backend.

### Recommended production architecture

The eventual RoPEU model should expose approximately this ABI:

```python
class RoPEUAgentModel(PreTrainedModel):
    def forward(
        self,
        input_ids=None,
        *,
        attention_mask=None,
        position_ids=None,
        control_state: ControlState | None = None,
        past_key_values=None,
        use_cache=True,
        **kwargs,
    ):
        ...
```

Internally:

```text
Tokenizer
   │
   ▼
Embeddings
   │
   ├──────────── Control Prefix
   ▼
┌───────────────────────────────────┐
│ Transformer Layer l               │
│                                   │
│ Norm                              │
│   ↓                               │
│ Q/K/V                             │
│   ↓                               │
│ RoPEU                             │
│   ↓                               │
│ Attention ← structured policy     │
│   ↓                               │
│ agent attention gate              │
│   ↓                               │
│ residual                          │
│   ↓                               │
│ Norm                              │
│   ↓                               │
│ FFN / adapter / expert            │
│      ↑                            │
│ controller route + gate           │
│   ↓                               │
│ residual                          │
└───────────────────────────────────┘
   │
   ▼
LM / tool-selection head
```

The controller should remain outside that block:

```text
              ┌────────────────────────────┐
              │ Trusted Agent Controller   │
              │                            │
Environment → │ state machine              │
Model output →│ capability policy          │
              │ adapter selection          │
              │ attention policy           │
              └──────────────┬─────────────┘
                             │
                       ControlState
                             │
                             ▼
                     RoPEU Transformer
```

This is the design I would choose for your project.

It gives you a useful hierarchy:

\[
\boxed{
\begin{aligned}
\text{RoPEU} &\rightarrow \text{positional geometry}\\
\text{control tokens} &\rightarrow \text{semantic intent}\\
\text{gates/adapters} &\rightarrow \text{internal capability}\\
\text{attention policy} &\rightarrow \text{information routing}\\
\text{external controller} &\rightarrow \text{authority}
\end{aligned}
}
\]

That separation is the architectural feature most likely to keep the project understandable as it grows.

The positional subsystem can then evolve independently from standard RoPE toward PI, YaRN, LongRoPE, or your own RoPEU extension; the module subsystem can evolve independently toward LoRA/IA³/adapters/MoE; and the control plane can evolve toward richer agent orchestration without forcing every experiment to alter positional mathematics. Existing research and current framework interfaces support each of those boundaries independently. citeturn6search0turn6search1turn6search2turn2search2turn3search0turn10search0

### Open questions and limitations

The largest unresolved research question is whether your eventual RoPEU definition is simply a configurable long-context RoPE implementation or introduces genuinely new rotary mathematics. No externally established “RoPEU” specification was identified, so the recommendations above intentionally make the agent harness independent of that choice.

A second open question is whether attention-map control materially outperforms simpler module gates. It is more expressive, but it also has the highest likelihood of interfering with optimized attention kernels. That should be decided experimentally rather than assumed.

A third is the appropriate granularity of control. Per-layer scalar gates are extremely cheap but coarse; per-head and per-channel gates are richer; per-token/per-head attention control is far richer but creates a much larger optimization and observability space.

Finally, neural control must not be confused with security enforcement. Prompt-injection research and current adversarial-ML guidance support treating model outputs and retrieved context as potentially adversarial; privileged tool access and authority transitions should therefore be mediated outside the Transformer even when the internal harness contains safety-oriented gates or adapters. citeturn8search0turn8search14

The highest-confidence development path is therefore:

\[
\boxed{
\text{RoPEU compatibility}
\rightarrow
\text{typed control ABI}
\rightarrow
\text{module gates}
\rightarrow
\text{prefix/token control}
\rightarrow
\text{long-context qualification}
\rightarrow
\text{structured attention modulation}
\rightarrow
\text{kernel optimization}
}
\]

rather than designing a highly entangled “agentic RoPE” from the outset.