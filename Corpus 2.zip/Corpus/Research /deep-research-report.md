# Critical Evidence-First Review of 100 m and 200 m Sprint Development: Testing a Recurring-Demand “Base + Edge” Framework

## Executive summary

The central question is not whether repeated sprint exposure produces adaptation—it does—but whether **high-speed running can progressively become a frequent, low-volume practice demand whose useful frequency is governed increasingly by technical quality rather than tissue-recovery cost**.

The evidence gives a qualified and fairly restrictive answer.

**[SYNTHESIS]** The strongest model supported by the literature is **progressive sprint specificity under multiple adaptation clocks**, not a single continuum in which submaximal running eventually turns maximal sprinting into an inexpensive everyday skill. Sprint mechanics change continuously with speed, but transfer across velocity domains is incomplete: faster running shortens contact time, raises the rate at which force must be expressed, changes force orientation, increases hamstring activation, and ultimately creates mechanical states that slower running does not reproduce. Weyand et al. showed that higher maximal speeds are distinguished principally by greater mass-specific ground support forces during shorter contacts; Morin and colleagues showed that acceleration performance is strongly related to effective horizontal force orientation; Higashihara et al. found a significant rise in hamstring activation going from 85% to 95% of maximal running speed even where several kinematic variables changed relatively little. citeturn11search0turn11search2turn11search6turn23search1

**[DIRECT EVIDENCE]** Sprint work can be distributed more frequently without losing adaptation. The clearest sprint “microdosing” experiment, Cuadrado-Peñafiel et al. (2023), distributed sprint training across more weekly sessions in field-hockey players and obtained sprint improvements comparable with a conventional distribution. Marzouki et al. similarly found that equal sprint volume performed once versus twice weekly improved linear sprint performance without a frequency advantage. These are genuine intervention data, but neither study involved elite 100/200-m sprinters, daily maximal-velocity sprinting, or a Base + Edge progression. Cuadrado-Peñafiel's intervention also redistributed rather than truly reduced the total weekly sprint dose. citeturn20search0turn20search2turn20search11turn20search22

**[UNKNOWN]** I found no controlled trial showing that daily or near-daily flying sprints, maximal accelerations, hill sprints, assisted runs, or >95% maximum-sprint-speed exposures outperform conventional 2–3-session sprint programming in trained 100/200-m specialists. The literature is much stronger on sprint *training methods* than on sprint *frequency as an independent variable*, and Haugen et al.'s synthesis of elite sprint science explicitly identifies the experimental evidence base as being dominated by non-elite and team-sport athletes. citeturn19search0turn19search1

**[MECHANISTIC EVIDENCE]** Bone biology provides perhaps the best mechanistic support for short, distributed loading bouts. Robling et al. demonstrated in animal bone that mechanosensitivity falls rapidly during continued loading and recovers during rest; dividing the same number of loading cycles into multiple bouts produced greater bone formation than concentrating them into one bout. Human jumping studies also show that relatively few high-impact cycles can increase bone mineral density. This supports the *principle* that additional contacts within a bout exhibit diminishing skeletal returns and that distributed loading can be biologically meaningful. It does **not** establish a sprint-contact prescription, an optimal daily sprint frequency, or a velocity threshold for tibial/femoral adaptation. Robling et al. (2001, *J Exp Biol*, DOI `10.1242/jeb.204.19.3389`); Robling et al. (2002, *Med Sci Sports Exerc*, DOI `10.1097/00005768-200202000-00003`). citeturn16search1turn16search2

**[DIRECT EVIDENCE]** Tendon evidence is more troublesome for the framework. In controlled human Achilles-tendon experiments, Arampatzis et al. found adaptation after ~4.55% tendon strain but not ~2.85% despite similar loading volume; Bohm et al. subsequently showed that strain magnitude, loading duration and frequency materially affect adaptation. These protocols used controlled muscular contractions rather than millisecond sprint contacts. Human tendon collagen synthesis rises after exercise and can remain elevated for multiple days. Consequently, the fact that an athlete feels recovered from a 10-second sprint exposure says little about completion of tendon remodelling. Arampatzis et al. (2007, *J Exp Biol*, DOI `10.1242/jeb.003814`); Bohm et al. (2014, *J Exp Biol*, DOI `10.1242/jeb.112268`); Miller et al. (2005, *J Physiol*, DOI `10.1113/jphysiol.2005.093690`). citeturn17search0turn18search2turn18search11

**[OBSERVATIONAL]** Injury evidence argues against both extremes. In elite sprinting, hamstring injury is the dominant diagnosis in recent epidemiological work. In field sports, abrupt increases in high-speed-running exposure predict hamstring injury risk, whereas sufficiently regular exposure to near-maximal velocity has sometimes been associated with lower subsequent injury risk. Thus high-speed exposure is simultaneously a potentially injurious acute stress and a specific preparation for future high-speed stress. Duhig et al. (2016, *Br J Sports Med*, DOI `10.1136/bjsports-2015-095679`) found that transient increases above an athlete's accustomed high-speed load were more informative than absolute high-speed distance alone. citeturn24search3turn24search9turn24search25

**[SYNTHESIS]** This leaves a version of Base + Edge standing, but not the strongest version proposed. What survives is:

> **Frequent, low-fatigue sprint-related practice can form a base; acceleration and maximal-velocity exposures should have separate ledgers; higher-velocity exposures can be introduced progressively; and some regular contact with the upper velocity range is probably necessary rather than withholding it indefinitely.**

What does **not** survive is:

> **A technically normalized exposure can be assumed to have become structurally cheap, or that enough accumulation at lower velocity proves a reserve against maximal sprint loading.**

The athlete's neural/technical ledger, muscle ledger, tendon ledger and bone ledger can all move at different rates. That is the most important correction to the original framework. citeturn18search1turn16search2turn19search0

The target athlete level and exact percentage thresholds were unspecified in the prompt. Accordingly, percentages below should be regarded as analytical ranges rather than prescriptions.

## Performance determinants and event-specific mechanics

The scientific literature does not support a single master determinant of sprint performance. World-class sprinting appears when many interacting qualities are expressed correctly during task-specific contacts.

| Determinant | What the evidence supports | Causal confidence |
|---|---|---|
| Acceleration | Rapid increase in velocity depends strongly on forward-oriented ground-force production and the ability to maintain useful force orientation as velocity rises. Morin et al. (2011, *Med Sci Sports Exerc*) and Morin et al. (2012, *Eur J Appl Physiol*, DOI `10.1007/s00421-012-2379-8`). citeturn11search6turn0search3 | **[MECHANISTIC EVIDENCE]** strong |
| Maximum velocity | Faster athletes apply greater support forces during shorter contacts; elite 100-m performance is strongly associated with maximum velocity. Weyand et al. 2000, DOI `10.1152/jappl.2000.89.5.1991`; elite-race analysis of 82 sprinters. citeturn11search0turn19search9 | **[MECHANISTIC EVIDENCE] + [OBSERVATIONAL]** strong |
| Horizontal force | Especially important during acceleration; the ability to orient resultant force rearward/horizontally predicts acceleration better than simply producing a large resultant force. citeturn11search6turn23search0 | **[MECHANISTIC EVIDENCE]** strong |
| Vertical/support force | Increasingly critical as ground-contact time falls at high speed; top-speed differences cannot be explained simply by faster leg repositioning. citeturn11search0turn11search2 | **[MECHANISTIC EVIDENCE]** strong |
| Ground-contact time | Shortens as speed rises and is strongly related to maximal-speed capability, but artificially minimizing contact time is not itself a valid intervention because sufficient impulse must still be generated. citeturn11search0turn10search16 | **[MECHANISTIC EVIDENCE]** strong relationship; causation conditional |
| Step length | Contributes mathematically to velocity but is not independently “the” determinant; studies differ in whether step length discriminates performance level. citeturn0search3turn10search16 | **[OBSERVATIONAL]** moderate |
| Step frequency | Faster sprinting is often associated with higher frequency/shorter temporal variables, but step length–frequency solutions differ between athletes. citeturn0search3turn19search14 | **[OBSERVATIONAL]** moderate |
| Leg/vertical stiffness | Associated with rapid force transmission and sprint ability, but higher stiffness is not universally better and isolated stiffness measures are not proven causes of elite performance. citeturn10search18turn19search14 | **[OBSERVATIONAL] + [MECHANISTIC EVIDENCE]** moderate |
| Elastic storage/return | Achilles and plantar-flexor structures play an important role in rapid locomotion; tendon properties affect muscle–tendon behaviour. Evidence that “more elastic return” independently causes faster sprinting is weaker than the general mechanism. citeturn18search2turn17search0 | **[MECHANISTIC EVIDENCE]** moderate |
| Rate of force development | Mechanically relevant because available contact time is extremely short; isolated RFD measures correlate with sprint qualities but are not equivalent to sprint-specific RFD. citeturn10search11turn10search18 | **[OBSERVATIONAL] + [SYNTHESIS]** moderate |
| Eccentric strength | Hamstring eccentric capability is associated with sprint mechanics and injury-related variables; sprint and eccentric training can alter architecture. citeturn9search3turn10search18 | **[DIRECT EVIDENCE]** for trainability; causal sprint-performance role moderate |
| Concentric strength | Resistance-based training improves sprint performance on average, especially acceleration, but strength gain and sprint gain are not interchangeable. citeturn13search5turn13search14 | **[DIRECT EVIDENCE]** moderate |
| Isometric strength | Isometric strength correlates with short acceleration performance in sprinters, particularly men in one study, but this does not establish isometric strength as a limiting cause. Brady et al. 2020, *IJSPP*, DOI `10.1123/ijspp.2019-0151`. citeturn10search11 | **[OBSERVATIONAL]** moderate/weak |
| Fascicle length | Sprinters tend to possess longer fascicles in relevant muscles; sprint training itself can increase biceps-femoris-long-head fascicle length. Mendiguchia et al. 2020, *PLOS ONE*, DOI `10.1371/journal.pone.0228283`. citeturn1search4turn9search3 | **[DIRECT EVIDENCE]** for adaptation; causal performance role uncertain |
| Muscle architecture | Pennation, fascicle length and muscle size influence mechanical capability, but much elite evidence is cross-sectional and therefore mixes adaptation with selection/genetics. citeturn1search4turn19search0 | **[OBSERVATIONAL]** moderate |
| Tendon properties | Tendon stiffness and morphology adapt to mechanical loading and affect rapid force transmission, but the optimum tendon phenotype for sprinting is not reducible to “maximum stiffness”. citeturn17search0turn18search2 | **[DIRECT EVIDENCE]** for adaptation; **[SYNTHESIS]** for sprint optimum |
| Neural drive | Sprint training depends on extremely high activation and coordination; neural measures have associations with sprint performance, but direct manipulation demonstrating that one neural variable controls elite sprint speed is lacking. citeturn13search1turn10search18 | **[OBSERVATIONAL] + [MECHANISTIC EVIDENCE]** |
| Intermuscular coordination | Hamstring, plantar-flexor, quadriceps and hip-extensor roles change throughout the stride and with velocity; near-maximal running exhibits speed-dependent activation patterns. citeturn23search1turn23search16 | **[MECHANISTIC EVIDENCE]** strong |
| Technique | Force direction, touchdown geometry, swing mechanics and posture matter mechanically. The optimal technical solution varies between individuals, so technical models should not be treated as rigid templates. citeturn11search6turn10search16turn19search14 | **[MECHANISTIC EVIDENCE] + [OBSERVATIONAL]** |
| Anthropometry | Morphology constrains the solution available to an athlete, but simple indices such as BMI or leg-length ratios have not consistently explained 100-m performance. citeturn0search3turn19search0 | **[OBSERVATIONAL]**; simple causal claims weak |

The practical implication is important. **[SYNTHESIS]** A program aimed predominantly at increasing squat strength, fascicle length, stiffness, RFD or step frequency is not thereby a complete sprint program. These are enabling capacities. The competition task is the integration of those capacities during contacts on the order of a fraction of a second. Resistance training can improve sprinting, but transfer is smaller and less consistent than the improvement in the strength exercise itself, which is precisely what specificity predicts. citeturn13search5turn13search14turn19search0

**Acceleration versus maximal velocity.** The distinction is substantial enough that collapsing both into a single “sprint dose” is a programming error.

| Dimension | Acceleration | Maximum velocity | Provenance |
|---|---|---|---|
| Primary mechanical problem | Increase centre-of-mass velocity; large propulsive impulse and effective backward force application | Maintain velocity while generating sufficient support impulse in extremely short contacts | **[MECHANISTIC EVIDENCE]** citeturn11search6turn11search0 |
| Force orientation | Larger horizontal component early | Net horizontal acceleration approaches zero; rapid vertical/support force becomes dominant | **[MECHANISTIC EVIDENCE]** citeturn11search6turn11search0 |
| Posture | Marked forward projection/lean, gradually rising | Upright high-speed posture | **[MECHANISTIC EVIDENCE]** citeturn23search0turn19search0 |
| Contact time | Longer early and progressively shorter | Shortest contacts of sprint | **[MECHANISTIC EVIDENCE]** citeturn11search0turn0search6 |
| Hamstrings | Major role in horizontal-force production; hip extension important | Very high activation in late swing plus demanding stretch/shortening and transition into stance | **[MECHANISTIC EVIDENCE]** citeturn23search0turn23search1 |
| Plantar flexors/Achilles | Increasing contribution as athlete rises and contacts shorten | High-rate support/propulsive transmission central | **[MECHANISTIC EVIDENCE]** citeturn23search16turn17search0 |
| Neural/coordination problem | Changing mechanics every step as velocity rises | Highly repeatable cyclic solution at very short temporal constraint | **[SYNTHESIS]**, supported by biomechanical phase differences citeturn19search0turn23search8 |
| Typical injury concern | High force, aggressive hip extension, slips/start loading | Hamstring injury concern especially salient because high-speed late-swing demands rise markedly | **[MECHANISTIC EVIDENCE] + [OBSERVATIONAL]** citeturn23search1turn24search9 |
| Training specificity | Starts, short accelerations, resisted work can preferentially target this phase | Flying runs and sufficiently long buildups required to expose actual maximal-speed mechanics | **[DIRECT EVIDENCE] + [COACHING PRACTICE]** citeturn0search8turn19search0 |

**[SYNTHESIS]** If a Base + Edge model is used, acceleration and maximal velocity should therefore have **separate Base and Edge variables**. A 10–20 m sled acceleration cannot be entered in the same biological/technical ledger as a 20 m fly at 98% MSS merely because both are short sprints. The velocities, contact characteristics, hamstring conditions and force orientations are different. citeturn0search8turn23search0turn23search1

**The 100 m versus the 200 m.** Both events depend heavily on maximal sprint speed, but the 200 m adds curve mechanics, longer maintenance of near-top velocity, a much larger fatigue component and greater metabolic perturbation.

**[OBSERVATIONAL]** In 82 elite male 100-m sprinters, maximum velocity was nearly perfectly related to most 20-m race splits; the exception was the initial 0–20 m, emphasizing that maximum velocity and early acceleration are related yet separable qualities. citeturn19search9

**[MECHANISTIC EVIDENCE]** The 200 m is more glycolytically and aerobically involved than the 100 m. Duffield, Dawson and Goodman measured 100- and 200-m track running and found both predominantly anaerobic but with greater aerobic involvement as event duration increased. Exact percentages depend heavily on the estimation method and should not be treated as fixed physiological constants. Duffield et al. 2004, *J Sci Med Sport*, DOI `10.1016/S1440-2440(04)80025-2`. citeturn22search3turn22search7

**[MECHANISTIC EVIDENCE]** Curve running is not mechanically identical to straight sprinting. Centripetal-force requirements create leg-specific force solutions, and maximal velocity falls as curve radius becomes more restrictive. Diaz et al. (2024) directly demonstrated radius- and leg-dependent effects on maximal velocity and ground-reaction forces; Millot et al. (2024) likewise reported altered ground-reaction-force behaviour on the curve. Diaz et al., *J Exp Biol*, DOI `10.1242/jeb.246649`; Millot et al., *Scand J Med Sci Sports*, DOI `10.1111/sms.14602`. citeturn23search3turn23search35

**[OBSERVATIONAL/DIRECT N=1 EVIDENCE]** Pacing also matters. Yoshimoto et al. (2025) analysed elite 200-m racing and intervened with an elite Japanese sprinter; redistributing effort to preserve the latter part of the race was associated with a performance improvement from 20.43 to 20.14 s. That is intriguing, but a single-athlete intervention does not establish a universal pacing prescription. DOI `10.3389/fspor.2025.1657245`. citeturn3search1turn3search5

Thus the shared 100/200 core is acceleration, maximal velocity, sprint-specific strength/power and technical skill. **[SYNTHESIS]** The 200-m specialist additionally needs substantial exposure to curve sprinting, high-speed contacts accumulated after the acceleration phase, speed endurance and technical preservation under fatigue. The amount required is individualized and remains inadequately established experimentally. citeturn19search0turn23search3turn22search3

## Practice frequency, microdosing, and velocity progression

**Sprinting is a skill, but that statement is easy to abuse.**

**[MECHANISTIC EVIDENCE]** Sprint execution depends on precisely timed coordination under rapidly changing constraints. Hamstring activation changes with velocity; force orientation changes throughout acceleration; individual athletes achieve similar outputs using meaningfully different mechanical profiles. These facts justify treating sprinting partly as a motor skill rather than merely a strength test. citeturn23search1turn11search6turn19search14

**[MECHANISTIC EVIDENCE]** General motor-learning literature often finds advantages to distributing practice, particularly when concentrated practice produces fatigue or deteriorating execution. Lee and Genovese's classic meta-analytic work also showed that the massed-versus-distributed effect depends on task type; distributed practice does not universally dominate for every motor task. Applying that literature directly to maximal sprinting would therefore be an extrapolation, because sprint practice itself constitutes a major musculoskeletal stressor. citeturn14search0turn14search9

The key distinction is:

\[
\text{frequent sprint-skill practice}
\;\neq\;
\text{frequent maximal-velocity tissue exposure}
\]

**[SYNTHESIS]** Submaximal buildups, starts, wicket/rhythm tasks, drills and technically controlled fast runs may allow frequent rehearsal of portions of the sprint solution. They cannot be assumed to reproduce maximal-speed force, contact-time or hamstring demands. citeturn11search0turn23search1turn19search0

**Direct sprint-frequency evidence**

| Study / method | Population and design | Finding relevant to Base + Edge | What it does **not** prove |
|---|---|---|---|
| Cuadrado-Peñafiel et al. 2023, *Sensors*, DOI `10.3390/s23020650` | Field-hockey players; six-week distributed/microdosed versus traditional sprint distribution | **[DIRECT EVIDENCE]** More frequent distribution produced useful sprint adaptation and was not inferior to the conventional arrangement. citeturn20search0turn20search2 | Does not test elite track sprinters, daily maximum velocity or progressively normalized Base + Edge. Total sprint volume was redistributed, not meaningfully eliminated. |
| Marzouki et al. 2021, *Biology of Sport*, DOI `10.5114/biolsport.2020.97675` | 36 young male soccer players; equal volume once vs twice weekly for 10 weeks | **[DIRECT EVIDENCE]** Both improved sprint tests; no between-frequency effect for linear sprinting/flying 10 m. citeturn20search11turn20search16 | Does not establish an advantage to higher sprint frequency. |
| Alcaraz et al. 2018, *Sports Med*, DOI `10.1007/s40279-018-0947-8` | Systematic review/meta-analysis of resisted-sled sprint interventions | **[DIRECT EVIDENCE]** Resisted sprint training can improve acceleration; effects on maximum-velocity performance were much less convincing. citeturn0search8 | Does not test resisted-sprint microdosing or daily resisted work. |
| Xu et al. 2025 resisted-sprint meta-analysis, DOI `10.1111/sms.70182` | 49 studies, 1,281 athletes across sports | **[DIRECT EVIDENCE]** Resisted sprinting has a modest advantage over unresisted training overall, especially in early acceleration. citeturn0search10 | Does not show a frequency advantage or elite-100/200-specific effect. |
| Assisted/overspeed sprint studies | Acute studies include body-weight support and assisted sprint conditions | **[MECHANISTIC EVIDENCE]** Assistance can acutely increase velocity and alter contact/step characteristics. Kratky & Müller 2013, DOI `10.1519/JSC.0b013e3182654a30`. citeturn10search8turn0search12 | Chronic superiority, safe microdose frequency and injury implications remain **[UNKNOWN]**. |

**[UNKNOWN]** No adequate experimental evidence was found for **daily or near-daily maximal flying runs in trained 100/200-m sprinters**. The same is true for near-daily microdosed short hills, daily assisted sprinting, daily >95% MSS exposures and “one fly every day” protocols. Their use may exist in coaching practice, but documented practice does not upgrade them to direct evidence. Haugen et al.'s review explicitly notes that much experimental sprint science is conducted in young/team-sport athletes rather than world-class sprinters. citeturn19search0turn19search2

**The 5–20-second unit.** There is no evidence that ten seconds is physiologically privileged.

| Bout duration | Likely dominant training problem | Main limitation |
|---|---|---|
| ~5 s from blocks/standing | **[MECHANISTIC EVIDENCE]** Mostly acceleration for even very fast athletes; relatively few/no sustained MSS contacts. citeturn19search9turn0search6 | Poor unit for quantifying maximum-velocity exposure |
| ~8–10 s | **[SYNTHESIS]** Can include acceleration plus a small maximal/near-maximal segment depending on ability and run-in | Same duration represents very different mechanical exposures in athletes of different speed |
| ~10–15 s | **[MECHANISTIC EVIDENCE]** Increasingly mixed alactic/glycolytic demand; a 15-s maximal sprint already has measurable aerobic contribution, reported around 8–12% in one contemporary study. citeturn22search0 | No longer a purely neural/max-speed exposure |
| ~15–20 s | **[MECHANISTIC EVIDENCE]** Greater PCr depletion, glycolytic contribution and emerging velocity loss/fatigue. 100/200-m energetics illustrate the change as event duration expands. citeturn22search3turn22search21 | Becomes speed-endurance training rather than pure MSS practice |

Consequently, **[SYNTHESIS]** a better sprint dose descriptor is multidimensional:

\[
D =
\{\text{start mode},\;
\text{peak velocity},\;
\text{metres above velocity threshold},\;
\text{high-speed contacts},\;
\text{rep count},\;
\text{recovery},\;
\text{velocity loss}\}
\]

A “10-second exposure” alone does not say whether the athlete performed ten seconds of acceleration, four seconds at >95% MSS, six seconds of fatigued speed endurance, or a submaximal rhythm run. citeturn19search9turn22search3

**Progressive velocity normalization.** The hypothesis survives partly.

**[MECHANISTIC EVIDENCE]** Mechanics evolve continuously rather than through a single binary jog/sprint switch. As speed increases, ground-contact time generally falls, support-force demands increase, and muscle activation changes. This makes gradual velocity progression biologically plausible. citeturn11search0turn11search2turn23search1

However, the literature also supplies a strong warning against treating the continuum as mechanically homogeneous. Higashihara et al. found that increasing treadmill speed from 85% to 95% of maximum significantly increased biceps-femoris and semitendinosus activation during late swing even though many kinematic variables did not change significantly. In other words, a movement can **look** very similar while its neuromuscular demand becomes substantially larger. Higashihara et al. 2010, *J Sports Sci*. citeturn23search1turn23search5

### Velocity-demand chart

The bands below are **descriptive bins, not validated biological thresholds**, and are intended for upright/flying running. Acceleration from rest presents a different force-vector problem. No credible literature permits a numerical injury probability to be assigned to these bands. citeturn11search0turn23search1turn24search3

| Relative running velocity | Contact time | Support-force / rapid-force demand | Hamstring late-swing demand | Per-contact injury risk |
|---|---|---|---|---|
| <75% MSS | Longer | Lower | Lower | **[UNKNOWN]**; no validated curve |
| ~75–85% MSS | ↓ | ↑ | ↑ | **[UNKNOWN]** |
| ~85–95% MSS | ↓↓ | ↑↑ | Marked rise; 85→95% activation increase demonstrated | **[UNKNOWN]**; increasing mechanical specificity |
| >95% MSS | Shortest | Highest/near-highest | Maximal-speed-specific | **[OBSERVATIONAL]** high-speed exposure is both a stressor and, when regularly tolerated, potentially protective preparation |

Supporting mechanics: Weyand et al. 2000/2010; hamstring velocity-response: Higashihara et al. 2010. Injury literature does **not** establish a monotonic velocity→injury function. citeturn11search0turn11search2turn23search1turn24search3turn24search25

Therefore **90% or 95% MSS should not be described as a discovered biological switch**. Those thresholds are often operational definitions used in high-speed-running monitoring. The underlying biological response is almost certainly continuous and athlete-specific. citeturn24search3turn24search21

**[SYNTHESIS]** A progression such as

\[
80\%\rightarrow85\%\rightarrow90\%\rightarrow93\%\rightarrow96\%+
\]

is defensible as a load-management strategy, but not because each percentage is a proven adaptation stage. Its rationale is simply to avoid large jumps while retaining eventual specificity. A critical requirement is that actual upper-end running cannot be postponed indefinitely: repeated 85% running does not prove readiness for 100%, nor can it reproduce the 95–100% neuromuscular problem. citeturn23search1turn19search0

## Structural adaptation, bone, tendon, and injury

This is where the recurring-demand hypothesis most needs separate ledgers.

**Muscle and fascicle architecture.**

**[DIRECT EVIDENCE]** Mendiguchia et al. compared sprint training with Nordic-hamstring training in footballers. Six weeks of sprint training increased biceps-femoris-long-head fascicle length and improved several sprint-mechanical variables; sprinting therefore acts as a specific structural stimulus, not merely a nervous-system practice. Mendiguchia et al. 2020, *PLOS ONE*, DOI `10.1371/journal.pone.0228283`. citeturn9search3

**[OBSERVATIONAL]** Longer fascicles and greater eccentric knee-flexor capacity have also been associated with lower hamstring-injury risk in prospective athletic cohorts, but association is not proof that a given fascicle target prevents injury in sprinters. citeturn9search1turn9search5

**[SYNTHESIS]** Muscle is therefore one of the better candidates for genuine adaptation to recurrent sprint exposure, but even here the dose-response across sprint velocity, weekly contacts and frequency remains insufficiently mapped.

**Tendon: magnitude, time and recovery matter.**

Arampatzis et al.'s experiment is particularly important because the exercise volume was similar while Achilles-tendon strain differed.

**[DIRECT EVIDENCE]** After 14 weeks, the leg trained around **4.55 ± 1.38% tendon–aponeurosis strain** showed increased stiffness and related adaptations; the low-strain condition around **2.85 ± 0.99%** did not show the same mechanical adaptation. Arampatzis et al. 2007, *Journal of Experimental Biology* 210:2743–2753, DOI `10.1242/jeb.003814`. citeturn17search0turn17search2

That finding is often described casually as a “4–5% tendon threshold”. That is too strong.

**[DIRECT EVIDENCE]** It establishes a threshold-like effect **within that particular controlled Achilles-loading protocol**. It does not establish that 4.5% is a universal threshold across tendons, individuals, loading rates, sprint contacts or training states. citeturn17search0

**[DIRECT EVIDENCE]** Bohm et al. subsequently compared high-strain protocols while manipulating strain rate and duration. Their work reinforces that tendon adaptation depends not only on peak loading but on how strain is applied over time. The reference condition used ~6.5% strain, four sessions/week, with approximately three seconds loading and three seconds relaxation. Bohm et al. 2014, *J Exp Biol*, DOI `10.1242/jeb.112268`. citeturn18search0turn18search2

This attacks a simple contact-count model:

\[
\text{tendon stimulus}
\neq
f(\text{number of foot contacts}) \text{ alone}.
\]

A sprint ground contact may have enormous force and high strain rate but extremely short loading duration. There is no experiment showing that ten 90-ms sprint contacts produce the same tendon adaptation as ten controlled 3-s high-strain contractions.

**[UNKNOWN]** Therefore the minimum number of maximal-sprint contacts required to increase Achilles or patellar-tendon stiffness is unknown. So is whether a three-second flying sprint segment constitutes an adequate tendon-remodelling dose.

**[MECHANISTIC EVIDENCE]** Miller et al. directly measured human patellar-tendon collagen synthesis after strenuous exercise. Synthesis was elevated by six hours, peaked around 24 hours and declined toward baseline over subsequent days, remaining elevated at later measurements. Miller et al. 2005, *J Physiol*, DOI `10.1113/jphysiol.2005.093690`. citeturn18search1turn18search11

Hence:

\[
\text{“I feel fresh today”}
\not\Rightarrow
\text{“my tendon has finished responding to yesterday's load.”}
\]

**[SYNTHESIS]** Complementary high-load isometric/slow resistance work remains rational even in a sprint-heavy program because it supplies a controllable magnitude-and-duration tendon stimulus that sprint contacts cannot currently be shown to supply optimally. citeturn17search0turn18search2

**Bone: the most interesting evidence for distributed loading.**

Bone mechanobiology is unusually compatible with one portion of the Base concept.

**[MECHANISTIC EVIDENCE — ANIMAL]** Bone does not continue gaining equal osteogenic benefit with every additional loading cycle. Mechanosensitivity falls within a bout. Robling et al. experimentally demonstrated recovery of mechanosensitivity when loading bouts were separated by rest; longer intervals restored more responsiveness. Their rat-ulna work found approximately eight hours sufficient for complete recovery under that experimental condition. Robling et al. 2001, *J Exp Biol* 204:3389–3399, DOI `10.1242/jeb.204.19.3389`. citeturn16search2

**[MECHANISTIC EVIDENCE — ANIMAL]** In a second experiment, 360 daily loading cycles delivered as four bouts of 90 separated by three hours produced greater bone adaptation than the same 360 cycles delivered continuously. Robling et al. 2002, *Med Sci Sports Exerc* 34:196–202, DOI `10.1097/00005768-200202000-00003`. citeturn16search1

The biological interpretation is:

\[
\text{osteogenic return per contact}
\downarrow
\quad \text{as repetitive loading accumulates within a bout}.
\]

**[MECHANISTIC EVIDENCE]** Bone also responds strongly to loading rate, magnitude and novelty; high-rate loading can be disproportionately osteogenic compared with repetitive low-rate loading. Sprinting therefore has characteristics that are *plausibly* osteogenic. But most elegant strain-rate and bout-saturation experiments are animal studies rather than sprint-training studies in humans. citeturn6search1turn16search2

**[DIRECT EVIDENCE — NON-SPRINT HUMAN]** Human jumping studies show that small numbers of high-impact jumps performed repeatedly over weeks can raise site-specific bone mineral density, supporting the broader principle that thousands of loading cycles are not necessary for skeletal adaptation. citeturn8search1turn8search7

But the translation boundary needs to be hard:

**[UNKNOWN]** There is no validated conversion from rat-ulna strain cycles or human jumping contacts to:

- metres above 95% MSS;
- sprint contacts per session;
- number of sprint days per week;
- required tibial strain;
- required femoral strain;
- or a minimum effective sprint velocity.

Similarly, no useful field measure tells a coach that a tibia is “now 30% overbuilt” relative to sprint demand.

**[UNKNOWN]** Minimum effective bone strain in an individual elite sprinter cannot currently be inferred from speed percentage, absence of soreness or successful session completion.

This is especially important because:

\[
\text{absence of bone pain}
\neq
\text{evidence of positive bone remodelling}.
\]

Stress adaptation and stress injury both develop before symptoms necessarily provide a useful capacity estimate.

**Cartilage and joint structures.**

**[UNKNOWN]** Sprint-specific longitudinal evidence for articular-cartilage adaptation is extremely sparse. Running studies using MRI demonstrate acute biochemical cartilage changes and generally fail to support the crude claim that running automatically destroys healthy cartilage, but those studies largely involve distance running, not maximal sprint contacts. They cannot determine the optimum sprint frequency for knee, ankle or hip cartilage. citeturn23search2turn23search6turn23search10

Therefore sprint-dose prescriptions for cartilage, pelvis, femoral head or other joint structures should remain **[UNKNOWN]**, rather than borrowing conclusions from tendon or bone.

**The major injury paradox.**

Recent elite-sprint epidemiology reports hamstring muscle injury as the most frequent diagnosis, accounting for roughly 31% of injury complaints in one elite sprint cohort. Achilles, calf and other lower-limb problems also contribute substantially to track-and-field injury burden. Edouard et al. 2023. citeturn24search9turn24search6

The causes cannot be reduced to “high force”.

| Candidate contributor | Evidence interpretation |
|---|---|
| Absolute sprint force/speed | **[MECHANISTIC EVIDENCE]** Higher speed raises relevant hamstring and lower-limb demands; this creates opportunity for failure but does not alone predict who gets injured. citeturn23search1turn23search25 |
| Rapid increase in high-speed exposure | **[OBSERVATIONAL]** Stronger support. Duhig et al. found transient increases above accustomed HSR associated with HSI risk. citeturn24search3 |
| Excessive high-speed exposure | **[OBSERVATIONAL]** Large acute loads relative to chronic preparation can be risky; there is no universal maximum-safe metre count. citeturn24search3turn24search25 |
| Insufficient high-speed exposure | **[OBSERVATIONAL]** Some football data associate regular near-MSS exposure or higher chronic high-speed preparation with lower subsequent risk. Causality remains uncertain. citeturn24search21turn24search25 |
| Fatigue | **[MECHANISTIC EVIDENCE]** Repeated sprinting alters performance and neuromuscular capacity, making tired contacts mechanically different from fresh contacts. citeturn22search17turn22search31 |
| Previous injury | **[OBSERVATIONAL]** A consistently identified background risk factor in hamstring literature, although exact risk depends on sport/population. citeturn24search0 |
| Eccentric weakness / architecture | **[OBSERVATIONAL]** Associated with injury risk; intervention evidence supports eccentric hamstring training broadly, but not a single protective threshold. citeturn9search1turn9search5 |
| Sprint technique | **[OBSERVATIONAL/MECHANISTIC]** Certain kinematic patterns have prospective associations with injury, but evidence is far from a deterministic “bad technique causes HSI” model. citeturn9search14turn23search4 |
| Training distribution | **[SYNTHESIS]** Probably matters insofar as it changes fatigue, acute spikes and contact quality; direct elite-sprinter RCT evidence is absent. citeturn20search0turn24search3 |

The apparent contradiction is therefore real but logical:

\[
\text{high-speed running}
=
\text{specific stressor}
+
\text{specific preparation for that stressor}.
\]

**[SYNTHESIS]** Avoiding >95% running indefinitely may preserve the athlete from today's high-speed stress while leaving them poorly prepared for tomorrow's race. Conversely, inserting a large amount abruptly because “high-speed exposure is protective” misreads observational injury research. The probable target is **regular, progressive exposure without abrupt excursions beyond accustomed capacity**. citeturn24search3turn24search21turn24search25

## Base-and-Edge framework under evidence pressure

The framework becomes more useful when each assumption is attacked separately.

| Framework proposition | Critical verdict |
|---|---|
| Adaptation follows recurring demands | **Survives, weak form. [SYNTHESIS]** Specific tissues and motor systems adapt to repeated loading/practice, but adaptation is not monotonic and each system has different dose-response and recovery behaviour. citeturn17search0turn16search2 |
| Maintain a stable Base and accumulate occurrences | **Partly survives. [SYNTHESIS]** Stable practice may improve coordination and tolerance, but biological accommodation can reduce incremental stimulus; identical loading cannot be assumed to remain adaptive indefinitely. Bone desensitization is a concrete example. citeturn16search1turn16search2 |
| Progress when the demand becomes ordinary | **Does not survive as a sole criterion. [SYNTHESIS]** Technical ease is evidence about the fast/observable ledger, not proof of tendon, bone or cartilage readiness. citeturn18search11turn16search2 |
| Progressively normalize faster running | **Survives with restrictions. [MECHANISTIC EVIDENCE + SYNTHESIS]** Velocity progression is plausible and avoids abrupt jumps, but mechanics/demand do not transfer perfectly; near-maximal exposure is eventually required. citeturn23search1turn11search0 |
| Keep a small Edge above the Base | **Plausible, not directly established. [SYNTHESIS]** It may preserve exposure specificity without dominating total load, but the optimal Edge frequency/intensity is unknown. |
| One controlled faster single can maintain the high end | **[UNKNOWN]** No convincing study establishes one repetition as the minimum effective dose for maximal-velocity skill or acceleration maintenance in trained sprinters. |
| Repeating a fixed demand builds large structural reserve | **[UNKNOWN]** Successful repetition shows tolerance to the completed demand, not the magnitude of reserve above it. |
| Frequent tiny sprint exposures outperform concentrated ones structurally | **[UNKNOWN]** Bone mechanism makes the idea plausible; tendon biology does not provide equivalent support; track-sprint trials do not exist. citeturn16search1turn18search2 |
| Eventually sprint practice can be governed mainly by skill quality rather than recovery | **Not established. [UNKNOWN]** Relative cost can presumably fall with adaptation, but maximal sprinting remains intrinsically high-rate mechanical loading. No longitudinal evidence demonstrates recovery ceasing to be a major constraint. |

**Base accumulation and accommodation.** The framework's strongest insight is the separation between **fast normalization and slow tissue adaptation**.

One useful model is:

\[
\begin{aligned}
L_\text{technical}&=\text{coordination, perceived effort, repeatability}\\
L_\text{neuromuscular}&=\text{activation, force expression, fatigue}\\
L_\text{muscle}&=\text{strength/architecture/remodelling}\\
L_\text{tendon}&=\text{matrix and mechanical-property adaptation}\\
L_\text{bone}&=\text{remodelling and stress tolerance}\\
L_\text{joint}&=\text{largely unmeasured}
\end{aligned}
\]

**[SYNTHESIS]** The framework fails whenever improvement in \(L_\text{technical}\) is treated as measurement of \(L_\text{tendon}\) or \(L_\text{bone}\). Human tendon synthesis and animal bone mechanosensitivity data directly show why these ledgers need not share a time course. citeturn18search11turn16search2

**Repeated-bout effects** further complicate progression. Repeated exposure can reduce muscle damage from a familiar eccentric stress, which may make a session feel increasingly inexpensive. That is a real adaptation, but it does not establish equivalent protective adaptation in tendon, bone and cartilage. Therefore the subjective cheapness of a fixed sprint dose can be genuine **and still be biologically incomplete**.

**Controlled non-maximal singles.** This is one of the most plausible yet least tested elements.

**[SYNTHESIS]** One high-quality 95% fly can certainly expose the athlete to mechanics absent at 80%; one controlled 20-m acceleration can preserve familiarity with force direction better than doing no acceleration at all. That follows from specificity. But:

\[
\text{nonzero useful exposure}
\neq
\text{minimum effective maintenance dose established}.
\]

**[UNKNOWN]** There is no adequate evidence that one weekly fly, one daily fly, one acceleration, or some specific count preserves maximal-velocity skill. The relevant studies generally compare full training programs rather than one-repetition maintenance doses. citeturn19search0

**Structural margin.** This is the weakest part of the proposed theory if defined strongly.

Suppose an athlete can run 10.5 m/s but trains mostly at 9.2 m/s for twelve weeks and remains healthy.

What is established?

**[OBSERVATIONAL AT THE INDIVIDUAL LEVEL]** The athlete tolerated the work performed.

What is not established?

**[UNKNOWN]**

\[
\text{tendon failure margin},
\quad
\text{bone fatigue margin},
\quad
\text{hamstring failure margin},
\quad
\text{cartilage reserve}.
\]

Deliberately slower progression is still sensible, but for a narrower reason.

**[SYNTHESIS]** It reduces the rate of demand increase and supplies additional calendar time for slow tissues to respond. It does **not** provide a direct measurement of how much reserve was created. That distinction is exactly analogous to engineering proof loading: surviving one operating load demonstrates survival at that load, not an unknown ultimate factor of safety.

**Elite coaching practice.** Haugen et al.'s extensive integration of science and best practice shows that successful sprint programs commonly separate acceleration, maximal velocity, speed endurance, technical work, strength/power and lower-intensity running while manipulating intensity and recovery according to session purpose. Their central conclusion is also sobering: high-level coaching practice is much richer than the experimental evidence used to justify it. Haugen et al. 2019, *Sports Medicine - Open*, DOI `10.1186/s40798-019-0221-0`. citeturn19search0turn19search17

A 2024 survey of elite Spanish sprint coaches similarly found widespread technical work, distinct acceleration/max-velocity emphasis and planned transitions toward competition specificity. These observations are informative but remain **[COACHING PRACTICE]**, not causal proof. citeturn19search13

The evidence therefore favours not one Base + Edge system but at least:

\[
\boxed{\text{Acceleration Base + Acceleration Edge}}
\]

\[
\boxed{\text{Maximum-Velocity Base + Maximum-Velocity Edge}}
\]

plus

\[
\boxed{\text{Strength / Tendon / Bone Support}}
\]

and for 200 m,

\[
\boxed{\text{Curve + Speed-Endurance Layer}}.
\]

That is **[SYNTHESIS]**, not an experimentally validated architecture.

## Experimental programme to distinguish the models

The existing literature cannot decide the central question because most studies change training method, volume and frequency simultaneously, use team-sport athletes, and last too little time to answer structural questions. citeturn19search0turn20search0

A decisive first study should isolate **distribution** while holding the important dose variables as equal as practically possible.

**Proposed multi-centre RCT**

| Element | Proposed design |
|---|---|
| Population | Trained national/sub-elite 100/200-m sprinters. World-class-only recruitment is unrealistic for adequate statistical power. Athlete level in the original hypothesis was unspecified. |
| Arms | **Conventional:** 2–3 concentrated sprint exposures/week. **Distributed:** same weekly acceleration distance, same metres >90/>95% MSS, same total contacts, but spread across 5–6 micro-sessions. **Base + Edge progression:** frequent stable submaximal Base plus separately governed upper-velocity Edge, with progression after predefined exposure blocks rather than subjective readiness alone. |
| Duration | Minimum ~9 months; ideally 12–18 months for structural outcomes. |
| Strength program | Standardized/matched across groups. |
| Sprint dose matching | Weekly acceleration metres, flying metres, >90% MSS metres, >95% MSS metres, estimated high-speed contacts and speed-endurance distance recorded separately. |
| Performance outcomes | Electronic 10/20/30-m splits, 30–60-m/flying velocity, 100 m, 200 m, curve split, speed-decrement metrics. |
| Mechanics | Force plates/instrumented treadmill where available, high-speed video, contact time, step length/frequency, force orientation, velocity–time curves. |
| Muscle | BFlh fascicle length, knee-flexor eccentric/isometric strength, plantar-flexor strength, optional MRI/ultrasound architecture. |
| Tendon | Achilles and patellar-tendon stiffness, strain, CSA, ultrasound tissue characterization. |
| Bone | DXA plus tibial/femoral pQCT/HR-pQCT or MRI where feasible; bone-turnover markers only as secondary outcomes because they cannot substitute for structural imaging. |
| Injury | Time-loss and medical-attention definitions; hamstring/Achilles/calf/foot/bone injury separately classified. |
| Recovery | CMJ/force metrics, subjective soreness/readiness, session RPE, velocity decrement, optional neuromuscular tests. |
| Main hypothesis | Distributed practice permits more consistently high-quality contacts and equal/better sprint development without higher injury burden. |
| Structural hypothesis | Base + Edge produces equal/better tendon/bone/muscle adaptation despite smaller session-level peaks. |
| Falsification criterion | If concentrated training gives equal or greater performance and structural adaptation at equal injury burden—or Base + Edge fails to preserve MSS—the proposed architecture loses its rationale. |

**Power considerations.** **[SYNTHESIS]** A world-class-only RCT is almost certainly underpowered because the population is tiny and between-athlete heterogeneity enormous. A realistic first definitive trial would probably require roughly 30–40 athletes per arm across multiple national training centres, with repeated-measures modelling and pre-registered smallest worthwhile changes. That number is a **design target, not a calculated final power estimate**: final sample size should be established by simulation using measurement error and within-athlete SD from the exact timing/imaging system. Elite sprint changes are small enough that measurement reliability and wind/environmental control are central design problems; Haugen's monitoring work and elite-development review emphasize these limitations. citeturn19search0turn19search11

**Proposed experimental timeline**

```mermaid
gantt
    title Base + Edge versus conventional sprint-development trial
    dateFormat  YYYY-MM-DD
    axisFormat  %b

    section Screening
    Athlete screening and familiarisation     :a1, 2027-01-01, 28d
    Baseline sprint/structural testing         :a2, after a1, 14d

    section Foundation
    Matched preparatory training               :b1, after a2, 42d

    section Intervention
    Randomised sprint programming Block A      :c1, after b1, 56d
    Mid-block testing                           :milestone, m1, after c1, 0d
    Block B                                     :c2, after c1, 56d
    Structural reassessment                    :milestone, m2, after c2, 0d
    Block C                                     :c3, after c2, 56d
    Competition-specific block                 :c4, after c3, 56d

    section Outcomes
    Final laboratory and sprint testing        :d1, after c4, 14d
    Competition performance window             :d2, after d1, 42d
    Structural follow-up                       :d3, after d2, 28d
```

Five experiments would resolve the most important uncertainties.

**Volume-equated distribution experiment — [DIRECT TEST NEEDED].** Randomize trained sprinters to identical weekly metres and high-speed contacts concentrated into two sessions versus distributed across five. This isolates whether frequency/distribution itself changes sprint performance, mechanical quality, recovery and injury.

**Velocity-normalization experiment — [DIRECT TEST NEEDED].** Over several months, compare gradual exposure through predefined MSS bands with conventional immediate near-maximal sprint exposure while equalizing eventual >95% MSS dose. Measure hamstring EMG, contacts, kinetics, architecture and performance. This tests whether “normalizing faster slices” creates adaptation that transfers upward rather than merely delaying specificity.

**Minimum-upper-edge-dose experiment — [DIRECT TEST NEEDED].** After a standardized maximal-speed development phase, randomize athletes during maintenance to zero, one, three or six high-quality >95% MSS repetitions weekly with otherwise identical training. This would determine whether a “single” has measurable maintenance value.

**Distributed-structure experiment — [DIRECT TEST NEEDED].** Match weekly sprint contacts but compare one large structural loading bout with three/five small bouts. Serial Achilles/patellar ultrasound, tendon stiffness, tibial imaging and bone markers would test whether the animal-bone distributed-loading result translates to human sprinting and whether tendon responds similarly or differently.

**Slow-progression/structural-margin experiment — [DIRECT TEST NEEDED].** Compare performance-led velocity progression with a deliberately delayed progression schedule while ultimately reaching the same sprint exposure. Follow athletes for ≥12 months. A genuine “reserve margin” argument requires evidence of greater structural properties and/or fewer future injuries—not merely fewer injuries during the deliberately easier buildup.

The experimentally useful definition of Base + Edge should therefore be falsifiable:

\[
\textbf{Base + Edge wins only if it increases the amount or quality of useful long-term sprint exposure}
\]

while producing equal or better:

\[
\text{performance + tissue adaptation + availability}
\]

than a conventional program.

Simply demonstrating that athletes can tolerate it is insufficient.

## Final synthesis and prioritized bibliography

**What would the evidence-supported minimum architecture for developing a world-class sprinter look like?**

**[SYNTHESIS]** At minimum: regular sprint-specific acceleration; genuine near-maximal/maximal-velocity running; event-specific speed endurance; sprint-compatible strength/power training; plyometric/reactive exposure; sufficient hamstring and plantar-flexor preparation; and programmed recovery. For the 200 m, add curve-specific sprinting and substantially more speed-endurance/race-distribution work. These components should be governed separately because their mechanical and recovery demands differ. There is no evidence-supported single “10-second base unit” that replaces this architecture. citeturn19search0turn11search6turn23search3turn22search3

**Which qualities benefit from frequent practice?**

**[DIRECT EVIDENCE + SYNTHESIS]** Sprint coordination, submaximal-to-fast technical running and acceleration-related work can plausibly be distributed frequently when the per-session dose is small; direct team-sport studies show sprint volume can be spread over more weekly sessions without sacrificing improvement. Motor-learning evidence also favours distribution when concentrated practice creates deterioration. What remains unproven is that the same frequency principle extends without qualification to daily maximal-speed sprinting. citeturn20search0turn20search22turn14search0

**Which qualities require larger recovery intervals?**

**[MECHANISTIC EVIDENCE + SYNTHESIS]** Large maximal-velocity volumes, speed endurance, repeated maximal accelerations and substantial strength/plyometric workloads cause greater neuromuscular and/or structural disturbance. Tendon remodelling markers remain elevated well beyond subjective recovery. The exact interval cannot be prescribed universally, but the evidence does not support treating all sprint contacts as independent low-cost skill trials. citeturn18search11turn22search17turn24search3

**What can safely be inferred when a sprint exposure becomes technically easy?**

**[SYNTHESIS]** The athlete has probably become more familiar, coordinated and acutely tolerant of that exact demand. If velocity, mechanics and next-day function remain stable, that is useful evidence that the *observable performance ledger* has normalized.

It is **not** direct evidence of slow-tissue reserve.

**What cannot be inferred about tendon or bone?**

**[UNKNOWN]** Technical ease does not tell you tendon strain capacity, tendon remodelling completeness, tibial/femoral fatigue resistance, bone mechanosensitivity or an injury factor of safety. Neither absence of soreness nor successful repetition measures those properties. citeturn17search0turn18search11turn16search2

**Is there evidence for progressively making high-speed running an ordinary recurring demand?**

**[SYNTHESIS]** There is evidence for progressive sprint exposure, frequent sprint-related practice, specific adaptation to sprinting and distributed sprint training. There is **not direct evidence** for the stronger proposition that near-maximal/maximal sprinting can be made a near-daily, structurally inexpensive practice in elite 100/200-m athletes. That endpoint remains **[UNKNOWN]**. citeturn20search0turn19search0turn9search3

**What is the strongest evidence against that approach?**

Three findings carry the most weight.

First, **velocity specificity**: hamstring activation rises substantially as running approaches maximum, and maximal-speed force/contact conditions cannot be reproduced by simply accumulating slower running. citeturn23search1turn11search0

Second, **tissue-timescale mismatch**: tendon matrix synthesis and structural adaptation operate over much longer periods than technical familiarity or perceived recovery. citeturn18search11turn17search0

Third, **accommodation/saturation**: at least in bone, merely repeating more identical cycles within the same exposure does not provide proportional adaptation; biological responsiveness itself changes with loading history and recovery. citeturn16search1turn16search2

These findings make “it has become ordinary, therefore intensify” an unsafe general progression rule.

**Which parts of Base + Edge survive?**

**[SYNTHESIS]** Five pieces survive reasonably well:

1. Repeated, recoverable sprint-specific practice is valuable.
2. Velocity can be progressed rather than introduced as an all-or-none event.
3. A small amount of higher-specificity exposure while most work is less costly is plausible.
4. Acceleration and maximum velocity need separate Base/Edge ledgers.
5. Progression should account for exposure history, not simply today's performance.

What does not survive is the assertion that technical normalization proves structural normalization, that one Edge repetition is known to be sufficient, that daily maximal exposure is eventually optimal, or that a large unobserved structural margin can be inferred from failure-free training.

**What experiments distinguish Base + Edge from conventional programming?**

The five decisive tests are: equal-volume distributed-versus-concentrated sprinting; gradual velocity normalization versus conventional upper-end exposure; a dose-response trial for one/few maximal-velocity “singles”; distributed-versus-concentrated sprint loading with tendon/bone imaging; and a long-term delayed-progression trial measuring actual structural adaptation and injury—not merely tolerance.

The most defensible overall model is therefore:

\[
\boxed{
\text{Frequent low-cost specific practice}
+
\text{regular but separately dosed high-specificity sprinting}
+
\text{independent structural preparation}
}
\]

rather than:

\[
\boxed{
\text{accumulate enough ordinary running until maximal sprinting becomes ordinary}
}.
\]

The first formulation fits the evidence. The second remains an interesting research hypothesis.

**Prioritized bibliography**

**Weyand PG, Sternlight DB, Bellizzi MJ, Wright S. 2000. *Journal of Applied Physiology*. “Faster top running speeds are achieved with greater ground forces not more rapid leg movements.” DOI `10.1152/jappl.2000.89.5.1991`.** Foundational maximal-velocity biomechanics. **[MECHANISTIC EVIDENCE]** citeturn11search0turn11search1

**Weyand PG et al. 2010. *Journal of Applied Physiology*. “The biological limits to running speed are imposed from the ground up.” DOI `10.1152/japplphysiol.00947.2009`.** Force/contact-time constraints at maximum speed. **[MECHANISTIC EVIDENCE]** citeturn11search2

**Morin JB et al. 2011. *Medicine & Science in Sports & Exercise*. “Technical ability of force application as a determinant factor of sprint performance.”** Central evidence on force orientation during acceleration. **[MECHANISTIC EVIDENCE]** citeturn11search6

**Morin JB et al. 2012. *European Journal of Applied Physiology*. “Mechanical determinants of 100-m sprint running performance.” DOI `10.1007/s00421-012-2379-8`.** Integrates force orientation, frequency and 100-m performance. **[OBSERVATIONAL/MECHANISTIC]** citeturn0search3

**Haugen T, Seiler S, Sandbakk Ø, Tønnessen E. 2019. *Sports Medicine - Open*. “The Training and Development of Elite Sprint Performance.” DOI `10.1186/s40798-019-0221-0`.** Most useful synthesis connecting experimental science with documented elite coaching practice. **[COACHING PRACTICE + REVIEW]** citeturn19search0turn19search17

**Higashihara A et al. 2010. *Journal of Sports Sciences*. “Functional differences in the activity of the hamstring muscles with increasing running speed.”** Critical evidence that moving from 85% to 95% can materially increase hamstring activation. **[MECHANISTIC EVIDENCE]** citeturn23search1

**Morin JB et al. 2015. “Sprint acceleration mechanics: the major role of hamstrings in horizontal force production.”** Links posterior-chain function to acceleration mechanics. **[MECHANISTIC EVIDENCE]** citeturn23search0

**Mendiguchia J et al. 2020. *PLOS ONE*. “Sprint versus isolated eccentric training…” DOI `10.1371/journal.pone.0228283`.** Direct evidence that sprint training changes hamstring architecture. **[DIRECT EVIDENCE]** citeturn9search3

**Cuadrado-Peñafiel V et al. 2023. *Sensors*. “Microdosing Sprint Distribution as an Alternative to Achieve Better Sprint Performance in Field Hockey Players.” DOI `10.3390/s23020650`.** Most directly relevant sprint-distribution intervention. **[DIRECT EVIDENCE]** citeturn20search0turn20search2

**Marzouki H et al. 2021. *Biology of Sport*. “Effects of 1 vs. 2 sessions per week of equal-volume sprint training…” DOI `10.5114/biolsport.2020.97675`.** Important frequency-control experiment. **[DIRECT EVIDENCE]** citeturn20search16turn20search22

**Alcaraz PE et al. 2018. *Sports Medicine*. Systematic review/meta-analysis of resisted-sled sprint training. DOI `10.1007/s40279-018-0947-8`.** Strongest general evidence for resisted acceleration training. **[DIRECT EVIDENCE]** citeturn0search8

**Arampatzis A, Karamanidis K, Albracht K. 2007. *Journal of Experimental Biology*. “Adaptational responses of the human Achilles tendon by modulation of the applied cyclic strain magnitude.” DOI `10.1242/jeb.003814`.** Key human tendon dose-response experiment. **[DIRECT EVIDENCE]** citeturn17search0turn16search4

**Bohm S, Mersmann F, Tettke M, Kraft M, Arampatzis A. 2014. *Journal of Experimental Biology*. “Human Achilles tendon plasticity in response to cyclic strain: effect of rate and duration.” DOI `10.1242/jeb.112268`.** Critical evidence that tendon dose cannot be reduced to peak force or repetition count. **[DIRECT EVIDENCE]** citeturn18search0turn18search2

**Miller BF et al. 2005. *Journal of Physiology*. “Coordinated collagen and muscle protein synthesis in human patella tendon and quadriceps muscle after exercise.” DOI `10.1113/jphysiol.2005.093690`.** Important recovery/remodelling time-course evidence. **[MECHANISTIC EVIDENCE]** citeturn18search1turn18search11

**Robling AG et al. 2001. *Journal of Experimental Biology*. “Recovery periods restore mechanosensitivity to dynamically loaded bone.” DOI `10.1242/jeb.204.19.3389`.** Foundational distributed-loading bone study; animal model. **[MECHANISTIC EVIDENCE]** citeturn16search2

**Robling AG et al. 2002. *Medicine & Science in Sports & Exercise*. “Shorter, more frequent mechanical loading sessions enhance bone mass.” DOI `10.1097/00005768-200202000-00003`.** Strong mechanistic case for separating skeletal-loading bouts; animal model. **[MECHANISTIC EVIDENCE]** citeturn16search1

**Duffield R, Dawson B, Goodman C. 2004. *Journal of Science and Medicine in Sport*. “Energy system contribution to 100-m and 200-m track running events.” DOI `10.1016/S1440-2440(04)80025-2`.** Direct event-specific energetics. **[MECHANISTIC EVIDENCE]** citeturn22search3turn22search7

**Diaz GB et al. 2024. *Journal of Experimental Biology*. “Maximum velocity and leg-specific ground reaction force production change with radius during flat curve sprinting.” DOI `10.1242/jeb.246649`.** Key 200-m curve-mechanics evidence. **[MECHANISTIC EVIDENCE]** citeturn23search3

**Duhig S et al. 2016. *British Journal of Sports Medicine*. “Effect of high-speed running on hamstring strain injury risk.” DOI `10.1136/bjsports-2015-095679`.** Important evidence that *changes relative to accustomed high-speed exposure*, not simply absolute high-speed distance, matter. **[OBSERVATIONAL]** citeturn24search3

**Edouard P et al. 2023. “Epidemiology of Injury Complaints in Elite Sprinting Athletes.”** Sprint-specific injury epidemiology, with hamstrings the dominant diagnosis. **[OBSERVATIONAL]** citeturn24search9

Taken together, these studies point toward a sprint-development model in which **exposure is progressively normalized, but specificity is never abolished; frequency can rise when dose is distributed intelligently, but high velocity remains a distinct mechanical stimulus; and structural readiness must be treated as partly hidden rather than inferred from how easy the sprint feels.** The evidence presently supports recurring sprint exposure far more strongly than it supports the claim that maximal sprinting can ultimately become an everyday, recovery-light skill.