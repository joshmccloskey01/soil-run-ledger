# Deep Research: “Yves Gravelle” Trading Training — and the Axia Futures Order-Flow Education It Is Likely Confused With

## TL;DR

- **No verifiable evidence exists of a futures trader or trading educator named “Yves Gravelle.”** Extensive searching finds only one prominent person by that name — a Canadian strongman, arm-lifting world champion and V15 rock climber from Ottawa — with zero connection to trading. The premise that “Yves Gravelle” is a Canadian futures trader affiliated with Axia Futures could not be substantiated from any primary or third-party source.
- **The order-flow/scalping training the query describes matches Axia Futures**, a London-based trading-education firm, and its known scalper personalities — most notably **Fabio Valentini** (an Italian NQ scalper) and internal figures such as co-founder Demetris Mavrommatis and head trainer Richard Bailey. If the user encountered “Yves Gravelle” in marketing, it is most likely a name error, a pseudonym, or a fabricated attribution.
- **Axia’s education is real, detailed and moderately well-reviewed, but its verified P&L is essentially absent.** Independent reviewers (TradingSchools.org, Elite Trader) have criticised the firm for charging thousands while declining to produce audited trading statements. Course prices are not published on Axia’s own site; third-party listings suggest roughly £4,500–£6,000 (≈ $3,500–$4,000). Prospective students should treat all performance claims as unverified marketing until shown broker/exchange statements.

## Key Findings

### 1. The identity problem

- **“Yves Gravelle” (the famous one) is not a trader.** His own Instagram bio reads: “Athlete Climbing/ Arm-lifting/ Arm Wrestling 3x APL Arm-lifting World Champion.”  IronMind, quoting referee Eric Roussin, describes him as “a 37-year-old Canadian rock climber specializing in bouldering… 8 times member of the Canadian Bouldering National team, has climbed V15, holds multiple Class World records in Armlifting, and 3 APL World titles… the lightest person to have successfully lifted the famous Thomas-inch Dumbbell.” He is based in Ottawa/Orleans, Ontario. Multiple independent sources (Lattice Training, The Nugget Climbing Podcast, IronMind, Bloc Shop) corroborate this athletic identity. None mention trading.
- **No futures trader named Yves Gravelle could be found** in any search combining the name with “trader,” “futures,” “order flow,” “scalping,” “Axia,” or “prop trading.” A dedicated verification pass confirmed zero credible results connecting anyone of that name to trading or to Axia Futures.
- **Conclusion:** The name is most likely a mistaken attribution / name-conflation, a marketing pseudonym, or a fabrication. The user should verify exactly where “Yves Gravelle trading training” was seen — it may be a scam using a borrowed name, an affiliate/aggregator error, or a confusion with a different Axia trader.

### 2. What the query almost certainly refers to: Axia Futures

The described profile — “Canadian futures trader known for order flow / scalping and associated with Axia Futures” — maps onto **Axia Futures**, a London (with a Cyprus/Limassol floor) trading-education firm. Axia Futures Limited was incorporated on 27 June 2016 (UK Companies House no. 10253337) and its website appeared in early 2017; it was founded by **Demetris Mavrommatis** (Co-Founder, Head of Trading; formerly HSBC M&A) and **Alex Haywood** (Co-Founder, Head of Strategy, who describes “13 years in the futures industry, exclusively in the proprietary domain”). Its trading partner is **Axia Markets Pro** — formerly **FCT Europe Ltd**, which states “FCT Europe Ltd (FRN 786372) is Authorised and Regulated by the Financial Conduct Authority in the UK” and was “Founded in 1984 by visionary Roger Carlsson as a Chicago local market making firm.” Axia teaches order-flow, price-ladder (DOM), footprint, volume/market profile and central-bank/news trading.

The most prominent *scalper* publicly associated with Axia’s ecosystem is **Fabio Valentini** — an Italian NQ (Nasdaq futures) order-flow scalper based in the UAE — not a Canadian. Axia’s own top trader shown in marketing is Demetris Mavrommatis (G7 bond, currency and equity-index futures, plus gold and oil; primary focus German Bund, gold and E-mini S&P). If the query’s “Canadian … order flow / scalping” description is a garbled memory, Valentini is the closest real match for the *style*, and Axia is the closest real match for the *firm*.

### 3. Verified track record — proven vs. claimed

- **For “Yves Gravelle” the trader:** nothing exists to verify because the trader himself cannot be located.
- **For Axia generally:** Independent reviewers repeatedly note the absence of verified, audited P&L. TradingSchools.org reported: “We reached out to Axia Futures and requested some sort of proof that anyone was live trading?… The company responded that everyone is a professional day trader, that trades successfully, but was unwilling to show any proof.”
- **For Fabio Valentini (the real analog):** His widely repeated World Cup Trading Championship (Robbins) figures are itemised by FuturesHive as “Competition #1: 69%… Competition #2: ~90%… Competition #3: 218%… Competition #4: 160%+… Cumulative Performance: 500%+ Total Returns… 600+ trades.” Chart Academy states he achieved “an audited return of more than 500 percent in a single year,” and Magica’s interview summary notes “He achieved a peak performance of 218% but ultimately finished in second place, just behind his friend Don Nadrian.” **Caveat:** these figures trace primarily to his own interviews and promotional/education content, not to the official worldcupchampionships.com standings page, which could not be independently cross-checked in this research. The Robbins World Cup Championship is a real, third-party competition that trades real (small) accounts, so a genuine ranking there — if confirmable — is one of the few semi-independent credentials in this space. Treat the specific percentages as claimed-but-not-independently-verified.

### 4. The training itself (Axia Futures product line)

Axia offers a tiered set of products (all “self-guided” unless noted):

- **Futures Trading and Trader Development** — foundational course; over 15 hours of video plus Q&A; introduces the price ladder and core tools.
- **Trading with Price Ladder and Order Flow Strategies** — intensive DOM/price-ladder training.
- **Volume Profiling with Strategy Development** — volume & TPO/market profile, theory + strategy.
- **Footprint course** — strategy-focused, process-driven footprint reading.
- **Central Bank Trading course** — how central banks operate and how to trade the events.
- **Trading Decoded** — a 1-week intensive (third-party listed original price ~$1,900).
- **Career Programme** — the flagship, historically an “8-week” then “6-week,” and currently marketed as a “4-Week Intensive Trading Course,” delivered in-person in London or via live-streamed classroom; taught by head trainer **Richard Bailey** (15+ years’ experience). Includes the “AXIA Observation Platform” (a SIM environment modelled on Axia risk parameters, structured trade-tagging across “5 Edge Domains,” and coach feedback).
- **6-month coaching programme** — weekly group sessions plus weekly/monthly 1-on-1 mentoring.

Software historically used/taught includes **Trading Technologies (TT)**, **Jigsaw**, **Tradovate**, and Axia’s own tools/news platform. Format spans recorded video, live-streamed classroom, live trading-floor streams, community, and a simulator.

### 5. Cost and terms

- **Axia does not publish prices on its own site**; the Career Programme requires an enquiry.
- **Third-party/historical indicators:** GigaCourses lists the Career Programme at “typically around £4,500 – £6,000”; resale sites cite official prices of “$3,997” (VIP Trading Courses) and “$4000” (Trades Mint), with fxtradingtools showing “$3,490.00 USD” original; Elite Trader users cited “More like £4k.” **None of these is confirmed by Axia’s official checkout, and several are pirate/resale/aggregator sites.**
- **Funding terms:** Axia states it “does not fund nor is legally allowed to fund traders,” but provides a conduit — graduates of its in-house Career Training Programme showing potential “could be financially backed by FCT Europe Ltd” (now Axia Markets Pro) under a profit-sharing arrangement. Traders are set up as independent contractors trading firm capital.
- **Refunds:** No clear public refund policy; at least one Trustpilot reviewer sought and did not receive a refund.

### 6. Reputation and reviews

- **Positive:** Trustpilot and Scam-Detector aggregate several favourable reviews praising trainer Richard Bailey, the market-profile/footprint content, the London floor experience, and the ongoing updating of online courses. Reviewers stress it is “not a get rich quick scheme.”
- **Negative:** Trustpilot also carries mixed/negative reviews — one detailed complaint said the 6-week program “was a waste,” was delivered too fast to absorb, was “not very interactive” (“You would really be just as well off taking an online program”), and had poor/no customer service (a requested callback never came), concluding a refund or extra coaching was justified.
- **Skeptical/critical:** Elite Trader threads and TradingSchools.org are the harshest. TradingSchools.org linked Axia’s principals to the earlier **Futex** prop-trading operation, which it says collapsed with millions in missing trader deposits, and argued Axia is “all about ‘surface and texture’… no legitimacy” absent verified trading proof. It also questioned the geographic plausibility of scalping US futures from London (trans-Atlantic latency). Axia co-founder **Alex Haywood** responded in the comments: “All traders on the AXIA London Trading Floor trade through FCT Europe Ltd and clear through Macquarie Investment Bank… FCT is FCA regulated and Mifid 2 compliant… has also been around since 1984 headed by the Chairman of the group… Roger Carlsson.”

### 7. Criticism, red flags and base rates

- **Core red flag:** No independently audited P&L for the “elite traders,” despite premium course pricing — a recurring theme across critics.
- **Marketing disclaimers:** Axia’s own site repeatedly states performance is “not typical,” results may be “hypothetical or simulated,” and “attending … will not guarantee any trading success.”
- **Industry base rates:** Retail day-trading/futures has very high failure rates; paid trading education is plagued by survivorship bias, the “sells courses vs. actually trades” problem, and unverifiable P&L. The economics of teaching (recurring, low-risk revenue) can dominate the economics of trading.
- **Name-attribution red flag:** The specific inability to locate “Yves Gravelle” the trader is itself a warning. If a seller is marketing a course under this name, the user should be especially cautious about a possible impersonation or fabrication scam.

### 8. Free / low-cost alternatives

- **Axia’s own free material:** an extensive YouTube channel and blog (price-ladder execution playlists, scalping-strategy write-ups, cumulative-delta tutorials), plus free workshop funnels (elitetraderworkshop.com).
- **Comparable order-flow education:** Jigsaw Trading (DOM/order-flow tooling and education); Bookmap education (liquidity heatmap); Trader Dale (volume profile/order flow); Peter Davies / auction-market-theory content; Michael Valtos / Orderflows (footprint course, ~$3,997 list with frequent discounts); TRADEPRO Academy Order Flow Mastery; and Fabio Valentini’s own paid education (Chart Academy / fabervaale.com). Bookmap, Sierra Chart, Quantower, ATAS, and NinjaTrader Order Flow+ are the common platforms.
- **Value takeaway:** The conceptual core (auction theory, DOM/ladder, footprint, delta, absorption/exhaustion, POC/value areas, liquidity) is available free or cheaply; premium programs mainly sell structure, mentorship, screen-time, and (in Axia’s case) a possible funded-desk pathway.

## Details

Order-flow/scalping instruction of the type described centres on: reading the DOM/price ladder to see resting bids/offers and aggressive market orders; footprint charts showing bid/ask volume at each price; cumulative volume delta; absorption (large orders absorbed with little price movement, hinting reversal) and exhaustion; iceberg/hidden orders; spoofing detection; and volume/market profile (POC, value area high/low, high/low-volume nodes, initial balance, day types), combined with risk rules (fixed risk, scaling, “if/then” scenario planning). Axia’s differentiators, per its own materials, are the price-ladder emphasis, central-bank/news-event trading, the trading-floor/debrief culture (“5 Edge Domains,” end-of-day debrief), and a possible funded pathway via Axia Markets Pro/FCT. Whether these justify a four-figure price versus free/cheap alternatives is the central buyer’s decision — and it cannot be answered by verified performance, because none is public.

## Recommendations

1. **First, resolve the identity.** Ask whoever is marketing “Yves Gravelle trading training” for the trader’s real, verifiable identity; a LinkedIn/regulatory footprint; and named firm affiliation. If they cannot produce a verifiable trader by that name, **treat it as a likely fabrication or impersonation and do not pay.**
1. **If the interest is really Axia (or Valentini-style order flow), demand verified P&L.** Before paying, ask for audited broker/exchange statements or third-party-verified competition standings (e.g., official Robbins/World Cup standings). Absence of these is a decisive negative signal.
1. **Start free.** Consume Axia’s free YouTube/blog content and free order-flow material (Jigsaw, Bookmap, Orderflows) for several weeks before spending anything. If you can’t make progress with free material, a paid course is unlikely to be the missing piece.
1. **If proceeding to a paid course, prefer low-commitment tiers first** (a single self-guided module or the 1-week intensive) over the four-figure Career Programme, and get the **refund policy in writing.**
1. **Verify the funded-desk pathway terms in writing** (profit split, drawdown rules, whether backing is guaranteed on graduation — Axia explicitly says it does *not* fund and only “may” recommend graduates).
1. **Thresholds that would change the recommendation:** (a) Production of genuine, third-party-audited P&L or official competition standings → cautiously more favourable. (b) Confirmation that “Yves Gravelle the trader” is a real, regulated individual with a track record → re-evaluate from scratch. (c) Any evidence of undisclosed links to collapsed operations (e.g., Futex) or refusal to document refund terms → walk away.

## Caveats

- **This report cannot describe “Yves Gravelle’s” specific curriculum, methodology, pricing, or reviews because no such trader or product could be verified to exist.** All product, pricing, methodology and reputation detail above pertains to **Axia Futures** (and, for the scalping analog, Fabio Valentini), which the query’s description most closely matches. This mapping is an inference, clearly flagged as such.
- **Pricing figures are unverified** — Axia does not publish them; ranges come from forums and course-resale/aggregator sites (some pirate sites), which are low-reliability.
- **Fabio Valentini’s percentage returns are claimed, widely repeated, and described by some sites as “audited,” but were not independently confirmed** against the official competition standings in this research. Note also a minor inconsistency in sources (“3x” vs “4x” competitor).
- **Provenance labels:** Axia course descriptions and “elite trader” framing are **marketing copy**. TradingSchools.org and Elite Trader are **opinionated third-party criticism**. Trustpilot/Scam-Detector are **user reviews** (mixed reliability, some solicited). The Futex linkage comes from a **critic’s article**; the Macquarie/FCA clearing details come from **the firm’s own rebuttal**; the FCA registration (FRN 786372, 1984 heritage) is corroborated by FCT’s own site.
- Currencies are quoted as found (GBP and USD); conversions are approximate.