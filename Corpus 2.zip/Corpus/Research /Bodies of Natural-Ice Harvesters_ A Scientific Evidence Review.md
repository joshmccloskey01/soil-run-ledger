# Did Anyone Ever Scientifically Study the Bodies of Natural-Ice Harvesters?

## TL;DR

- **No.** No dedicated scientific, medical, physiological, anthropometric, or bioarchaeological study of natural-ice harvesters as an occupational population has ever been found to exist — not in the 19th/20th centuries when the trade flourished, and not since. The historical record is rich on *what the work was* but essentially silent on *what it did to the workers’ bodies.* [DIRECT SCIENTIFIC]/[EPIDEMIOLOGICAL]: [UNKNOWN]
- We CAN reconstruct the physical “dose” with reasonable confidence from primary industrial and census sources: 10–24 hour operations during a 2–4 week seasonal burst, blocks of ~100–300+ lb handled repeatedly, crews of dozens working long days in sub-freezing conditions. [PRIMARY HISTORICAL]/[RECONSTRUCTION]
- Claims that experienced ice workers “adapted” or became exceptionally durable are NOT established by direct evidence; they are plausible under modern exercise physiology (repeated-bout effect, Wolff’s law, muscle memory) but remain inference. The dominant, well-documented health signal from the trade is acute traumatic hazard — drowning, crushing, cutting, cold — not measured musculoskeletal adaptation. [SYNTHESIS]

## Key Findings

1. **The population was never studied as bodies.** [DIRECT SCIENTIFIC: UNKNOWN] Extensive searching of medical, occupational-health, physiology, anthropometric and bioarchaeological literature returned no study treating ice cutters/harvesters/icemen as a defined cohort. The single closest item is an art-history cover essay (McKiernan, *Occupational Medicine*, 2017, on Carl Larsson’s 1905 painting *Harvesting Ice*), which is commentary, not original research on the workers.
1. **The key primary source is economic, not medical.** [PRIMARY HISTORICAL] Henry Hall’s *The Ice Industry of the United States* (Tenth Census, 1880; published 1888) is the foundational document. It reports production tonnage, capital, ice-house capacity, transport and dollar values — and contains no analysis of workers’ health, bodies, or injuries.
1. **The physical dose is reconstructable.** [RECONSTRUCTION] Blocks were typically ~22 inches square,  16–24 inches thick, weighing roughly  100–300+ lb.  Large operations fielded crews of dozens; per the New York State Parks blog citing the *New York Daily Herald* (Feb 13, 1874), the Mutual Benefit Company’s Hudson icehouse at Staatsburg “employed 75 men, 10 boys, five horses, and a steam engine to fill the ice house,” and Iowa’s Dubuque firms reported crews of 75–125 men by 1916. Operations often ran 10-hour to around-the-clock shifts during a short mid-winter harvest window of a few weeks.
1. **The industry was large and international.** [PRIMARY HISTORICAL] Per JSTOR Daily’s “On the Rocks,” “At its peak in the nineteenth century, an estimated 90,000 people and 25,000 horses were involved in the natural ice trade in the States.” Per Basberg’s LSE Global Economic History Network Working Paper No. 20/06, “The Rise and Decline of the Anglo-Norwegian Ice Trade,” “by the turn of the century, Norway exported more than 1,000,000 tons of ice each year.” Per the Three Rivers Park District, “In 1900, ice harvesting was the 9th largest industry in the United States, in financial terms.”
1. **The documented health signal is acute trauma, not chronic adaptation.** [PRIMARY HISTORICAL]/[EPIDEMIOLOGICAL] Contemporary newspaper and local-history records emphasize drowning, being crushed by heavy blocks, cutting injuries from saws and picks, conveyor entanglement, and cold exposure/frostbite. A 1933 *Monthly Labor Review* note records a compensation award for a drowned ice cutter.  There is no equivalent body of records on osteoarthritis, back disorders, or work capacity.
1. **Occupation was differentiated.** [PRIMARY HISTORICAL] The work separated into distinct roles  — snow-scrapers, plowmen/markers, sawyers, breaker-bar men, floaters/channel-guiders (pike poles), and ice-house packers — each with different physical demands. Sawing and hauling were the most metabolically taxing; packing involved repetitive lifting/positioning.
1. **Adaptation is inference, not evidence.** [SYNTHESIS] No contemporary source systematically documents novices vs. experienced workers, seasonal reconditioning, or older workers maintaining output. Modern physiology makes such adaptation plausible but the historical population cannot confirm it.

## Details

### 1. What the work actually was (reconstruction)

[PRIMARY HISTORICAL]/[RECONSTRUCTION] The harvest was a seasonal burst confined to mid-winter, when ice reached a workable thickness (commonly 8–18 inches). The sequence was consistent across regions: clear snow, score a grid with a horse-drawn (later gasoline) ice plow, saw along scored lines with long two-handled hand saws, snap individual blocks free with breaker bars, float blocks along open channels using pike poles and tongs, and move them up ramps/elevators into insulated ice houses where crews stacked and insulated them with sawdust.

Block dimensions were fairly standardized: about 22 inches square (American export “cakes”), 16–24 inches thick. Weight estimates in the sources range from ~80 lb (small Amish farm blocks today)  to 250–300 lb (commercial Minnesota blocks) up to ~400 lb (large blocks noted in the Hudson trade).  [PRIMARY HISTORICAL]

Working hours: In Will County (Illinois), cutters reportedly worked “10 hours a day, seven days of the week.” In Mankato, Minnesota, men worked roughly 6:30 a.m.–5 p.m.   Large commercial harvests (e.g., Worthington/Okabena Lake, Minnesota) ran 24 hours a day with a night shift by kerosene lantern, over two to three weeks. Delivery icemen (a distinct downstream occupation) began around 4:00 a.m. and worked into the evening, often seven days a week.   [PRIMARY HISTORICAL]

Season length and cumulative workload: harvests typically lasted from a few days (small farms) to several weeks; some operations had windows as short as 11 days (Ottumwa, Iowa).  Output benchmarks: a large crew of ~75 could cut ~1,500 tons/day;  a Maine operation harvested ~9,000 tons/season;  Worthington harvested up to ~40,000 tons/winter; the Wisconsin Lakes Ice & Cartage Company reported 260,000 tons in 1909. [PRIMARY HISTORICAL] A per-man daily mass-moved figure is not directly recorded, and any single number would be a fragile reconstruction given role differentiation and mechanization differences. [RECONSTRUCTION]

Wages (a proxy for how the labor was valued): commonly $1.00–$2.00/day for laborers  in the late 19th century, higher ($2.50–$4.50) for teamsters supplying a horse or for skilled/hazard roles; ~$1.50 for a 10-hour day in 1906 Wisconsin.  [PRIMARY HISTORICAL]

### 2. Was it ever scientifically studied?

[DIRECT SCIENTIFIC: UNKNOWN] No. Searches across occupational medicine, physiology, industrial hygiene, and anthropometry found no cohort study, clinical series, or anthropometric survey of ice workers. This is historically explicable: occupational medicine formalized only as the trade declined (first dedicated occupational-health journals ~1901– 1919), and ice harvesting was seasonal, casual, and dispersed labor — farmers, sailors, lumberjacks, and immigrants working a few weeks per winter — precisely the workforce that left no institutional medical record.

Census mortality data of the era (US mortality schedules 1850–1900; registration-area occupational mortality tables from 1908–1909 onward) do publish occupational mortality, but they are dominated by trades like blacksmiths, miners, and clergy; ice harvesting does not appear as a resolved occupational category, and early mortality reporting was ~40–60% incomplete. [EPIDEMIOLOGICAL]

### 3. Skeletal evidence

[DIRECT SCIENTIFIC: UNKNOWN] No bioarchaeological study has examined identified ice-industry workers. Ice work does not appear as an occupational category in any identified skeletal collection. The closest analogues are general known-occupation/manual-labor collections and studies: Christ Church Spitalfields (London, 18th–19th c.); the Coimbra and Lisbon identified collections (Portugal); the SIMON collection (Geneva, manual workers);  and US anatomical collections (Terry; Hamann–Todd, including Alioto’s 2020 study of occupational stress in that industrial-era collection). Population activity-reconstruction studies such as Henderson et al. (2013) on 19th-century rural English laborers  are the nearest in time/place/labor type, but concern general agricultural/manual labor, not ice work. [INDIRECT SCIENTIFIC]

Crucially, the field itself now cautions that entheseal changes and osteoarthritis are strongly confounded by age, sex, and body size, and that inferring a *specific* occupation from bones is not currently defensible (Jurmain et al. 2012; Henderson & Nikita 2016; and the finding of *absent* hand osteoarthritis in known Spitalfields weavers).  So even identified ice-worker remains could not reliably be “read” as ice cutters. [MECHANISTIC]/[INDIRECT SCIENTIFIC]

### 4. Occupational adaptation vs. learned technique

[PRIMARY HISTORICAL]/[SYNTHESIS] Contemporary and modern re-enactment accounts describe the work as highly skill-dependent: steering 300-lb floating cakes, positioning a breaker bar for a clean snap,  and rhythmic paired sawing. This is consistent with substantial *learned technique* and crew coordination. But no source systematically contrasts novices with veterans, documents seasonal reconditioning, or records older workers sustaining high output. Any statement that experienced workers “physically adapted” is therefore inference, not historical evidence.

### 5. Recurring-demand structure

[RECONSTRUCTION] The temporal signature is distinctive: months of no ice work, then an intense seasonal burst of days-to-weeks of very long days, combining thousands of submaximal repetitions (sawing strokes, pike-pole pushes, tong lifts) with occasional near-maximal efforts (freeing a jammed or oversized block, recovering equipment). In principle this makes the occupation an interesting natural model of recurring/seasonal demand — but only in principle, because the worker-level data to test it were never collected.

### 6. Base vs. edge tasks

[RECONSTRUCTION]/[SYNTHESIS] The work plausibly separated into high-volume ordinary tasks (repetitive sawing, floating, stacking) and occasional unusually demanding events (jammed ice, awkward heavy blocks, a horse or man going through). Whether veterans treated edge loads as routine is not documented; the existence of heavy labor alone does not establish adaptation.

### 7. Whole-career outcomes and survivor bias

[UNKNOWN] There is no record of what decades of ice harvesting did to a worker’s joints, spine, or longevity — no attrition data, no disability records specific to the trade. Because most harvesters were seasonal/casual and moved between occupations, any cohort observed “after decades in the trade” would be doubly selected (biological tolerance plus the economic ability to keep returning). This selection cannot be quantified from surviving records.

### 8. Injury vs. adaptation

[PRIMARY HISTORICAL] The clearly documented harm is environmental/traumatic: drowning (repeatedly described as the greatest danger),   crushing by heavy blocks, saw/pick lacerations, conveyor entanglement, and cold injury/frostbite.  This matters analytically: an occupation can impose real physical loading (and possible adaptation) while its recorded health footprint is dominated by acute accidents rather than measured chronic musculoskeletal change.

### 9. Seasonal detraining/retraining

[UNKNOWN]/[MECHANISTIC] The trade is a near-ideal setting for studying repeated-bout effects and reacquisition of work capacity across seasons — workers returned each winter after months away. Modern physiology robustly documents the repeated-bout effect (a single eccentric bout protects against damage from later bouts, lasting weeks to ~6 months) and “muscle memory” (retained myonuclei, epigenetic marks). But there is no historical evidence of early-season soreness, injury spikes, or veteran-vs-novice reconditioning among ice workers. The physiology is real; its application to these specific workers is inference.

### 10. Comparison with other historical labor populations

[INDIRECT SCIENTIFIC] The closest genuine analogues in load, repetition and movement pattern are dockworkers/stevedores (repetitive heavy lifting/carrying),  lumberjacks (seasonal, cold, sawing/axe work, whole-body loading), and quarry/stone workers. Seasonality and cold-plus-sawing make lumberjacking the single most similar occupation; load-carrying and repetitive lifting make dock work similarly comparable. Even for these better-known trades, rigorous period physiological data are thin, and none can be silently substituted for ice workers.

### 11. Modern physiological interpretation (mechanisms only)

[MECHANISTIC] If the reconstructed exposure is interpreted through modern physiology, one would *expect*: improved motor skill and neural efficiency (technique); localized muscular hypertrophy and increased tendon stiffness; possible site-specific bone adaptation (Wolff’s law); improved fatigue resistance; and elevated caloric demand amplified by cold. The bone-loading case is well demonstrated in the dominant arms of racquet athletes: Haapasalo et al. (2000, *Bone*), using peripheral quantitative CT on 12 former Finnish national-level male tennis players versus matched controls, found dominant-arm side-to-side differences of “BMC (ranging 14%–27%), Tot.Ar (16%–21%), Co.Ar [cortical area] (12%–32%), BSI [bone strength index] (23%–37%).” On the metabolic side, cold exposure measurably raises energy expenditure (mild cold roughly 7–11%, with much larger acute increases during shivering; prolonged cold hiking can raise metabolic rate ~40% via shivering thermogenesis). These are established mechanisms in general populations; NONE has been measured in ice harvesters, and their operation in these specific workers remains unproven.

### 12. Testing the recurring-demand hypothesis

[SYNTHESIS] Hypothesis: repeated exposure to a meaningful-but-resolvable occupational demand leads the body to organize around it until initially hard workloads become routine.

- *Directly supported by historical ice-worker evidence:* nothing. [UNKNOWN]
- *Made plausible by modern physiology:* repeated-bout effect, Wolff’s law loading adaptation, muscle memory, endurance/strength adaptation. [MECHANISTIC]
- *Remains inference:* that any specific ice worker or the population as a whole underwent these adaptations. [SYNTHESIS]
- *Potentially contradictory considerations:* the trade’s dominant recorded outcome is acute injury; survivor/selection bias could masquerade as adaptation; and much of what looked like growing capability was likely skill/technique, not tissue remodeling.

## Recommendations

**For a researcher pursuing this question:**

1. **Go to the true primary sources first.** Transcribe the labor passages directly from Henry Hall’s 1888 report (the census.gov PDF or the 1974 Early American Industries Association reprint) — the machine-readable text is blocked, so this requires manual retrieval. Pair it with Census Bulletin 174 (1902) and the trade press (*Cold Storage and Ice Trades Review*; *Ice and Refrigeration*). This moves the picture from [RECONSTRUCTION] toward [PRIMARY HISTORICAL] on hours, crew sizes, and per-man output.
1. **Mine occupational-mortality tables** (US registration-area reports 1908 onward; UK Registrar-General’s occupational mortality; Norwegian records) for any resolved “ice” category. If found, this would upgrade the health picture from anecdote to [EPIDEMIOLOGICAL]. A named occupational code with a usable number of deaths (≈100+) would justify a mortality comparison.
1. **Pursue the Norwegian scholarship**, which is the most active current research strand (the Norwegian Maritime Museum “Last Ice Age” project; Elisabeth S. Koren on manpower/work conditions in the ice fleet; Bjørn L. Basberg on the trade’s economics). This is the likeliest place a genuine labor-conditions (if not physiological) study exists, possibly in Norwegian-language sources.
1. **Treat any adaptation claim as a hypothesis to be flagged, not a finding.** If writing for a physiology audience, present the ice trade as a *candidate natural experiment* whose data were never collected — not as evidence.
1. **If skeletal evidence is wanted,** the only viable route is indirect: identified manual-labor collections (Coimbra, Lisbon, Hamann–Todd) and 19th-century rural laborer series — clearly labeled as analogues, with the field’s confounding caveats attached.

**What would change these conclusions:** discovery of (a) a period medical/insurance/anthropometric survey naming ice workers, (b) an occupational-mortality table resolving the trade, or (c) an identified skeletal series of documented ice-industry workers. Absent any of these, the top-line answer stands.

## Caveats

- **Absence of evidence:** “No study found” reflects thorough targeted searching, not proof of non-existence — particularly for non-English (Norwegian, Russian) sources, which were only partially reachable.
- **Secondary-source reliance for Hall:** the verbatim Hall quotations available were reproduced via institutional secondary sources because the original full text was not machine-accessible; the barge passage is corroborated identically across two independent institutions (New York State Parks and the South Street Seaport Museum).
- **Reconstruction limits:** block weights, hours, and outputs vary by region, era, and mechanization level; single “typical” figures smooth over real heterogeneity and are labeled [RECONSTRUCTION] accordingly.
- **Mechanism ≠ history:** all modern physiology cited (repeated-bout effect, Wolff’s law, cold thermogenesis, the tennis pQCT data) describes general human biology. Its inclusion interprets what such work *could* do; it does not document what happened to any actual ice harvester.
- **Do not conflate icemen and ice harvesters:** urban delivery “icemen” are a related but distinct downstream occupation with a different exposure profile (daily year-round carrying) from seasonal field harvesters; sources sometimes blur them.

## Final Answers

1. **Has anyone actually scientifically studied natural-ice harvesters as a physical/occupational population?** No. No direct scientific, medical, anthropometric, or skeletal study of this population exists. [UNKNOWN / negative]
1. **What can we reconstruct with confidence about the physical dose?** A seasonal burst of long days (10–24 h) over days-to-weeks; repetitive whole-body work (sawing, poling, lifting) handling ~100–300+ lb blocks; sustained cold exposure raising caloric demand; distinct sub-occupations with different loads. [RECONSTRUCTION / PRIMARY HISTORICAL]
1. **Is there evidence that experienced workers physically adapted?** No direct evidence. Skill/technique gains are well attested qualitatively; tissue-level physiological adaptation is plausible but unproven for this population. [SYNTHESIS]
1. **What evidence exists for long-term benefit, degeneration, injury, or selection?** Only for acute injury (drowning, crushing, cuts, cold), documented in newspapers and one compensation record. Long-term musculoskeletal outcomes, disability, and attrition/selection are undocumented. [PRIMARY HISTORICAL for injury; UNKNOWN for the rest]
1. **What can this population legitimately tell us about adaptation to high-frequency recurring demand?** As a matter of historical evidence, almost nothing directly — the worker-level data were never collected. Its legitimate value is as a vivid *candidate natural experiment* (seasonal detraining/retraining, high-repetition submaximal loading with occasional maximal efforts) that modern physiology suggests *would* produce adaptation, while honestly leaving the historical case [UNKNOWN].