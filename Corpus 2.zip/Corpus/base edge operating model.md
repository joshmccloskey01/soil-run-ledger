# Base/Edge — Operating Model

**Objective:** capacity rising while health rises, where health is tolerance to load and tolerance is read as clearance time. The same instrument reports both variables, so a capacity gain bought with slower clearance is a loss on the same ledger. There is nothing to trade.

**Stack.** *05_Biological Adaptation* is the theory this loop answers to; it does not operate anything. Base/Edge is the operating loop. Skill-first is a parallel theory, mostly absorbed — its capacity-as-retained-consequence, maintenance, burden-of-proof, and capacity-horizon sections are already carried by the fundamental with mechanism attached. What survives from it: the within-exposure quality rule (now the Base floor) and ownership-versus-completion (now the advancement criterion). Its core claim — skill as the sole training interface, everything else strictly downstream — does not survive. The fundamental lists skill as one ledger among many, each with its own floor, ceiling, and update rate. Skill is a peer being updated, not the port.

---

## 1. Formalism

$$S_t + I_t \rightarrow S_{t+1}$$

There is no output. What is controllable is the exposure offered, not the transition.

Measured variables — glycogen, force, clearance time, soreness, pace — are observable components of state. They are not adaptation outputs. **The error is promoting one observable's trajectory into the transition law itself.**

The consequence that matters operationally:

> **Adaptation changes the admissible action set.**

A changed state matters because it admits inputs the previous state did not. Promotion is a changed boundary on what the next state can legally receive, not more output in a separate channel.

*Ashby supplies this.* His machine-with-input is a transformation on states where the input parameter selects which transformation applies; there is no output in the definition. The formalism is his. The directed policy below is not.

---

## 2. Commitment 1 — reject generalized supercompensation timing

Yakovlev's finding, 1949–1959, was supercompensation of muscle and liver glycogen and muscle phosphocreatine. Both are storage quantities with regulated setpoints, and that is the class of variable that can overshoot: deplete a tank, refill past the line.

Tendon collagen, bone mineral, and recruitment access are not storage quantities. They do not deplete and refill; they remodel. The curve is the behavior of one variable type, not a general law.

The defect is internal to the model, not imported. It concedes heterochronism — tendon and bone take considerably longer than muscle — and then still prescribes training at *the* peak. One clock, admitted to be many.

**Conceded:** variable-specific overshoot is real. Glycogen supercompensation and carbohydrate loading are not disputed.

**Not claimed:** that stress does not drive adaptation. The fundamental contains stress, signal, cost, and an adaptive band. What is rejected is the deplete-and-overshoot *shape* generalized into a scheduling clock.

---

## 3. Commitment 2 — reject deliberate consequence accumulation

**This model rejects deliberate consequence accumulation that breaks the recurrence bound, including overreach-then-taper peaking.**

This is independent of Commitment 1 and is owned directly. Fitness–Fatigue supports taper and peaking through a different mechanism and survives the supercompensation critique intact. It is a coherent model, rejected as an operating policy rather than as an account of physiology.

The structure being rejected:

$$S_0 + I_{\text{high-cost}} \rightarrow \cdots \rightarrow S_k \qquad\text{then}\qquad S_k + I_{\text{low}} \rightarrow \cdots \rightarrow S_n$$

Rejection lands on the **first** phase. Low inputs are legal. Deliberately entering states that break the intended recurrence in order to recover from them later is not.

**Cost, stated:** the highest transiently expressible state on date *t* is given up in favour of the highest continuously available state. Conventional peaking may produce a race-day expression above the continuously sustainable one. That is a real cost, not a philosophical preference, and it is largest exactly where the objective is.

**No competition exception.** The commitment is flat. If an exception is created later it must be written as an exception, not absorbed into the horizon language.

---

## 4. Sizing under constraint

Sizing replaces timing. The traditional question is how large a stress can be imposed and when the rebound can be exploited. This model asks how small the exposure must be to remain admissible on the intended cadence.

Minimization alone is degenerate — zero exposure wins. So:

$$D_{\min,\text{role}}(S_t) \;\le\; D \;\le\; D_{\max,\text{cadence}}(S_t)$$

Both bounds are **state-relative**. Neither is a property of the movement.

**The floor is compound.** $D_{\min,\text{role}}$ is the minimum demand that still performs the assigned role — for Base, still the skill *and*, where assigned, still holding the relevant ledger; for Edge, still contacting the ceiling it is assigned to preserve. Where more than one role is assigned to an exposure, the floor is the maximum of them. A compound floor narrows the feasible interval, so infeasibility becomes more common, not less.

**Empty interval.** Where $D_{\min,\text{role}} > D_{\max,\text{cadence}}$, no sizing solution exists. The correct report is *inadmissible from this state*, not *reduce further*. Without this, the model can always escape falsification by prescribing less.

**The empty interval is a filter, and it has a direction.** It is not a rare edge case. Movements that scale down gracefully stay in the loop; movements whose minimum role-performing dose carries systemic cost beyond the cadence bound drop out. So the anchor list is partly *determined* by the cadence rule rather than chosen — a consequence the loop produces on its own, and one that predicts which movements will fail before they are tried. The archer chin is the first recorded instance of the class, not an anomaly.

**Worked example — archer chin, 18 July 2026.** One repetition already exceeded the daily-recurrence bound, and no smaller unit still performed the edge function. The feasible interval was empty. The movement then left the loop for twenty-two days, breaking both coupling arrows at once: no edge contact holding the ceiling, and nothing for the base to promote into. The correct statement is that no archer-chin exposure was admissible *from S₁₈ ⱼᵤₗ*, not that the movement is inadmissible. Written as a state property, it says what has to change.

---

## 5. Identification rule

$$\text{hold } I_{\text{commanded}} \;\Rightarrow\; \text{observed change is attributable to changed state}$$

Changing the input while trying to infer the transition law confounds the thing being identified.

**Only the commanded input is held.** External conditions — sleep, food, ambient load, temperature — vary and are not controlled. What is required is that the loop does not change the variable it controls. That makes the read statistical rather than exact: uncontrolled variation enters every day, so *stopped behaving differently* is a judgement across a run of days, not a comparison between two of them.

Operating consequences:

- **Advancement and diagnosis cannot occupy the same comparison cycle.** Either hold the dose and read the trend, or advance and accept that the cycle is blind.
- **Promotion resets the series.** Comparison runs within a block where the endpoints are fixed, never across one.
- **Stop days are marked, not omitted.** Where the governor closes loading, the exposure did not occur. If that day is dropped silently, the days either side are compared as though adjacent.

---

## 6. The loop

Base practice → small daily edge single → observe → repeat if admissible → normalize → promote into base → edge moves up.

The rise is not located in either layer. It is in the exchange. The edge holds access to maximum tension so a given load stays practicable in the base; the base makes that load ordinary; the edge then sits higher without chasing a number. Both arrows are load-bearing; preservation is what the edge does between promotions, not its purpose.

### One axis, two roles

Base and Edge are not two categories of movement. They are two positions on one load axis of the same movement. Loaded heavily enough, base work *is* edge work — the role is determined by where on the axis the load sits, not by which exercise it is.

The base's operating definition is the light end: **light enough that volume stays cheap.** The edge is the heavy end that still recurs daily.

Three consequences:

- **Promotion is only meaningful because the axis is shared.** A normalized edge load enters the base as a load, not as a different kind of work. Across genuinely different mechanisms — isometrics and running, say — there is nothing to promote into.
- **The ramp is the traverse of the band between them.** Loads above the base ceiling and below the edge belong to neither role. That band is crossed in singles, which is why ramp singles belong to the edge entry rather than the base total. The ramp is not a warm-up.
- **A movement needs a nonzero base–edge gap to run the loop at all.** Where the two collapse to one point there is no lighter position to practice from and nothing to ramp through.

### Base

Frequent, intentional, cheap practice. Distributed rather than concentrated. Tracked as total accumulation. Maximize useful intentional practice per unit of biological cost.

**Floor: the repetition must sit at a demand where it is still the skill.** Below that it is movement, not practice, and it leaves no residue.

### Edge

One high-force single per lift per day, ramped to.

**Ceiling: below peak, so it can recur daily.** An edge that cannot be repeated daily is too large for this model. If an exposure only fits every third day, reduce it until recurrence becomes daily — do not schedule it every third day.

**Floor: tension high enough to hold recruitment access.** Daily recurrence pushes edge size down the way the ratio pushes base cost down. Without a floor it converges on an exposure that recurs perfectly and touches nothing — and that failure is invisible, because the exposure looks fine every day.

Both layers have the same structure: a floor defining what still counts, and an economics driving toward it.

### The heavy line

**Truly heavy = the load at which one repetition materially moves the state.**

At or above that line, one repetition. The mismatch is fully declared at rep 1. Rep 2 is the same external load meeting a state that has already moved by an unknown amount — information per rep collapses, cost per rep rises, and the probe destroys its own baseline. Reps within a session do not make a problem recurrent; recurrence lives on the day axis.

The loop sits below this line deliberately. Above it an exposure is a test: it cannot recur, each attempt lands on a different arrival state, and no series exists to compare against.

*Exception:* multiple repetitions where repeated execution is itself the skill.

**Scope.** This is an operating rule for peak-demand edge work, not a universal statement about repetitions on every ledger. Above the line, additional reps enlarge the dose rather than improve the read; below it the argument does not apply.

### The ramp

Divide the gap between current base load and current edge load into fixed increments and ramp in singles to the edge load.

Ramp steps sit below the heavy line by construction, so they do not move the arrival state at the top. Raggedness is therefore not a problem — put the odd increment at the bottom and keep the steps nearest the edge consistent. Within a block both endpoints are fixed, so the ramp is identical every day across the window where comparison runs. It is derivable, not stored.

Ramp singles belong to the edge entry, not the base total.

**Step count is a free reading.** At fixed increment, step count *is* the base–edge gap. Falling steps mean the base is catching up. Zero steps mean base has met edge and promotion is overdue.

### Advancement

The daily edge single is its own probe. It recurs identically, so it needs no separate one.

**Advance when the exposure stops behaving differently from the days preceding it.** This is the ramp criterion on the day axis instead of the load axis, and the comparison is cleaner — the reference is the identical load, repeatedly, not a set of different loads.

Not on calendar. Not because one rep felt easy. Completion is not ownership.

### Promotion

When an edge load has become ordinary it enters the base as practicable load and the edge moves up. Promotion resets the series.

### Anchor selection

**A movement qualifies as an anchor only if it scales down to a size that recurs daily.** A movement whose minimum unit already sits at or above the heavy line cannot satisfy this and stays out until the state changes. Bodyweight movements with no loadable gap have no ramp and need a separate edge definition or sit out.

### State reporting

- Legs: pistol squat is the probe.
- Upper body: shoulder health via bands and floor work.
- Edge: reports itself through daily recurrence.
- Running: separate probe, separate governor.

### Running

The loop transfers; the self-probing property does not. Base running built to a level, then a short near-maximal exposure — on the order of ten seconds — at whatever pace recurs daily. Pace is the dependent variable; daily recurrence is the fixed constraint.

**The gym edge is self-governed. The running edge is externally governed.** The daily readout in running is an acute signal, and bone cannot complete a remodeling cycle in the window where that signal clears. The governor is therefore separate from the exposure.

**The governor is event-based, not a curve.** No clearance duration is estimated. The state transition is the read:

$$\text{joint score appears} \;\Rightarrow\; \text{loading of that joint stops for the day}$$

$$\text{next-day probe normal} \;\Rightarrow\; \text{return to loop} \qquad \text{next-day probe still flags} \;\Rightarrow\; \text{rehab state}$$

This uses an observable to change which inputs are admissible in the next state, rather than inferring a slow ledger from a continuous metric.

**Same-day clearance is an admission rule, not a proof.** Failure to clear rejects the dose immediately. Successful clearance means only that the exposure passed this governor — it does not establish that every slow ledger has resolved. A normalized day with a same-day bound leaves no slack by design: anything costing three or four days breaks cadence on day two rather than being absorbed and surfacing in week four. The breakage is the signal.

**Wording:** the criterion is *no bad residue*. Residue is the adaptation. What is being excluded is damage, not consequence.

**Promotion differs here.** The running edge can normalize on the neural ledger while the base cannot absorb the promotion, because the tissue limiting the base is slower than the one being read.

---

## 7. Falsifiers

**Near-term — event rate, not duration.** Once the governor is event-based, clearance duration is no longer graded and cannot carry a trend. The countable quantity is flag events. **At held dose, if tolerance is rising, event frequency should fall.** If events hold steady or rise while the commanded input is fixed, tolerance is not keeping pace with the load being asked of it.

*Limit:* rate needs a block long enough to count in, and promotion resets the block. Where blocks are short and events rare, no block accumulates enough to read — the falsifier is then unavailable rather than passed. This should be stated when it occurs, not discovered afterward.

**Terminal.** Continuously available performance must eventually prove competitive with what a deliberate taper-and-peak architecture produces. The test is within-athlete: whether deliberate accumulation followed by taper produces a competition state that continuous recurrence cannot.

*Running it violates Commitment 2.* The test requires the accumulation phase the commitment forbids, so it can only be run as a declared, bounded exception, once. It also carries an order effect: a taper arm run after years of continuous operation stands on a state the continuous arm built. Both facts weaken the result and neither removes the need to run it.

**Structural.** The model must be able to report that no admissible dose exists rather than prescribe less indefinitely. If infeasibility is never reported, the falsifiers above are unreachable.

---

## OPEN

**OPEN-1 — what counts as a flag.** The joint score is graded, so *score appears* must state whether it means any nonzero value or a band above zero. Any-nonzero closes this item: the bound is stated and the tolerance is zero. A band relocates the item to the band's edge and leaves it open.

**OPEN-2 — what assigns the ledger floors.** The floor is now compound: Base holds the skill floor *and*, where assigned, a ledger maintenance floor. Nothing yet determines the assignment, so an unassigned ledger has no floor and can decay with nothing reporting it.

The sharp case is a tissue pair with different update rates: neural recruitment normalizes inside twenty-four hours, tendon collagen does not. A daily edge single can therefore read clean on the ledger that reports fast while the slow one accumulates, and the loop reports nothing until structural failure. This is the model's most dangerous silent state and it is currently undischarged.

**OPEN-3 — recurrence is not classified.** The governor has two outcomes, transient and persistent, and both are decided on a one-day window. A joint that flags, clears overnight, and flags again days later reads as transient on every instance, so the pattern never reaches rehab — which is the slow-accumulation case the governor exists to catch. A third state keyed to event recurrence across days would close it. **Not adjudicated.**

---

## Provenance and status

**Mechanistic coherence does not upgrade epistemic status.** Material returned with a mechanism attached retains its prior status until independently warranted. A restatement that reads as more grounded because it now has machinery under it has not thereby become more grounded.

**Worked warning — the taper reformulation.** Commitment 2 was at one point restated as *do not enter a state from which the intended recurrence cannot be restored within the loop's permitted transition horizon*. Coherent, formally expressed, mechanism attached. But the horizon **is** the recurrence bound — tomorrow, for lifting — so the reformulation reduced to the loop restated, while reading as though it had opened room for peaking. It also described taper as a chain of low inputs, which omits the accumulation phase where the disagreement actually lives. A coherent restatement can silently change the commitment it claims to preserve. Status-mark anything that returns this way.
