<!-- NORMALIZED COPY. Canonical source: 02_SOURCE/The Computer.json. Document ID: COMPUTER. Sequence: 6. -->

# The Computer

**Author:** Josh McCloskey

**Document Type:** Working paper

**First Issued:** July 11, 2026

**Current Revision:** R3

**Last Revised:** July 11, 2026

**Status:** Active working paper — conceptual architecture with toy experimental support

*The body is the current model, read as it now stands. The complete revision history is at the back.*

*The field laid over a computer. Same structural problem, different substrate.*

> **Mechanism boundary.** In this framework, a mechanism is a bounded arrangement of interacting components whose organized relationships transform inputs into repeatable outputs under governing constraints. The Field and the computer may share a state-transition shape without sharing the same material mechanism. The comparison carries structure, not biological equivalence.


The computer is not being used here as a metaphor for the field, and the field is not being used as proof that a computer is alive.

The field is an intuition layer.

It makes one thing difficult to forget:

> **An input never lands on nothing. It lands on a system that already has a state, a history, a capacity, and limits.**

A computer also has a boundary, an inside and an outside, a current state, incoming inputs, internal transformations, outputs, retained changes, and costs.

The important question is not whether a computer can copy the material mechanism of a field, a body, or a brain.

The question is:

> **Can a computer be made to obey the same deeper accounting problem: every attempt changes what is available for the next attempt?**

That is the beginning of adaptation through a computer.

---

## 1. The basic state transition

At the simplest level:

\[
S_t + I_t \rightarrow O_t + S_{t+1}
\]

Where:

- \(S_t\) is the current state;
- \(I_t\) is the input;
- \(O_t\) is the output;
- \(S_{t+1}\) is the state left behind.

The field has this shape.

\[
\text{Field State}
+
\text{Input}
\rightarrow
\text{Response}
\rightarrow
\text{Output}
+
\text{Changed Field}
\]

A human has this shape.

\[
\text{Human State}
+
\text{Input}
\rightarrow
\text{Response}
\rightarrow
\text{Output}
+
\text{Changed Human}
\]

A computer has this shape.

\[
\text{Computer State}
+
\text{Input}
\rightarrow
\text{Computation}
\rightarrow
\text{Output}
+
\text{Changed Computer State}
\]

The materials and mechanisms are different.

The structural fact is the same:

> **The next input arrives at the state produced by the previous interaction.**

History is carried forward through state.

---

## 2. The boundary: inside and outside

The boundary decides what belongs to the system and what the system must answer to.

For a field:

### Inside

- soil;
- roots;
- organisms;
- water already present;
- retained structure;
- stored resources.

### Outside

- weather;
- added water;
- added nutrients;
- disturbance;
- harvesting;
- changing environmental conditions.

For a computer system:

### Inside

- memory;
- files;
- models;
- agent state;
- code;
- stored rules;
- revision history;
- internal representations;
- the slow ledger.

### Outside

- the task;
- the user;
- reality;
- tests;
- sensors;
- tools;
- APIs;
- other agents;
- consequences the system does not control.

The distinction matters because the system cannot be allowed to define reality for itself.

An agent can predict.

It can reason.

It can update its own internal state.

But error only becomes meaningful when the inside is forced to answer to something outside itself.

\[
\text{Inside Model}
\leftrightarrow
\text{Outside Reality}
\]

The difference between them creates error.

That error can drive update.

---

## 3. The field laid over the computer

### Soil state = retained computer state

The field is already in a condition before rain arrives.

The computer is already in a condition before input arrives.

Computer state can include:

- active memory;
- stored files;
- databases;
- code;
- model context;
- revision history;
- unresolved debt;
- accumulated rules;
- dependency structure;
- previous failures;
- current capacity.

Some state is temporary.

Some persists.

The persistent part matters because that is what allows one interaction to change the starting point of the next.

---

### Rain = input or load

An input is anything that enters or acts on the system.

Examples:

- a prompt;
- a sensor reading;
- a file;
- a command;
- an API call;
- a CAD change request;
- a message from another agent;
- a test result;
- a contradiction discovered in the knowledge tree.

The input alone does not determine the result.

\[
\text{State} + \text{Input} \rightarrow \text{Result}
\]

The same input can produce a different result in a different state.

Same rain. Different field.

---

### Field structure = hardware and software structure

The field has material organization.

The computer does too.

Hardware provides physical capacity:

- CPU;
- GPU;
- memory;
- storage;
- network;
- power.

Software provides organized relations:

- code;
- models;
- agents;
- databases;
- feature trees;
- revision systems;
- control logic.

The response emerges from the interaction between the physical substrate, the organized structure, the current state, and the input.

---

### Crop = output

The computer can produce:

- an answer;
- a file;
- a design;
- a prediction;
- a control action;
- a CAD revision;
- a new rule;
- a decision.

But output is not adaptation.

A system can produce an excellent output and become worse underneath.

That distinction is central.

---

### Changed soil = retained change

A file changes.

A database updates.

A CAD model acquires a new dependency.

A knowledge artifact gains a new revision.

A failed attempt becomes a retained rule.

A contradiction is discovered and resolved.

The result of the interaction changes the state that receives the next input.

That is where adaptation can begin.

---

## 4. A computer does not adapt merely because it changes state

A log file changes state.

A cache changes state.

A broken program changes state.

Not every state change is adaptation.

For this architecture, adaptation requires more:

1. a system has a current state;
2. an input or perturbation acts on it;
3. the system responds;
4. the response has consequences;
5. some change is retained;
6. the retained change alters future response;
7. the change is evaluated against something outside the system;
8. the system must continue operating under constraint.

The missing piece is the constraint.

A real adaptive system cannot attempt everything for free.

---

## 5. Every attempt consumes something

In a physical system, every attempt has a cost.

Not as a moral penalty.

Not as a score added afterward.

The attempt changes what remains available.

A plant cannot make unlimited roots.

A body cannot perform unlimited training exposures.

A field cannot absorb unlimited rain.

A living system does not get to search an infinite possibility space without consequence.

Every attempt consumes some combination of:

- usable energy;
- time;
- material;
- repair capacity;
- structural reserve;
- opportunity;
- attention;
- organization.

The important quantity is not the isolated price tag of the attempt.

The important quantity is:

> **What is the net state afterward?**

An expensive attempt can be worth it.

A cheap attempt can still be destructive.

The system should not optimize for minimizing attempt cost.

It should optimize the state that survives the attempt.

---

## 6. The slow ledger

The slow ledger is the underlying state that determines what the system can continue to absorb and become.

The optimization order is:

\[
\boxed{
\text{1. Slow-ledger health}
\rightarrow
\text{2. Slow-ledger capacity}
\rightarrow
\text{3. Immediate performance}
}
\]

The immediate result is not the primary score.

The first question is:

> **Did the interaction leave the slow ledger healthier or less healthy?**

The second is:

> **Did it increase or reduce the slow ledger's capacity?**

Only after that does immediate output become decisive.

This matters because a system can improve its visible performance while degrading the thing that produces the performance.

A computer can:

- produce a better answer by adding contradictions;
- solve a CAD problem with brittle dependencies;
- generate more code while increasing technical debt;
- expand memory while destroying organization;
- keep iterating while accumulating unresolved failures;
- improve a benchmark while becoming less maintainable or less general.

That is the computer version of continuing to perform while carrying debt.

The output can still look good.

The slow ledger can still be getting worse.

---

## 7. Why a simple energy budget is not enough

Giving an agent 1,000 simulated energy points creates a budget.

It does not yet create an adaptive metabolism.

A fixed energy counter misses the important fact:

> **The same attempt should not have the same consequence in every state.**

A system with high health and high capacity may absorb a demand cleanly.

The same demand imposed on a degraded, tangled, debt-loaded system may create a much larger net cost.

So the effect of an attempt must be state-dependent.

\[
\text{Net Consequence}
=
f(
\text{Attempt},
\text{Current Slow-Ledger State},
\text{Available Resources},
\text{Outside Result}
)
\]

The missing mechanism is not merely simulated energy.

It is a **simulated metabolism** or **resource economy** coupled to the slow ledger.

The system needs some analogue of:

- available resource;
- maintenance;
- depletion;
- debt;
- recovery;
- repair;
- capacity;
- state-dependent absorption.

The rules do not need to pretend that simulated units are literal joules.

The simulation is an internal constraint model inspired by the unavoidable accounting that physical systems face.

The purpose is to make attempts have consequences that alter future possibility.

---

## 8. The difference between a battery and a metabolism

A battery says:

\[
E_{t+1} = E_t - \text{cost}
\]

That only answers:

> How much fuel is left?

A metabolism must answer more:

- How much resource is available now?
- How much can be mobilized at once?
- How much must be reserved for maintenance?
- What unresolved debt remains?
- How much damage or disorder did the last attempt leave?
- How fast can the system recover?
- Has the system become more capable?
- Has the system become more fragile?
- Does the same next attempt now cost more or less?

The state might eventually contain variables such as:

\[
L_t = \{H_t, C_t, D_t, R_t\}
\]

Where:

- \(H\) = slow-ledger health;
- \(C\) = slow-ledger capacity;
- \(D\) = unresolved debt;
- \(R\) = immediately available resource.

This is only a candidate minimum, not a finished solution.

The key is the transition:

\[
L_t
+
\text{Attempt}
+
\text{Outside Consequence}
\rightarrow
L_{t+1}
\]

The attempt changes the ledger.

The new ledger changes what the system can do next.

---

## 9. The accounting must live outside the agent

If the agent is allowed to decide:

> "That attempt made me healthier."

the architecture can be gamed immediately.

The governing accounting has to exist outside the agent's own claims.

The agent may propose.

The agent may predict.

The agent may explain.

But the environment must update the state according to rules the agent does not control.

That external layer can inspect measurable consequences such as:

- tests passed or failed;
- contradictions created or resolved;
- dependencies added;
- rollbacks required;
- unresolved assumptions;
- repeated failed attempts;
- memory growth;
- complexity growth;
- verification status;
- resource use;
- repair work still required.

Not all of these are thermodynamic energy.

They are possible observable demands and consequences from which a simulated resource economy could be constructed.

The key principle is:

> **Do not ask the agent to pretend it has a metabolism. Build a metabolism around the agent.**

---

## 10. Debt

Debt is not the same thing as resource expenditure.

Debt is cost that remains unresolved in the state.

Examples in a computer system:

- an assumption that was never checked;
- a brittle dependency;
- a temporary patch;
- an untested change;
- a contradiction;
- a result that works but is not understood;
- memory added without integration;
- a failed attempt whose cause was never resolved.

Debt matters because a system can continue producing output while debt accumulates.

That is exactly why immediate performance cannot be the primary objective.

Debt changes the future.

A debt-loaded system may:

- require more effort to make the next change;
- become easier to break;
- become harder to reason about;
- recover more slowly;
- waste more resources;
- lose capacity.

Repair can therefore be adaptive work even when it produces little visible output.

Testing.

Consolidation.

Refactoring.

Simplification.

Documentation.

Contradiction resolution.

Revision integration.

These may lower immediate production while improving the slow ledger.

---

## 11. Capacity

Capacity is not merely the size of the computer.

For this architecture, a useful candidate definition is:

> **Capacity is the amount and complexity of demand the system can repeatedly absorb while preserving slow-ledger health and avoiding persistent debt.**

A system that can solve one hard problem and then collapse into repair has less adaptive capacity than a system that can repeatedly absorb hard problems without degrading.

Capacity is revealed by what the system can integrate.

Not merely by what it can express once.

---

## 12. The existing multi-agent system

An earlier agent system already implemented one piece of this architecture.

Each agent ran:

\[
\text{Reality}
\rightarrow
\text{Observe}
\rightarrow
\text{Predict}
\rightarrow
\text{Error}
\rightarrow
\text{Adjust}
\]

The system included:

- a Controller;
- a Researcher;
- a Builder;
- an Auditor;
- a shared Debt Ledger.

Agents could record:

- assumptions;
- shortcuts;
- unvalidated claims;
- technical debt.

The Auditor could inspect the shared ledger and decide whether the result should ship.

That already demonstrated an important principle:

> **One agent's attempt can leave retained consequences visible to the rest of the system.**

But that debt layer was primarily an integrity layer.

It did not yet simulate the deeper thermodynamic problem.

It did not answer:

- What resource economy funds attempts?
- How does the same attempt have different consequences in different states?
- How does unresolved debt alter future cost?
- What counts as slow-ledger health?
- What counts as slow-ledger capacity?
- How can capacity grow?
- When should the system stop producing and repair itself instead?

Those questions became the experimental program that followed.

---

## 13. The narrow open problem

The problem is no longer:

> How do we make a computer adapt like life?

That is too large.

The narrow problem is:

> **What is the smallest computational mechanism that makes every attempt produce an unavoidable, state-dependent net change in a simulated resource economy, where the system is optimized first for slow-ledger health, second for slow-ledger capacity, and only third for immediate task performance?**

The mechanism must satisfy several constraints:

1. **Every attempt has consequences.**
2. **The consequence depends on current state.**
3. **The result is not the primary objective.**
4. **The isolated cost of the attempt is not the primary objective.**
5. **The net effect on the slow ledger is what matters.**
6. **Health is evaluated before capacity.**
7. **Capacity is evaluated before performance.**
8. **Debt can accumulate while performance remains high.**
9. **Repair can improve the system without improving immediate output.**
10. **The accounting exists outside the agent and constrains future action.**

That problem produced a sequence of toy experiments. The present evidence supports staged protection, damage-free effort feedback, throttling and reopening, and compatibility with executable program artifacts. Literal thermodynamic accounting and real-LLM integration remain open.

---

## 14. The field and the computer

### The field

\[
\text{Current Field State}
+
\text{Input}
+
\text{Available Resources}
\rightarrow
\text{Response}
\rightarrow
\text{Output}
+
\text{Net Retained Change}
\]

The next input meets the changed field.

### The computer

\[
\text{Current Computer State}
+
\text{Input}
+
\text{Simulated Available Resources}
\rightarrow
\text{Attempt}
\rightarrow
\text{Outside Consequence}
+
\text{Net Slow-Ledger Change}
\]

The next attempt meets the changed computer.

The point is not that the field and the computer share the same material mechanism.

The point is that both can be forced to answer the same structural question:

> **What did this interaction leave behind, and how does that change what can happen next?**

---

## 15. Why this matters

### Knowledge

A conversation should not merely produce an answer.

It should leave behind:

- revisions;
- reasons;
- failures;
- corrections;
- unresolved debt;
- retained rules.

The next conversation starts from the changed state.

---

### CAD

A CAD revision should not merely leave final geometry.

It should retain:

- what was attempted;
- what failed;
- why it failed;
- what changed;
- what solved it;
- what new dependency was introduced;
- what future rule should be retained.

The system can then learn from failure history rather than only inspecting the surviving model.

---

### Multi-agent systems

Agents should not merely exchange messages.

Their attempts should alter shared state in a way that affects:

- what later agents can attempt;
- what debt later agents inherit;
- when repair is required;
- how much future load the system can absorb.

---

### Science

A theory should not merely accumulate confirming outputs.

It should carry:

- predictions;
- errors;
- failed explanations;
- revisions;
- uncertainty;
- reasons for change.

The history of correction becomes part of the knowledge state.

---

## 16. The computer as an adaptive field

The field makes adaptation visible because nothing is free.

The computer hides cost because computation can look abstract.

But the physical computer is not free of thermodynamics, and an artificial adaptive system should not be allowed to behave as though iteration itself has no consequence.

The goal is not to imitate biology cosmetically.

The goal is to create a computational environment in which:

> **attempts alter state, state alters future cost, retained change alters future response, and the system survives by protecting and expanding the slow ledger that makes future adaptation possible.**

That is the computer.

Not merely a machine that answers.

A bounded system that carries the consequences of its own attempts forward.

---

## 17. Output, save, and retained structure

A file begins as an output of a process.

While it is being produced, its working representation exists as temporary physical state in memory.

When the user or system saves it, the selected application state is encoded and committed to persistent storage.

\[
\text{Working State in RAM}
\rightarrow
\text{Save / Commit}
\rightarrow
\text{Persistent Artifact}
\]

The save operation does not normally preserve the entire computer state. It preserves a selected representation: the document, program, model, database transaction, configuration, or other artifact that the application is responsible for.

The same object can occupy different roles across time:

- while being produced, it is output;
- after being saved, it is retained structure;
- when it is retrieved, it becomes input again;
- when that retrieved structure changes future processing, it functions as memory.

> **Memory is retained output made causally available to a later state transition.**

Saving is therefore not merely storage convenience. In this architecture, save or commit is the boundary where temporary work is allowed to become part of the enduring machine.

---

## 18. Retained structure and functioning memory

Not everything that persists is functioning adaptive memory.

A file can remain on a drive for years without affecting another process.

Persistence is necessary, but causal availability is also required.

For retained structure to function as memory, the system must be able to:

- locate it;
- load or reconstruct it;
- interpret its representation;
- recognize its status and authority;
- connect it to the current problem;
- let it constrain or enable the next transition.

Indexes, dependencies, provenance, authority rules, and retrieval lenses are therefore not decorative additions. They are part of the mechanism that turns stored residue into active memory.

A working definition is:

> **Retained structure is a persistent configuration produced by prior interactions that constrains or enables future state transitions.**

---

## 19. The memory layers of the computer

The computer contains several physically real but functionally different memory layers.

### Immediate physical state

- registers and cache;
- electrical and logical states used during the current operation.

### Working memory

- RAM;
- temporary program variables;
- active model context;
- staged revisions;
- current controller state.

Working memory is fast and active, but normally volatile.

### Persistent retained structure

- files;
- databases;
- event logs;
- program artifacts;
- dependency graphs;
- accepted documents and lenses.

These structures remain after the immediate process ends and can be loaded back into working memory.

### Neural-network weights

Model weights are also retained physical structure, stored on disk and loaded into RAM or GPU memory during operation.

They contain compressed competence distributed across many parameters. They are powerful for language, pattern recognition, and proposal generation, but poor as an authoritative project ledger because a specific retained claim is difficult to locate, inspect, attribute, revise surgically, cite, or roll back.

The layers interact:

\[
\text{Persistent Artifact}
\rightarrow
\text{Retrieved into Working Memory}
\rightarrow
\text{Interpreted by Model or Program}
\rightarrow
\text{Proposed Change}
\rightarrow
\text{Governed Commit}
\]

---

## 20. A conventional computer can support adaptation without AI

Artificial intelligence is not required for the adaptive loop.

A conventional computer already has the physical capabilities needed to support adaptation:

- inputs;
- current state;
- persistent storage;
- state-transition rules;
- tests and sensors;
- feedback;
- the ability to make retained state affect later behavior.

The controller can be ordinary software.

It reads observable state and selects an action according to explicit rules.

\[
\text{Observed State}
\rightarrow
\text{Controller Rule}
\rightarrow
\text{Action}
\]

The source of a candidate change can be a human, sensor, fixed rule, optimizer, procedural generator, search process, or neural model.

The adaptive computer is not defined by where proposals originate. It is defined by how proposed changes are tested, retained, rejected, and allowed to alter future possibility.

> **A computer becomes adaptive when prior processing leaves retained structure that is used to regulate later state transitions under external constraint.**

---

## 21. The controller and what changes when AI is added

A controller does not need intelligence. It is the software that reads state and determines the next permitted action according to a rule.

Without AI, the system can still choose among actions such as ADD, REVISE, MAINTAIN, TEST, REJECT, HOLD, or STOP.

When an AI model is added, it becomes another potentially controlling process. Its jurisdiction must therefore be explicit.

### AI as proposal generator

The model generates a candidate answer, document edit, program, hypothesis, plan, or design. A non-AI controller stages and tests the proposal before any durable commit.

### AI as planner

The model may recommend what to attempt next, while the lower controller and governor decide what actions are allowed and what consequences are retained.

### AI as direct controller

The model can be allowed to choose actions directly, but its outputs remain probabilistic and must not be allowed to rewrite the tests, erase history, bypass the governor, or declare its own proposal correct.

The clean hierarchy is:

\[
\text{AI Proposal / Planning}
\rightarrow
\text{Adaptive Controller}
\rightarrow
\text{Governor}
\rightarrow
\text{External Test}
\rightarrow
\text{Commit or Reject}
\]

The AI asks what might be worth trying. The controller regulates activity. The governor enforces invariants. The test answers to reality. The commit mechanism decides what the attempt is allowed to leave behind.

---

## 22. Two adaptive layers

A system containing a neural network can contain at least two different adaptive layers.

### Neural-network adaptation

The network changes its weights through training or fine-tuning.

This retained change is distributed across many parameters, difficult to inspect, difficult to attribute to one event, and difficult to reverse surgically.

### Adaptive-computer retention

The surrounding computer retains explicit changes as:

- documents;
- programs;
- tests;
- dependency graphs;
- accepted claims;
- event history;
- artifacts;
- lenses;
- controller state.

These changes can be staged, tested, committed, rejected, compared, cited, and rolled back.

For this architecture, durable project learning should ordinarily remain explicit and externally inspectable rather than being silently absorbed into model weights.

Neural-weight adaptation may still have a later role, but it should be slow, versioned, and subordinate to the explicit record.

A concise division is:

> **The model thinks. Artifacts and lenses remember. The computer decides what becomes memory.**

---

## 23. Artifacts and lenses

### Artifact

An artifact is retained structure about the world, the task, or the project.

Examples include a definition, program, verified result, design, test, dependency, accepted claim, or current state.

### Lens

A lens is retained structure that changes how artifacts or inputs are interpreted, retrieved, classified, compared, or evaluated.

Examples include authority rules, retrieval priorities, dependency maps, evaluation criteria, classifications, and preferred explanatory perspectives.

Lenses are also artifacts, but they are often more load-bearing because changing a lens can alter many downstream interpretations at once.

A lens revision should therefore face at least as much staging, impact analysis, and external testing as an ordinary artifact revision.

---

## 24. The write path as adaptive virtual hardware

The architecture is implemented in software, but it behaves like a lower-level machine because it defines the rules every higher-level process must obey.

Most software changes what a system does with an input.

This architecture changes what the interaction is allowed to leave behind.

\[
S_{t+1}=U(S_t,I_t,O_t,E_t)
\]

Where the update mechanism \(U\) determines whether an output remains temporary, becomes history, alters a lens, changes a live artifact, creates debt, or is rejected.

The relevant question is not only what the model produced. It is:

> **How did the interaction change the structure that will receive the next input?**

This is why the architecture can reasonably be described as adaptive virtual hardware, a retention architecture, a plasticity mechanism, or a governed write path. It is not literal new silicon. It is the software-defined substrate that controls what becomes durable computational structure.

---

## 25. Structural damage and process cost are different ledgers

A failed attempt can leave zero damage in the live artifact while still consuming real process effort.

A staged revision may require generation, temporary storage, execution, testing, comparison, rejection, restoration, logging, and time.

Therefore:

- structural damage asks what became worse in the live retained structure;
- process cost asks what was spent attempting the change;
- debt asks what unresolved consequence remains afterward.

A rejected staged revision can have:

- structural damage = 0;
- retained useful structure = 0;
- process cost > 0;
- history retained = yes.

The controller should not need to permit injury before it can detect difficulty. It can read damage-free signals such as failed-attempt rate, rejection pressure, time spent, test cost, or work per successful retained change.

Rejection rate is an observable proxy for wasted process effort. It is not yet a measured thermodynamic cost.

---

## 26. Experimental grounding to date

The conceptual architecture has now been tested through a sequence of controlled toy experiments. The raw scripts, diffs, logs, and hashes remain the authoritative experimental artifacts; this section states only the architectural conclusions carried forward.

### Preventive staged revision

A revision regime failed when changes to load-bearing nodes committed before they were checked. One bad revision could therefore cascade through dependent structure before feedback arrived.

Staging high-impact revisions in a temporary copy, applying the same legitimate external test, and committing only successful candidates eliminated the observed catastrophic collapse mode while preserving the live artifact on rejection.

### The missing signal after prevention

Once prevention removed structural damage, the original controller lost the unresolved-debt signal it had used to throttle. Safety was restored, but adaptive regulation disappeared.

### Effort-pressure throttle

Recent staged-rejection rate was then used as an observable, scale-free proxy for failed effort. A free HOLD action allowed the controller to reduce expansion without inventing structural damage.

The frozen mechanism generalized out of sample: structure remained protected, hard phases produced more rejection and HOLD, expansion fell under difficulty, and expansion reopened when rejection pressure disappeared.

### Executable procedural artifacts

The affine candidate representation was later replaced by executable compositional program artifacts while the controller, governor, accounting, history, and schedule remained frozen.

The architecture remained stable, regulated, and bounded on affine targets. This established compatibility with executable retained programs, not open-ended adaptation, because the target family still rewarded mostly affine solutions.

The next designed test uses genuinely non-affine target families so the wider representation must perform real compositional work.

---

## 27. Current architecture

The current design can be summarized as:

\[
\text{Input}
+
\text{Existing Retained Structure}
\rightarrow
\text{Proposal}
\rightarrow
\text{Staged Candidate}
\rightarrow
\text{External Test}
\rightarrow
\begin{cases}
\text{Commit to live artifacts and lenses}\\
\text{Reject while preserving live structure}
\end{cases}
\rightarrow
\text{History and Process Signal}
\rightarrow
\text{Controller Update}
\]

The model, human, sensor, or generator supplies proposals.

The computer supplies the boundary, state, tests, history, controller, governor, and commit rules.

The durable memory is the accepted artifact-and-lens structure, together with the event history explaining how it changed.

The deepest design question is therefore not simply how to make a model produce a better answer.

It is:

> **What kind of machine should exist around a thinking model so that its outputs become disciplined, testable, reversible, cumulative structure?**

## Related Work

- **Extends:** The Field — Carries the field's state, input, response, output, retained-change, resource, and nested-system structure into a computational setting without claiming identical material mechanisms.

- **Uses concept from:** Adaptive Framework — Core — Uses boundaries, state history, error, retained change, unresolved consequence, ledgers, and recursive update.

- **Related to:** Local Multi-Agent AI Team — The earlier agent architecture already implemented shared retained debt, role-specific agents, and a Reality → Observe → Predict → Error → Adjust loop.

- **Open connection:** Thermodynamics Trunk — The proposed simulated metabolism is intended to mimic the constraint structure of thermodynamic cost without claiming that simulated units are literal physical energy.

- **Applied by:** Simulated Thermodynamic Cost Prototype — A future toy system should test whether every attempt can create unavoidable, state-dependent net change that alters future possibility.

- **Grounded by:** Preventive Staged Revision Experiments — Unchecked commits to load-bearing nodes produced cascade failure; staging and external validation protected the live artifact before commit.

- **Grounded by:** Effort-Pressure Throttle Experiments — Recent staged-rejection rate restored throttling and reopening without reintroducing structural damage; the signal is a process-effort proxy, not literal energy.

- **Prepared for:** Real LLM Proposal Engines — A language model can later replace or supplement the procedural generator while remaining subordinate to external tests, the governor, and the governed commit path.

- **Applies beyond:** Artificial Intelligence — The same governed retention architecture can accept proposals from humans, sensors, optimizers, procedural search, or deterministic controllers.

## Open Questions

- What is the smallest computational mechanism that makes every attempt produce an unavoidable, state-dependent net change in a simulated resource economy?

- How should process cost be measured beyond staged-rejection rate without confusing failed effort, structural damage, and unresolved debt?

- What variables are actually required to represent slow-ledger health, slow-ledger capacity, unresolved debt, available resource, and recovery without decorative bookkeeping?

- How can slow-ledger health and capacity be externally operationalized so neither an agent nor its proposal model can game the accounting?

- What exact conditions turn a persistent artifact into functioning memory rather than inert storage?

- How should the downstream burden of a lens change be measured when one interpretive rule can alter many later retrievals and judgments?

- Which controller decisions should remain deterministic and which, if any, may safely be delegated to an LLM?

- How can real LLMs be inserted as proposal generators while preserving reproducible tests, staged commits, immutable history, and rollback?

- When, if ever, should repeatedly validated external structure be compressed into neural-network weights?

- Can the same retention and controller architecture improve non-AI systems such as CAD change control, scientific model revision, maintenance planning, and configuration management?

- What would falsify the claim that this architecture adds something beyond version control, transactions, retry limits, prompt memory, or an ordinary debt ledger?

## Revision History

### R1 — July 11, 2026

- **Field-to-computer mapping established**

  - **What Changed:** Established The Computer as a field-based intuition layer for computational adaptation, mapping boundary, current state, input, computation, output, and retained change onto a computer system.

  - **Forcing Error:** A computational analogue was needed for the field architecture so that the same structural questions could be asked of AI, software, CAD, and persistent knowledge systems.

  - **Verification:** The mapping is structurally useful but remains an analogy across different substrates; it does not by itself establish a complete mechanism of computational adaptation.

### R2 — July 11, 2026

- **Thermodynamic constraint problem added**

  - **What Changed:** Added the requirement that every attempt consume or perturb something and that the important quantity is the net state left afterward, not the isolated attempt cost or immediate result.

  - **Forcing Error:** A simple state-transition model allowed effectively free iteration and therefore failed to capture the unavoidable cost structure present in real adaptive systems.

  - **Verification:** Conceptual requirement established; the computational simulation mechanism remains open and must be tested in a toy environment.

- **Slow-ledger hierarchy formalized**

  - **What Changed:** Defined the optimization order as slow-ledger health first, slow-ledger capacity second, and immediate performance third.

  - **Forcing Error:** Immediate output can improve while the underlying system becomes more brittle, debt-loaded, contradictory, or less able to absorb future demand.

  - **Verification:** The hierarchy is consistent with the broader adaptive framework, but computer-specific health and capacity measures remain unresolved.

- **Battery-versus-metabolism distinction introduced**

  - **What Changed:** Separated a fixed simulated energy budget from the deeper requirement for a state-dependent simulated metabolism or resource economy involving availability, maintenance, debt, repair, recovery, and changing capacity.

  - **Forcing Error:** A fixed energy counter only limits the number of attempts; it does not make the same attempt have different consequences in different states or alter future absorbable demand.

  - **Verification:** The distinction identifies the missing implementation problem but does not yet solve it.

- **External accounting requirement added**

  - **What Changed:** Specified that slow-ledger accounting must exist outside the agent's own claims so attempts have unavoidable consequences that constrain later action.

  - **Forcing Error:** An agent that can self-report its own health can game the accounting and turn the metabolism into a prompt instruction rather than an enforced environment.

  - **Verification:** The principle is testable by implementing an external transition layer and checking whether the agent can still bypass or manipulate the state update.

- **Narrow computational research problem defined**

  - **What Changed:** Reduced the broader question of computer adaptation to the smallest testable mechanism that couples attempts, state-dependent consequences, slow-ledger health, capacity, debt, repair, and future constraints.

  - **Forcing Error:** The prior problem statement was too broad to implement or falsify in a single prototype.

  - **Verification:** The problem is now narrow enough to design a toy experiment whose failure conditions can be stated explicitly.

### R3 — July 11, 2026

- **Save and commit boundary formalized**

  - **What Changed:** Defined output, save, persistent artifact, later retrieval, and functioning memory as different roles in one state-transition cycle.

  - **Forcing Error:** The prior paper referred to retained change but did not identify the concrete boundary where temporary application state becomes durable computational structure.

  - **Verification:** The distinction follows ordinary computer operation: working representations exist in volatile memory, while save or commit encodes selected state into persistent storage for later reconstruction.

- **Retained structure separated from inert persistence**

  - **What Changed:** Defined retained structure as prior configuration that remains causally available to constrain or enable future transitions, and identified indexing, authority, provenance, and retrieval as part of active memory.

  - **Forcing Error:** A forgotten file can persist physically without affecting any later action, so persistence alone was too weak to define adaptive memory.

  - **Verification:** The definition is operational: remove later retrieval or causal influence and the retained object no longer functions as memory for the system.

- **Non-AI adaptation and rule-based controller established**

  - **What Changed:** Separated the adaptive computer from artificial intelligence and identified the controller as ordinary software that maps observed state to permitted action.

  - **Forcing Error:** Treating the LLM as the source of adaptation obscured that state retention, feedback, tests, and rule-based control already support adaptation in a conventional computer.

  - **Verification:** The existing toy systems regulate ADD, REVISE, HOLD, testing, and commitment using deterministic software while the proposal source remains replaceable.

- **AI controller hierarchy defined**

  - **What Changed:** Assigned distinct jurisdictions to the AI proposal or planning layer, adaptive controller, governor, external test, and commit mechanism.

  - **Forcing Error:** Adding an AI introduces another potentially controlling process; without explicit authority boundaries it could judge its own outputs, alter tests, or bypass retention rules.

  - **Verification:** The hierarchy is enforceable when model outputs remain proposals and lower layers retain permission, validation, history, and commit authority.

- **Two adaptive layers and explicit memory authority introduced**

  - **What Changed:** Separated neural-weight adaptation from externally governed artifact-and-lens adaptation, making explicit retained structure the authoritative project memory.

  - **Forcing Error:** Knowledge stored only in distributed weights is difficult to inspect, cite, attribute, revise surgically, or roll back.

  - **Verification:** Artifacts and lenses can be versioned, tested, staged, cited, and independently inspected while the model remains a replaceable reasoning and proposal engine.

- **Adaptive virtual hardware formulation added**

  - **What Changed:** Defined the software write path as a lower-level retention and plasticity architecture controlling what outputs are allowed to become future structure.

  - **Forcing Error:** The hardware language was being used intuitively but lacked a precise basis. The deeper distinction is between content and the update mechanism that determines retained residue.

  - **Verification:** The formulation remains technically honest: it is not new silicon, but a software-defined substrate whose rules constrain every higher-level model or application.

- **Structural damage, process cost, and debt separated**

  - **What Changed:** Distinguished damage to the live artifact, effort consumed by an attempt, and unresolved consequence carried forward.

  - **Forcing Error:** Preventive staging removed structural damage and therefore erased the old debt signal, even though rejected attempts still required work.

  - **Verification:** Effort-pressure experiments restored throttling and reopening from staged-rejection history while keeping live structural health protected.

- **Toy experimental evidence integrated**

  - **What Changed:** Added the current conclusions from preventive gating, effort-pressure control, and executable procedural artifact experiments, while preserving the boundary between supported results and open thermodynamic or LLM claims.

  - **Forcing Error:** The R2 body still described the mechanism as a future toy experiment even after multiple frozen and out-of-sample tests had been reported.

  - **Verification:** The paper records only the architectural conclusions; raw scripts, diffs, logs, and hashes remain the authoritative evidence for exact experimental claims.
