# Supercompensation vs. Daily Normalization

## The standard model

**Origin.** Yakovlev, 1949–1959: supercompensation of muscle and liver glycogen and muscle phosphocreatine following exercise. Both are storage quantities with regulated setpoints — the class of variable that can genuinely overshoot. Deplete a tank, refill past the line.

**Shape.** A session disturbs the system. Performance dips below baseline, recovers, rebounds *above* baseline, then decays back if nothing follows.

**Operating rule.** Time the next session at the peak of the rebound. Too early and the system is still recovering; too late and the gain has decayed.

**What the schedule is built from.** The recovery curve. To train correctly you must know where the peak is, which means knowing how long recovery takes for the load you gave. Session spacing, frequency, and periodization all descend from this estimate.

**Load direction.** Upward. Each cycle starts from a higher baseline, so the load must rise to stay above threshold.

**What is being timed.** An excursion. The system is deliberately driven out of its ordinary state and the return trip is scheduled.

**Internal admission.** Heterochronism — different tissues recover on different timelines, tendon and bone considerably slower than muscle. The model states this and then still prescribes training at *the* peak. One clock, admitted to be many.

---

## Daily normalization

**Shape.** No scheduled excursion. The base exposure is sized so the state it leaves is admissible for the same exposure tomorrow. This does not claim physiology never dips — a transient disturbance that has cleared before the next occurrence falsifies nothing. What is rejected is the dip-and-rebound curve as the object the schedule is built from.

**Operating rule.** One high-force single per lift per day, below peak. Base practice around it, cheap and distributed.

**What the schedule is built from.** Nothing. There is no schedule. Cadence is fixed at daily and the *dose* is the variable — reduce until it recurs. If a candidate exposure only fits every third day it is too large *to be base*, and the answer is a smaller base exposure, not a longer gap. This governs the base and nothing else. A sharp edge is not required to recur daily and is not disqualified by failing to — maximal sprinting is permanently edge precisely because it sits at a ceiling that does not become ordinary.

**Load direction.** Held, then advanced when the exposure stops behaving differently from the days preceding it. Advancement is read, not scheduled.

**What is being timed.** Nothing. Sizing replaces timing.

**Multiple tissues.** No clock is being chosen, so heterochronism does not arise in the same form. The requirement is narrower than it may read: the observable channels stay admissible, the longitudinal record stays acceptable, and the blind governor bounds accumulation where observability fails. Slow tissues are handled by the size of the dose and the rate cap, not by predicting their recovery and not by any claim to know their state. See OPEN-2. That is a ceiling-only account and is incomplete on its own; see *Floors and ceilings under partial observability*.

**Admission is event-based, and asymmetric.** Any joint score flags: loading stops on that joint for the day, immediately, with no duration estimated. Entry to rehab is instant because a score firing is a positive read — something crossed.

Exit is not the converse. A score failing to fire is the quiet observable, and a quiet observable is what a slow ledger looks like while it is still loading. Clearance therefore runs on a separate and stricter standard: zero held across a sustained window, swept through deep range, not a point sample. Instant in, slow out. That asymmetry is not an inconsistency; it is the correct response to an instrument that reports failure but not margin.

*Two fourteens, and they are not the same rule.* The clearance window above is flag-triggered and gates return to normal loading on one joint. The fortnightly interruption described later is untriggered, applies to the whole accumulation, and reads nothing. They share a number and nothing else. Whether the clearance window is still fourteen days — or was superseded when entry moved to immediate rehab on detected abnormality — is not settled here. OPEN-6.

Passing the governor is an admission, not proof that every slow ledger resolved.

---

## What the top exposure is for

The operating rule above states the single and its size constraint. It did not state its function, and the size constraint is not the function.

**Base adapts. Edge probes.** The accumulation lives in the base. A single minimal exposure is not the driver pulling the organism upward, and the architecture does not rely on it being one. It may contribute adaptation; nothing is built on that contribution.

**Its function is to produce catchable error.** An exposure entirely inside the base generates none — execution is clean, nothing deviates, and the sensing stops improving because there is nothing to detect. Error is the calibration signal. The edge is where error is available.

**That sets the dose criterion from a different direction.** Not how much can be absorbed, but how much error can be produced and attributed. Below the band there is nothing to sense. Above it the error arrives faster than the catch.

**Why one.** The first repetition is the only uncontaminated read. A second is performed in the residue of the first, so a deviation there cannot be attributed to the demand rather than to the residue, and unattributable error calibrates nothing. The single is not restraint. It is the minimum exposure that yields an uncontaminated, attributable error signal — the least damage required to acquire useful error, not the most that can be taken before the signal fouls. The distinction matters: *largest clean dose* points the optimization at the contamination boundary, which is the wrong direction to be pushing from.

**Below peak, and why that is not a margin.** Control caps the strength side outright: a maximal lift is the load at which control fails, so *controlled single* and *maximal* are mutually exclusive there. The top strength exposure is not a maximum voluntarily held back. There is no maximal tier on this side to hold back from.

Where a genuine ceiling does exist — maximal sprinting — it is permanently edge, because it is defined at the boundary of present capability. Only the floor moves. The project is not making maximal effort cheap; it is making fast ordinary.

---

## Two calibration loops

**Online.** During the exposure: mechanics, contact, coordination, position. Sense deviation, correct or stop. This is the only control in the architecture that operates *inside* the bounded action — the governor caps rate between exposures, the ledger evaluates afterward, promotion happens between sessions. It is therefore the only thing that reaches a single-exposure failure, which is the failure mode nothing else here can touch.

**Longitudinal.** The ledger, calibrating the online instrument against what followed — misses, subsequent trajectory, changing flag patterns, dated probe definitions. It cannot ask whether successful catches were predictive; a prevented event leaves nothing to compare against. The first controls the rep. The second improves the first, and does so from the failures only.

**Asymmetric evidence, stated.** A catch that worked leaves no trace of what it prevented. Stopping when something was wrong and stopping when nothing was wrong are indistinguishable in the record. Online sensing accumulates its misses and none of its successes; it cannot be scored against later outcomes the way a formal probe can. It improves through use and the improvement is not demonstrable. This is not a defect to be fixed — it is the shape of the evidence, and calibration works anyway because the misses are the training signal.

**Domain.** Online sensing reads the fast channel in real time. Bone and tendon emit nothing during the exposure. Sharpening perception raises the ceiling on control quality and does nothing for the tissues the governor exists for.

**A confound this introduces.** A sharper instrument raises the flag rate. The same body under a more sensitive instrument triggers more holds — not regression, but exactly what regression would look like in the record. Instrument change and state change are confounded unless the probe definition is itself recorded and dated. It currently is not.

---

## Side by side

| | Supercompensation | Daily normalization |
|---|---|---|
| Core object | A recovery curve with a peak | A state transition |
| Question asked | How large a hit, and when do I hit again? | How small must this be to recur tomorrow? |
| Free variable | Timing | Dose |
| Fixed variable | Dose (rises each cycle) | Cadence (daily) |
| Requires knowing | Where the peak is | Whether the probe flags today |
| Fatigue | Instrumental — evidence the threshold was crossed | Cost. Always paid, never evidence of error |
| Dose too large | Inferred from a missed peak | Reported directly: recurrence breaks |
| Multiple tissue timelines | Admitted, then ignored | Absorbed into dose size |
| Progression trigger | Calendar and completion | Exposure stops behaving differently |
| Failure mode | Peak missed; overtraining or lost gain | Dose too large; flag and stop |
| Bad day | Wasted or harmful session | Observation |
| What the top exposure is for | Crossing the threshold that triggers the rebound | Producing attributable error |
| Identification vs. advancement | Monitored versions attempt to read recovery while dose may also change; fixed-clock versions assume the recovery schedule rather than identify it | Holds commanded input across a comparison block, then advances after normalization. Gains cleaner identification by giving up simultaneous advancement; observable stability does not establish complete hidden-state stability |

---

## Identification and advancement

*This is not a new objection. It is the identification rule already stated in the operating model, applied to the comparison. The rule: hold the commanded input, so that observed change is attributable to changed state rather than to changed input. Only the commanded input is held — sleep, food, ambient load and the rest vary and are not controlled, which makes the read statistical rather than exact and judged across a run of days. Advancement and diagnosis cannot occupy the same comparison cycle.*

Applied here, supercompensation forks, and the objection lands differently on each branch.

**Monitored supercompensation** reads observed recovery or readiness to infer when the next session should land, while the dose is also being raised cycle to cycle. Control and identification are entangled: a shift in apparent recovery time can come from the changed state or from the changed input, and the operating rule provides no way to separate them.

**Fixed-clock supercompensation** does not have that problem, because it is not identifying anything. Forty-eight hours for this, seventy-two for that, taken from a table. The recovery schedule is assumed rather than observed, and nothing in the method checks whether the current state follows it.

The first cannot cleanly separate changed state from changed input under that design. The second does not measure.

**The cost on this side, stated.** Daily normalization separates identification from advancement sequentially. The gain is a cleaner held-input comparison; the cost is that comparison cycles are cycles not spent advancing the input.

**The limit, stated.** A stable block establishes stability of the governed observables under the held regime, not proof that every hidden or slow biological ledger has stabilized. The identification rule licenses one direction only — observed change implies changed state. It does not license the converse, and a quiet observable is exactly what a slow ledger looks like while it is still loading. This section does not close OPEN-2.

**Provenance — related prior structure, not authority.** Feldbaum's dual control: control actions in a system that is incompletely known simultaneously regulate the plant and reveal information about it, so an informative probe may be poor control and the best immediate control action may teach little. Base/Edge does not implement dual control. Its held-input rule instead separates some identification and advancement operations sequentially — one policy response to a related conflict, carrying the cost stated above. The tension is borrowed; the resolution is not.

---

## Sampling density and its domain

Daily cadence gives the densest readings, the fastest detection of a bad configuration, and the smallest exposure between checks. That is a real property and it is the strongest thing on this side of the comparison.

It has a stated domain, and the domain is the admission decision.

**Where density works.** When the sampled state clears between samples. The exposure is sized so it does, which is what makes daily the right cadence rather than an arbitrary one.

**Where density buys nothing.** No sampling rate reaches a quantity that does not vary on the sampling clock. Bone remodels across months; sampling a daily observable more often returns noise around a value that has not moved. Density is a property of the controller, not evidence about the tissue.

**Where density costs.** Each probe is itself an exposure. Sampling more often loads the joint more often. This is why the operating rule is one high-force single per lift per day rather than several.

**What density does not supply at any rate.** Density, the probe, and the flag rule are all decisions about today. None of them is the progression trigger. Normalization is the same demand recurring with less disorder — a comparison across a block. No sampling rate constitutes it. The block length and the flattening criterion are not yet stated, and this document does not state them.

---

## The disagreement, precisely

Not over whether stress drives adaptation. Demand producing stress, stress carrying a readable signal, resolution costing something, and an adaptive band between too little and too much — all retained.

The disagreement is that supercompensation takes a storage variable's deplete-and-refill curve and promotes it into a general adaptation clock, then schedules training against a presumed peak on that clock. Tendon, bone, and recruitment access do not deplete and refill; they remodel. The curve describes one variable type, not the organism.

**The replacement is not a better estimate of the peak. It is the removal of the question.** An exposure small enough to recur daily never requires knowing where a rebound lands, because the system is never driven far enough out for the return trip to need scheduling.

**Where the argument closes and where it does not.** Every-third-day spacing was justified by slow-tissue completion inside the gap. Slow turnover makes that false, and the justification is removed by argument, with no observation required. That is finished.

What the elimination does not do is support the survivor. An unopposed option acquires nothing from the absence of a competitor. Daily normalization is left standing and unopposed; it is not thereby established. Any third arrangement not named here is equally unopposed.

**Conceded:** glycogen supercompensation is real and carbohydrate loading works. What is rejected is the generalization, not the finding.

---

## Spacing arguments that do not descend from supercompensation

Removing supercompensation removes the *stated* justification for spacing. It does not establish that no mechanism could justify spacing, and three candidates exist. The first two are recalled from the reference set and **not verified in the session that produced this document**; the numbers are the part to check.

**Tendon net balance — the one that could cut against daily.** Collagen degradation is reported to exceed synthesis for roughly the first day after heavy loading before crossing positive (Magnusson / Kjaer). If that holds, the conventional 48–72h tendon spacing has a real basis, and it is not supercompensation. But the mechanism is strain-gated: the negative window follows high-strain loading and is not a property of any exposure. It therefore defends spacing for doses above a strain threshold and says nothing about a base dose sitting below it. Dose-sizing already handles this — an exposure small enough to recur daily is by construction below the gate. The threshold value is unknown and is not established here.

**Bone mechanotransduction — the one that favours distribution.** Osteocytes are reported to desensitize within a few dozen loading cycles and resensitize over hours, with the same total cycles split into separated bouts producing a larger osteogenic response than one continuous bout. If that holds, small and frequent is not merely tolerable for bone but the better stimulus.

**High/low (Francis) — the strongest of the three, and not a recovery curve.** The claim is not that a peak must be timed. It is that high-intensity exposure carries a systemic cost requiring roughly 48–72h, and — separately and more sharply — that submaximal work inside the gap *interferes* with maximal expression rather than merely failing to help. Removing supercompensation does not touch either claim. [COACHING PRACTICE]

Four things follow.

*It is testable in this architecture's own units.* The interference claim is directional: top-exposure output should hold or rise across months while the base floor rises underneath it. If the floor rises and the ceiling does not, the base is consuming the edge and the claim is confirmed. This is the falsifiable form of the whole proposal.

*The dose/session distinction is a burden shift, not a refutation.* The evidence usually cited for long recovery after sprinting comes from conventional sessions — multiple reps, starts, fly work, plyometrics, lifting in the same unit. That establishes the cost of a session package. It does not establish the cost of one bounded exposure. What follows is that the recovery requirement of a single exposure is unestablished, not that it is small.

*The scope of that shift, stated.* It holds for central cost. It does not transfer to hamstring, which fails from single exposures and does not require accumulated dose to do so. And fast base running sits inside the band where eccentric hamstring demand rises disproportionately, so a week of daily fast base contains no day on which that tissue is unloaded — which is a thing Francis's low days supply for free. That is the structural cost of the proposal. The architecture has a *response* — bound the dose, run the online controller for single-exposure error, rehab detected abnormality immediately, cap the rate permanently. A response is not an answer. None of it establishes that daily exposure in that band without unloaded days is tolerable, and the online controller, the only element that reaches a single-exposure hamstring failure, accumulates its misses and not its saves. Policy is in place; the question is open.

*Where the disagreement actually is.* High/low encodes a real constraint — an athlete cannot indiscriminately accumulate demanding work — and attaches it to a fixed calendar. The disagreement is over attachment, not over caution. A calendar cannot move with the athlete. Attaching the same caution to the *rate at which the floor rises* keeps it in force permanently and still lets the floor climb. Not established: whether normalization lowers systemic cost or only local cost. If only local, a week of fast base is a high/high week and Francis's criterion is met on his own terms.

None of the three is load-bearing for the argument above. All are recorded so that a later reader does not mistake "supercompensation is dead" for "no mechanism bears on spacing."

---

## What is being validated, and by what

**Policy control, not causal identification.** The framework does not need the adaptation mechanism decomposed. It needs: demand presented, resolved repeatedly, demand raised, resolved repeatedly, while function holds. *Resolved* already carries the flag rule — an exposure that leaves a problem surfacing in the joint/function system was not resolved, whatever its execution looked like.

**Which means the reference is a constraint, not a number.** Requalification elsewhere asks whether the same system still passes the same test. Training's system is *supposed* to change, so a probe reading differently is expected rather than alarming, and an original numerical baseline is the wrong object. What must hold through state evolution is a constraint: capacity rising while joint abnormality stays zero and control constraints remain satisfied.

**Inherited flaw, stated.** A constraint built from signal-triggered channels is satisfied vacuously wherever the signal does not exist. For bone and tendon it is met by silence. It reads as always-true in the domain it most needs to bind.

**What the trajectory judges and what it does not.** It judges policy sufficiency. It does not judge the account of why — a wrong mechanistic story that produces a working policy is confirmed identically to a correct one. The substrate confirms the bundle; only the record can decompose it. This is the argument for keeping the bookkeeping on this side, not a lighter version of it.

**What it cannot separate.** For bone and tendon, safe accumulation and pre-failure read the same: capacity rising, function holding, up to the discontinuity. The criterion is well-posed for anything that degrades gradually and reports as it goes, and reads identically in both branches for the two tissues where it does not.

**Asymmetry of the evidence.** A good trend under a policy is weak evidence that the policy caused it and cannot rule out that a more aggressive one would have done as well. A bad trend is much stronger evidence against. The record falsifies faster than it confirms. The honest early claim is *not yet contradicted*, not *supported*. And it is one arm: there is no counterfactual athlete under high/low, so sufficiency is available and superiority is not.

## Why the governor does not retire

Normalization is what creates the temptation to accelerate — demand feels ordinary, raise it, feels ordinary, raise again. Successful adaptation drives runaway progression on its own. The governor is not scaffolding removed once things feel routine; feeling routine is when it is the only thing still working.

Two authorities, kept separate. **Demonstrated resolution determines whether movement is permitted. The governor determines how fast permitted movement may occur.**

And a structural reason the record cannot absorb it: **latency exceeds the decision interval.** The gap between a promotion and the evidence that would evaluate it is longer than the gap between promotions, so authorization always runs several steps ahead of the last verifiable one. The governor covers the interval the record cannot have closed yet. It is not redundant with the ledger; it is what stands where the ledger has not yet reported.

---

## Floors and ceilings under partial observability

Every governor stated above bounds from one side. The flag rule, the dose cap, the rate cap and the clearance window all answer *how much loading is too much*, and all of them are satisfied by less. For a tissue with a working observable that is adequate, because the observable eventually objects to underloading through lost capacity. For a tissue with no field-readable state channel it is not, because nothing objects to anything. A ceiling-only controller can drift its exposure toward zero and report itself compliant the entire way down.

**Physiology and accounting are different objects.** Impact loading does credit bone. This framework declines to book that credit, because it cannot read the individual accumulated state well enough to spend against it — so running is priced as cost at every exposure and never amortized into the slow ledger. That is a refusal to spend an unverified asset, not a claim that the asset does not exist. Physiological bone credit and admitted bone credit are separate quantities, and the second must not be allowed to stand in for the first.

**The bias that creates has a direction.** The refusal protects against overestimating slow-tissue capacity, and therefore systematically underestimates it. The gap widens under time on the policy: actual capacity rises, admitted capacity does not. The failure this produces is not overload. It is chronic under-allocation of the loading that tissue requires to develop at all.

**The two failures are not equally observable.** Excess loading eventually produces an event — a reaction, a fracture — that reports itself, late and expensively but unambiguously. Insufficient loading produces no event. Nothing announces that capacity went undeveloped; it presents as ordinary and becomes legible only when some later demand exceeds it. Conservatism is therefore not automatically the safe direction. It is a direction, with a cost, and it looks cheaper only because its failures do not generate observations.

**The correction is a floor, not a credit channel.** The framework cannot say *this much impact yields this much bone capacity*; the coefficient is not available, and inventing one would be exactly the false confidence the refusal exists to prevent. It can say that a minimum mechanically meaningful exposure must recur. Bounded above by the governor and the flag rule, bounded below by the floor: floor ≤ admissible exposure rate ≤ ceiling. Nothing about tissue state is asserted at either bound. This is the first constraint in the document that does not require reading the tissue it governs — every other one is a response to an observable, and this one is a standing requirement that holds whatever the channels report. That is the right shape for a tissue that has no channel.

**The floor is a rate requirement, not accumulated credit.** Not *this many contacts this month, so bone is covered* — that is bookkeeping against an unmeasured balance again, and bone saturates within a bout regardless, so a monthly total is satisfiable by stacking in a way the tissue does not read. The floor specifies that exposure *recurs*, at a cadence. This gives it the same property as the fortnightly interruption: it is auditable without measuring anything, because compliance is a fact about the schedule rather than about the athlete.

**It must contain magnitude, not only recurrence.** A floor stated in contacts or minutes is satisfiable by large volumes of low-magnitude running, which is the exposure least likely to supply the demand the constraint exists to preserve. Bone appears to read magnitude and novelty rather than accumulated cycles. [MECHANISTIC for the saturation and magnitude-gating; OBSERVATIONAL and weaker for the sprinter-versus-distance bone density contrast, which is cross-sectional and cannot separate training effect from selection. Per-contact force figures are recalled from the reference set and not verified here.] So the floor is a pair — a minimum magnitude class and a minimum recurrence — with the ceiling above both.

The pair is in tension with the ceiling by construction: the ceiling wants to cap high-magnitude exposure and the floor requires some of it. That is a corridor, not a contradiction. Whether the corridor is wide or narrow is unknown and worth establishing, because a narrow one would mean the two constraints have nearly specified the running dose without anybody choosing it.

**A veto overrides the floor and does not erase it.** A joint flag is a hard stop and outranks the floor; when the knee says zero locomotion, zero locomotion wins. What changes is the bookkeeping. The pause is not physiologically neutral, and the record should not read as though it were. The correct entry is *bone floor unmet, higher-priority veto in force* — a debt of known duration and unknown depth. The current zero-prescribed-locomotion phase is the first instance, and it is accruing now.

**The general claim.** Where tissue state cannot be read directly, safety cannot mean only limiting excess. A valid controller must also prevent chronic underexposure to the demands known to maintain or develop that tissue. [SYNTHESIS.]

Re-entry after a period of unmet floor is not specified. OPEN-7.

---

## Status

**Frozen 11 August 2026.** SHA-256 of the content immediately prior to this marker: `fb65164a71ac2e50cb388f484970e0072c8ab99e0ed2f8e03ee0e56c7c584f36`.

Freezing does not mean finished. The open items below are open, and the document is more useful with them named than it would be with them argued further. The stopping condition is that the framework is explicitly open and empirical, so continued conversational pressure will keep producing edge cases indefinitely without increasing what the document can support. What is required is not that the uncertainties be resolved, only that none of them masquerade as resolved.

The next revision should be generated by observation. An objection alone does not unfreeze this; a reading does.

**Untested.** The daily module described here has not been run. There is no observational content on either side of the comparison, and nothing in the record counts for or against it. The case is mechanistic and negative — the alternative's justification collapsed — and it is exactly that.

**Blocking dependencies.** A comparison block requires a held commanded input, which is not yet specified. The floor/ceiling architecture introduces a prior coverage dependency: the governed tissue set itself must be enumerated. Without a tissue roster the ledger can detect violation of an existing floor but cannot detect omission of a floor that should have existed — noncompliance leaves a missing event and is findable; a coverage omission leaves nothing, because the event type was never created. The roster therefore precedes floor and ceiling assignment, and commanded inputs follow from those assignments.

This is what admitting underexposure as a failure state costs. The record previously had one audit surface — what happened. The floor adds a second — what was required and did not happen. The roster adds a third — what should have been required and was never encoded. Only the first is answerable from events alone.

**What the roster does not fix.** It is an external completeness specification with no internal validator, so it can omit a tissue exactly as the ledger omitted a floor, one level up. It does not terminate the regress; it relocates the omission onto a short enumerable surface that can be read in one pass, which the event stream cannot. It should be dated and revisable on the same terms as any other definition here, and its own discovered omissions logged rather than quietly patched.

**One rule the roster can be built from.** Within the governed set — the tissues and control systems that carry mechanical demand in service of the stated goal — a ceiling is required wherever an available exposure can exceed local capacity. That is every row in practice, but it is a scoped claim about this set and not a general property of things.

Whether a row needs an *explicit* floor is not settled by observability alone. Two conditions must hold together: chronic underexposure has to produce a loss the system intends to prevent, and that loss has to fail to report itself in time for the ordinary loop to correct it. Either one absent removes the case. An unobservable structure with no underexposure consequence earns no floor from its silence, and a consequential one that announces its own decline is already handled by feedback that exists. Muscle sits in the second escape: it can certainly be undertrained, but lost capacity surfaces fast enough that a standing blind floor adds little on top. Bone sits in neither. [SYNTHESIS — follows from the observability argument, not from any source.]

**The two conditions are not independent, at least for bone.** Its underexposure consequence is severe partly *because* the channel is weak: undeveloped capacity is discovered by exceeding it, so the discovery event is the injury. Read as two separate factors the rule overstates its own resolution — bone is not merely high on both axes, it is high on one because of the other. The ranking is unaffected, since bone is the first row under either reading. What changes is that the rule orders rows and does not score them.

**And the roster needs a join to be operational.** Its rows are tissues; the exercise library's rows are movements. A structure that no movement names is invisible on one side and unloadable on the other, so coverage is only computable once each tissue is mapped to the exposures that load it. Without that mapping the roster states intent; with it, coverage becomes a query over existing events.

**Open, unchanged.** OPEN-2. Governed observables can be quiet while a slow ledger is still loading. The flag rule narrows the exposure window; it does not close this. Fourteen days at zero is fourteen days of a fast instrument reading zero.

**Open, new.**

- **OPEN-3. Instrument drift is confounded with state change.** A probe family that sharpens over time raises its own flag rate. Nothing currently distinguishes "the body got worse" from "the instrument got better." The defense is recording and dating the probe definition; not implemented.
- **OPEN-4. Compensation is inside the probe, not around it.** The probe is instrument and load path at once. When strategy shifts, the metric does not merely stay good while the mechanism deteriorates — a well-compensated pattern reads *better* while redistributing load, so the reading and the failure mechanism become correlated in the wrong direction. No conscious adversary is required; constraint satisfaction is enough. This is where measurement-as-intervention and Goodhart are one item rather than two.
- **OPEN-5. Probe results and governor compliance are not ledger events.** Promotions are — the preset species is append-only, timestamped, latest-wins, and changed only by explicit edit — so a promotion can be located in time. It cannot be evaluated against the state it was made in, because the probes and the scheduled interruptions leave no residue. Governor compliance is the higher-value of the two: the governor is the safeguard that does not depend on probe coverage, so a scheduled interruption that silently did not happen leaves only the signal-triggered rule, which is blind to bone and tendon.
- **OPEN-6. The clearance window is unresolved.** Entry to rehab moved to immediate-on-detected-abnormality. Whether exit still requires fourteen days at zero, or whether that standard was superseded by the change to entry, is not decided. The two rules are now stated as distinct objects; which one governs exit is not.
- **OPEN-7. Re-entry after an unmet floor is unspecified.** When a veto clears, does the previous floor simply resume, or does the known duration of the violation alter the return corridor? The missed loading cannot be repaid by volume: the depth of lost capacity is unobservable, and stacking is precisely what bone does not read. So the answer is almost certainly rate-governed re-entry rather than repayment — which puts the return under the control of the tissue that reports nothing until a reaction exists. Neither the rate nor what sets it is stated here. Note also that the floor is currently unmet by an unbounded and unnamed duration, since the veto has no scheduled end.

**Compliance, and why it is not a footnote.** Two governor violations are on record — five one-arm pull repetitions on 18 July, and three near-maximal 400s inside eleven days ending 8 June. Both were accumulations of the edge, which is the one thing the edge rule forbids. Neither was a design failure; the prescription existed. It existed in memory, which is not a place a cap can be enforced from, and both violations looked identical from inside the moment: the demand was available, nothing hurt, and nothing in the loop between deciding and doing forced an encounter with the rule. An unrecorded governor is unenforceable. This is the forward-facing half of OPEN-5 and the more useful half.

**A rate finding, from the 400 m record.** Roughly 1:38 in mid-March to 1:15 on 8 June, with seventeen of those seconds inside the final month. No structural tissue moves at that rate, so the gain was almost entirely neural, coordinative and metabolic — meaning expressed capacity was pulling away from absorbable capacity throughout. The curve read as validation and was closer to a divergence readout. This yields a governor criterion the document does not otherwise have: **if expressed capacity is rising faster than the slow ledger's maximum possible adaptation rate, margin is contracting regardless of how anything feels.** [SYNTHESIS — the maximum plausible rate is not quantified here.]

**Corrections logged this revision.**

- "Denser is always better" was stated without a validity domain and is now bounded to the admission decision. Density is a controller property, not evidence about tissue, and each probe carries a cost.
- The flag rule as previously written covered entry to rehab only. Exit was reading clearance off the instrument that cannot certify it. Entry and exit now run on different standards.
- The elimination of supercompensation was at risk of being read as support for daily normalization. It is not, and the document now says so.
- The operating rule stated the single and its size constraint without its function. The size constraint is not the reason. Error attribution is, and it is now stated.
- The top exposure was previously described as "below peak," which reads as a maximum voluntarily held back. On the strength side there is no maximal tier to hold back from: control failure defines the maximum, so a controlled single cannot be one.
- Percentage-of-max is rejected as the control variable. The denominator requires a maximal test, which is itself an edge exposure, and a stale denominator errs unsafe precisely when capability has fallen. The control variable is absolute observed demand; percentage is descriptive after measurement.
- The fortnightly interruption was at risk of being read as a verification that margin exists. Nothing is read during it. It is a blind rate governor, and its value is entirely in the interruption.
- "No dip and no rebound" overclaimed. The model rejects the rebound curve as the organizing object, not the existence of transient disturbance.
- "If an exposure only fits every third day it is too large" applied a base rule to the whole architecture, contradicting the later statement that maximal sprinting is permanently edge. Now scoped to base.
- "Admissible tomorrow on every ledger it touches" asserted knowledge of silent ledgers in the same document that denies having it. Replaced with the observable-channels formulation.
- "The largest dose that still yields a clean signal" pointed the optimization at the contamination boundary. The derived rule is the minimum exposure sufficient for attributable error.
- "Whether those catches were predictive" contradicted the counterfactual admission two lines below it. The longitudinal loop calibrates from misses and subsequent trajectory; it cannot score saves.
- The hamstring cost was logged as "not answered here," which read as though the architecture had no response. It has a policy response and no answer. Both are now stated, separately.
- Conservatism was treated throughout as a direction without a cost. Every governor in the document bounded exposure from above only — which is adequate for tissues whose observables object to underloading, and unbounded below for the ones that do not. The floor is the missing half, and the ceiling-only slow-tissue account under *Multiple tissues* now says so.
- The refusal to credit bone adaptation from impact was carried as though it were a statement about physiology. It is a statement about admissibility. Impact does credit bone; the framework declines to spend against a balance it cannot read. Separating the two is what made the under-dose failure mode visible.
- A period under veto was implicitly treated as physiologically neutral. It is not. It is a floor violation with a higher-priority cause, and it accrues.
- The blocking dependency was stated as a single item — specify the commanded input — which put the ordering wrong. Enumerating the governed tissue set is prior to assigning floors and ceilings, and both are prior to specifying inputs. The earlier statement was not incomplete by accident: with ceilings only, coverage never had to be enumerated, because an unrepresented tissue and a fully compliant one look identical from above.
- "Ceiling necessity is universal — anything can be overloaded" quantified without a domain. Now scoped to the governed set. This is the same failure as the previously logged "denser is always better," recurring in a new place.
- Floor necessity was derived from observability alone, which would generate a floor for anything unobservable regardless of whether underexposure costs anything. Two conditions are required: a consequence worth preventing, and a channel too weak or slow to prevent it. Same shape as the ceiling error — a rule built from one dimension and left unrestricted — and both appeared in adjacent sentences of the same paragraph.
